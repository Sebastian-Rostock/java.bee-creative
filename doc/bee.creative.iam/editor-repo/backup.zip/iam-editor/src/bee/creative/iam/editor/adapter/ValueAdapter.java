package bee.creative.iam.editor.adapter;

import bee.creative.util.Getter;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ObservableValueBase;

/** Diese Klasse implementiert ein {@link ObservableValue} als Adapter auf einen {@link Getter Eigenschaft} einer gegebenen {@link #inputProperty Eingabe}.
 *
 * @param <GInput> Typ der Eingabe.
 * @param <GValue> Typ des Werts. */
@SuppressWarnings ("javadoc")
public class ValueAdapter<GInput, GValue> extends ObservableValueBase<GValue> implements FieldListener<Object>, InvalidationListener {

	/** Dieses Feld speichert das {@link Property} zur Eingabe dieses Adapters. */
	public final ObjectProperty<GInput> inputProperty = new SimpleObjectProperty<>();

	/** Dieses Feld speichert den {@link Getter} zum {@link #getValue() Lesen des Werts} einer Eigenschaft der {@link #inputProperty Eingabe}. */
	public final Getter<? super GInput, ? extends GValue> valueGetter;

	/** Dieser Konstruktor initialisiert den {@link #valueGetter}. */
	public ValueAdapter(final Getter<? super GInput, ? extends GValue> valueGetter) {
		this.valueGetter = valueGetter;
		this.inputProperty.addListener(this);
	}

	{}

	public void invalidate() {
		this.fireValueChangedEvent();
	}

	/** Diese Methode gibt den aktuellen Wert der {@link #valueGetter Eigenachaft} der {@link #inputProperty Eingabe} zurück. */
	@Override
	public GValue getValue() {
		final GInput input = this.inputProperty.get();
		return this.valueGetter.get(input);
	}

	/** Diese Methode signalisiert die Aktualisierung des {@link #getValue() Werts} dieses {@link ValueAdapter} und kann im Rahmen eines {@link FieldListener}
	 * aufgerufen werden. Der gegebene Parameter wird ignowiert. */
	@Override
	public void fieldChanged(final Object input) {
		this.invalidate();
	}

	/** Diese Methode signalisiert die Aktualisierung des {@link #getValue() Werts} dieses {@link ValueAdapter} und kann im Rahmen eines
	 * {@link InvalidationListener} aufgerufen werden. Der gegebene Parameter wird ignowiert. */
	@Override
	public void invalidated(final Observable observable) {
		this.invalidate();
	}

	/** Diese Methode setzt die {@link #inputProperty Eingabe} und gibt {@code this} zurück. */
	public ValueAdapter<GInput, GValue> useInput(final GInput input) {
		this.inputProperty.set(input);
		return this;
	}

	/** Diese Methode {@link Property#bind(ObservableValue) bindet} die {@link #inputProperty Eingabe} an den gegebenen {@link ObservableValue} und gibt
	 * {@code this} zurück. */
	public ValueAdapter<GInput, GValue> useInput(final ObservableValue<? extends GInput> input) {
		this.inputProperty.bind(input);
		return this;
	}

	/** Diese Methode {@link ObservableField#addListener(InvalidationListener) registriert} diesen {@link ValueAdapter} zur automatischen
	 * {@link #invalidated(Observable) Aktiualisierung} bei {@link ObservableField#set(Object, Object) Änderungen} am gegebenen {@link ObservableField} und gibt
	 * {@code this} zurück. */
	public ValueAdapter<GInput, GValue> useObservable(final ObservableField<?, ?> sender) {
		sender.addListener(this);
		return this;
	}

}