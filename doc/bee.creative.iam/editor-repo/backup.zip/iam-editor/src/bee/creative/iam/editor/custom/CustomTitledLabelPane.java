package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.iam.editor.adapter.PropertyAdapter;
import bee.creative.util.Field;
import javafx.beans.property.Property;
import javafx.scene.control.Label;

/** Diese Klasse implementiert ein {@link CustomTitledPane} mit einem Steuerelement zur Anzeige einer Texteigenschaft der Eingabe.
 *
 * @param <GInput> Typ der Eingabe. */
@SuppressWarnings ("javadoc")
public class CustomTitledLabelPane<GInput> extends CustomTitledPane {

	/** Dieses Feld speichert das Steuerelement zur Texteingabe. */
	public final Label valueEditor;

	/** Dieses Feld speichert den {@link PropertyAdapter}, der den Wert des {@link #valueEditor} über ein gegebenes {@link ObservableField} anbindet. */
	public final PropertyAdapter<GInput, String> valueProperty;

	/** Dieses Feld speichert das {@link Property} zur Eingabe des {@link #valueProperty}. */
	public final Property<GInput> inputProperty;

	public CustomTitledLabelPane(final Field<? super GInput, String> valueField) {
		this.valueEditor = new Label();
		this.valueEditor.setWrapText(true);
		this.valueProperty = new PropertyAdapter<>(valueField);
		this.valueEditor.textProperty().bind(this.valueProperty);
		this.inputProperty = this.valueProperty.inputProperty;
		this.contentPane.getChildren().add(this.valueEditor);
	}

	public CustomTitledLabelPane(final String titleText, final ObservableField<? super GInput, String> valueField) {
		this(titleText, valueField, valueField);
	}

	public CustomTitledLabelPane(final String titleText, final ObservableField<?, ?> observableField, final Field<? super GInput, String> valueField) {
		this(valueField);
		this.titleLabel.setText(titleText);
		this.valueProperty.useObservable(observableField);
	}

}