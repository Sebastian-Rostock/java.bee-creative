package bee.creative.iam.editor.data;

import bee.creative.iam.IAMArray;

/** Diese Klasse implementiert ein Objekt zur Zusammenstellung von Minimum, Maximum und Durchschnitt gegebener Zahlenwerte.
 *
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */
@SuppressWarnings ("javadoc")
public class StatsData {

	/** Dieses Feld speichert das Minimum. */
	public int min = Integer.MAX_VALUE;

	/** Dieses Feld speichert das Maxnimum. */
	public int max = Integer.MIN_VALUE;

	/** Dieses Feld speichert die Summe. */
	public long sum;

	/** Dieses Feld speichert die Anzahl. */
	public int count;
	{}

	/** Diese Methode aktualisiert {@link #min Minimum}, {@link #max Maximum}, {@link #sum Summe} und {@link #count Anzahl} mit dem gegebenen Wert. */
	public void put(final int value) {
		if (value > this.max) {
			this.max = value;
		}
		if (value < this.min) {
			this.min = value;
		}
		this.sum += value;
		this.count++;
	}

	/** Diese Methode degiert jeden Zahhlenwert der gegebenen Zahlenfolge an {@link #put(int)}. */
	public void put(final IAMArray array) {
		for (int i = 0, size = array.length(); i < size; i++) {
			this.put(array.get(i));
		}
	}

	{}

	@Override
	public String toString() {
		if (this.count == 0) return "-";
		return String.format("%d..%d (%.1f)", this.min, this.max, this.sum / (float)this.count);
	}

}
