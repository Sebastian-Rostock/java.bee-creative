package bee.creative.iam.editor.data;

import java.io.OutputStream;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import bee.creative.csv.CSVReader;
import bee.creative.csv.CSVWriter;
import bee.creative.fem.FEMException;
import bee.creative.iam.IAMArray;
import bee.creative.iam.IAMBuilder.IAMMappingBuilder;
import bee.creative.iam.IAMCodec.IAMArrayFormat;
import bee.creative.iam.IAMCodec.IAMFindMode;
import bee.creative.iam.IAMEntry;
import bee.creative.iam.IAMIndex;
import bee.creative.iam.IAMLoader.IAMMappingLoader;
import bee.creative.iam.IAMMapping;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.mmf.MMFArray;
import bee.creative.util.Field;
import bee.creative.util.Fields;
import bee.creative.util.Getter;
import bee.creative.util.IO;
import bee.creative.util.Iterables;
import bee.creative.util.Objects;
import bee.creative.util.Setter;

/** Diese Klasse implementiert das Datenmodell einer Abbildung eines {@link IAMIndex}. */
@XmlType (propOrder = {"entryList"})
@XmlRootElement (name = "iam-mapping")
@XmlAccessorType (XmlAccessType.FIELD)
@SuppressWarnings ("javadoc")
public final class MappingData extends BaseData {

	/** Diese Schnittstelle definiert einen {@link Setter} für eine {@link Object}-Eigenschaft eines {@link MappingData}. */
	public static interface MappingSetter extends Setter<MappingData, Object> {
	}

	{}

	/** Dieses Feld speichert das {@link Field} zu {@link #owner}. */
	public static final Field<MappingData, IndexData> FIELD_Owner = MappingData.nativeField("owner");

	/** Dieses Feld speichert das {@link Field} zur dieses Objekt verwaltenden Liste im {@link #owner}. */
	public static final Field<MappingData, List<MappingData>> FIELD_OwnerList = Fields.navigatedField(MappingData.FIELD_Owner, IndexData.FIELD_MappingList);

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #index}. */
	public static final ObservableField<MappingData, Integer> FIELD_Index = BaseData.indexField(MappingData.FIELD_OwnerList);

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #entryList}. */
	public static final ObservableField<MappingData, List<EntryData>> FIELD_EntryList =
		new ObservableField<>(Fields.setupField(MappingData.nativeField("entryList"), (i) -> new ArrayList<>()));

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #findmode}. */
	public static final ObservableField<MappingData, IAMFindMode> FIELD_Findmode = MappingData.observableField("findmode");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #errorinfo}. */
	public static final ObservableField<MappingData, String> FIELD_Errorinfo = MappingData.observableField("errorinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #entryfindinfo}. */
	public static final ObservableField<MappingData, String> FIELD_Entryfindinfo = MappingData.observableField("entryfindinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #entrycountinfo}. */
	public static final ObservableField<MappingData, String> FIELD_Entrycountinfo = MappingData.observableField("entrycountinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #keylengthinfo}. */
	public static final ObservableField<MappingData, String> FIELD_Keylengthinfo = MappingData.observableField("keylengthinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #keycontentinfo}. */
	public static final ObservableField<MappingData, String> FIELD_Keycontentinfo = MappingData.observableField("keycontentinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #valuelengthinfo}. */
	public static final ObservableField<MappingData, String> FIELD_Valuelengthinfo = MappingData.observableField("valuelengthinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #valuecontentinfo}. */
	public static final ObservableField<MappingData, String> FIELD_Valuecontentinfo = MappingData.observableField("valuecontentinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #byteslengthinfo}. */
	public static final ObservableField<MappingData, String> FIELD_Byteslengthinfo = MappingData.observableField("byteslengthinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #bytesheaderinfo}. */
	public static final ObservableField<MappingData, String> FIELD_Bytesheaderinfo = MappingData.observableField("bytesheaderinfo");

	public static final String NAME_EntryList = "Einträge";

	public static final String NAME_Findmode = "Suchmodus";

	/** Dieses Feld speichert den {@link Setter} zum Export der Elemente in eine gegebenen {@link CSVWriter#from(Object) CSV-Datei}. */
	public static final MappingSetter SETTER_ExportCSV = (mappingData, object) -> {
		try (CSVWriter writer = CSVWriter.from(object)) {
			writer.writeEntry(EntryData.HEADER_CSV);
			for (final EntryData entryData: Iterables.iterable(mappingData.entryList)) {
				final ArrayData keyData = EntryData.GETTER_Key.get(entryData);
				final ArrayData valueData = EntryData.GETTER_Value.get(entryData);
				writer.writeEntry(ProjectData.toString(entryData.name), ProjectData.toString(keyData.array), ProjectData.toString(keyData.string),
					ProjectData.toString(keyData.format), Boolean.toString(keyData.updateArray), Boolean.toString(keyData.updateString),
					ProjectData.toString(valueData.array), ProjectData.toString(valueData.string), ProjectData.toString(valueData.format),
					Boolean.toString(valueData.updateArray), Boolean.toString(valueData.updateString));
			}
		} catch (

		final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert den {@link Setter} zum Export der Elemente in eine gegebenen {@link IO#outputStreamFrom(Object) IAM-Datei}. */
	public static final MappingSetter SETTER_ExportIAM = (mappingData, object) -> {
		final byte[] bytes = mappingData.toBytes();
		try (OutputStream stream = IO.outputStreamFrom(object)) {
			stream.write(bytes);
		} catch (

		final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert den {@link Setter} zum Import von Elementen aus einer gegebenen {@link CSVReader#from(Object) CSV-Datei}. */
	public static final MappingSetter SETTER_ImportCSV = (mappingData, object) -> {
		try (CSVReader reader = CSVReader.from(object)) {
			String[] array = reader.readEntry();
			if (!Objects.equals(EntryData.HEADER_CSV, array)) throw new FEMException() //
				.push("CSV-Hedaer ungültig: %s erhalten, %s erwartet.", Objects.toString(array), Objects.toString(EntryData.HEADER_CSV));
			final List<EntryData> entryList = new ArrayList<>(MappingData.FIELD_EntryList.get(mappingData));
			for (array = reader.readEntry(); array != null; array = reader.readEntry()) {
				if (array.length != EntryData.HEADER_CSV.length) throw new FEMException()//
					.push("CSV-Eintrag mit ungültiger Länge: %s erhalten und Länge %s erwartet.", Objects.toString(array), EntryData.HEADER_CSV.length);
				final EntryData entryData = new EntryData();
				final ArrayData keyData = new ArrayData();
				final ArrayData valueData = new ArrayData();
				entryData.name = array[0];
				entryData.owner = mappingData;
				entryData.index = entryList.size();
				entryData.key = keyData;
				entryData.value = valueData;
				keyData.array = array[1];
				keyData.string = array[2];
				keyData.format = IAMArrayFormat.from(array[3]);
				keyData.updateArray = Boolean.parseBoolean(array[4]);
				keyData.updateString = Boolean.parseBoolean(array[5]);
				valueData.array = array[6];
				valueData.string = array[7];
				valueData.format = IAMArrayFormat.from(array[8]);
				valueData.updateArray = Boolean.parseBoolean(array[9]);
				valueData.updateString = Boolean.parseBoolean(array[10]);
				entryList.add(entryData);
			}
			MappingData.FIELD_EntryList.set(mappingData, entryList);
		} catch (

		final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert den {@link Setter} zum Import von Elementen aus gegebenen {@link IAMMapping#from(Object) IAM-Daten}. */
	public static final MappingSetter SETTER_ImportIAM = (mappingData, object) -> {
		try {
			final IAMMapping mapping = IAMMapping.from(object);
			final List<EntryData> entryList = new ArrayList<>(MappingData.FIELD_EntryList.get(mappingData));
			for (final IAMEntry entry: mapping) {
				final EntryData entryData = new EntryData();
				final ArrayData keyData = new ArrayData();
				final ArrayData valueData = new ArrayData();
				entryData.owner = mappingData;
				entryData.index = entryList.size();
				entryData.key = keyData;
				entryData.value = valueData;
				keyData.array = keyData.string = IAMArrayFormat.ARRAY.format(entry.key().toArray());
				valueData.array = valueData.string = IAMArrayFormat.ARRAY.format(entry.value().toArray());
				entryList.add(entryData);
			}
			MappingData.FIELD_EntryList.set(mappingData, entryList);
		} catch (

		final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert einen {@link Setter} zum Entfernen von Elementen aus {@link #entryList}. */
	public static final Setter<MappingData, List<EntryData>> SETTER_RemoveEntry = (i, v) -> ProjectData.remove(i, v, MappingData.FIELD_EntryList);

	/** Dieses Feld speichert einen {@link Getter} zur Ermittlung eines neuen Elements in {@link #entryList}. */
	public static final Getter<MappingData, EntryData> GETTER_AppendEntry =
		(i) -> ProjectData.append(i, new EntryData(), EntryData.FIELD_Owner, MappingData.FIELD_EntryList);

	{}

	static final <GValue> Field<MappingData, GValue> nativeField(final String name) {
		return BaseData.nativeField(MappingData.class, name);
	}

	static final <GValue> ObservableField<MappingData, GValue> observableField(final String name) {
		return new ObservableField<>(MappingData.nativeField(name));
	}

	{}

	/** Dieses Feld speichert den Besitzer, der dieses Objekt in einer Liste verwaltet. */
	@XmlTransient
	IndexData owner;

	/** Dieses Feld speichert den Suchmodus. */
	@XmlAttribute
	IAMFindMode findmode = IAMFindMode.AUTO;

	/** Dieses Feld speichert die Datenmodelle der Einträge. */
	@XmlElement (name = "entry")
	List<EntryData> entryList;

	/** Dieses Feld speichert statistische Informationen zu Fehlern bei der Binärkodierung. */
	@XmlTransient
	String errorinfo = "-";

	/** Dieses Feld speichert statistische Informationen zur Suche von Schlüsseln im Binärformat. */
	@XmlTransient
	String entryfindinfo = "-";

	/** Dieses Feld speichert statistische Informationen zur Anzahl der Einträge im Binärformat. */
	@XmlTransient
	String entrycountinfo = "-";

	/** Dieses Feld speichert statistische Informationen zur Länge der Zahlenfolgen der Schlüssel. */
	@XmlTransient
	String keylengthinfo = "-";

	/** Dieses Feld speichert statistische Informationen zum Inhalt der Zahlenfolgen der Schlüssel. */
	@XmlTransient
	String keycontentinfo = "-";

	/** Dieses Feld speichert statistische Informationen zur Länge der Zahlenfolgen der Werte. */
	@XmlTransient
	String valuelengthinfo = "-";

	/** Dieses Feld speichert statistische Informationen zum Inhalt der Zahlenfolgen der Werte. */
	@XmlTransient
	String valuecontentinfo = "-";

	/** Dieses Feld speichert statistische Informationen zur Länge des Binärformats der Abbildung. */
	@XmlTransient
	String byteslengthinfo = "-";

	/** Dieses Feld speichert statistische Informationen zur Kodierung des Binärformats der Abbildung. */
	@XmlTransient
	String bytesheaderinfo = "-";

	{}

	/** Diese Methode gibt die Daten der Abbildung als Bytefolge zurück. */
	public byte[] toBytes() {
		return this.toMapping().toBytes(this.owner.toOrder());
	}

	/** Diese Methode gibt die Daten der Abbildung als {@link IAMMapping} zurück. */
	public IAMMapping toMapping() {
		final IAMMappingBuilder builder = new IAMMappingBuilder();
		for (final EntryData entry: Iterables.iterable(this.entryList)) {
			final int[] key = EntryData.GETTER_Key.get(entry).toArray();
			final int[] value = EntryData.GETTER_Value.get(entry).toArray();
			builder.put(key, value);
		}
		builder.mode(IAMFindMode.from(this.findmode).toMode(builder.entryCount()));
		return builder;
	}

	/** Diese Methode aktualisiert die Felder mit statistischen Informationen. */
	public void updateInfo() {
		final StatsData keylength = new StatsData(), keycontent = new StatsData();
		final StatsData valuelength = new StatsData(), valuecontent = new StatsData();
		String error = "-", entryfind = "-", entrycount = "-", byteheader = "-", bytelength = "-";
		try {
			final byte[] bytes = this.toBytes();
			bytelength = String.format("%,d Byte", bytes.length);
			final ByteOrder order = IAMMappingLoader.HEADER.orderOf(bytes);
			final MMFArray array = new MMFArray(bytes, order).toINT32();
			final IAMMappingLoader mapping = new IAMMappingLoader(array);
			final ArrayList<IAMArray> keys = new ArrayList<>(mapping.entryCount());
			for (final IAMEntry entry: mapping) {
				final IAMArray key = entry.key();
				keys.add(IAMArray.from(key.toArray()));
				keycontent.put(key);
				keylength.put(key.length());
				valuecontent.put(entry.value());
				valuelength.put(entry.valueLength());
			}
			final int header = array.get(0);
			byteheader = String.format("%s.%s.%s.%s.%s", (header >> 8) & 3, (header >> 6) & 3, (header >> 4) & 3, (header >> 2) & 3, (header >> 0) & 3);
			entrycount = String.format("%,d", mapping.entryCount());
			if (!keys.isEmpty()) {
				long testTime, testCount = 1, repeatCount = 1;
				while (true) {
					final int rmax = (int)repeatCount, fmax = (int)testCount;
					final long s = System.nanoTime();
					for (int r = 0; r < rmax; r++) {
						for (int f = 0; f < fmax; f++) {
							final IAMArray key = keys.get(f);
							if (mapping.find(key) < 0) throw new IllegalStateException("Schlüssel nicht gefunden!");
						}
					}
					final long e = System.nanoTime();
					testTime = e - s;
					if (testTime > 100000000) {
						break;
					}
					testCount <<= 1;
					if (testCount > keys.size()) {
						testCount = keys.size();
						repeatCount <<= 1;
					}
				}
				testCount *= repeatCount;
				entryfind = String.format("%,.2f ns (%,d/%,d)", (double)testTime / (double)testCount, testTime, testCount);
			}
		} catch (final Exception cause) {
			error = cause.getMessage();
		}
		MappingData.FIELD_Errorinfo.set(this, error);
		MappingData.FIELD_Entryfindinfo.set(this, entryfind);
		MappingData.FIELD_Entrycountinfo.set(this, entrycount);
		MappingData.FIELD_Keylengthinfo.set(this, keylength.toString());
		MappingData.FIELD_Keycontentinfo.set(this, keycontent.toString());
		MappingData.FIELD_Valuelengthinfo.set(this, valuelength.toString());
		MappingData.FIELD_Valuecontentinfo.set(this, valuecontent.toString());
		MappingData.FIELD_Byteslengthinfo.set(this, bytelength);
		MappingData.FIELD_Bytesheaderinfo.set(this, byteheader);
	}

	{}

	@Override
	public String toString() {
		return Objects.toInvokeString("", this.name);
	}

}