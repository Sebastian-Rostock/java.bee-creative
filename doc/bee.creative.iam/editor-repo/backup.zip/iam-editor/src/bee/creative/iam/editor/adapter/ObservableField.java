package bee.creative.iam.editor.adapter;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import bee.creative.iam.editor.data.ProjectData;
import bee.creative.util.Field;
import bee.creative.util.Objects;
import bee.creative.util.Pointer;
import bee.creative.util.Pointers;

/** Diese Klasse implementiert ein überwachbares {@link Field Datenfeld}.
 *
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]
 * @param <GInput> Typ der Eingabe.
 * @param <GValue> Typ des Werts der Eigenschaft. */
@SuppressWarnings ("javadoc")
public final class ObservableField<GInput, GValue> implements Field<GInput, GValue> {

	/** Dieses Feld speichert das Datenfel, an das in {@link #get(Object)} und {@link #set(Object, Object)} delegiert wird. */
	public final Field<? super GInput, GValue> field;

	/** Dieses Feld ist {@code true}, wenn die Änderungserkennung und Benachrightigung in {@link #set(Object, Object)} aktiv ist. */
	boolean setting;

	/** Dieses Feld speichert alle registrierten {@link FieldListener}. */
	final List<Pointer<FieldListener<? super GInput>>> listeners = new LinkedList<>();

	/** Dieser Konstruktor initialisiert das überwachte Datenfeld.
	 * 
	 * @param field überwachtes Datenfeld. */
	public ObservableField(final Field<? super GInput, GValue> field) {
		this.field = field;
	}

	{}

	/** Diese Methode registriert die gegebene Methode für den Empfang von Änderungsereignissen dieses Datenfelds. */
	public void addListener(final FieldListener<? super GInput> listener) {
		if (listener == null) return;
		this.listeners.add(Pointers.weakPointer(listener));
	}

	/** Diese Methode schließt die gegebene Methode vom Empfang von Änderungsereignissen dieses Datenfelds aus. */
	public void removeListener(final FieldListener<? super GInput> listener) {
		if (listener == null) return;
		this.listeners.remove(Pointers.hardPointer(listener));
	}

	{}

	/** {@inheritDoc} */
	@Override
	public GValue get(final GInput input) {
		return this.field.get(input);
	}

	/** {@inheritDoc} */
	@Override
	public void set(final GInput input, final GValue newValue) {
		try {
			if (this.setting) return;
			this.setting = true;
			final GValue oldValue = this.field.get(input);
			if (Objects.equals(oldValue, newValue)) return;
			this.field.set(input, newValue);
			ProjectData.logChange(this, input, oldValue, newValue);
			for (final Iterator<Pointer<FieldListener<? super GInput>>> iterator = this.listeners.iterator(); iterator.hasNext();) {
				final FieldListener<? super GInput> listener = iterator.next().data();
				if (listener == null) {
					iterator.remove();
				} else {
					listener.fieldChanged(input);
				}
			}
		} finally {
			this.setting = false;
		}
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return this.field.toString();
	}

}