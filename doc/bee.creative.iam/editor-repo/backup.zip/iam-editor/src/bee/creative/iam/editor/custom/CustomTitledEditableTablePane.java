package bee.creative.iam.editor.custom;

import java.util.List;
import bee.creative.iam.editor.EditorMain;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.util.Getter;
import bee.creative.util.Setter;
import javafx.scene.control.TableView.TableViewSelectionModel;

/** Diese Klasse implementiert eine {@link CustomTitledTablePane} mit Schaltflächen zum {@link #onAppendAction() Hinzufügen} neuer sowie
 * {@link #onRemoveAction() Entfernen} gewählter Elemente.
 *
 * @param <GInput> Typ der Eingabe.
 * @param <GItem> Tyo der Elemente in der Tabelle. */
@SuppressWarnings ("javadoc")
public class CustomTitledEditableTablePane<GInput, GItem> extends CustomTitledTablePane<GInput, GItem> {

	/** Dieses Feld speichert den {@link Getter} zur Erzeugung eines neuen Elements. */
	public final Getter<? super GInput, GItem> appendGetter;

	/** Dieses Feld speichert den {@link CustomButton} zum Aufruf von {@link #onAppendAction()}. */
	public final CustomButton appendButton;

	/** Dieses Feld speichert den {@link Setter} zur Entfernen gewählter Elemente. */
	public final Setter<? super GInput, List<GItem>> removeSetter;

	/** Dieses Feld speichert den {@link CustomButton} zum Aufruf von {@link #onRemoveAction()}. */
	public final CustomButton removeButton;

	public CustomTitledEditableTablePane(final Setter<? super GInput, List<GItem>> removeSetter, final Getter<? super GInput, GItem> appendGetter,
		final ObservableField<? super GInput, List<GItem>> itemsField) {
		super(itemsField);
		this.appendGetter = appendGetter;
		this.appendButton = new CustomButton(EditorMain.IMAGE_Action_Append);
		this.appendButton.setOnAction(event -> this.onAppendAction());
		this.removeSetter = removeSetter;
		this.removeButton = new CustomButton(EditorMain.IMAGE_Action_Remove);
		this.removeButton.setOnAction(event -> this.onRemoveAction());
		this.removeButton.disableProperty().bind(this.tableView.getSelectionModel().selectedItemProperty().isNull());
		this.titlePane.getChildren().addAll(this.appendButton, this.removeButton);
	}

	{}

	/** Diese Methode fügt über {@link #appendGetter} ein neues Element zur Eingabe hinzu. */
	public void onAppendAction() {
		final GInput input = this.inputProperty.getValue();
		if (input == null) return;
		final TableViewSelectionModel<GItem> selection = this.tableView.getSelectionModel();
		selection.clearSelection();
		selection.select(this.appendGetter.get(input));
	}

	/** Diese Methode entfernt über {@link #removeSetter} die gewählten Element zur Eingabe. */
	public void onRemoveAction() {
		final GInput input = this.inputProperty.getValue();
		if (input == null) return;
		final TableViewSelectionModel<GItem> selection = this.tableView.getSelectionModel();
		if (selection.isEmpty()) return;
		this.removeSetter.set(input, selection.getSelectedItems());
		selection.clearSelection();
	}

}