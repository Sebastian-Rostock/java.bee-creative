package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.EditorMain;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.VBox;

/** Diese Klasse implementiert ein {@link TitledPane} mit einer {@link VBox} als {@link #setContent(Node) Inhaltsbereich}. */
@SuppressWarnings ("javadoc")
public class CustomTitledCollapsiblePane extends TitledPane {

	/** Dieses Feld speichert die {@link VBox} das Inhaltsbereichs. */
	public final VBox contentPane;

	public CustomTitledCollapsiblePane() {
		this.contentPane = new VBox(EditorMain.LAYOUT_Spacing);
		this.contentPane.setPadding(new Insets(EditorMain.LAYOUT_Spacing));
		this.contentPane.setFillWidth(true);
		this.setExpanded(false);
		this.setCollapsible(true);
		this.setContent(this.contentPane);
	}

}