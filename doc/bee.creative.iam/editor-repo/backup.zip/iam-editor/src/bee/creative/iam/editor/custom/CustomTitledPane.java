package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.EditorMain;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

/** Diese Klasse implementiert eine {@link VBox} mit {@link #titlePane Titelzeile}, {@link #titleLabel Beschriftung} und darunter leicht versetztem
 * {@link #contentPane Inhaltsbereich}. **/
@SuppressWarnings ("javadoc")
public class CustomTitledPane extends VBox {

	/** Dieses Feld speichert die {@link HBox}, die den Titelbereich füllt. */
	public final HBox titlePane;

	/** Dieses Feld speichert das {@link Label}, das als erstes Steuerelement linksbündig im Titel steht. */
	public final Label titleLabel;

	/** Dieses Feld speichert die {@link HBox}, die den Inhaltsbereich füllt. */
	public final VBox contentPane;

	public CustomTitledPane() {
		super(3);
		this.titleLabel = new Label();
		this.titleLabel.setStyle("-fx-font-weight: bold");
		this.titleLabel.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		this.titlePane = new HBox(EditorMain.LAYOUT_Gap, this.titleLabel);
		this.titlePane.setFillHeight(true);
		this.contentPane = new VBox(EditorMain.LAYOUT_Gap);
		this.contentPane.setPadding(new Insets(0, 0, 0, EditorMain.LAYOUT_Spacing));
		this.contentPane.setFillWidth(true);
		this.setFillWidth(true);
		this.getChildren().addAll(this.titlePane, this.contentPane);
		HBox.setHgrow(this.titleLabel, Priority.ALWAYS);
		VBox.setVgrow(this.titlePane, Priority.NEVER);
		VBox.setVgrow(this.contentPane, Priority.ALWAYS);
	}

}