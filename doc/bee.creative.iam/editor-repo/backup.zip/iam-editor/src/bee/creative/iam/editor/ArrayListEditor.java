package bee.creative.iam.editor;

import java.util.List;
import bee.creative.iam.IAMCodec.IAMArrayFormat;
import bee.creative.iam.editor.custom.CustomTitledComboboxPane;
import bee.creative.iam.editor.custom.CustomTitledTextareaPane;
import bee.creative.iam.editor.custom.CustomToggleButton;
import bee.creative.iam.editor.data.ArrayData;
import bee.creative.util.Fields;
import bee.creative.util.Getter;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.layout.VBox;

/** Diese Klasse implementiert einen Editor zur parallelen Bearbeitung der {@link ArrayData} in der iterierbaren Eingabe.
 *
 * @param <GEntry> Typ der Elemente in der Eingabe. */
@SuppressWarnings ("javadoc")
public class ArrayListEditor<GEntry> extends VBox {

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_Array}. */
	public final CustomTitledTextareaPane<List<GEntry>> arrayEditor;

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_String}. */
	public final CustomTitledTextareaPane<List<GEntry>> stringEditor;

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_Format}. */
	public final CustomTitledComboboxPane<List<GEntry>, IAMArrayFormat> formatEditor;

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_UpdateArray}. */
	public final CustomToggleButton<List<GEntry>> updateArrayEditor;

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_UpdateString}. */
	public final CustomToggleButton<List<GEntry>> updateStringEditor;

	/** Dieses Feld speichert das {@link Property} der Eingabe des Editors. */
	public final Property<List<GEntry>> inputProperty;

	public ArrayListEditor(final Getter<? super GEntry, ArrayData> arrayGetter) {
		this.inputProperty = new SimpleObjectProperty<>();
		this.arrayEditor = new CustomTitledTextareaPane<>(ArrayData.NAME_Array, ArrayData.FIELD_Array,
			Fields.aggregatedField(Fields.navigatedField(arrayGetter, ArrayData.FIELD_Array), EditorMain.STRING_Empty, EditorMain.STRING_Mixed));
		this.arrayEditor.inputProperty.bind(this.inputProperty);
		this.updateArrayEditor = new CustomToggleButton<>(EditorMain.IMAGE_Action_Lower, ArrayData.FIELD_UpdateArray,
			Fields.aggregatedField(Fields.navigatedField(arrayGetter, ArrayData.FIELD_UpdateArray)));
		this.updateArrayEditor.inputProperty.bind(this.inputProperty);
		this.updateStringEditor = new CustomToggleButton<>(EditorMain.IMAGE_Action_Raise, ArrayData.FIELD_UpdateString,
			Fields.aggregatedField(Fields.navigatedField(arrayGetter, ArrayData.FIELD_UpdateString)));
		this.updateStringEditor.inputProperty.bind(this.inputProperty);
		this.formatEditor = new CustomTitledComboboxPane<>(ArrayData.NAME_Format, ArrayData.FIELD_Format, IAMArrayFormat.values(),
			Fields.aggregatedField(Fields.navigatedField(arrayGetter, ArrayData.FIELD_Format)));
		this.formatEditor.inputProperty.bind(this.inputProperty);
		this.formatEditor.titlePane.getChildren().addAll(this.updateArrayEditor, this.updateStringEditor);
		this.stringEditor = new CustomTitledTextareaPane<>(ArrayData.NAME_String, ArrayData.FIELD_String,
			Fields.aggregatedField(Fields.navigatedField(arrayGetter, ArrayData.FIELD_String), EditorMain.STRING_Empty, EditorMain.STRING_Mixed));
		this.stringEditor.inputProperty.bind(this.inputProperty);
		this.setSpacing(EditorMain.LAYOUT_Spacing);
		this.getChildren().addAll(this.arrayEditor, this.formatEditor, this.stringEditor);
	}

	public ArrayListEditor(final String arrayText, final String formatText, final String stringText, final Getter<? super GEntry, ArrayData> arrayGetter) {
		this(arrayGetter);
		this.arrayEditor.titleLabel.setText(arrayText);
		this.formatEditor.titleLabel.setText(formatText);
		this.stringEditor.titleLabel.setText(stringText);
	}

}