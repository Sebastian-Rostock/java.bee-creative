package bee.creative.iam.editor;

import java.util.List;
import bee.creative.iam.IAMCodec.IAMByteOrder;
import bee.creative.iam.IAMCodec.IAMFindMode;
import bee.creative.iam.IAMIndex;
import bee.creative.iam.editor.ListingEditorTab.InfosPane;
import bee.creative.iam.editor.ListingEditorTab.SelectionPane;
import bee.creative.iam.editor.custom.CustomButton;
import bee.creative.iam.editor.custom.CustomGridPane;
import bee.creative.iam.editor.custom.CustomIntegerColumn;
import bee.creative.iam.editor.custom.CustomStringColumn;
import bee.creative.iam.editor.custom.CustomTab;
import bee.creative.iam.editor.custom.CustomTitledCollapsiblePane;
import bee.creative.iam.editor.custom.CustomTitledComboboxPane;
import bee.creative.iam.editor.custom.CustomTitledOrderableTablePane;
import bee.creative.iam.editor.custom.CustomTitledTextfieldPane;
import bee.creative.iam.editor.custom.CustomToolFilePane;
import bee.creative.iam.editor.custom.CustomValueColumn;
import bee.creative.iam.editor.data.BaseData;
import bee.creative.iam.editor.data.IndexData;
import bee.creative.iam.editor.data.IndexData.IndexSetter;
import bee.creative.iam.editor.data.ListingData;
import bee.creative.iam.editor.data.MappingData;
import bee.creative.util.Fields;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser.ExtensionFilter;

/** Diese Klasse implementiert den {@link CustomTab} zur Bearbeitung eines {@link IndexData}. */
@SuppressWarnings ("javadoc")
public final class IndexEditorTab extends CustomTab<IndexData> {

	/** Diese Klasse implementiert die Werkzeugleiste des {@link MappingEditorTab}. */
	public final class ToolPane extends CustomToolFilePane {

		public ToolPane() {
			super(EditorMain.IMAGE_Editor_Project, "Verzeichnis in Tabelle bearbeiten...");
			this.exportButton.setOnAction(event -> IndexEditorTab.this.onExportAction());
			this.importButton.setOnAction(event -> IndexEditorTab.this.onImportAction());
		}

	}

	/** Diese Klasse implementiert den Editor für die direkten Eigenschaften des {@link MappingData}. */
	public final class ParentPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link IndexData#FIELD_Name}. */
		public final CustomTitledTextfieldPane<IndexData> nameEditor;

		/** Dieses Feld speichert den Editor für {@link IndexData#FIELD_Byteorder}. */
		public final CustomTitledComboboxPane<IndexData, IAMByteOrder> byteorderEditor;

		public ParentPane() {
			final ObjectProperty<IndexData> inputProperty = IndexEditorTab.this.inputProperty;
			this.nameEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Name, BaseData.FIELD_Name, BaseData.FIELD_Name);
			this.nameEditor.inputProperty.bind(inputProperty);
			this.byteorderEditor = new CustomTitledComboboxPane<>(IndexData.NAME_Byteorder, IndexData.FIELD_Byteorder, IAMByteOrder.values(), //
				IndexData.FIELD_Byteorder);
			this.byteorderEditor.inputProperty.bind(inputProperty);
			this.contentPane.getChildren().addAll(this.nameEditor, this.byteorderEditor);
			this.setText("Attribute des Verzeichnisses");
			this.expandedProperty().bindBidirectional(MappingEditorTab.ParentExpanded);
		}

	}

	/** Diese Klasse implementiert den Editor für die Eigenschaften der untergeordneten {@link ListingData} und {@link MappingData}. */
	public final class ChildrenPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert die {@link CustomGridPane}, mit der die Editoren für Auflistungen und Abbildungen nebeneinander Positioniert werden. */
		public final CustomGridPane contentPane2;

		/** Dieses Feld speichert die linke Spalte der {@link #contentPane2}. */
		public final ChildrenPane1 childrenPane1;

		/** Dieses Feld speichert die rechte Spalte der {@link #contentPane2}. */
		public final ChildrenPane2 childrenPane2;

		public ChildrenPane() {
			this.childrenPane1 = new ChildrenPane1();
			this.childrenPane2 = new ChildrenPane2();
			this.contentPane2 = new CustomGridPane();
			this.contentPane2.add(this.childrenPane1, 0, 0);
			this.contentPane2.add(this.childrenPane2, 1, 0);
			this.contentPane.getChildren().add(this.contentPane2);
			this.setText("Auflistungen und Abbildungen des Verzeichnisses");
			this.expandedProperty().bindBidirectional(IndexEditorTab.ChildrenExpanded);
		}

	}

	/** Diese Klasse implementiert den Editor für die Eigenschaften der untergeordneten {@link ListingData}. */
	public final class ChildrenPane1 extends VBox {

		/** Dieses Feld speichert den Editor für {@link IndexData#FIELD_ListingList}. */
		public final CustomTitledOrderableTablePane<IndexData, ListingData> listingsEditor;

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_Index}. */
		public final CustomIntegerColumn<ListingData> listingsIndexEditor;

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_Name}. */
		public final CustomStringColumn<ListingData> listingsNameEditor;

		/** Dieses Feld speichert den {@link CustomButton} zur Auswahl in {@link #listingsEditor}. */
		public final CustomButton listingsChildButton;

		/** Dieses Feld speichert den {@link SelectionPane1} zur Auswahl in {@link #listingsEditor}. */
		public final SelectionPane1 selectionPane;

		@SuppressWarnings ("unchecked")
		public ChildrenPane1() {
			this.listingsIndexEditor = new CustomIntegerColumn<>(ListingData.FIELD_Index);
			this.listingsIndexEditor.setText(BaseData.NAME_Index);
			this.listingsNameEditor = new CustomStringColumn<>(BaseData.FIELD_Name);
			this.listingsNameEditor.setText(BaseData.NAME_Name);
			this.listingsEditor = new CustomTitledOrderableTablePane<>(IndexData.SETTER_removeListing, IndexData.GETTER_appendListing, IndexData.FIELD_ListingList);
			this.listingsEditor.titleLabel.setText(IndexData.NAME_ListingList);
			this.listingsEditor.inputProperty.bind(IndexEditorTab.this.inputProperty);
			this.listingsEditor.tableView.getColumns().addAll(this.listingsIndexEditor, this.listingsNameEditor);
			VBox.setVgrow(this.listingsEditor, Priority.ALWAYS);
			this.listingsChildButton = new CustomButton(EditorMain.IMAGE_Editor_Listing, "Gewählte Auflistungen einzeln bearbeiten...");
			this.listingsChildButton.disableProperty().bind(this.listingsEditor.removeButton.disableProperty());
			this.selectionPane = new SelectionPane1();
			this.selectionPane.contentPane.disableProperty().bind(this.listingsEditor.removeButton.disableProperty());
			this.selectionPane.inputProperty.bind(this.listingsEditor.selectionAdapter);
			this.getChildren().addAll(this.listingsEditor, this.listingsChildButton, this.selectionPane);
			this.setSpacing(EditorMain.LAYOUT_Spacing);
			GridPane.setHgrow(this, Priority.ALWAYS);
			GridPane.setVgrow(this, Priority.ALWAYS);
		}

	}

	/** Diese Klasse implementiert den Editor für die Eigenschaften der untergeordneten {@link MappingData}. */
	public final class ChildrenPane2 extends VBox {

		/** Dieses Feld speichert den Editor für {@link IndexData#FIELD_MappingList}. */
		public final CustomTitledOrderableTablePane<IndexData, MappingData> mappingsEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Index}. */
		public final CustomIntegerColumn<MappingData> mappingsIndexEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Name}. */
		public final CustomStringColumn<MappingData> mappingsNameEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Findmode}. */
		public final CustomValueColumn<MappingData, IAMFindMode> mappingsFindmodeEditor;

		/** Dieses Feld speichert den {@link CustomButton} zur Auswahl in {@link #mappingsEditor}. */
		public final CustomButton mappingsChildButton;

		/** Dieses Feld speichert den {@link SelectionPane2} zur Auswahl in {@link #mappingsEditor}. */
		public final SelectionPane2 mappingsListEditor;

		@SuppressWarnings ("unchecked")
		public ChildrenPane2() {
			this.mappingsIndexEditor = new CustomIntegerColumn<>(MappingData.FIELD_Index);
			this.mappingsIndexEditor.setText(BaseData.NAME_Index);
			this.mappingsNameEditor = new CustomStringColumn<>(BaseData.FIELD_Name);
			this.mappingsNameEditor.setText(BaseData.NAME_Name);
			this.mappingsFindmodeEditor = new CustomValueColumn<>(MappingData.FIELD_Findmode, IAMFindMode.values());
			this.mappingsFindmodeEditor.setText(MappingData.NAME_Findmode);
			this.mappingsEditor = new CustomTitledOrderableTablePane<>(IndexData.SETTER_removeMapping, IndexData.GETTER_appendMapping, IndexData.FIELD_MappingList);
			this.mappingsEditor.titleLabel.setText(IndexData.NAME_MappingList);
			this.mappingsEditor.inputProperty.bind(IndexEditorTab.this.inputProperty);
			this.mappingsEditor.tableView.getColumns().addAll(this.mappingsIndexEditor, this.mappingsNameEditor, this.mappingsFindmodeEditor);
			VBox.setVgrow(this.mappingsEditor, Priority.ALWAYS);
			this.mappingsChildButton = new CustomButton(EditorMain.IMAGE_Editor_Mapping, "Gewählte Abbildungen einzeln bearbeiten...");
			this.mappingsChildButton.disableProperty().bind(this.mappingsEditor.removeButton.disableProperty());
			this.mappingsListEditor = new SelectionPane2();
			this.mappingsListEditor.contentPane.disableProperty().bind(this.mappingsEditor.removeButton.disableProperty());
			this.mappingsListEditor.inputProperty.bind(this.mappingsEditor.selectionAdapter);
			this.getChildren().addAll(this.mappingsEditor, this.mappingsChildButton, this.mappingsListEditor);
			this.setSpacing(EditorMain.LAYOUT_Spacing);
			GridPane.setHgrow(this, Priority.ALWAYS);
			GridPane.setVgrow(this, Priority.ALWAYS);
		}

	}

	/** Diese Klasse implementiert einen Editor zur parallelen Bearbeitung der {@link ListingData} in der iterierbaren Eingabe. */
	public final class SelectionPane1 extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_Name}. */
		public final CustomTitledTextfieldPane<List<ListingData>> nameEditor;

		/** Dieses Feld speichert das {@link Property} der Eingabe des Editors. */
		public final Property<List<ListingData>> inputProperty;

		public SelectionPane1() {
			this.nameEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Name, BaseData.FIELD_Name, //
				Fields.aggregatedField(BaseData.FIELD_Name, EditorMain.STRING_Empty, EditorMain.STRING_Mixed));
			this.inputProperty = this.nameEditor.inputProperty;
			this.contentPane.getChildren().addAll(this.nameEditor);
			this.expandedProperty().bindBidirectional(IndexEditorTab.SelectionExpanded);
		}

	}

	/** Diese Klasse implementiert einen Editor zur parallelen Bearbeitung der {@link MappingData} in der iterierbaren Eingabe. */
	public final class SelectionPane2 extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Name}. */
		public final CustomTitledTextfieldPane<List<MappingData>> mappingNameEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Findmode}. */
		public final CustomTitledComboboxPane<List<MappingData>, IAMFindMode> mappingFindmodeEditor;

		/** Dieses Feld speichert das {@link Property} der Eingabe des Editors. */
		public final Property<List<MappingData>> inputProperty;

		public SelectionPane2() {
			this.mappingNameEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Name, BaseData.FIELD_Name, //
				Fields.aggregatedField(BaseData.FIELD_Name, EditorMain.STRING_Empty, EditorMain.STRING_Mixed));
			this.inputProperty = this.mappingNameEditor.inputProperty;
			this.mappingFindmodeEditor = new CustomTitledComboboxPane<>(MappingData.NAME_Findmode, BaseData.FIELD_Name, IAMFindMode.values(), //
				Fields.aggregatedField(MappingData.FIELD_Findmode));
			this.mappingFindmodeEditor.inputProperty.bind(this.inputProperty);
			this.contentPane.getChildren().addAll(this.mappingNameEditor, this.mappingFindmodeEditor);
			this.expandedProperty().bindBidirectional(IndexEditorTab.SelectionExpanded);
		}

	}

	{}

	/** Dieses Feld synchronisiert {@link InfosPane#expandedProperty()}. */
	public static final BooleanProperty InfosExpanded = new SimpleBooleanProperty(false);

	/** Dieses Feld synchronisiert {@link ParentPane#expandedProperty()}. */
	public static final BooleanProperty ParentExpanded = new SimpleBooleanProperty(true);

	/** Dieses Feld synchronisiert {@link ChildrenPane#expandedProperty()}. */
	public static final BooleanProperty ChildrenExpanded = new SimpleBooleanProperty(true);

	/** Dieses Feld synchronisiert {@link SelectionPane#expandedProperty()}. */
	public static final BooleanProperty SelectionExpanded = new SimpleBooleanProperty(false);

	static final ExtensionFilter[] fileFilters =
		{new ExtensionFilter("Index-IAM-Datei", "*.iam"), new ExtensionFilter("Index-INI-Datei", "*.ini"), new ExtensionFilter("Index-XML-Datei", "*.xml")};

	static final IndexSetter[] exportSetters = {IndexData.SETTER_ExportIAM, IndexData.SETTER_ExportINI, IndexData.SETTER_ExportXML};

	static final IndexSetter[] importSetters = {IndexData.SETTER_ImportIAM, IndexData.SETTER_ImportINI, IndexData.SETTER_ImportXML};

	{}

	/** Dieses Feld speichert die {@link ToolPane}. */
	public final ToolPane toolPane;

	/** Dieses Feld speichert die {@link ParentPane}. */
	public final ParentPane parentPane;

	/** Dieses Feld speichert die {@link ChildrenPane}. */
	public final ChildrenPane childrenPane;

	public IndexEditorTab() {
		this.toolPane = new ToolPane();
		this.parentPane = new ParentPane();
		this.childrenPane = new ChildrenPane();
		this.contentPane.getChildren().addAll(this.toolPane, this.parentPane, this.childrenPane);
		this.setGraphic(new ImageView(EditorMain.IMAGE_Editor_Index));
		this.textProperty().bind(this.parentPane.nameEditor.valueEditor.textProperty());
	}

	{}

	/** Diese Methode exportiert die Abbildungen und Auflistungen des bearbeiteten {@link IndexData} in eine IAM-Datei. */
	public void onExportAction() {
		EditorMain.showFileDialog(false, this.getTabPane(), this.inputProperty.get(), //
			"Verzeichnis exportieren...", IndexEditorTab.fileFilters, IndexEditorTab.exportSetters);
	}

	/** Diese Methode importiert die Abbildungen und Auflistungen eines {@link IAMIndex} aus einer IAM-Datei und fügt sie dem bearbeiteten {@link IndexData}
	 * an. */
	public void onImportAction() {
		EditorMain.showFileDialog(true, this.getTabPane(), this.inputProperty.get(), //
			"Verzeichnis importieren...", IndexEditorTab.fileFilters, IndexEditorTab.importSetters);
	}

}