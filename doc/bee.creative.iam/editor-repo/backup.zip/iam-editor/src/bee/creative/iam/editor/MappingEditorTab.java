package bee.creative.iam.editor;

import java.util.List;
import bee.creative.iam.IAMCodec.IAMFindMode;
import bee.creative.iam.IAMMapping;
import bee.creative.iam.editor.custom.CustomButton;
import bee.creative.iam.editor.custom.CustomGridPane;
import bee.creative.iam.editor.custom.CustomIntegerColumn;
import bee.creative.iam.editor.custom.CustomStringColumn;
import bee.creative.iam.editor.custom.CustomTab;
import bee.creative.iam.editor.custom.CustomTitledCollapsiblePane;
import bee.creative.iam.editor.custom.CustomTitledComboboxPane;
import bee.creative.iam.editor.custom.CustomTitledLabelPane;
import bee.creative.iam.editor.custom.CustomTitledOrderableTablePane;
import bee.creative.iam.editor.custom.CustomTitledTextfieldPane;
import bee.creative.iam.editor.custom.CustomToolFilePane;
import bee.creative.iam.editor.data.BaseData;
import bee.creative.iam.editor.data.EntryData;
import bee.creative.iam.editor.data.MappingData;
import bee.creative.iam.editor.data.MappingData.MappingSetter;
import bee.creative.util.Fields;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser.ExtensionFilter;

/** Diese Klasse implementiert den {@link CustomTab} zur Bearbeitung eines {@link MappingData}. */
@SuppressWarnings ("javadoc")
public final class MappingEditorTab extends CustomTab<MappingData> {

	/** Diese Klasse implementiert die Werkzeugleiste des {@link MappingEditorTab}. */
	public final class ToolPane extends CustomToolFilePane {

		public ToolPane() {
			super(EditorMain.IMAGE_Editor_Index, "Abbildung in Tabelle bearbeiten...");
			this.exportButton.setOnAction(event -> MappingEditorTab.this.onExportAction());
			this.importButton.setOnAction(event -> MappingEditorTab.this.onImportAction());
		}

	}

	/** Diese Klasse implementiert einen Editor zur aktualisierung statistischer Informationen der gegebenen {@link MappingData}. */
	public final class InfosPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Errorinfo}. */
		public final CustomTitledLabelPane<MappingData> errorinfoEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Entryfindinfo}. */
		public final CustomTitledLabelPane<MappingData> entryfindinfoEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Entrycountinfo}. */
		public final CustomTitledLabelPane<MappingData> entrycountinfoEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Keylengthinfo}. */
		public final CustomTitledLabelPane<MappingData> keylengthinfoEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Keycontentinfo}. */
		public final CustomTitledLabelPane<MappingData> keycontentinfoEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Valuelengthinfo}. */
		public final CustomTitledLabelPane<MappingData> valuelengthinfoEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Valuecontentinfo}. */
		public final CustomTitledLabelPane<MappingData> valuecontentinfoEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Byteslengthinfo}. */
		public final CustomTitledLabelPane<MappingData> byteslengthinfoEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Bytesheaderinfo}. */
		public final CustomTitledLabelPane<MappingData> bytesheaderinfoEditor;

		/** Dieses Feld speichert {@link CustomButton} zu {@link #onUpdateAction()}. */
		public final CustomButton updateinfoButton;

		/** Dieses Feld speichert die {@link CustomGridPane} zur Positionierung der Steuerelemente. */
		public final CustomGridPane contentPane2;

		public InfosPane() {
			final ObjectProperty<MappingData> inputProperty = MappingEditorTab.this.inputProperty;
			this.entrycountinfoEditor = new CustomTitledLabelPane<>("Anzahl der Einträge", MappingData.FIELD_Entrycountinfo);
			this.entrycountinfoEditor.inputProperty.bind(inputProperty);
			this.entryfindinfoEditor = new CustomTitledLabelPane<>("Suchzeit eines Schlüssels", MappingData.FIELD_Entryfindinfo);
			this.entryfindinfoEditor.inputProperty.bind(inputProperty);
			this.keycontentinfoEditor = new CustomTitledLabelPane<>("Zahlen der Schlüssel", MappingData.FIELD_Keycontentinfo);
			this.keycontentinfoEditor.inputProperty.bind(inputProperty);
			this.keylengthinfoEditor = new CustomTitledLabelPane<>("Längen der Schlüssel", MappingData.FIELD_Keylengthinfo);
			this.keylengthinfoEditor.inputProperty.bind(inputProperty);
			this.valuecontentinfoEditor = new CustomTitledLabelPane<>("Zahlen der Werte", MappingData.FIELD_Valuecontentinfo);
			this.valuecontentinfoEditor.inputProperty.bind(inputProperty);
			this.valuelengthinfoEditor = new CustomTitledLabelPane<>("Längen der Werte", MappingData.FIELD_Valuelengthinfo);
			this.valuelengthinfoEditor.inputProperty.bind(inputProperty);
			this.byteslengthinfoEditor = new CustomTitledLabelPane<>("Größe der Binärkodierung", MappingData.FIELD_Byteslengthinfo);
			this.byteslengthinfoEditor.inputProperty.bind(inputProperty);
			this.bytesheaderinfoEditor = new CustomTitledLabelPane<>("Variante der Binärkodierung", MappingData.FIELD_Bytesheaderinfo);
			this.bytesheaderinfoEditor.inputProperty.bind(inputProperty);
			this.errorinfoEditor = new CustomTitledLabelPane<>("Fehler bei Binärkodierung", MappingData.FIELD_Errorinfo);
			this.errorinfoEditor.inputProperty.bind(inputProperty);
			this.updateinfoButton = new CustomButton(EditorMain.IMAGE_Action_Update, "Aktualisieren");
			this.updateinfoButton.setOnAction((event) -> this.onUpdateAction());
			this.contentPane2 = new CustomGridPane();
			this.contentPane2.add(this.entrycountinfoEditor, 0, 0);
			this.contentPane2.add(this.entryfindinfoEditor, 1, 0);
			this.contentPane2.add(this.keycontentinfoEditor, 0, 1);
			this.contentPane2.add(this.keylengthinfoEditor, 1, 1);
			this.contentPane2.add(this.valuecontentinfoEditor, 0, 2);
			this.contentPane2.add(this.valuelengthinfoEditor, 1, 2);
			this.contentPane2.add(this.byteslengthinfoEditor, 0, 3);
			this.contentPane2.add(this.bytesheaderinfoEditor, 1, 3);
			this.contentPane2.add(this.errorinfoEditor, 0, 4);
			this.contentPane2.add(this.updateinfoButton, 1, 4);
			this.contentPane.getChildren().add(this.contentPane2);
			this.setText("Statistik zur Abbildung");
			this.expandedProperty().bindBidirectional(MappingEditorTab.InfosExpanded);
		}

		{}

		/** Diese Methode aktualisiert die statistischen Informationen via {@link MappingData#updateInfo()}. */
		public void onUpdateAction() {
			MappingEditorTab.this.inputProperty.getValue().updateInfo();
		}

	}

	/** Diese Klasse implementiert den Editor für die direkten Eigenschaften des {@link MappingData}. */
	public final class ParentPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Index}. */
		public final CustomTitledTextfieldPane<MappingData> indexEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Name}. */
		public final CustomTitledTextfieldPane<MappingData> nameEditor;

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_Findmode}. */
		public final CustomTitledComboboxPane<MappingData, IAMFindMode> findmodeEditor;

		public ParentPane() {
			final ObjectProperty<MappingData> inputProperty = MappingEditorTab.this.inputProperty;
			this.indexEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Index, MappingData.FIELD_Index,
				Fields.translatedField(MappingData.FIELD_Index, EditorMain.GETTER_IntegerFormatter, EditorMain.GETTER_IntegerParser));
			this.indexEditor.inputProperty.bind(inputProperty);
			this.nameEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Name, BaseData.FIELD_Name, BaseData.FIELD_Name);
			this.nameEditor.inputProperty.bind(inputProperty);
			this.findmodeEditor =
				new CustomTitledComboboxPane<>(MappingData.NAME_Findmode, MappingData.FIELD_Findmode, IAMFindMode.values(), MappingData.FIELD_Findmode);
			this.findmodeEditor.inputProperty.bind(inputProperty);
			this.contentPane.getChildren().addAll(this.indexEditor, this.nameEditor, this.findmodeEditor);
			this.setText("Attribute der Abbildung");
			this.expandedProperty().bindBidirectional(MappingEditorTab.ParentExpanded);
		}

	}

	/** Diese Klasse implementiert den Editor für die Eigenschaften der untergeordneten {@link EntryData}. */
	public final class ChildrenPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link MappingData#FIELD_EntryList}. */
		public final CustomTitledOrderableTablePane<MappingData, EntryData> entriesEditor;

		/** Dieses Feld speichert den Editor für {@link EntryData#FIELD_Index}. */
		public final CustomIntegerColumn<EntryData> entriesIndexEditor;

		/** Dieses Feld speichert den Editor für {@link EntryData#FIELD_Name}. */
		public final CustomStringColumn<EntryData> entriesNameEditor;

		/** Dieses Feld speichert den Editor für {@link EntryData#GETTER_Key}. */
		public final ArrayColumnEditor<EntryData> entriesKeyEditor;

		/** Dieses Feld speichert den Editor für {@link EntryData#GETTER_Value}. */
		public final ArrayColumnEditor<EntryData> entriesValueEditor;

		/** Dieses Feld speichert den {@link CustomButton} zur Auswahl in {@link #entriesEditor}. */
		public final CustomButton entriesItemButton;

		/** Dieses Feld speichert den {@link SelectionPane} zur Auswahl in {@link #entriesEditor}. */
		public final SelectionPane selectionPane;

		@SuppressWarnings ("unchecked")
		public ChildrenPane() {
			this.entriesIndexEditor = new CustomIntegerColumn<>(EntryData.FIELD_Index);
			this.entriesIndexEditor.setText(BaseData.NAME_Index);
			this.entriesNameEditor = new CustomStringColumn<>(BaseData.FIELD_Name);
			this.entriesNameEditor.setText(BaseData.NAME_Name);
			this.entriesKeyEditor = new ArrayColumnEditor<>(EntryData.GETTER_Key);
			this.entriesKeyEditor.setText(EntryData.NAME_Key);
			this.entriesValueEditor = new ArrayColumnEditor<>(EntryData.GETTER_Value);
			this.entriesValueEditor.setText(EntryData.NAME_Value);
			this.entriesEditor = new CustomTitledOrderableTablePane<>(MappingData.SETTER_RemoveEntry, MappingData.GETTER_AppendEntry, MappingData.FIELD_EntryList);
			this.entriesEditor.titleLabel.setText(MappingData.NAME_EntryList);
			this.entriesEditor.inputProperty.bind(MappingEditorTab.this.inputProperty);
			this.entriesEditor.tableView.getColumns().addAll(this.entriesIndexEditor, this.entriesNameEditor, this.entriesKeyEditor, this.entriesValueEditor);
			VBox.setVgrow(this.entriesEditor, Priority.ALWAYS);
			this.entriesItemButton = new CustomButton(EditorMain.IMAGE_Editor_Entry, "Gewählte Einträge einzeln bearbeiten...");
			this.entriesItemButton.disableProperty().bind(this.entriesEditor.removeButton.disableProperty());
			this.selectionPane = new SelectionPane();
			this.selectionPane.contentPane.disableProperty().bind(this.entriesEditor.removeButton.disableProperty());
			this.selectionPane.inputProperty.bind(this.entriesEditor.selectionAdapter);
			this.contentPane.getChildren().addAll(this.entriesEditor, this.entriesItemButton, this.selectionPane);
			this.setText("Einträge der Abbildung");
			this.expandedProperty().bindBidirectional(MappingEditorTab.ChildrenExpanded);
		}

	}

	/** Diese Klasse implementiert einen Editor zur parallelen Bearbeitung von {@link EntryData} an den Elementen der iterierbaren Eingabe. */
	public final class SelectionPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link EntryData#FIELD_Name}. */
		public final CustomTitledTextfieldPane<List<EntryData>> nameEditor;

		/** Dieses Feld speichert den Editor für {@link EntryData#GETTER_Key}. */
		public final ArrayListEditor<EntryData> keyEditor;

		/** Dieses Feld speichert den Editor für {@link EntryData#GETTER_Value}. */
		public final ArrayListEditor<EntryData> valueEditor;

		/** Dieses Feld speichert das {@link Property} der Eingabe des Editors. */
		public final Property<List<EntryData>> inputProperty;

		public SelectionPane() {
			this.keyEditor = new ArrayListEditor<>(EntryData.NAME_KeyArray, EntryData.NAME_KeyFormat, EntryData.NAME_KeyString, //
				EntryData.GETTER_Key);
			this.inputProperty = this.keyEditor.inputProperty;
			this.nameEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Name, BaseData.FIELD_Name, //
				Fields.aggregatedField(BaseData.FIELD_Name, EditorMain.STRING_Empty, EditorMain.STRING_Mixed));
			this.nameEditor.inputProperty.bind(this.inputProperty);
			this.valueEditor = new ArrayListEditor<>(EntryData.NAME_ValueArray, EntryData.NAME_ValueFormat, EntryData.NAME_ValueString, //
				EntryData.GETTER_Value);
			this.valueEditor.inputProperty.bind(this.inputProperty);
			this.contentPane.getChildren().addAll(this.nameEditor, this.keyEditor, this.valueEditor);
			this.setText("Gewählte Einträge parallel bearbeiten");
			this.expandedProperty().bindBidirectional(MappingEditorTab.SelectionExpanded);
		}

	}

	{}

	/** Dieses Feld synchronisiert {@link InfosPane#expandedProperty()}. */
	public static final BooleanProperty InfosExpanded = new SimpleBooleanProperty(false);

	/** Dieses Feld synchronisiert {@link ParentPane#expandedProperty()}. */
	public static final BooleanProperty ParentExpanded = new SimpleBooleanProperty(true);

	/** Dieses Feld synchronisiert {@link ChildrenPane#expandedProperty()}. */
	public static final BooleanProperty ChildrenExpanded = new SimpleBooleanProperty(true);

	/** Dieses Feld synchronisiert {@link SelectionPane#expandedProperty()}. */
	public static final BooleanProperty SelectionExpanded = new SimpleBooleanProperty(false);

	static final ExtensionFilter[] fileFilters =
		{new ExtensionFilter("Abbildung-IAM-Datei", "*.mapping.iam"), new ExtensionFilter("Abbildung-CSV-Datei", "*.mapping.csv")};

	static final MappingSetter[] exportSetters = {MappingData.SETTER_ExportIAM, MappingData.SETTER_ExportCSV};

	static final MappingSetter[] importSetters = {MappingData.SETTER_ImportIAM, MappingData.SETTER_ImportCSV};

	{}

	/** Dieses Feld speichert die {@link ToolPane}. */
	public final ToolPane toolPane;

	/** Dieses Feld speichert die {@link InfosPane}. */
	public final InfosPane infosPane;

	/** Dieses Feld speichert die {@link ParentPane}. */
	public final ParentPane parentPane;

	/** Dieses Feld speichert die {@link ChildrenPane}. */
	public final ChildrenPane childrenPane;

	public MappingEditorTab() {
		this.toolPane = new ToolPane();
		this.infosPane = new InfosPane();
		this.parentPane = new ParentPane();
		this.childrenPane = new ChildrenPane();
		this.contentPane.getChildren().addAll(this.toolPane, this.infosPane, this.parentPane, this.childrenPane);
		this.setGraphic(new ImageView(EditorMain.IMAGE_Editor_Mapping));
		this.textProperty().bind(this.parentPane.nameEditor.valueEditor.textProperty());
	}

	{}

	/** Diese Methode exportiert die Einträge des bearbeiteten {@link MappingData} in eine IAM- oder CSV-Datei. */
	public void onExportAction() {
		EditorMain.showFileDialog(false, this.getTabPane(), this.inputProperty.get(), //
			"Einträge der Abbildung exportieren...", MappingEditorTab.fileFilters, MappingEditorTab.exportSetters);
	}

	/** Diese Methode importiert die Einträge eines {@link IAMMapping} aus einer IAM- oder CSV-Datei und fügt sie dem bearbeiteten {@link MappingData} an. */
	public void onImportAction() {
		EditorMain.showFileDialog(true, this.getTabPane(), this.inputProperty.get(), //
			"Einträge einer Abbildung importieren...", MappingEditorTab.fileFilters, MappingEditorTab.importSetters);
	}

}