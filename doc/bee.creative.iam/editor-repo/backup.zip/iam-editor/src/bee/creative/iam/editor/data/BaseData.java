package bee.creative.iam.editor.data;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import bee.creative.iam.editor.adapter.IndexField;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.util.Field;
import bee.creative.util.Fields;
import bee.creative.util.Natives;

@XmlType
@XmlAccessorType (XmlAccessType.FIELD)
@SuppressWarnings ("javadoc")
public abstract class BaseData {

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #name}. */
	public static final ObservableField<BaseData, String> FIELD_Name = new ObservableField<>(BaseData.nativeField(BaseData.class, "name"));

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #index}. */
	public static final Field<BaseData, Integer> FIELD_Index = BaseData.nativeField(BaseData.class, "index");

	public static final String NAME_Name = "Name";

	public static final String NAME_Index = "Index";

	{}

	public static final <GInput extends BaseData> ObservableField<GInput, Integer> indexField(final Field<? super GInput, List<GInput>> ownerListField) {
		return new ObservableField<>(Fields.defaultField(new IndexField<>(BaseData.FIELD_Index, ownerListField)));
	}

	static final <GInput, GValue> Field<GInput, GValue> nativeField(final Class<GInput> clazz, final String name) {
		return Fields.defaultField(Fields.nativeField(Natives.parseField(clazz, name)));
	}

	{}

	/** Dieses Feld speichert den informativen Namen dieses Objekts. */
	@XmlAttribute
	String name = "";

	/** Dieses Feld speichert die Position dieses Objekts in der Liste des Besitzers. */
	@XmlTransient
	int index;

}
