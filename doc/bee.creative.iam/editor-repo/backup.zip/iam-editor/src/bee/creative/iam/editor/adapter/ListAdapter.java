package bee.creative.iam.editor.adapter;

import java.util.Collections;
import java.util.List;
import bee.creative.util.Getter;
import javafx.collections.ObservableList;

/** Diese Klasse erweitert einen {@link ValueAdapter} zur Adaptierung einer {@link ObservableList}.
 * 
 * @see ObservableList#setAll(java.util.Collection)
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]
 * @param <GInput> Typ der Eingabe.
 * @param <GValue> Typ der Elemente in der {@link ObservableList}. */
@SuppressWarnings ("javadoc")
public class ListAdapter<GInput, GValue> extends ValueAdapter<GInput, List<GValue>> {

	/** Dieses Feld speichert die angebundene {@link ObservableList}. */
	public ObservableList<GValue> observableList;

	public ListAdapter(final Getter<? super GInput, ? extends List<GValue>> valueGetter, final ObservableList<GValue> observableList) {
		super(valueGetter);
		this.observableList = observableList;
		this.addListener((sender) -> {
			final List<GValue> value = this.getValue();
			observableList.setAll(value != null ? value : Collections.emptyList());
		});
	}

}
