package bee.creative.iam.editor;

import bee.creative.iam.editor.custom.CustomButton;
import bee.creative.iam.editor.custom.CustomTab;
import bee.creative.iam.editor.custom.CustomTitledTextfieldPane;
import bee.creative.iam.editor.data.BaseData;
import bee.creative.iam.editor.data.EntryData;
import bee.creative.util.Fields;
import javafx.scene.image.ImageView;

/** Diese Klasse implementiert den {@link CustomTab} zur Bearbeitung eines {@link EntryData}. */
@SuppressWarnings ("javadoc")
public final class EntryEditorTab extends CustomTab<EntryData> {

	/** Dieses Feld speichert den {@link CustomButton}, über welchen zur Tabelle zurück navigiert werden kann. */
	public final CustomButton ownerButton;

	/** Dieses Feld speichert den Editor für {@link EntryData#FIELD_Index}. */
	public final CustomTitledTextfieldPane<EntryData> indexEditor;

	/** Dieses Feld speichert den Editor für {@link EntryData#FIELD_Name}. */
	public final CustomTitledTextfieldPane<EntryData> nameEditor;

	/** Dieses Feld speichert den Editor für {@link EntryData#GETTER_Key}. */
	public final ArrayDataEditor<EntryData> keyEditor;

	/** Dieses Feld speichert den Editor für {@link EntryData#GETTER_Value}. */
	public final ArrayDataEditor<EntryData> valueEditor;

	public EntryEditorTab() {
		this.ownerButton = new CustomButton(EditorMain.IMAGE_Editor_Mapping, "Eintrag in Tabelle bearbeiten...");
		this.indexEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Index, EntryData.FIELD_Index, //
			Fields.translatedField(EntryData.FIELD_Index, EditorMain.GETTER_IntegerFormatter, EditorMain.GETTER_IntegerParser));
		this.indexEditor.inputProperty.bind(this.inputProperty);
		this.nameEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Name, BaseData.FIELD_Name, BaseData.FIELD_Name);
		this.nameEditor.inputProperty.bind(this.inputProperty);
		this.keyEditor = new ArrayDataEditor<>(EntryData.NAME_KeyArray, EntryData.NAME_KeyFormat, EntryData.NAME_KeyString, EntryData.GETTER_Key);
		this.keyEditor.inputProperty.bind(this.inputProperty);
		this.valueEditor = new ArrayDataEditor<>(EntryData.NAME_ValueArray, EntryData.NAME_ValueFormat, EntryData.NAME_ValueString, EntryData.GETTER_Value);
		this.valueEditor.inputProperty.bind(this.inputProperty);
		this.contentPane.getChildren().addAll(this.ownerButton, this.indexEditor, this.nameEditor, this.keyEditor, this.valueEditor);
		this.contentScroller.setFitToHeight(false);
		this.setGraphic(new ImageView(EditorMain.IMAGE_Editor_Entry));
		this.textProperty().bind(this.nameEditor.valueEditor.textProperty());
	}

}