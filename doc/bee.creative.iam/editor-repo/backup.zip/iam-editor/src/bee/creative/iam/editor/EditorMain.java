package bee.creative.iam.editor;

import java.io.File;
import java.io.InputStream;
import java.util.Arrays;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.iam.editor.adapter.PropertyAdapter;
import bee.creative.iam.editor.data.IndexData;
import bee.creative.iam.editor.data.ProjectData;
import bee.creative.util.Field;
import bee.creative.util.Getter;
import bee.creative.util.Setter;
import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Callback;

public class EditorMain extends Application {

	public static final Image IMAGE_Toolbar_New = EditorMain.imageFrom("res/icon01.png");

	public static final Image IMAGE_Toolbar_Load = EditorMain.imageFrom("res/icon02.png");

	public static final Image IMAGE_Toolbar_Save = EditorMain.imageFrom("res/icon03.png");

	public static final Image IMAGE_Toolbar_Undo = EditorMain.imageFrom("res/icon04.png");

	public static final Image IMAGE_Toolbar_Redo = EditorMain.imageFrom("res/icon05.png");

	public static final Image IMAGE_Editor_Project = EditorMain.imageFrom("res/icon06.png");

	public static final Image IMAGE_Editor_Index = EditorMain.imageFrom("res/icon07.png");

	public static final Image IMAGE_Editor_Listing = EditorMain.imageFrom("res/icon08.png");

	public static final Image IMAGE_Editor_Item = EditorMain.imageFrom("res/icon09.png");

	public static final Image IMAGE_Editor_Mapping = EditorMain.imageFrom("res/icon10.png");

	public static final Image IMAGE_Editor_Entry = EditorMain.imageFrom("res/icon11.png");

	public static final Image IMAGE_Action_Raise = EditorMain.imageFrom("res/icon12.png");

	public static final Image IMAGE_Action_Lower = EditorMain.imageFrom("res/icon13.png");

	public static final Image IMAGE_Action_Append = EditorMain.imageFrom("res/icon14.png");

	public static final Image IMAGE_Action_Remove = EditorMain.imageFrom("res/icon15.png");

	public static final Image IMAGE_Action_Update = EditorMain.imageFrom("res/icon16.png");

	public static final Image IMAGE_Action_Import = EditorMain.imageFrom("res/icon17.png");

	public static final Image IMAGE_Action_Export = EditorMain.imageFrom("res/icon18.png");

	public static final String STRING_Empty = "";

	public static final String STRING_Mixed = "...";

	public static final Getter<String, Integer> GETTER_IntegerParser = (s) -> (s != null) && !s.isEmpty() ? new Integer(s) : null;

	public static final Getter<Integer, String> GETTER_IntegerFormatter = (i) -> i != null ? i.toString() : null;

	public static final int LAYOUT_Gap = 3;

	public static final int LAYOUT_Spacing = 12;

	/** Dieses Feld speichert den zuletzt in {@link #showFileDialog(boolean, Parent, Object, String, ExtensionFilter[], Setter[])} gewählten Dateinamen. */
	static File fileDialogCache;

	{}

	static Image imageFrom(final String name) {
		final InputStream stream = EditorMain.class.getResourceAsStream(name);
		return stream != null ? new Image(stream) : null;
	}

	public static <GInput> void showFileDialog(final boolean open, final Parent parent, final GInput input, final String title, final ExtensionFilter[] filters,
		final Setter<? super GInput, ? super File>[] setters) {
		try {
			final FileChooser chooser = new FileChooser();
			chooser.setTitle(title);
			chooser.setInitialDirectory(EditorMain.fileDialogCache);
			chooser.getExtensionFilters().setAll(filters);
			final Window window = parent.getScene().getWindow();
			final File file = open ? chooser.showOpenDialog(window) : chooser.showSaveDialog(window);
			if (file == null) return;
			EditorMain.fileDialogCache = file.getParentFile();
			final int index = Arrays.asList(filters).indexOf(chooser.getSelectedExtensionFilter());
			ProjectData.logChange(setters[index], input, file);
		} catch (final Exception cause) {
			new Alert(AlertType.ERROR, cause.getMessage()).showAndWait();
		}
	}

	/** Diese Methode gibt einen an das gegebene {@link Field Datenfeld} {@link PropertyAdapter gebundenen} {@link TableColumn#setCellValueFactory(Callback)
	 * Methode zur Ermittlung des Werts einer Tabellenzelle} zurück, welcher bei Modifikation des gegebenen {@link ObservableField überwachenden Datenfelds} seine
	 * Aktualisierung signalisiert.
	 *
	 * @param <GEntry> Typ der Elemente in der Tabelle.
	 * @param <GValue> Typ des Werts.
	 * @param field Datenfeld, das in der Tabellenzelle bearbeitet wird.
	 * @param observableField Datenfeld zur Überwachung von Änderungen.
	 * @return {@link Callback}. */
	public static <GEntry, GValue> Callback<CellDataFeatures<GEntry, GValue>, ObservableValue<GValue>> factory(final Field<? super GEntry, GValue> field,
		final ObservableField<?, ?> observableField) {
		return (event) -> new PropertyAdapter<>(field).useInput(event.getValue()).useObservable(observableField);
	}

	public static <GInput, GValue> EventHandler<CellEditEvent<GInput, GValue>> handler(final Field<? super GInput, GValue> field) {
		return (event) -> ProjectData.logChange(field, event.getRowValue(), event.getNewValue());
	}

	public static void main(final String[] args) {
		Application.launch(args);
	}

	{}

	@Override
	public void start(final Stage window) {
		System.setProperty("javafx.userAgentStylesheetUrl", "CASPIAN");
		IndexData.GETTER_appendMapping.get(ProjectData.GETTER_AppendIndex.get(ProjectData.INSTANCE));
		final EditorWindow parent = new EditorWindow();
		window.setTitle("Programmtitel");
		window.setScene(new Scene(parent, 1280, 960));
		window.show();
	}
}
