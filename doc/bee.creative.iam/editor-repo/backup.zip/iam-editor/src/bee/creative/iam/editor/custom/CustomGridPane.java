package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.EditorMain;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;

/** Diese Klasse implementiert ein {@link GridPane} mit zwei gleich großen Spalten.
 * 
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */
@SuppressWarnings ("javadoc")
public class CustomGridPane extends GridPane {

	public CustomGridPane() {
		final ColumnConstraints constraints = new ColumnConstraints();
		constraints.setPercentWidth(50);
		this.setHgap(EditorMain.LAYOUT_Spacing);
		this.setVgap(EditorMain.LAYOUT_Spacing);
		this.getColumnConstraints().addAll(constraints, constraints);
	}

}
