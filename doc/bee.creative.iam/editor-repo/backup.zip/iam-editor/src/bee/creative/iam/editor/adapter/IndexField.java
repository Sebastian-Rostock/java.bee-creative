package bee.creative.iam.editor.adapter;

import java.util.ArrayList;
import java.util.List;
import bee.creative.util.Field;

/** Diese Klasse implementiert ein {@link Field Datenfeld}, dass die Position der Eingabe in einer Liste modifizierbar macht. Die Liste ist dazu über ein
 * {@link Field} von der Eingabe aus erreichbar. Die Position wird zur Wiederverwendung über ein weiters {@link Field Datenfeld} der Eingabe gespeichert. Wenn
 * die gespeicherte Position negativ ist, wird sie nicht neu bestimmt.
 *
 * @param <GInput> Typ der Eingabe. */
@SuppressWarnings ("javadoc")
public final class IndexField<GInput> implements Field<GInput, Integer> {

	/** Diese Methode gibt die Position des gegebenen Objekts in der gegebenen Lsite zurück. Bei erfolgloser Suche wird {@code -1} geliefert. Die Suche erfolgt
	 * linear bidirektional ab der gegebenen Position, wobei diese Position selbst nicht geprüft wird.
	 *
	 * @param list durchsuchte Liste.
	 * @param item gesuchtes Objekt.
	 * @param head Startposition.
	 * @param size Listenlänge.
	 * @return Trefferposition oder {@code -1}. */
	static int find(final List<?> list, final Object item, final int head, final int size) {
		final int body = size - head - 1, stop = Math.min(head, body);
		for (int i = 1; i <= stop; i++) {
			if (list.get(head - i) == item) return head - i;
			if (list.get(head + i) == item) return head + i;
		}
		for (int i = head + head + 1; i < size; i++) {
			if (list.get(i) == item) return i;
		}
		for (int i = Math.min(head - body, size) - 1; i >= 0; i--) {
			if (list.get(i) == item) return i;
		}
		return -1;
	}

	{}

	/** Dieses Feld speichert das Datenfeld zur Pufferung der Position. */
	final Field<? super GInput, Integer> indexField;

	/** Dieses Feld speichert das Datenfeld Ermittlung und Modifikation der Liste. */
	final Field<? super GInput, List<GInput>> listingField;

	/** Dieser Konstruktor initialisiert das Datenfeld zur Pufferung der Position sowie das zur Ermittlung und Modifikation der Liste. */
	public IndexField(final Field<? super GInput, Integer> indexField, final Field<? super GInput, List<GInput>> listingField) {
		this.indexField = indexField;
		this.listingField = listingField;
	}

	{}

	@Override
	public Integer get(final GInput input) {
		Integer index = this.indexField.get(input);
		final int head = index.intValue();
		if (head < 0) return index;
		final List<GInput> listing = this.listingField.get(input);
		final int size = listing.size();
		if ((head < size) && (listing.get(head) == input)) return index;
		index = new Integer(IndexField.find(listing, input, head, size));
		this.indexField.set(input, index);
		return index;
	}

	@Override
	public void set(final GInput input, final Integer value) {
		final List<GInput> listing = new ArrayList<>(this.listingField.get(input));
		final int size = listing.size();
		final int oldIndex = this.get(input).intValue(), newIndex = Math.min(Math.max(value.intValue(), 0), size - 1);
		if (oldIndex == newIndex) return;
		if (oldIndex >= 0) {
			listing.remove(oldIndex);
		}
		listing.add(newIndex, input);
		this.listingField.set(input, listing);
	}

	@Override
	public String toString() {
		return this.indexField.toString();
	}

}