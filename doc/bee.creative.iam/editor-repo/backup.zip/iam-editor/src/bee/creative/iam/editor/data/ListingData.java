package bee.creative.iam.editor.data;

import java.io.OutputStream;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import bee.creative.csv.CSVReader;
import bee.creative.csv.CSVWriter;
import bee.creative.fem.FEMException;
import bee.creative.iam.IAMArray;
import bee.creative.iam.IAMBuilder.IAMListingBuilder;
import bee.creative.iam.IAMCodec.IAMArrayFormat;
import bee.creative.iam.IAMIndex;
import bee.creative.iam.IAMListing;
import bee.creative.iam.IAMLoader.IAMListingLoader;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.mmf.MMFArray;
import bee.creative.util.Field;
import bee.creative.util.Fields;
import bee.creative.util.Getter;
import bee.creative.util.IO;
import bee.creative.util.Iterables;
import bee.creative.util.Objects;
import bee.creative.util.Setter;

/** Diese Klasse implementiert das Datenmodell einer Auflistung eines {@link IAMIndex}. */
@XmlType (propOrder = {"itemList"})
@XmlRootElement (name = "iam-listing")
@XmlAccessorType (XmlAccessType.FIELD)
@SuppressWarnings ("javadoc")
public final class ListingData extends BaseData {

	/** Diese Schnittstelle definiert einen {@link Setter} für eine {@link Object}-Eigenschaft eines {@link ListingData}. */
	public static interface ListingSetter extends Setter<ListingData, Object> {
	}

	{}

	/** Dieses Feld speichert das {@link Field} zu {@link #owner}. */
	public static final Field<ListingData, IndexData> FIELD_Owner = ListingData.nativeField("owner");

	/** Dieses Feld speichert das {@link Field} zur dieses Objekt verwaltenden Liste im {@link #owner}. */
	public static final Field<ListingData, List<ListingData>> FIELD_OwnerList = Fields.navigatedField(ListingData.FIELD_Owner, IndexData.FIELD_ListingList);

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #index}. */
	public static final ObservableField<ListingData, Integer> FIELD_Index = BaseData.indexField(ListingData.FIELD_OwnerList);

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #itemList}. */
	public static final ObservableField<ListingData, List<ItemData>> FIELD_ItemList =
		new ObservableField<>(Fields.setupField(ListingData.nativeField("itemList"), (i) -> new ArrayList<>()));

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #errorinfo}. */
	public static final ObservableField<ListingData, String> FIELD_Errorinfo = ListingData.observableField("errorinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #itemfindinfo}. */
	public static final ObservableField<ListingData, String> FIELD_Itemfindinfo = ListingData.observableField("itemfindinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #itemcountinfo}. */
	public static final ObservableField<ListingData, String> FIELD_Itemcountinfo = ListingData.observableField("itemcountinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #datalengthinfo}. */
	public static final ObservableField<ListingData, String> FIELD_Datalengthinfo = ListingData.observableField("datalengthinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #datacontentinfo}. */
	public static final ObservableField<ListingData, String> FIELD_Datacontentinfo = ListingData.observableField("datacontentinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #byteslengthinfo}. */
	public static final ObservableField<ListingData, String> FIELD_Byteslengthinfo = ListingData.observableField("byteslengthinfo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #bytesheaderinfo}. */
	public static final ObservableField<ListingData, String> FIELD_Bytesheaderinfo = ListingData.observableField("bytesheaderinfo");

	public static final String NAME_ItemList = "Elemente";

	/** Dieses Feld speichert den {@link Setter} zum Export der Elemente in eine gegebenen {@link CSVWriter#from(Object) CSV-Datei}. */
	public static final ListingSetter SETTER_ExportCSV = (listingData, object) -> {
		try (CSVWriter writer = CSVWriter.from(object)) {
			writer.writeEntry(ItemData.HEADER_CSV);
			for (final ItemData item: Iterables.iterable(listingData.itemList)) {
				final ArrayData data = ItemData.GETTER_Data.get(item);
				writer.writeEntry(ProjectData.toString(item.name), ProjectData.toString(data.array), ProjectData.toString(data.string),
					ProjectData.toString(data.format), Boolean.toString(data.updateArray), Boolean.toString(data.updateString));
			}
		} catch (final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert den {@link Setter} zum Export der Elemente in eine gegebenen {@link IO#outputStreamFrom(Object) IAM-Datei}. */
	public static final ListingSetter SETTER_ExportIAM = (listingData, object) -> {
		final byte[] bytes = listingData.toBytes();
		try (OutputStream stream = IO.outputStreamFrom(object)) {
			stream.write(bytes);
		} catch (final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert den {@link Setter} zum Import von Elementen aus einer gegebenen {@link CSVReader#from(Object) CSV-Datei}. */
	public static final ListingSetter SETTER_ImportCSV = (listingData, object) -> {
		try (CSVReader reader = CSVReader.from(object)) {
			String[] array = reader.readEntry();
			if (!Objects.equals(ItemData.HEADER_CSV, array)) throw new FEMException() //
				.push("CSV-Hedaer ungültig: %s erhalten, %s erwartet.", Objects.toString(array), Objects.toString(ItemData.HEADER_CSV));
			final List<ItemData> itemList = new ArrayList<>(ListingData.FIELD_ItemList.get(listingData));
			for (array = reader.readEntry(); array != null; array = reader.readEntry()) {
				if (array.length != ItemData.HEADER_CSV.length) throw new FEMException()//
					.push("CSV-Eintrag mit ungültiger Länge: %s erhalten und Länge %s erwartet.", Objects.toString(array), ItemData.HEADER_CSV.length);
				final ItemData itemData = new ItemData();
				final ArrayData arrayData = new ArrayData();
				itemData.name = array[0];
				itemData.owner = listingData;
				itemData.index = itemList.size();
				itemData.data = arrayData;
				arrayData.array = array[1];
				arrayData.string = array[2];
				arrayData.format = IAMArrayFormat.from(array[3]);
				arrayData.updateArray = Boolean.parseBoolean(array[4]);
				arrayData.updateString = Boolean.parseBoolean(array[5]);
				itemList.add(itemData);
			}
			ListingData.FIELD_ItemList.set(listingData, itemList);
		} catch (final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert den {@link Setter} zum Import von Elementen aus gegebenen {@link IAMListing#from(Object) IAM-Daten}. */
	public static final ListingSetter SETTER_ImportIAM = (listingData, object) -> {
		try {
			final IAMListing listing = IAMListing.from(object);
			final List<ItemData> itemList = new ArrayList<>(ListingData.FIELD_ItemList.get(listingData));
			for (final IAMArray item: listing) {
				final ItemData itemData = new ItemData();
				final ArrayData arrayData = new ArrayData();
				itemData.owner = listingData;
				itemData.index = itemList.size();
				itemData.data = arrayData;
				arrayData.array = arrayData.string = IAMArrayFormat.ARRAY.format(item.toArray());
				itemList.add(itemData);
			}
			ListingData.FIELD_ItemList.set(listingData, itemList);
		} catch (final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert einen {@link Setter} zum Entfernen von Elementen aus {@link #itemList}. */
	public static final Setter<ListingData, List<ItemData>> SETTER_RemoveItem = (i, v) -> ProjectData.remove(i, v, ListingData.FIELD_ItemList);

	/** Dieses Feld speichert einen {@link Getter} zur Ermittlung eines neuen Elements in {@link #itemList}. */
	public static final Getter<ListingData, ItemData> GETTER_AppendItem =
		(i) -> ProjectData.append(i, new ItemData(), ItemData.FIELD_Owner, ListingData.FIELD_ItemList);

	{}

	static final <GValue> Field<ListingData, GValue> nativeField(final String name) {
		return BaseData.nativeField(ListingData.class, name);
	}

	static final <GValue> ObservableField<ListingData, GValue> observableField(final String name) {
		return new ObservableField<>(ListingData.nativeField(name));
	}

	{}

	/** Dieses Feld speichert den Besitzer, der dieses Objekt in einer Liste verwaltet. */
	@XmlTransient
	IndexData owner;

	/** Dieses Feld speichert die Datenmodelle der Elemente. */
	@XmlElement (name = "item")
	List<ItemData> itemList;

	/** Dieses Feld speichert statistische Informationen zu Fehlern bei der Binärkodierung. */
	@XmlTransient
	String errorinfo = "-";

	/** Dieses Feld speichert statistische Informationen zur Suche von Elementen im Binärformat. */
	@XmlTransient
	String itemfindinfo = "-";

	/** Dieses Feld speichert statistische Informationen zur Anzahl der Elemente im Binärformat. */
	@XmlTransient
	String itemcountinfo = "-";

	/** Dieses Feld speichert statistische Informationen zur Länge der Zahlenfolgen der Daten. */
	@XmlTransient
	String datalengthinfo = "-";

	/** Dieses Feld speichert statistische Informationen zum Inhalt der Zahlenfolgen der Daten. */
	@XmlTransient
	String datacontentinfo = "-";

	/** Dieses Feld speichert statistische Informationen zur Länge des Binärformats der Abbildung. */
	@XmlTransient
	String byteslengthinfo = "-";

	/** Dieses Feld speichert statistische Informationen zur Kodierung des Binärformats der Abbildung. */
	@XmlTransient
	String bytesheaderinfo = "-";

	{}

	/** Diese Methode gibt die Daten der Auflistung als Bytefolge zurück. */
	public byte[] toBytes() {
		return this.toListing().toBytes(this.owner.toOrder());
	}

	/** Diese Methode gibt die Daten der Auflistung als {@link IAMListing} zurück. */
	public IAMListing toListing() {
		final IAMListingBuilder result = new IAMListingBuilder();
		for (final ItemData item: Iterables.iterable(this.itemList)) {
			result.put(ItemData.GETTER_Data.get(item).toArray());
		}
		return result;
	}

	/** Diese Methode aktualisiert die Felder mit statistischen Informationen. */
	public void updateInfo() {
		final StatsData datalength = new StatsData(), datacontent = new StatsData();
		String error = "-", itemfind = "-", itemcount = "-", byteheader = "-", bytelength = "-";
		try {
			final byte[] bytes = this.toBytes();
			bytelength = String.format("%,d Byte", bytes.length);
			final ByteOrder order = IAMListingLoader.HEADER.orderOf(bytes);
			final MMFArray array = new MMFArray(bytes, order).toINT32();
			final IAMListingLoader listing = new IAMListingLoader(array);
			final ArrayList<IAMArray> datas = new ArrayList<>(listing.itemCount());
			for (final IAMArray data: listing) {
				datas.add(IAMArray.from(data.toArray()));
				datacontent.put(data);
				datalength.put(data.length());
			}
			final int header = array.get(0);
			byteheader = String.format("%s.%s.%s.%s", (header >> 6) & 3, (header >> 4) & 3, (header >> 2) & 3, (header >> 0) & 3);
			itemcount = String.format("%,d", listing.itemCount());
			if (!datas.isEmpty()) {
				long testTime, testCount = 1, repeatCount = 1;
				while (true) {
					final int rmax = (int)repeatCount, fmax = (int)testCount;
					final long s = System.nanoTime();
					for (int r = 0; r < rmax; r++) {
						for (int f = 0; f < fmax; f++) {
							final IAMArray key = datas.get(f);
							if (listing.find(key) < 0) throw new IllegalStateException("Schlüssel nicht gefunden!");
						}
					}
					final long e = System.nanoTime();
					testTime = e - s;
					if (testTime > 100000000) {
						break;
					}
					testCount <<= 1;
					if (testCount > datas.size()) {
						testCount = datas.size();
						repeatCount <<= 1;
					}
				}
				testCount *= repeatCount;
				itemfind = String.format("%,.2f ns (%,d/%,d)", (double)testTime / (double)testCount, testTime, testCount);
			}
		} catch (final Exception cause) {
			error = cause.getMessage();
		}
		ListingData.FIELD_Errorinfo.set(this, error);
		ListingData.FIELD_Itemfindinfo.set(this, itemfind);
		ListingData.FIELD_Itemcountinfo.set(this, itemcount);
		ListingData.FIELD_Datalengthinfo.set(this, datalength.toString());
		ListingData.FIELD_Datacontentinfo.set(this, datacontent.toString());
		ListingData.FIELD_Byteslengthinfo.set(this, bytelength);
		ListingData.FIELD_Bytesheaderinfo.set(this, byteheader);
	}

	{}

	@Override
	public String toString() {
		return Objects.toInvokeString("", this.name);
	}

}