package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.iam.editor.adapter.PropertyAdapter;
import bee.creative.util.Field;
import javafx.beans.property.Property;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/** Diese Klasse implementiert einen {@link ToggleButton} als Editor mit {@link #inputProperty Eingabe} und {@link #valueProperty Datenanbindung}.
 * 
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]
 * @param <GInput> Typ der Eingabe. */
@SuppressWarnings ("javadoc")
public class CustomToggleButton<GInput> extends ToggleButton {

	/** Dieses Feld speichert den {@link PropertyAdapter}, der den Wert des {@link ToggleButton} über ein gegebenes {@link ObservableField} anbindet. */
	public final PropertyAdapter<GInput, Boolean> valueProperty;

	/** Dieses Feld speichert das {@link Property} zur Eingabe des {@link #valueProperty}. */
	public final Property<GInput> inputProperty;

	public CustomToggleButton(final Field<? super GInput, Boolean> valueField) {
		this.valueProperty = new PropertyAdapter<>(valueField);
		this.valueProperty.bindBidirectional(this.selectedProperty());
		this.inputProperty = this.valueProperty.inputProperty;
		this.setPadding(new Insets(3));
		this.setCursor(Cursor.HAND);
	}

	public CustomToggleButton(final Image buttonImage, final ObservableField<?, ?> observableField, final Field<? super GInput, Boolean> valueField) {
		this(valueField);
		this.setGraphic(new ImageView(buttonImage));
		this.valueProperty.useObservable(observableField);
	}

}