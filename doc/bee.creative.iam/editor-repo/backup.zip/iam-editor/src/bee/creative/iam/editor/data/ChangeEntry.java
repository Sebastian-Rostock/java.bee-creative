package bee.creative.iam.editor.data;

import bee.creative.util.Objects;
import bee.creative.util.Setter;

/** Diese Klasse implementiert einen Änderungseintrag zu einer {@link #setter Eigenschaft} eines {@link #input Objekts}.
 *
 * @param <GInput> Typ des Objekts.
 * @param <GValue> Typ der Eigenschaft.
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */
public final class ChangeEntry<GInput, GValue> {

	/** Dieses Feld speichert das Objekt, dessen Eigenschaft geändert wurde. */
	public final GInput input;

	/** Dieses Feld speichert den {@link Setter} zur geänderten Eigenschaft. */
	public final Setter<? super GInput, ? super GValue> setter;

	/** Dieses Feld speichert den alten Wert. */
	public GValue oldValue;

	/** Dieses Feld speichert den neuen Wert. */
	public GValue newValue;

	@SuppressWarnings ("javadoc")
	public ChangeEntry(final GInput input, final Setter<? super GInput, ? super GValue> setter, final GValue oldValue, final GValue newValue) {
		this.input = input;
		this.setter = setter;
		this.oldValue = oldValue;
		this.newValue = newValue;
	}

	{}

	/** Diese Methode setzt den Wert der Eigenschaft auf den {@link #newValue neuen}. */
	public final void redo() {
		this.setter.set(this.input, this.newValue);
	}

	/** Diese Methode setzt den Wert der Eigenschaft auf den {@link #oldValue alten}. */
	public final void undo() {
		this.setter.set(this.input, this.oldValue);
	}

	{}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return Objects.toInvokeString(this, this.setter, this.oldValue, this.newValue);
	}

}