package bee.creative.iam.editor;

import bee.creative.iam.IAMCodec.IAMArrayFormat;
import bee.creative.iam.editor.custom.CustomBooleanColumn;
import bee.creative.iam.editor.custom.CustomStringColumn;
import bee.creative.iam.editor.custom.CustomValueColumn;
import bee.creative.iam.editor.data.ArrayData;
import bee.creative.util.Fields;
import bee.creative.util.Getter;
import javafx.scene.control.TableColumn;

/** Diese Klasse implementiert eine gruppierte {@link TableColumn} zur Bearbeitung der {@link ArrayData} in den Zeilen einer Tabelle.
 * 
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]
 * @param <GEntry> Typ der Elemente der Tabelle. */
@SuppressWarnings ("javadoc")
public class ArrayColumnEditor<GEntry> extends TableColumn<GEntry, Object> {

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_Array}. */
	public final CustomStringColumn<GEntry> arrayColumn;

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_String}. */
	public final CustomStringColumn<GEntry> stringColumn;

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_Format}. */
	public final CustomValueColumn<GEntry, IAMArrayFormat> formatColumn;

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_UpdateArray}. */
	public final CustomBooleanColumn<GEntry> updateArrayColumn;

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_UpdateString}. */
	public final CustomBooleanColumn<GEntry> updateStringColumn;

	@SuppressWarnings ("unchecked")
	public ArrayColumnEditor(final Getter<? super GEntry, ArrayData> arrayGetter) {
		this.arrayColumn = new CustomStringColumn<>(Fields.navigatedField(arrayGetter, ArrayData.FIELD_Array), ArrayData.FIELD_Array);
		this.arrayColumn.setText(ArrayData.NAME_Array);
		this.stringColumn = new CustomStringColumn<>(Fields.navigatedField(arrayGetter, ArrayData.FIELD_String), ArrayData.FIELD_String);
		this.stringColumn.setText(ArrayData.NAME_String);
		this.formatColumn = new CustomValueColumn<>(Fields.navigatedField(arrayGetter, ArrayData.FIELD_Format), IAMArrayFormat.values(), ArrayData.FIELD_Format);
		this.formatColumn.setText(ArrayData.NAME_Format);
		this.updateArrayColumn = new CustomBooleanColumn<>(Fields.navigatedField(arrayGetter, ArrayData.FIELD_UpdateArray), ArrayData.FIELD_UpdateArray);
		this.updateArrayColumn.setText(ArrayData.NAME_UpdateArray);
		this.updateStringColumn = new CustomBooleanColumn<>(Fields.navigatedField(arrayGetter, ArrayData.FIELD_UpdateString), ArrayData.FIELD_UpdateString);
		this.updateStringColumn.setText(ArrayData.NAME_UpdateString);
		this.getColumns().addAll(this.arrayColumn, this.formatColumn, this.stringColumn, this.updateArrayColumn, this.updateStringColumn);
	}

}