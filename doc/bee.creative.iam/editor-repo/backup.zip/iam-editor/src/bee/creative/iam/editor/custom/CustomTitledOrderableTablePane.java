package bee.creative.iam.editor.custom;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import bee.creative.iam.editor.EditorMain;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.iam.editor.data.ProjectData;
import bee.creative.util.Field;
import bee.creative.util.Getter;
import bee.creative.util.Setter;
import javafx.scene.control.TableView.TableViewSelectionModel;

/** Diese Klasse implementiert eine {@link CustomTitledEditableTablePane} mit Steuerelementen zum {@link #move(boolean) Verschieben} gewählter Elemente.
 *
 * @param <GInput> Typ der Eingabe.
 * @param <GItem> Tyo der Elemente in der Tabelle. */
@SuppressWarnings ("javadoc")
public class CustomTitledOrderableTablePane<GInput, GItem> extends CustomTitledEditableTablePane<GInput, GItem> {

	/** Dieses Feld speichert den {@link CustomButton} zum Heben der Position gewählter Elemente. */
	public final CustomButton raiseButton;

	/** Dieses Feld speichert den {@link CustomButton} zum Senken der Position gewählter Elemente. */
	public final CustomButton lowerButton;

	/** Dieses Feld speichert das Field zur Anpassung der Elementreihenfolge. */
	public final Field<? super GInput, List<GItem>> itemsField;

	public CustomTitledOrderableTablePane(final Setter<? super GInput, List<GItem>> removeSetter, final Getter<? super GInput, GItem> appendGetter,
		final ObservableField<? super GInput, List<GItem>> itemsField) {
		super(removeSetter, appendGetter, itemsField);
		this.itemsField = itemsField;
		this.lowerButton = new CustomButton(EditorMain.IMAGE_Action_Lower);
		this.lowerButton.setOnAction(event -> this.onLowerAction());
		this.lowerButton.disableProperty().bind(this.removeButton.disableProperty());
		this.raiseButton = new CustomButton(EditorMain.IMAGE_Action_Raise);
		this.raiseButton.setOnAction(event -> this.onRaiseAction());
		this.raiseButton.disableProperty().bind(this.removeButton.disableProperty());
		this.titlePane.getChildren().addAll(1, Arrays.asList(this.lowerButton, this.raiseButton));
	}

	{}

	/** Diese Methode verschiebt die {@link #selectionAdapter aktuelle Auswahl} in die gegebene Richtung.
	 *
	 * @param direction {@code true} senken, {@code false} steigern. */
	void move(final boolean direction) {
		final GInput input = this.inputProperty.getValue();
		if (input == null) return;
		final TableViewSelectionModel<GItem> selection = this.tableView.getSelectionModel();
		if (selection.isEmpty()) return;
		final Set<GItem> items = new HashSet<>(selection.getSelectedItems());
		ProjectData.logChange(this.itemsField, input, ProjectData.move(this.itemsField.get(input), items, direction));
		selection.clearSelection();
		for (final GItem entry: items) {
			selection.select(entry);
		}
	}

	/** Diese Methode senkt die Position der {@link #selectionAdapter aktuelle Auswahl}. */
	public void onLowerAction() {
		this.move(true);
	}

	/** Diese Methode hebt die Position der {@link #selectionAdapter aktuelle Auswahl}. */
	public void onRaiseAction() {
		this.move(false);
	}

}