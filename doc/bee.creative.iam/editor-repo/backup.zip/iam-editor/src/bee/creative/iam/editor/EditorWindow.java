package bee.creative.iam.editor;

import java.util.ArrayList;
import java.util.List;
import bee.creative.iam.editor.adapter.FieldListener;
import bee.creative.iam.editor.adapter.ValueAdapter;
import bee.creative.iam.editor.custom.CustomButton;
import bee.creative.iam.editor.custom.CustomTab;
import bee.creative.iam.editor.data.BaseData;
import bee.creative.iam.editor.data.EntryData;
import bee.creative.iam.editor.data.IndexData;
import bee.creative.iam.editor.data.ItemData;
import bee.creative.iam.editor.data.ListingData;
import bee.creative.iam.editor.data.MappingData;
import bee.creative.iam.editor.data.ProjectData;
import bee.creative.iam.editor.data.ProjectData.ProjectSetter;
import bee.creative.util.Getter;
import bee.creative.util.Iterables;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.property.ObjectProperty;
import javafx.geometry.Orientation;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Separator;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.control.TableView;
import javafx.scene.control.TableView.TableViewSelectionModel;
import javafx.scene.control.ToolBar;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.TextFieldTreeCell;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.util.StringConverter;

public final class EditorWindow extends VBox {

	static final class CustomTreeItem extends TreeItem<Object> {

		private final Object input;

		final ObjectBinding<Object> valueBinding;

		FieldListener<Object> valueListener;

		FieldListener<ProjectData> childrenListener1;

		FieldListener<IndexData> childrenListener2;

		FieldListener<ListingData> childrenListener3;

		FieldListener<MappingData> childrenListener4;

		CustomTreeItem(final Object input) {
			this.input = input;
			this.valueBinding = new ObjectBinding<Object>() {

				@Override
				protected Object computeValue() {
					return CustomTreeItem.this.input;
				}

			};
			this.valueListener = sender -> {
				if (sender != this.input) return;
				this.valueBinding.invalidate();
			};
			if (this.input instanceof ProjectData) {
				this.childrenListener1 = sender -> {
					if (sender != this.input) return;
					final List<TreeItem<Object>> children = new ArrayList<>();
					Iterables.appendAll(children, Iterables.navigatedIterable( //
						CustomTreeItem::new, ProjectData.FIELD_IndexList.get(sender)));
					this.getChildren().setAll(children);
				};
				this.childrenListener1.fieldChanged((ProjectData)input);
				ProjectData.FIELD_IndexList.addListener(this.childrenListener1);
			}
			if (this.input instanceof IndexData) {
				this.childrenListener2 = sender -> {
					if (sender != this.input) return;
					final List<TreeItem<Object>> children = new ArrayList<>();
					Iterables.appendAll(children, Iterables.navigatedIterable( //
						CustomTreeItem::new, IndexData.FIELD_ListingList.get(sender)));
					Iterables.appendAll(children, Iterables.navigatedIterable( //
						CustomTreeItem::new, IndexData.FIELD_MappingList.get(sender)));
					this.getChildren().setAll(children);
				};
				this.childrenListener2.fieldChanged((IndexData)input);
				BaseData.FIELD_Name.addListener(this.valueListener);
				IndexData.FIELD_ListingList.addListener(this.childrenListener2);
				IndexData.FIELD_MappingList.addListener(this.childrenListener2);
				this.setGraphic(new ImageView(EditorMain.IMAGE_Editor_Index));
			}
			if (this.input instanceof ListingData) {
				this.childrenListener3 = sender -> {
					if (sender != this.input) return;
					final List<TreeItem<Object>> children = new ArrayList<>();
					Iterables.appendAll(children, Iterables.navigatedIterable( //
						itemData -> new CustomTreeItem(itemData), ListingData.FIELD_ItemList.get(sender)));
					this.getChildren().setAll(children);
				};
				this.childrenListener3.fieldChanged((ListingData)input);
				BaseData.FIELD_Name.addListener(this.valueListener);
				ListingData.FIELD_ItemList.addListener(this.childrenListener3);
				this.setGraphic(new ImageView(EditorMain.IMAGE_Editor_Listing));
			}
			if (this.input instanceof MappingData) {
				this.childrenListener4 = (sender) -> {
					if (sender != this.input) return;
					final List<TreeItem<Object>> children = new ArrayList<>();
					Iterables.appendAll(children, Iterables.navigatedIterable( //
						entryData -> new CustomTreeItem(entryData), MappingData.FIELD_EntryList.get(sender)));
					this.getChildren().setAll(children);
				};
				this.childrenListener4.fieldChanged((MappingData)input);
				BaseData.FIELD_Name.addListener(this.valueListener);
				MappingData.FIELD_EntryList.addListener(this.childrenListener4);
				this.setGraphic(new ImageView(EditorMain.IMAGE_Editor_Mapping));
			}
			if (this.input instanceof ItemData) {
				BaseData.FIELD_Name.addListener(this.valueListener);
				this.setGraphic(new ImageView(EditorMain.IMAGE_Editor_Item));
			}
			if (this.input instanceof EntryData) {
				BaseData.FIELD_Name.addListener(this.valueListener);
				this.setGraphic(new ImageView(EditorMain.IMAGE_Editor_Entry));
			}
			this.valueProperty().bind(this.valueBinding);
		}
	}

	public final ToolBar toolBar;

	CustomButton createButton;

	CustomButton importButton;

	CustomButton exportButton;

	CustomButton undoButton;

	CustomButton redoButton;

	SplitPane splitPane;

	TreeView<Object> treeView;

	TabPane tabPane;

	ProjectEditorTab tab;

	static final StringConverter<Object> STRING_CONVERTER = new StringConverter<Object>() {

		<T> String toString(final T o, final Getter<? super T, ?> nameGetter, final Getter<? super T, ?> indexGetter) {
			return indexGetter.get(o) + " - " + nameGetter.get(o);
		}

		@Override
		public String toString(final Object object) {
			if (object instanceof IndexData) {
				final IndexData indexData = (IndexData)object;
				return this.toString(indexData, BaseData.FIELD_Name, IndexData.FIELD_Index);
			}
			if (object instanceof ListingData) {
				final ListingData listingData = (ListingData)object;
				return this.toString(listingData, BaseData.FIELD_Name, ListingData.FIELD_Index);
			}
			if (object instanceof MappingData) {
				final MappingData mappingData = (MappingData)object;
				return this.toString(mappingData, BaseData.FIELD_Name, MappingData.FIELD_Index);
			}
			if (object instanceof EntryData) {
				final EntryData entryData = (EntryData)object;
				return this.toString(entryData, BaseData.FIELD_Name, EntryData.FIELD_Index);
			}
			if (object instanceof ItemData) {
				final ItemData itemData = (ItemData)object;
				return this.toString(itemData, BaseData.FIELD_Name, ItemData.FIELD_Index);
			}
			return null;
		}

		@Override
		public Object fromString(final String string) {
			return null;
		}

	};

	static final ExtensionFilter[] fileFilters = {new ExtensionFilter("Projekt-XML-Datei", "*.xml")};

	static final ProjectSetter[] exportSetters = {ProjectData.SETTER_ExportXML};

	static final ProjectSetter[] importSetters = {ProjectData.SETTER_ImportXML};

	public void onCreateAction() {
		if (!this.undoButton.isDisable()) {
			final Alert alert = new Alert(AlertType.CONFIRMATION,
				"Möchten Sie alle ungespeicherten Änderungen des aktuell bearbeiteten Projekts verwerfen und ein neues Projekt beginnen?", ButtonType.YES,
				ButtonType.NO);
			alert.setHeaderText("Neues Projekt beginnen...");
			if (alert.showAndWait().get() != ButtonType.YES) return;
		}
		this.tabPane.getTabs().clear();
		this.openProjectData(ProjectData.INSTANCE);
		ProjectData.clearProject();
	}

	public void onImportAction() {
		if (!this.undoButton.isDisable()) {
			final Alert alert = new Alert(AlertType.CONFIRMATION,
				"Möchten Sie alle ungespeicherten Änderungen des aktuell bearbeiteten Projekts verwerfen und ein bestehendes Projekt öffnen?", ButtonType.YES,
				ButtonType.NO);
			alert.setHeaderText("Bestehendes Projekt öffnen...");
			if (alert.showAndWait().get() != ButtonType.YES) return;
		}
		this.tabPane.getTabs().clear();
		EditorMain.showFileDialog(true, this, ProjectData.INSTANCE, "Projekt öffnen...", EditorWindow.fileFilters, EditorWindow.importSetters);
		this.openProjectData(ProjectData.INSTANCE);
	}

	public void onExportAction() {
		EditorMain.showFileDialog(false, this, ProjectData.INSTANCE, "Projekt speichern...", EditorWindow.fileFilters, EditorWindow.exportSetters);
	}

	Separator toolSeparator;

	ObjectProperty<ProjectData> inputProperty;

	ValueAdapter<ProjectData, Boolean> disableUndoAdapter;

	ValueAdapter<ProjectData, Boolean> disableRedoAdapter;

	public EditorWindow() {

		this.createButton = new CustomButton(EditorMain.IMAGE_Toolbar_New, "Neu");
		this.createButton.setOnAction(event -> this.onCreateAction());

		this.importButton = new CustomButton(EditorMain.IMAGE_Toolbar_Load, "Öffnen...");
		this.importButton.setOnAction(event -> this.onImportAction());

		this.exportButton = new CustomButton(EditorMain.IMAGE_Toolbar_Save, "Speichern...");
		this.exportButton.setOnAction(event -> this.onExportAction());

		this.toolSeparator = new Separator(Orientation.VERTICAL);

		this.disableUndoAdapter = new ValueAdapter<>(ProjectData.FIELD_DisabledUndo);
		this.inputProperty = this.disableUndoAdapter.useObservable(ProjectData.FIELD_DisabledUndo).inputProperty;
		this.disableRedoAdapter = new ValueAdapter<>(ProjectData.FIELD_DisableRedo);
		this.disableRedoAdapter.useObservable(ProjectData.FIELD_DisableRedo).inputProperty.bind(this.inputProperty);
		this.undoButton = new CustomButton(EditorMain.IMAGE_Toolbar_Undo, "Änderung rückgängig");
		this.undoButton.setOnAction(event -> this.onUndoAction());
		this.undoButton.disableProperty().bind(this.disableUndoAdapter);
		this.redoButton = new CustomButton(EditorMain.IMAGE_Toolbar_Redo, "Änderung wiederholen");
		this.redoButton.setOnAction(event -> this.onRedoAction());
		this.redoButton.disableProperty().bind(this.disableRedoAdapter);
		this.toolBar = new ToolBar(this.createButton, this.importButton, this.exportButton, this.toolSeparator, this.undoButton, this.redoButton);

		this.treeView = new TreeView<>();
		this.treeView.setCellFactory(TextFieldTreeCell.forTreeView(EditorWindow.STRING_CONVERTER));
		this.treeView.setShowRoot(false);

		this.tabPane = new TabPane();
		this.tabPane.setTabClosingPolicy(TabClosingPolicy.ALL_TABS);

		this.treeView.setOnMouseClicked(event -> {
			if (event.getClickCount() < 1) return;
			final TreeItem<Object> item = this.treeView.getSelectionModel().getSelectedItem();
			if (item == null) return;
			this.openData(item.getValue());
		});

		this.splitPane = new SplitPane();
		this.splitPane.setDividerPositions(0.2);

		VBox.setVgrow(this.splitPane, Priority.ALWAYS);

		SplitPane.setResizableWithParent(this.treeView, Boolean.FALSE);
		this.splitPane.setOrientation(Orientation.HORIZONTAL);
		this.splitPane.getItems().addAll(this.treeView, this.tabPane);

		this.getChildren().addAll(this.toolBar, this.splitPane);

		ProjectData.clearProject();
		this.inputProperty.set(ProjectData.INSTANCE);
		this.openProjectData(this.inputProperty.get());
	}

	void onUndoAction() {
		ProjectData.undoChange();
	}

	void onRedoAction() {
		ProjectData.redoChange();
	}

	CustomTab<?> openData(final Object value) {
		if (value instanceof IndexData) return this.openIndexData((IndexData)value);
		if (value instanceof ListingData) return this.openListingData((ListingData)value);
		if (value instanceof MappingData) return this.openMappingData((MappingData)value);
		if (value instanceof EntryData) return this.openEntryData((EntryData)value);
		if (value instanceof ItemData) return this.openItemData((ItemData)value);
		return null;
	}

	{}

	/** Diese Methode gibt den {@link CustomTab} aus {@link #tabPane} mit der gegebenen Eingabe zurück.
	 *
	 * @param input Eingabe.
	 * @return {@link CustomTab} oder {@code null}. */
	public final CustomTab<?> findTab(final Object input) {
		for (final Tab tab: this.tabPane.getTabs()) {
			final CustomTab<?> result = (CustomTab<?>)tab;
			if (result.inputProperty.get() == input) return result;
		}
		return null;
	}

	public final TreeItem<?> findItem(final Object input) {
		return this.findItem(this.treeView.getRoot(), input);
	}

	public final TreeItem<?> findItem(final TreeItem<?> parent, final Object input) {
		for (TreeItem<?> result: parent.getChildren()) {
			if (result.getValue() == input) return result;
			result = this.findItem(result, input);
			if (result != null) return result;
		}
		return null;
	}

	TreeItem<Object> createTreeItem(final Object input) {
		final TreeItem<Object> result = new CustomTreeItem(input);

		return result;
	}

	<GEntry> void selectEntry(final TableView<GEntry> table, final GEntry entry) {
		final TableViewSelectionModel<GEntry> s = table.getSelectionModel();
		s.clearSelection();
		s.select(entry);
	}

	public void selectTab(final CustomTab<?> tab) {
		if (!this.tabPane.getTabs().contains(tab)) {
			this.tabPane.getTabs().add(tab);
		}
		this.tabPane.getSelectionModel().select(tab);
	}

	final ProjectEditorTab openProjectData(final ProjectData projectData) {
		final ProjectEditorTab oldEditor = (ProjectEditorTab)this.findTab(projectData);
		if (oldEditor != null) {
			this.selectTab(oldEditor);
			return oldEditor;
		} else {
			final ProjectEditorTab newEditor = new ProjectEditorTab();
			newEditor.inputProperty.set(projectData);
			newEditor.childrenPane.indicesChildButton.setOnAction((event) -> this.openIndexList(newEditor.childrenPane.selectionPane.inputProperty.getValue()));
			this.selectTab(newEditor);
			this.treeView.setRoot(this.createTreeItem(projectData));
			return newEditor;
		}
	}

	final void openIndexList(final List<IndexData> indexList) {
		for (final IndexData indexData: indexList) {
			this.openIndexData(indexData);
		}
	}

	final IndexEditorTab openIndexData(final IndexData indexData) {
		final IndexEditorTab oldEditor = (IndexEditorTab)this.findTab(indexData);
		if (oldEditor != null) {
			this.selectTab(oldEditor);
			return oldEditor;
		} else {
			final IndexEditorTab newEditor = new IndexEditorTab();
			newEditor.inputProperty.set(indexData);
			newEditor.toolPane.ownerButton.setOnAction((event) -> this.openIndexOwner(indexData));
			newEditor.childrenPane.childrenPane1.listingsChildButton
				.setOnAction((event) -> this.openListingList(newEditor.childrenPane.childrenPane1.selectionPane.inputProperty.getValue()));
			newEditor.childrenPane.childrenPane2.mappingsChildButton
				.setOnAction((event) -> this.openMappingList(newEditor.childrenPane.childrenPane2.mappingsListEditor.inputProperty.getValue()));
			this.selectTab(newEditor);
			return newEditor;
		}
	}

	final void openIndexOwner(final IndexData indexData) {
		this.selectEntry(this.openProjectData(IndexData.FIELD_Owner.get(indexData)).childrenPane.indicesEditor.tableView, indexData);
	}

	final void openListingList(final List<ListingData> listingList) {
		for (final ListingData listingData: listingList) {
			this.openListingData(listingData);
		}
	}

	final ListingEditorTab openListingData(final ListingData listingData) {
		final ListingEditorTab oldEditor = (ListingEditorTab)this.findTab(listingData);
		if (oldEditor != null) {
			this.selectTab(oldEditor);
			return oldEditor;
		} else {
			final ListingEditorTab newEditor = new ListingEditorTab();
			newEditor.inputProperty.set(listingData);
			newEditor.toolPane.ownerButton.setOnAction((event) -> this.openListingOwner(listingData));
			newEditor.childrenPane.itemsChildButton.setOnAction((event) -> this.openItemList(newEditor.childrenPane.selectionPane.inputProperty.getValue()));
			this.selectTab(newEditor);
			return newEditor;
		}
	}

	final void openListingOwner(final ListingData listingData) {
		this.selectEntry(this.openIndexData(ListingData.FIELD_Owner.get(listingData)).childrenPane.childrenPane1.listingsEditor.tableView, listingData);
	}

	final void openMappingList(final List<MappingData> mappingList) {
		for (final MappingData mappingData: mappingList) {
			this.openMappingData(mappingData);
		}
	}

	final MappingEditorTab openMappingData(final MappingData mappingData) {
		final MappingEditorTab oldEditor = (MappingEditorTab)this.findTab(mappingData);
		if (oldEditor != null) {
			this.selectTab(oldEditor);
			return oldEditor;
		} else {
			final MappingEditorTab newEditor = new MappingEditorTab();
			newEditor.inputProperty.set(mappingData);
			newEditor.toolPane.ownerButton.setOnAction((event) -> this.openMappingOwner(mappingData));
			newEditor.childrenPane.entriesItemButton.setOnAction((event) -> this.openEntryList(newEditor.childrenPane.selectionPane.inputProperty.getValue()));
			this.selectTab(newEditor);
			return newEditor;
		}
	}

	void openMappingOwner(final MappingData mappingData) {
		this.selectEntry(this.openIndexData(MappingData.FIELD_Owner.get(mappingData)).childrenPane.childrenPane2.mappingsEditor.tableView, mappingData);
	}

	final void openEntryList(final List<EntryData> itemList) {
		for (final EntryData itemData: itemList) {
			this.openEntryData(itemData);
		}
	}

	final EntryEditorTab openEntryData(final EntryData itemData) {
		final EntryEditorTab oldEditor = (EntryEditorTab)this.findTab(itemData);
		if (oldEditor != null) {
			this.selectTab(oldEditor);
			return oldEditor;
		} else {
			final EntryEditorTab newEditor = new EntryEditorTab();
			newEditor.inputProperty.set(itemData);
			newEditor.ownerButton.setOnAction((event) -> this.openEntryOwner(itemData));
			this.selectTab(newEditor);
			return newEditor;
		}
	}

	final void openEntryOwner(final EntryData enrtyData) {
		this.selectEntry(this.openMappingData(EntryData.FIELD_Owner.get(enrtyData)).childrenPane.entriesEditor.tableView, enrtyData);
	}

	final void openItemList(final List<ItemData> enrtyList) {
		for (final ItemData enrtyData: enrtyList) {
			this.openItemData(enrtyData);
		}
	}

	final ItemEditorTab openItemData(final ItemData itemData) {
		final ItemEditorTab oldEditor = (ItemEditorTab)this.findTab(itemData);
		if (oldEditor != null) {
			this.selectTab(oldEditor);
			return oldEditor;
		} else {
			final ItemEditorTab newEditor = new ItemEditorTab();
			newEditor.inputProperty.set(itemData);
			newEditor.toolPane.ownerButton.setOnAction((event) -> this.openItemOwner(itemData));
			this.selectTab(newEditor);
			return newEditor;
		}
	}

	final void openItemOwner(final ItemData itemData) {
		this.selectEntry(this.openListingData(ItemData.FIELD_Owner.get(itemData)).childrenPane.itemsEditor.tableView, itemData);
	}

}