package bee.creative.iam.editor.data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import javax.xml.bind.JAXB;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.util.Field;
import bee.creative.util.Fields;
import bee.creative.util.Getter;
import bee.creative.util.IO;
import bee.creative.util.Natives;
import bee.creative.util.Objects;
import bee.creative.util.Setter;

/** Diese Klasse implementiert das Wurzelelement der Domäne des IAM Editors.
 *
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */
@XmlType (propOrder = {"indexList"})
@XmlRootElement (name = "iam-project")
@XmlAccessorType (XmlAccessType.FIELD)
@SuppressWarnings ("javadoc")
public final class ProjectData {

	/** Diese Schnittstelle definiert einen {@link Setter} für eine {@link Object}-Eigenschaft eines {@link ProjectData}. */
	public static interface ProjectSetter extends Setter<ProjectData, Object> {
	}

	{}

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #indexList}. */
	public static final ObservableField<ProjectData, List<IndexData>> FIELD_IndexList =
		new ObservableField<>(Fields.setupField(ProjectData.nativeField("indexList"), (i) -> new ArrayList<>()));

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #disableRedo}. */
	public static final ObservableField<ProjectData, Boolean> FIELD_DisableRedo = ProjectData.observableField("disableRedo");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #disableUndo}. */
	public static final ObservableField<ProjectData, Boolean> FIELD_DisabledUndo = ProjectData.observableField("disableUndo");

	public static final String NAME_IndexList = "Verzeichnisse";

	/** Dieses Feld speichert den {@link Setter} zum {@link IO#outputWriterFrom(Object) Export} des Projekts. */
	public static final ProjectSetter SETTER_ExportXML = (thiz, file) -> {
		try {
			JAXB.marshal(thiz, IO.outputWriterFrom(file));
		} catch (final Exception cause) {
			throw new IllegalArgumentException(cause);
		}
	};

	/** Dieses Feld speichert den {@link Setter} zum {@link IO#inputReaderFrom(Object) Import} des Projekts. */
	public static final ProjectSetter SETTER_ImportXML = (thiz, file) -> {
		try {
			final ProjectData result = JAXB.unmarshal(IO.inputReaderFrom(file), ProjectData.class);
			final List<IndexData> indexList = ProjectData.FIELD_IndexList.get(result);
			for (final IndexData index: indexList) {
				index.owner = thiz;
				for (final ListingData listing: IndexData.FIELD_ListingList.get(index)) {
					listing.owner = index;
					for (final ItemData item: ListingData.FIELD_ItemList.get(listing)) {
						item.owner = listing;
					}
				}
				for (final MappingData mapping: IndexData.FIELD_MappingList.get(index)) {
					mapping.owner = index;
					for (final EntryData entry: MappingData.FIELD_EntryList.get(mapping)) {
						entry.owner = mapping;
					}
				}
			}
			ProjectData.FIELD_DisableRedo.set(thiz, Boolean.TRUE);
			ProjectData.FIELD_DisabledUndo.set(thiz, Boolean.TRUE);
			thiz.redoList.clear();
			thiz.undoList.clear();
			ProjectData.FIELD_IndexList.set(thiz, indexList);
		} catch (final Exception cause) {
			throw new IllegalArgumentException(cause);
		}
	};

	/** Dieses Feld speichert einen {@link Setter} zum Entfernen von Elementen aus {@link #indexList}. */
	public static final Setter<ProjectData, List<IndexData>> SETTER_RemoveIndex = (i, v) -> ProjectData.remove(i, v, ProjectData.FIELD_IndexList);

	/** Dieses Feld speichert einen {@link Getter} zur Ermittlung eines neuen Elements in {@link #indexList}. */
	public static final Getter<ProjectData, IndexData> GETTER_AppendIndex =
		(i) -> ProjectData.append(i, new IndexData(), IndexData.FIELD_Owner, ProjectData.FIELD_IndexList);

	public static final ProjectData INSTANCE = new ProjectData();

	{}

	static final <GValue> Field<ProjectData, GValue> nativeField(final String name) {
		return Fields.defaultField(Fields.nativeField(Natives.parseField(ProjectData.class, name)));
	}

	static final <GValue> ObservableField<ProjectData, GValue> observableField(final String name) {
		return new ObservableField<>(ProjectData.nativeField(name));
	}

	{}

	/** Diese Methode verschiebt die gegebenen Elemente in einer Kopie der gegebenen Liste um eins nach Vorn bzw. Hinten und gibt die so modifizierte Liste
	 * zurück.
	 *
	 * @param <GEntry> Typ der Elemente.
	 * @param entries Liste aller Elemente.
	 * @param selection Auswahl der zu verschiebenden Elemente.
	 * @param direction {@code true}, wenn die Auswahl in Richtung des Beginns verschoben werden soll.
	 * @return Ergebnisliste der Verschiebung. */
	public static <GEntry> List<GEntry> move(final List<GEntry> entries, final Set<?> selection, final boolean direction) {
		if (entries.isEmpty()) return entries;
		@SuppressWarnings ("unchecked")
		final GEntry[] result = (GEntry[])entries.toArray();
		final int length = result.length;
		boolean blocked = true;
		if (direction) {
			for (int i = 0; i < length; i++) {
				if (!selection.contains(result[i])) {
					blocked = false;
				} else if (!blocked) {
					final GEntry entry = result[i - 1];
					result[i - 1] = result[i];
					result[i] = entry;
				}
			}
		} else {
			for (int i = length - 1; i >= 0; i--) {
				if (!selection.contains(result[i])) {
					blocked = false;
				} else if (!blocked) {
					final GEntry entry = result[i + 1];
					result[i + 1] = result[i];
					result[i] = entry;
				}
			}
		}
		return Arrays.asList(result);
	}

	/** Diese Methode implementiert die {@link Setter} zum Anfügen von Elementen.
	 *
	 * @see #GETTER_AppendIndex
	 * @param <GOwner> Typ des Besitzers, dessen {@link Getter} aufgerufen wird.
	 * @param <GEntry> Typ der Elemente, die ergänzt werden sollen.
	 * @param owner Besitzer.
	 * @param entry neues Element.
	 * @param ownerField Datenfeld zur aktualisierung des Besitzers am gegebenen Element.
	 * @param entriesField Datenfeld zur Ermittlung der alten sowie aktualisierung der neuen Liste von Elementen am Besitzer.
	 * @return neues Element. */
	public static <GOwner, GEntry> GEntry append(final GOwner owner, final GEntry entry, final Field<? super GEntry, GOwner> ownerField,
		final Field<? super GOwner, List<GEntry>> entriesField) {
		final List<GEntry> oldEntries = entriesField.get(owner), newEntries = new ArrayList<>(oldEntries.size() + 1);
		newEntries.addAll(oldEntries);
		newEntries.add(entry);
		ownerField.set(entry, owner);
		ProjectData.logChange(entriesField, owner, newEntries);
		return entry;
	}

	/** Diese Methode implementiert die {@link Setter} zum Entfernen von Elementen.
	 *
	 * @see #SETTER_RemoveIndex
	 * @param <GOwner> Typ des Besitzers, dessen {@link Setter} aufgerufen wird.
	 * @param <GEntry> Typ der Elemente, die entfernt werden sollen.
	 * @param owner Besitzer.
	 * @param selection Elemente, die entfernt werden sollen.
	 * @param entriesField Datenfeld zur Ermittlung der alten sowie aktualisierung der neuen Liste von Elementen am Besitzer. */
	public static <GOwner, GEntry> void remove(final GOwner owner, final List<GEntry> selection, final Field<? super GOwner, List<GEntry>> entriesField) {
		final List<GEntry> entries = new ArrayList<>(entriesField.get(owner));
		entries.removeAll(new HashSet<>(selection));
		ProjectData.logChange(entriesField, owner, entries);
	}

	/** Diese Methode ist eine Abkürzung für {@code java.util.Objects.toString(object, "")}. */
	public static String toString(final Object object) {
		return java.util.Objects.toString(object, "");
	}

	{}

	/** Dieses Feld speichert den Zeitpunkt, bis zu welchem aufeinanderfolgende Änderungen der gleichen Eigenschaft in {@link #logChange(Setter, Object, Object)}
	 * gruppiert werden. */
	@XmlTransient
	long changeTime;

	/** Dieses Feld speichert die rekursionstiefe der Aufrufe von {@link #logChange(Setter, Object, Object)}, {@link #undoChange()} und {@link #redoChange()}. */
	@XmlTransient
	int changeDepth;

	/** Dieses Feld speichert die aktuell in {@link #logChange(Setter, Object, Object)} protokollierte Änderungsgruppe. */
	@XmlTransient
	ChangeGroup changeGroup;

	/** Dieses Feld speichert die Datenmodelle der Inhaltsverzeichnisse. */
	@XmlElement (name = "index")
	List<IndexData> indexList;

	/** Dieses Feld speichert die Liste der Änderungen, die wiederhergestellt werden können. */
	@XmlTransient
	final LinkedList<ChangeGroup> redoList = new LinkedList<>();

	/** Dieses Feld speichert die Liste der Änderungen, die rückgängig gemacht werden können. */
	@XmlTransient
	final LinkedList<ChangeGroup> undoList = new LinkedList<>();

	/** Dieses Feld ist nur dann {@code true}, wenn {@link #redoList} leer ist. */
	@XmlTransient
	boolean disableRedo = true;

	/** Dieses Feld ist nur dann {@code true}, wenn {@link #undoList} leer ist. */
	@XmlTransient
	boolean disableUndo = true;

	{}

	/** Diese Methode protokolliert alle Änderungen, die über {@link #logChange(Setter, Object, Object, Object)} während des {@link Setter#set(Object, Object)
	 * Setzens} der gegebenen {@link Setter Eigenschaft} der gegebenen Eingabe auf den gegebenen Wert angezeigt werden.
	 *
	 * @param <GInput> Typ der Eingabe des {@link Setter}.
	 * @param <GValue> Typ des Werts des {@link Setter}.
	 * @param setter {@link Setter}.
	 * @param input Eingabe.
	 * @param value Wert. */
	public static <GInput, GValue> void logChange(final Setter<? super GInput, ? super GValue> setter, final GInput input, final GValue value) {
		final ProjectData thiz = ProjectData.INSTANCE;
		try {
			if (thiz.changeDepth == 0) {
				thiz.changeGroup = new ChangeGroup(input, setter);
			}
			thiz.changeDepth++;
			setter.set(input, value);
		} finally {
			thiz.changeDepth--;
			if (thiz.changeDepth == 0) {
				final ChangeGroup next = thiz.changeGroup;
				thiz.changeGroup = null;
				if ((next != null) && !next.changes.isEmpty()) {
					final ChangeGroup prev = thiz.undoList.peek();
					final long time = System.currentTimeMillis();
					if ((prev != null) && Objects.equals(prev.setter, next.setter) && Objects.equals(prev.input, next.input) && (time < thiz.changeTime)) {
						next.changes.addAll(0, prev.changes);
						thiz.undoList.set(0, next);
					} else {
						thiz.undoList.add(0, next);
					}
					thiz.changeTime = time + 500;
					next.compact();
					thiz.redoList.clear();
					ProjectData.FIELD_DisableRedo.set(thiz, Boolean.TRUE);
					ProjectData.FIELD_DisabledUndo.set(thiz, Boolean.FALSE);
					System.out.println(next);
				}
			}
		}
	}

	/** Diese Methode erfasst die Änderung der über den gegebenen {@link Setter} modifizierbaren Eigenschaft der gegebenen Eingabe, sofern {@link #changeGroup}
	 * nicht {@code null} ist.
	 *
	 * @param <GInput> Typ der Eingabe.
	 * @param <GValue> Typ des Werts der Eigenschaft.
	 * @param setter {@link Setter} der Eigenschaft.
	 * @param input Eingabe.
	 * @param oldValue alter Wert.
	 * @param newValue neuer Wert. */
	public static <GInput, GValue> void logChange(final Setter<? super GInput, ? super GValue> setter, final GInput input, final GValue oldValue,
		final GValue newValue) {
		final ProjectData thiz = ProjectData.INSTANCE;
		if (thiz.changeGroup == null) return;
		thiz.changeGroup.changes.add(new ChangeEntry<>(input, setter, oldValue, newValue));
	}

	/** Diese Methode mach die letzte {@link #logChange(Setter, Object, Object) erfasste} Änderung rückgängig. */
	public static void redoChange() {
		final ProjectData thiz = ProjectData.INSTANCE;
		if (thiz.changeDepth != 0) return;
		try {
			thiz.changeDepth++;
			final ChangeGroup group = thiz.redoList.poll();
			if (group == null) return;
			group.redo();
			thiz.undoList.push(group);
			ProjectData.FIELD_DisableRedo.set(thiz, Boolean.valueOf(thiz.redoList.isEmpty()));
			ProjectData.FIELD_DisabledUndo.set(thiz, Boolean.FALSE);
		} finally {
			thiz.changeDepth--;
		}
	}

	/** Diese Methode wiederholt die letzte {@link #undoChange() rückgängig gemachte} Änderung. */
	public static void undoChange() {
		final ProjectData thiz = ProjectData.INSTANCE;
		if (thiz.changeDepth != 0) return;
		try {
			thiz.changeDepth++;
			final ChangeGroup group = thiz.undoList.poll();
			if (group == null) return;
			group.undo();
			thiz.redoList.push(group);
			ProjectData.FIELD_DisableRedo.set(thiz, Boolean.FALSE);
			ProjectData.FIELD_DisabledUndo.set(thiz, Boolean.valueOf(thiz.undoList.isEmpty()));
		} finally {
			thiz.changeDepth--;
		}
	}

	/** Diese Methode entfernt alle Inhaltsverzeichnisse und Änderungen. */
	public static void clearProject() {
		final ProjectData thiz = ProjectData.INSTANCE;
		ProjectData.FIELD_DisableRedo.set(thiz, Boolean.TRUE);
		ProjectData.FIELD_DisabledUndo.set(thiz, Boolean.TRUE);
		thiz.redoList.clear();
		thiz.undoList.clear();
		ProjectData.FIELD_IndexList.set(thiz, null);
	}

}