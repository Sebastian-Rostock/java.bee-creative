package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.EditorMain;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.util.Field;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.ComboBoxTableCell;

/** Diese Klasse implementiert eine {@link TableColumn} zur Bearbeitung eines {@link Enum}-{@link Field Datenfelds} der Elemente einer Tabelle.
 *
 * @param <GEntry> Typ der Elemente der Tabelle.
 * @param <GValue> Typ des {@link Enum}. */
@SuppressWarnings ("javadoc")
public class CustomValueColumn<GEntry, GValue> extends TableColumn<GEntry, GValue> {

	public CustomValueColumn(final ObservableField<? super GEntry, GValue> valueField, final GValue[] values) {
		this(valueField, values, valueField);
	}

	public CustomValueColumn(final Field<? super GEntry, GValue> valueField, final GValue[] values, final ObservableField<?, ?> observableField) {
		this.setCellFactory(ComboBoxTableCell.forTableColumn(values));
		this.setCellValueFactory(EditorMain.factory(valueField, observableField));
		this.setOnEditCommit(EditorMain.handler(valueField));
	}

}