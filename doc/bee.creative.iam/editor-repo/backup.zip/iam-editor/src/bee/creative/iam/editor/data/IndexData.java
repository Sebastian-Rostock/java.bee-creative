package bee.creative.iam.editor.data;

import java.io.OutputStream;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import bee.creative.iam.IAMBuilder.IAMIndexBuilder;
import bee.creative.iam.IAMCodec;
import bee.creative.iam.IAMCodec.IAMByteOrder;
import bee.creative.iam.IAMCodec.IAMDataType;
import bee.creative.iam.IAMIndex;
import bee.creative.iam.IAMListing;
import bee.creative.iam.IAMMapping;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.util.Field;
import bee.creative.util.Fields;
import bee.creative.util.Getter;
import bee.creative.util.IO;
import bee.creative.util.Iterables;
import bee.creative.util.Objects;
import bee.creative.util.Setter;

/** Diese Klasse implementiert die Nutzdaten eines {@link IAMIndex}. */
@XmlType (propOrder = {"listingList", "mappingList"})
@XmlRootElement (name = "iam-index")
@XmlAccessorType (XmlAccessType.FIELD)
@SuppressWarnings ("javadoc")
public final class IndexData extends BaseData {

	/** Diese Schnittstelle definiert einen {@link Setter} für eine {@link Object}-Eigenschaft eines {@link IndexData}. */
	public static interface IndexSetter extends Setter<IndexData, Object> {
	}

	{}

	/** Dieses Feld speichert das {@link Field} zu {@link #owner}. */
	public static final Field<IndexData, ProjectData> FIELD_Owner = IndexData.nativeField("owner");

	/** Dieses Feld speichert das {@link Field} zur dieses Objekt verwaltenden Liste im {@link #owner}. */
	public static final Field<IndexData, List<IndexData>> FIELD_OwnerList = Fields.navigatedField(IndexData.FIELD_Owner, ProjectData.FIELD_IndexList);

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #index}. */
	public static final ObservableField<IndexData, Integer> FIELD_Index = BaseData.indexField(IndexData.FIELD_OwnerList);

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #byteorder}. */
	public static final ObservableField<IndexData, IAMByteOrder> FIELD_Byteorder = IndexData.observableField("byteorder");

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #listingList}. */
	public static final ObservableField<IndexData, List<ListingData>> FIELD_ListingList =
		new ObservableField<>(Fields.setupField(IndexData.nativeField("listingList"), (i) -> new ArrayList<>()));

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #mappingList}. */
	public static final ObservableField<IndexData, List<MappingData>> FIELD_MappingList =
		new ObservableField<>(Fields.setupField(IndexData.nativeField("mappingList"), (i) -> new ArrayList<>()));

	public static final String NAME_Byteorder = "Bytereihenfolge";

	public static final String NAME_ListingList = "Auflistungen";

	public static final String NAME_MappingList = "Abbildungen";

	/** Dieses Feld speichert den {@link Setter} zum Import von Auflistungen und Abbildungen aus gegebenen {@link IAMIndex#from(Object) IAM-Daten}. */
	public static final IndexSetter SETTER_ImportIAM = (thiz, file) -> {
		try {
			final IAMIndex index = IAMIndex.from(file);
			final List<ListingData> listingList = new ArrayList<>(IndexData.FIELD_ListingList.get(thiz));
			for (final IAMListing listing: index.listings()) {
				final ListingData listingData = new ListingData();
				listingData.owner = thiz;
				listingData.index = listingList.size();
				ListingData.SETTER_ImportIAM.set(listingData, listing);
				listingList.add(listingData);
			}
			IndexData.FIELD_ListingList.set(thiz, listingList);
			final List<MappingData> mappingList = new ArrayList<>(IndexData.FIELD_MappingList.get(thiz));
			for (final IAMMapping mapping: index.mappings()) {
				final MappingData mappingData = new MappingData();
				mappingData.owner = thiz;
				mappingData.index = mappingList.size();
				MappingData.SETTER_ImportIAM.set(mappingData, mapping);
				mappingList.add(mappingData);
			}
			IndexData.FIELD_MappingList.set(thiz, mappingList);
		} catch (final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert den {@link Setter} zum Import von Auflistungen und Abbildungen aus gegebenen {@link IAMDataType#INI INI-Daten}. */
	public static final IndexSetter SETTER_ImportINI = (thiz, file) -> {
		try {
			IndexData.SETTER_ImportIAM.set(thiz, new IAMCodec().useSourceData(file).useSourceFormat(IAMDataType.INI).decodeSource());
		} catch (final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert den {@link Setter} zum Import von Auflistungen und Abbildungen aus gegebenen {@link IAMDataType#XML XML-Daten}. */
	public static final IndexSetter SETTER_ImportXML = (thiz, file) -> {
		try {
			IndexData.SETTER_ImportIAM.set(thiz, new IAMCodec().useSourceData(file).useSourceFormat(IAMDataType.XML).decodeSource());
		} catch (final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert den {@link Setter} zum Export der Elemente in eine gegebenen {@link IO#outputStreamFrom(Object) IAM-Datei}. */
	public static final IndexSetter SETTER_ExportIAM = (thiz, file) -> {
		final byte[] bytes = thiz.toBytes();
		try (OutputStream stream = IO.outputStreamFrom(file)) {
			stream.write(bytes);
		} catch (final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert den {@link Setter} zum Export der Elemente in eine gegebenen {@link IAMDataType#INI IAM-Datei}. */
	public static final IndexSetter SETTER_ExportINI = (thiz, file) -> {
		try {
			new IAMCodec().useTargetData(file).useTargetFormat(IAMDataType.INI).encodeTarget(thiz.toIndex());
		} catch (final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert den {@link Setter} zum Export der Elemente in eine gegebenen {@link IAMDataType#XML XML-Datei}. */
	public static final IndexSetter SETTER_ExportXML = (thiz, file) -> {
		try {
			new IAMCodec().useTargetData(file).useTargetFormat(IAMDataType.XML).encodeTarget(thiz.toIndex());
		} catch (final Exception cause) {
			throw new IllegalStateException(cause);
		}
	};

	/** Dieses Feld speichert einen {@link Setter} zum Entfernen von Elementen aus {@link #listingList}. */
	public static final Setter<IndexData, List<ListingData>> SETTER_removeListing = //
		(i, v) -> ProjectData.remove(i, v, IndexData.FIELD_ListingList);

	/** Dieses Feld speichert einen {@link Setter} zum Entfernen von Elementen aus {@link #mappingList}. */
	public static final Setter<IndexData, List<MappingData>> SETTER_removeMapping = //
		(i, v) -> ProjectData.remove(i, v, IndexData.FIELD_MappingList);

	/** Dieses Feld speichert einen {@link Getter} zur Ermittlung eines neuen Elements in {@link #listingList}. */
	public static final Getter<IndexData, ListingData> GETTER_appendListing = //
		(i) -> ProjectData.append(i, new ListingData(), ListingData.FIELD_Owner, IndexData.FIELD_ListingList);

	/** Dieses Feld speichert einen {@link Getter} zur Ermittlung eines neuen Elements in {@link #mappingList}. */
	public static final Getter<IndexData, MappingData> GETTER_appendMapping = //
		(i) -> ProjectData.append(i, new MappingData(), MappingData.FIELD_Owner, IndexData.FIELD_MappingList);

	{}

	static final <GValue> Field<IndexData, GValue> nativeField(final String name) {
		return BaseData.nativeField(IndexData.class, name);
	}

	static final <GValue> ObservableField<IndexData, GValue> observableField(final String name) {
		return new ObservableField<>(IndexData.nativeField(name));
	}

	{}

	/** Dieses Feld speichert den Besitzer, der dieses Objekt in einer Liste verwaltet. */
	@XmlTransient
	ProjectData owner;

	/** Dieses Feld speichert die Bytereihenfolge. */
	@XmlAttribute
	IAMByteOrder byteorder = IAMByteOrder.AUTO;

	/** Dieses Feld speichert die Datenmodelle der Auflistungen. */
	@XmlElement (name = "listing")
	List<ListingData> listingList;

	/** Dieses Feld speichert die Datenmodelle der Abbildungen. */
	@XmlElement (name = "mapping")
	List<MappingData> mappingList;

	{}

	/** Diese Methode gibt die Daten des Verzeichnisses als Bytefolge zurück. */
	public byte[] toBytes() {
		return this.toIndex().toBytes(this.toOrder());
	}

	/** Diese Methode gibt die Daten des Verzeichnisses als {@link IAMIndex} zurück. */
	public IAMIndex toIndex() {
		final IAMIndexBuilder builder = new IAMIndexBuilder();
		for (final ListingData listing: Iterables.iterable(this.listingList)) {
			builder.putListing(listing.toListing());
		}
		for (final MappingData mapping: Iterables.iterable(this.mappingList)) {
			builder.putMapping(mapping.toMapping());
		}
		return builder;
	}

	/** Diese Methode gibt die konfigurierte Bytereihenfolge zurück. */
	public ByteOrder toOrder() {
		return IAMByteOrder.from(this.byteorder).toOrder();
	}

	{}

	@Override
	public String toString() {
		return Objects.toInvokeString("index", this.listingList, this.mappingList);
	}

}