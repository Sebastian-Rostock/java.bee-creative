package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.EditorMain;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.util.Field;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.IntegerStringConverter;

/** Diese Klasse implementiert eine {@link TableColumn} zur Bearbeitung eines {@link Integer}-{@link Field Datenfelds} der Elemente einer Tabelle.
 *
 * @param <GEntry> Typ der Elemente der Tabelle. */
@SuppressWarnings ("javadoc")
public class CustomIntegerColumn<GEntry> extends TableColumn<GEntry, Integer> {

	public CustomIntegerColumn(final ObservableField<? super GEntry, Integer> valueField) {
		this(valueField, valueField);
	}

	public CustomIntegerColumn(final Field<? super GEntry, Integer> valueField, final ObservableField<?, ?> observableField) {
		this.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
		this.setCellValueFactory(EditorMain.factory(valueField, observableField));
		this.setOnEditCommit(EditorMain.handler(valueField));
	}

}