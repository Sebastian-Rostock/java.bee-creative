package bee.creative.iam.editor;

import bee.creative.iam.IAMCodec.IAMArrayFormat;
import bee.creative.iam.editor.custom.CustomTitledComboboxPane;
import bee.creative.iam.editor.custom.CustomTitledTextareaPane;
import bee.creative.iam.editor.custom.CustomToggleButton;
import bee.creative.iam.editor.data.ArrayData;
import bee.creative.util.Fields;
import bee.creative.util.Getter;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.layout.VBox;

/** Diese Klasse implementiert einen Editor zur Bearbeitung eins {@link ArrayData} der Eingabe.
 *
 * @param <GInput> Typ der Eingabe. */
@SuppressWarnings ("javadoc")
public class ArrayDataEditor<GInput> extends VBox {

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_Array}. */
	public final CustomTitledTextareaPane<GInput> arrayEditor;

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_String}. */
	public final CustomTitledTextareaPane<GInput> stringEditor;

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_Format}. */
	public final CustomTitledComboboxPane<GInput, IAMArrayFormat> formatEditor;

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_UpdateArray}. */
	public final CustomToggleButton<GInput> updateArrayEditor;

	/** Dieses Feld speichert den Editor für {@link ArrayData#FIELD_UpdateString}. */
	public final CustomToggleButton<GInput> updateStringEditor;

	/** Dieses Feld speichert das {@link Property} der Eingabe des Editors. */
	public final Property<GInput> inputProperty = new SimpleObjectProperty<>();

	public ArrayDataEditor(final Getter<? super GInput, ArrayData> arrayGetter) {
		this.arrayEditor = new CustomTitledTextareaPane<>(ArrayData.NAME_Array, ArrayData.FIELD_Array, //
			Fields.navigatedField(arrayGetter, ArrayData.FIELD_Array));
		this.arrayEditor.inputProperty.bind(this.inputProperty);
		this.updateArrayEditor = new CustomToggleButton<>(EditorMain.IMAGE_Action_Lower, ArrayData.FIELD_UpdateArray, //
			Fields.navigatedField(arrayGetter, ArrayData.FIELD_UpdateArray));
		this.updateArrayEditor.inputProperty.bind(this.inputProperty);
		this.updateStringEditor = new CustomToggleButton<>(EditorMain.IMAGE_Action_Raise, ArrayData.FIELD_UpdateString, //
			Fields.navigatedField(arrayGetter, ArrayData.FIELD_UpdateString));
		this.updateStringEditor.inputProperty.bind(this.inputProperty);
		this.formatEditor = new CustomTitledComboboxPane<>(ArrayData.NAME_Format, ArrayData.FIELD_Format, IAMArrayFormat.values(), //
			Fields.navigatedField(arrayGetter, ArrayData.FIELD_Format));
		this.formatEditor.inputProperty.bind(this.inputProperty);
		this.formatEditor.titlePane.getChildren().addAll(this.updateArrayEditor, this.updateStringEditor);
		this.stringEditor = new CustomTitledTextareaPane<>(ArrayData.NAME_String, ArrayData.FIELD_String, //
			Fields.navigatedField(arrayGetter, ArrayData.FIELD_String));
		this.stringEditor.inputProperty.bind(this.inputProperty);
		this.setSpacing(EditorMain.LAYOUT_Spacing);
		this.getChildren().addAll(this.arrayEditor, this.formatEditor, this.stringEditor);
	}

	public ArrayDataEditor(final String arrayText, final String formatText, final String stringText, final Getter<? super GInput, ArrayData> arrayGetter) {
		this(arrayGetter);
		this.arrayEditor.titleLabel.setText(arrayText);
		this.formatEditor.titleLabel.setText(formatText);
		this.stringEditor.titleLabel.setText(stringText);
	}

}