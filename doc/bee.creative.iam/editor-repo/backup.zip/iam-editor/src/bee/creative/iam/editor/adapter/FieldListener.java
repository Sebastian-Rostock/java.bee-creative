package bee.creative.iam.editor.adapter;

/** Diese Schnittstelle definiert eine Methode zur Behandlung der Änderung des Werts eines {@link ObservableField überwachenden Datenfelds}.
 *
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]
 * @param <GInput> Typ der Eingabe. */
public interface FieldListener<GInput> {

	/** Diese Methode wird bei Änderung des Werts eine {@link ObservableField überwachenden Datenfelds} der gegebenne Eingabe aufgerufen.
	 *
	 * @param input Eingabe. */
	public void fieldChanged(GInput input);

}