package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.iam.editor.adapter.PropertyAdapter;
import bee.creative.util.Field;
import javafx.beans.property.Property;
import javafx.scene.control.ComboBox;

/** Diese Klasse implementiert ein {@link CustomTitledPane} mit einem Steuerelement zur Bearbeitung einer einwertigen der Eingabe, wobei der Wert dieser
 * Eigenschaft aus einer gegebenen Aufzählung stammt, z.B. einem {@link Enum}.
 *
 * @param <GInput> Typ der Eingabe.
 * @param <GValue> Typ des Werts. */
@SuppressWarnings ("javadoc")
public class CustomTitledComboboxPane<GInput, GValue> extends CustomTitledPane {

	/** Dieses Feld speichert das Steuerelement zur Wertauswahl. */
	public final ComboBox<GValue> valueEditor;

	/** Dieses Feld speichert den {@link PropertyAdapter}, der den Wert des {@link #valueEditor} über ein gegebenes {@link ObservableField} anbindet. */
	public final PropertyAdapter<GInput, GValue> valueProperty;

	/** Dieses Feld speichert das {@link Property} zur Eingabe des {@link #valueProperty}. */
	public final Property<GInput> inputProperty;

	public CustomTitledComboboxPane(final Field<? super GInput, GValue> valueField) {
		this.valueEditor = new ComboBox<>();
		this.valueEditor.setMaxWidth(Double.MAX_VALUE);
		this.valueProperty = new PropertyAdapter<>(valueField);
		this.valueProperty.bindBidirectional(this.valueEditor.valueProperty());
		this.inputProperty = this.valueProperty.inputProperty;
		this.contentPane.getChildren().add(this.valueEditor);
	}

	public CustomTitledComboboxPane(final String titleText, final ObservableField<?, ?> observableField, final GValue[] values,
		final Field<? super GInput, GValue> valueField) {
		this(valueField);
		this.titleLabel.setText(titleText);
		this.valueEditor.getItems().addAll(values);
		this.valueProperty.useObservable(observableField);
	}

}