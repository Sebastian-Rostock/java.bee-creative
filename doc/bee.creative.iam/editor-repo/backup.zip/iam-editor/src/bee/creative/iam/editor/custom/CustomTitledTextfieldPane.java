package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.iam.editor.adapter.PropertyAdapter;
import bee.creative.util.Field;
import javafx.beans.property.Property;
import javafx.scene.control.TextField;

/** Diese Klasse implementiert ein {@link CustomTitledPane} mit einem Steuerelement zur Bearbeitung einer einzeiligen Texteigenschaft der Eingabe.
 *
 * @param <GInput> Typ der Eingabe. */
@SuppressWarnings ("javadoc")
public class CustomTitledTextfieldPane<GInput> extends CustomTitledPane {

	/** Dieses Feld speichert das Steuerelement zur Texteingabe. */
	public final TextField valueEditor;

	/** Dieses Feld speichert den {@link PropertyAdapter}, der den Wert des {@link #valueEditor} über ein gegebenes {@link ObservableField} anbindet. */
	public final PropertyAdapter<GInput, String> valueProperty;

	/** Dieses Feld speichert das {@link Property} zur Eingabe des {@link #valueProperty}. */
	public final Property<GInput> inputProperty;

	public CustomTitledTextfieldPane(final Field<? super GInput, String> valueField) {
		this.valueEditor = new TextField();
		this.valueProperty = new PropertyAdapter<>(valueField);
		this.valueProperty.bindBidirectional(this.valueEditor.textProperty());
		this.inputProperty = this.valueProperty.inputProperty;
		this.contentPane.getChildren().add(this.valueEditor);
	}

	public CustomTitledTextfieldPane(final String titleText, final ObservableField<?, ?> observableField, final Field<? super GInput, String> valueField) {
		this(valueField);
		this.titleLabel.setText(titleText);
		this.valueProperty.useObservable(observableField);
	}

}