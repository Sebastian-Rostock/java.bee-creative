package bee.creative.iam.editor.custom;

import java.util.ArrayList;
import java.util.List;
import bee.creative.iam.editor.adapter.ListAdapter;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.iam.editor.adapter.PropertyAdapter;
import bee.creative.iam.editor.adapter.ValueAdapter;
import javafx.beans.Observable;
import javafx.beans.property.Property;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableView;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

/** Diese Klasse implementiert eine {@link CustomTitledPane} mit einem {@link TableView}.
 *
 * @param <GInput> Typ der Eingabe.
 * @param <GItem> Tyo der Elemente in der Tabelle. */
@SuppressWarnings ("javadoc")
public class CustomTitledTablePane<GInput, GItem> extends CustomTitledPane {

	/** Dieses Feld speichert die Tabelle, deren Elemente über {@link #itemsAdapter} bereitgestellt werden. */
	public final TableView<GItem> tableView;

	/** Dieses Feld speichert den {@link PropertyAdapter}, der die Elemente der {@link #tableView} über ein gegebnes {@link ObservableField} anbindet. */
	public final ListAdapter<GInput, GItem> itemsAdapter;

	/** Dieses Feld speichert das {@link Property} zur Eingabe des {@link #itemsAdapter}. */
	public final Property<GInput> inputProperty;

	/** Dieses Feld speichert den {@link ValueAdapter} zur {@link MultipleSelectionModel#getSelectedItems() Auswahl} im {@link #tableView}. */
	public final ValueAdapter<GInput, List<GItem>> selectionAdapter;

	public CustomTitledTablePane(final ObservableField<? super GInput, List<GItem>> itemsField) {
		this.tableView = new TableView<>();
		this.itemsAdapter = new ListAdapter<>(itemsField, this.tableView.getItems());
		this.itemsAdapter.useObservable(itemsField);
		this.inputProperty = this.itemsAdapter.inputProperty;
		this.selectionAdapter = new ValueAdapter<>(input -> new ArrayList<>(this.tableView.getSelectionModel().getSelectedItems()));
		this.selectionAdapter.inputProperty.bind(this.inputProperty);
		this.tableView.setEditable(true);
		this.tableView.setMaxHeight(Double.MAX_VALUE);
		this.tableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		this.tableView.getSelectionModel().getSelectedItems().addListener((final Observable observable) -> this.selectionAdapter.invalidate());
		this.contentPane.getChildren().add(this.tableView);
		VBox.setVgrow(this.tableView, Priority.ALWAYS);
	}

}