package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.EditorMain;
import javafx.beans.binding.ObjectExpression;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleObjectProperty;
import javafx.geometry.Insets;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tab;
import javafx.scene.layout.VBox;

/** Diese Klasse implementiert einen {@link Tab} mit {@link #contentScroller Bildlauf} und {@link #inputProperty Eingabe}.
 *
 * @param <GInput> Typ der Eingabe. */
@SuppressWarnings ("javadoc")
public class CustomTab<GInput> extends Tab {

	/** Dieses Feld speichert das {@link Property} der Eingabe des Editors. */
	public final ObjectProperty<GInput> inputProperty = new SimpleObjectProperty<>();

	/** Dieses Feld speichert die {@link VBox} mit den Steuerelementen des Formulars. */
	public final VBox contentPane = new VBox();

	/** Dieses Feld speichert die für {@link #contentProperty()} verwendete {@link ScrollPane} zum Bildlauf von {@link #contentPane}. */
	public final ScrollPane contentScroller = new ScrollPane();

	public CustomTab() {
		this.contentPane.setPadding(new Insets(EditorMain.LAYOUT_Spacing));
		this.contentPane.setSpacing(EditorMain.LAYOUT_Spacing);
		this.contentPane.setMaxHeight(Double.MAX_VALUE);
		this.contentPane.disableProperty().bind(ObjectExpression.objectExpression(this.inputProperty).isNull());
		this.contentScroller.setContent(this.contentPane);
		this.contentScroller.setFitToWidth(true);
		this.contentScroller.setFitToHeight(true);
		this.setContent(this.contentScroller);
	}

}