package bee.creative.iam.editor.data;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import bee.creative.iam.IAMListing;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.util.Field;
import bee.creative.util.Fields;
import bee.creative.util.Getter;
import bee.creative.util.Objects;

/** Diese Klasse implementiert das Datenmodell eins Elements eines {@link IAMListing}. */
@XmlType
@XmlAccessorType (XmlAccessType.FIELD)
@SuppressWarnings ("javadoc")
public final class ItemData extends BaseData {

	/** Dieses Feld speichert das {@link Field} zu {@link #owner}. */
	public static final Field<ItemData, ListingData> FIELD_Owner = ItemData.nativeField("owner");

	/** Dieses Feld speichert das {@link Field} zur dieses Objekt verwaltenden Liste im {@link #owner}. */
	public static final Field<ItemData, List<ItemData>> FIELD_OwnerList = Fields.navigatedField(ItemData.FIELD_Owner, ListingData.FIELD_ItemList);

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #index}. */
	public static final ObservableField<ItemData, Integer> FIELD_Index = BaseData.indexField(ItemData.FIELD_OwnerList);

	public static final String NAME_Data = "Daten";

	public static final String NAME_DataArray = "Daten-Zahlenfolge";

	public static final String NAME_DataString = "Daten-Zeichenkette";

	public static final String NAME_DataFormat = "Daten-Format";

	public static final String NAME_DataUpdateArray = "Daten-Zeichenkette-Parsen";

	public static final String NAME_DataUpdateString = "Daten-Zahlenfolge-Formatieren";

	/** Dieses Feld speichert die Kopfzeile der CSV-Datei. */
	public static final String[] HEADER_CSV = {BaseData.NAME_Name, ItemData.NAME_DataArray, ItemData.NAME_DataString, ItemData.NAME_DataFormat,
		ItemData.NAME_DataUpdateArray, ItemData.NAME_DataUpdateString};

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #data}. */
	public static final Getter<ItemData, ArrayData> GETTER_Data = Fields.setupField(ItemData.nativeField("data"), (i) -> new ArrayData());

	{}

	static final <GValue> Field<ItemData, GValue> nativeField(final String name) {
		return nativeField(ItemData.class, name);
	}

	static final <GValue> ObservableField<ItemData, GValue> observableField(final String name) {
		return new ObservableField<>(ItemData.nativeField(name));
	}

	{}

	/** Dieses Feld speichert den Besitzer, der dieses Objekt in einer Liste verwaltet. */
	@XmlTransient
	ListingData owner;

	/** Dieses Feld speichert die Daten des Elements. */
	@XmlElement
	ArrayData data;

	{}

	@Override
	public String toString() {
		return Objects.toInvokeString("", this.name);
	}

}