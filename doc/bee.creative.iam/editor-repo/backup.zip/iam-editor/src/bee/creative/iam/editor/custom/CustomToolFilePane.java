package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.EditorMain;
import javafx.scene.image.Image;

/** Diese Klasse erweitert eine {@link CustomToolPane} um zwei Steuerelemente zum Im- und Exportieren in das bearbeitete Objekts.
 * 
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */
@SuppressWarnings ("javadoc")
public class CustomToolFilePane extends CustomToolPane {

	/** Dieses Feld speichert den {@link CustomButton} zum Importieren in das bearbeitete Objekt. */
	public final CustomButton importButton;

	/** Dieses Feld speichert den {@link CustomButton} zum Exportieren des bearbeiteten Objekts. */
	public final CustomButton exportButton;

	public CustomToolFilePane(final Image ownerImage, final String ownerText) {
		super(ownerImage, ownerText);
		this.importButton = new CustomButton(EditorMain.IMAGE_Action_Import, "Importieren...");
		this.exportButton = new CustomButton(EditorMain.IMAGE_Action_Export, "Exportieren...");
		this.getChildren().addAll(this.importButton, this.exportButton);
	}

}
