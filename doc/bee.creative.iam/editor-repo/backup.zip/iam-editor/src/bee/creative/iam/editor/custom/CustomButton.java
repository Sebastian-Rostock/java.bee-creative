package bee.creative.iam.editor.custom;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/** Diese Klasse implementiert einen {@link Button} zur Darstellung einer Grafik links von der Beschriftung.
 *
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */
@SuppressWarnings ("javadoc")
public class CustomButton extends Button {

	public CustomButton() {
		this.setCursor(Cursor.HAND);
		this.setAlignment(Pos.CENTER_LEFT);
		this.setMaxWidth(Double.MAX_VALUE);
		this.setPadding(new Insets(3));
	}

	public CustomButton(final Image image) {
		this();
		this.setGraphic(new ImageView(image));
	}

	public CustomButton(final Image image, final String text) {
		this(image);
		this.setText(text);
	}

}