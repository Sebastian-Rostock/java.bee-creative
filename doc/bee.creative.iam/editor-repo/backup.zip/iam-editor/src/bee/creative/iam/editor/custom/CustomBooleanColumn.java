package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.iam.editor.adapter.PropertyAdapter;
import bee.creative.util.Field;
import javafx.beans.property.BooleanProperty;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.CheckBoxTableCell;

/** Diese Klasse implementiert eine {@link TableColumn} zur Bearbeitung eines {@link Boolean}-{@link Field Datenfelds} der Elemente einer Tabelle.
 *
 * @param <GEntry> Typ der Elemente der Tabelle. */
@SuppressWarnings ("javadoc")
public class CustomBooleanColumn<GEntry> extends TableColumn<GEntry, Boolean> {

	public CustomBooleanColumn(final ObservableField<? super GEntry, Boolean> valueField) {
		this(valueField, valueField);
	}

	public CustomBooleanColumn(final Field<? super GEntry, Boolean> valueField, final ObservableField<?, ?> observableField) {
		this.setCellFactory(CheckBoxTableCell.forTableColumn(this));
		this.setCellValueFactory((event) -> BooleanProperty.booleanProperty(new PropertyAdapter<>(valueField) //
			.useInput(event.getValue()).useObservable(observableField)));
	}

}