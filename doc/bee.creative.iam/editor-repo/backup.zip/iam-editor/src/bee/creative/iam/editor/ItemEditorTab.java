package bee.creative.iam.editor;

import bee.creative.iam.editor.custom.CustomTab;
import bee.creative.iam.editor.custom.CustomTitledCollapsiblePane;
import bee.creative.iam.editor.custom.CustomTitledTextfieldPane;
import bee.creative.iam.editor.custom.CustomToolPane;
import bee.creative.iam.editor.data.BaseData;
import bee.creative.iam.editor.data.ItemData;
import bee.creative.util.Fields;
import javafx.beans.property.ObjectProperty;
import javafx.scene.image.ImageView;

/** Diese Klasse implementiert den {@link CustomTab} zur Bearbeitung eines {@link ItemData}. */
@SuppressWarnings ("javadoc")
public final class ItemEditorTab extends CustomTab<ItemData> {

	/** Diese Klasse implementiert die Werkzeugleiste des {@link ListingEditorTab}. */
	public final class ToolPane extends CustomToolPane {

		public ToolPane() {
			super(EditorMain.IMAGE_Editor_Listing, "Element in Tabelle bearbeiten...");
		}

	}

	/** Diese Klasse implementiert den Editor für die direkten Eigenschaften des {@link ItemData}. */
	public final class ParentPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link ItemData#FIELD_Index}. */
		public final CustomTitledTextfieldPane<ItemData> indexEditor;

		/** Dieses Feld speichert den Editor für {@link ItemData#FIELD_Name}. */
		public final CustomTitledTextfieldPane<ItemData> nameEditor;

		/** Dieses Feld speichert den Editor für {@link ItemData#FIELD_Name}. */
		public final ArrayDataEditor<ItemData> dataEditor;

		public ParentPane() {
			final ObjectProperty<ItemData> inputProperty = ItemEditorTab.this.inputProperty;
			this.indexEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Index, ItemData.FIELD_Index,
				Fields.translatedField(ItemData.FIELD_Index, EditorMain.GETTER_IntegerFormatter, EditorMain.GETTER_IntegerParser));
			this.indexEditor.inputProperty.bind(inputProperty);
			this.nameEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Name, BaseData.FIELD_Name, BaseData.FIELD_Name);
			this.nameEditor.inputProperty.bind(inputProperty);
			this.dataEditor = new ArrayDataEditor<>(ItemData.NAME_DataArray, ItemData.NAME_DataFormat, ItemData.NAME_DataString, ItemData.GETTER_Data);
			this.dataEditor.inputProperty.bind(inputProperty);
			this.contentPane.getChildren().addAll(this.indexEditor, this.nameEditor, this.dataEditor);
			this.setText("Attribute des Elements");
			this.setExpanded(true);
			this.setCollapsible(false);
		}

	}

	{}

	/** Dieses Feld speichert die {@link ToolPane}. */
	public final ToolPane toolPane;

	/** Dieses Feld speichert die {@link ParentPane}. */
	public final ParentPane parentPane;

	public ItemEditorTab() {
		this.toolPane = new ToolPane();
		this.parentPane = new ParentPane();
		this.contentPane.getChildren().addAll(this.toolPane, this.parentPane);
		this.contentScroller.setFitToHeight(false);
		this.setGraphic(new ImageView(EditorMain.IMAGE_Editor_Item));
		this.textProperty().bind(this.parentPane.nameEditor.valueEditor.textProperty());
	}

}