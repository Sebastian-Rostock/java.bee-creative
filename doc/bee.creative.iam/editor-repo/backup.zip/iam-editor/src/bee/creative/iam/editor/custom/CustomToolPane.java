package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.EditorMain;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;

/** Diese Klasse implementiert eine {@link HBox} mit einem linksbündigen {@link CustomButton} zur Navigation zum Besitzer des bearbeiteten Objekts. Neue
 * Steuerelemente werden gruppiert rechtsbündig ausgerichtet.
 * 
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */
@SuppressWarnings ("javadoc")
public class CustomToolPane extends HBox {

	/** Dieses Feld speichert den {@link CustomButton} zur Navigation zum Besitzer des bearbeiteten Objekts. */
	public final CustomButton ownerButton;

	/** Dieses Feld speichert den Platzhalter nach {@link #ownerButton}. */
	public final Pane ownerSeparator;

	public CustomToolPane(final Image ownerImage, final String ownerText) {
		super(EditorMain.LAYOUT_Gap);
		this.ownerButton = new CustomButton(ownerImage, ownerText);
		this.ownerSeparator = new Pane();
		this.getChildren().addAll(this.ownerButton, this.ownerSeparator);
		HBox.setHgrow(this.ownerSeparator, Priority.ALWAYS);
	}

}
