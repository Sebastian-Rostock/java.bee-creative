package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.EditorMain;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.util.Field;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.TextFieldTableCell;

/** Diese Klasse implementiert eine {@link TableColumn} zur Bearbeitung eines {@link String}-{@link Field Datenfelds} der Elemente einer Tabelle.
 *
 * @param <GEntry> Typ der Elemente der Tabelle. */
@SuppressWarnings ("javadoc")
public class CustomStringColumn<GEntry> extends TableColumn<GEntry, String> {

	public CustomStringColumn(final ObservableField<? super GEntry, String> valueField) {
		this(valueField, valueField);
	}

	public CustomStringColumn(final Field<? super GEntry, String> valueField, final ObservableField<?, ?> observableField) {
		this.setCellFactory(TextFieldTableCell.forTableColumn());
		this.setCellValueFactory(EditorMain.factory(valueField, observableField));
		this.setOnEditCommit(EditorMain.handler(valueField));
	}

}