package bee.creative.iam.editor;

import java.util.List;
import bee.creative.iam.IAMListing;
import bee.creative.iam.editor.custom.CustomButton;
import bee.creative.iam.editor.custom.CustomGridPane;
import bee.creative.iam.editor.custom.CustomIntegerColumn;
import bee.creative.iam.editor.custom.CustomStringColumn;
import bee.creative.iam.editor.custom.CustomTab;
import bee.creative.iam.editor.custom.CustomTitledCollapsiblePane;
import bee.creative.iam.editor.custom.CustomTitledLabelPane;
import bee.creative.iam.editor.custom.CustomTitledOrderableTablePane;
import bee.creative.iam.editor.custom.CustomTitledTextfieldPane;
import bee.creative.iam.editor.custom.CustomToolFilePane;
import bee.creative.iam.editor.data.BaseData;
import bee.creative.iam.editor.data.ItemData;
import bee.creative.iam.editor.data.ListingData;
import bee.creative.iam.editor.data.ListingData.ListingSetter;
import bee.creative.util.Fields;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser.ExtensionFilter;

/** Diese Klasse implementiert den {@link CustomTab} zur Bearbeitung eines {@link ListingData}. */
@SuppressWarnings ("javadoc")
public final class ListingEditorTab extends CustomTab<ListingData> {

	/** Diese Klasse implementiert die Werkzeugleiste des {@link ListingEditorTab}. */
	public final class ToolPane extends CustomToolFilePane {

		public ToolPane() {
			super(EditorMain.IMAGE_Editor_Index, "Auflistung in Tabelle bearbeiten...");
			this.exportButton.setOnAction(event -> ListingEditorTab.this.onExportAction());
			this.importButton.setOnAction(event -> ListingEditorTab.this.onImportAction());
		}

	}

	/** Diese Klasse implementiert einen Editor zur aktualisierung statistischer Informationen der gegebenen {@link ListingData}. */
	public final class InfosPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_Errorinfo}. */
		public final CustomTitledLabelPane<ListingData> errorinfoEditor;

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_Itemfindinfo}. */
		public final CustomTitledLabelPane<ListingData> itemfindinfoEditor;

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_Itemcountinfo}. */
		public final CustomTitledLabelPane<ListingData> itemcountinfoEditor;

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_Datalengthinfo}. */
		public final CustomTitledLabelPane<ListingData> datalengthinfoEditor;

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_Datacontentinfo}. */
		public final CustomTitledLabelPane<ListingData> datacontentinfoEditor;

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_Byteslengthinfo}. */
		public final CustomTitledLabelPane<ListingData> byteslengthinfoEditor;

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_Bytesheaderinfo}. */
		public final CustomTitledLabelPane<ListingData> bytesheaderinfoEditor;

		/** Dieses Feld speichert {@link CustomButton} zu {@link #onUpdateAction()}. */
		public final CustomButton updateinfoButton;

		/** Dieses Feld speichert die {@link CustomGridPane} zur Positionierung der Steuerelemente. */
		public final CustomGridPane contentPane2;

		public InfosPane() {
			final ObjectProperty<ListingData> inputProperty = ListingEditorTab.this.inputProperty;
			this.itemcountinfoEditor = new CustomTitledLabelPane<>("Anzahl der Elemente", ListingData.FIELD_Itemcountinfo);
			this.itemcountinfoEditor.inputProperty.bind(inputProperty);
			this.itemfindinfoEditor = new CustomTitledLabelPane<>("Suchzeit eines Elements", ListingData.FIELD_Itemfindinfo);
			this.itemfindinfoEditor.inputProperty.bind(inputProperty);
			this.datacontentinfoEditor = new CustomTitledLabelPane<>("Zahlen der Elemente", ListingData.FIELD_Datacontentinfo);
			this.datacontentinfoEditor.inputProperty.bind(inputProperty);
			this.datalengthinfoEditor = new CustomTitledLabelPane<>("Längen der Elemente", ListingData.FIELD_Datalengthinfo);
			this.datalengthinfoEditor.inputProperty.bind(inputProperty);
			this.byteslengthinfoEditor = new CustomTitledLabelPane<>("Größe der Binärkodierung", ListingData.FIELD_Byteslengthinfo);
			this.byteslengthinfoEditor.inputProperty.bind(inputProperty);
			this.bytesheaderinfoEditor = new CustomTitledLabelPane<>("Variante der Binärkodierung", ListingData.FIELD_Bytesheaderinfo);
			this.bytesheaderinfoEditor.inputProperty.bind(inputProperty);
			this.errorinfoEditor = new CustomTitledLabelPane<>("Fehler bei Binärkodierung", ListingData.FIELD_Errorinfo);
			this.errorinfoEditor.inputProperty.bind(inputProperty);
			this.updateinfoButton = new CustomButton(EditorMain.IMAGE_Action_Update, "Aktualisieren");
			this.updateinfoButton.setOnAction((event) -> this.onUpdateAction());
			this.contentPane2 = new CustomGridPane();
			this.contentPane2.add(this.itemcountinfoEditor, 0, 0);
			this.contentPane2.add(this.itemfindinfoEditor, 1, 0);
			this.contentPane2.add(this.datacontentinfoEditor, 0, 1);
			this.contentPane2.add(this.datalengthinfoEditor, 1, 1);
			this.contentPane2.add(this.byteslengthinfoEditor, 0, 2);
			this.contentPane2.add(this.bytesheaderinfoEditor, 1, 2);
			this.contentPane2.add(this.errorinfoEditor, 0, 3);
			this.contentPane2.add(this.updateinfoButton, 1, 3);
			this.contentPane.getChildren().add(this.contentPane2);
			this.setText("Statistik zur Auflistung");
			this.expandedProperty().bindBidirectional(ListingEditorTab.InfosExpanded);
		}

		{}

		/** Diese Methode aktualisiert die statistischen Informationen via {@link ListingData#updateInfo()}. */
		public void onUpdateAction() {
			ListingEditorTab.this.inputProperty.getValue().updateInfo();
		}

	}

	/** Diese Klasse implementiert den Editor für die direkten Eigenschaften des {@link ListingData}. */
	public final class ParentPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_Index}. */
		public final CustomTitledTextfieldPane<ListingData> indexEditor;

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_Name}. */
		public final CustomTitledTextfieldPane<ListingData> nameEditor;

		public ParentPane() {
			final ObjectProperty<ListingData> inputProperty = ListingEditorTab.this.inputProperty;
			this.indexEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Index, ListingData.FIELD_Index, //
				Fields.translatedField(ListingData.FIELD_Index, EditorMain.GETTER_IntegerFormatter, EditorMain.GETTER_IntegerParser));
			this.indexEditor.inputProperty.bind(inputProperty);
			this.nameEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Name, BaseData.FIELD_Name, BaseData.FIELD_Name);
			this.nameEditor.inputProperty.bind(inputProperty);
			this.contentPane.getChildren().addAll(this.indexEditor, this.nameEditor);
			this.setText("Attribute der Auflistung");
			this.expandedProperty().bindBidirectional(ListingEditorTab.ParentExpanded);
		}

	}

	/** Diese Klasse implementiert den Editor für die Eigenschaften der untergeordneten {@link ItemData}. */
	public final class ChildrenPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link ListingData#FIELD_ItemList}. */
		public final CustomTitledOrderableTablePane<ListingData, ItemData> itemsEditor;

		/** Dieses Feld speichert den Editor für {@link ItemData#FIELD_Index}. */
		public final CustomIntegerColumn<ItemData> itemsIndexEditor;

		/** Dieses Feld speichert den Editor für {@link ItemData#FIELD_Name}. */
		public final CustomStringColumn<ItemData> itemsNameEditor;

		/** Dieses Feld speichert den Editor für {@link ItemData#GETTER_Data}. */
		public final ArrayColumnEditor<ItemData> itemsDataEditor;

		/** Dieses Feld speichert den {@link CustomChildButton} zur Auswahl in {@link #itemsEditor}. */
		public final CustomButton itemsChildButton;

		/** Dieses Feld speichert den {@link SelectionPane} zur Auswahl in {@link #itemsEditor}. */
		public final SelectionPane selectionPane;

		@SuppressWarnings ("unchecked")
		public ChildrenPane() {
			this.itemsIndexEditor = new CustomIntegerColumn<>(ItemData.FIELD_Index);
			this.itemsIndexEditor.setText(BaseData.NAME_Index);
			this.itemsNameEditor = new CustomStringColumn<>(BaseData.FIELD_Name);
			this.itemsNameEditor.setText(BaseData.NAME_Name);
			this.itemsDataEditor = new ArrayColumnEditor<>(ItemData.GETTER_Data);
			this.itemsDataEditor.setText(ItemData.NAME_Data);
			this.itemsEditor = new CustomTitledOrderableTablePane<>(ListingData.SETTER_RemoveItem, ListingData.GETTER_AppendItem, ListingData.FIELD_ItemList);
			this.itemsEditor.titleLabel.setText(ListingData.NAME_ItemList);
			this.itemsEditor.inputProperty.bind(ListingEditorTab.this.inputProperty);
			this.itemsEditor.tableView.getColumns().addAll(this.itemsIndexEditor, this.itemsNameEditor, this.itemsDataEditor);
			VBox.setVgrow(this.itemsEditor, Priority.ALWAYS);
			this.itemsChildButton = new CustomButton(EditorMain.IMAGE_Editor_Item, "Gewählte Elemente einzeln bearbeiten...");
			this.itemsChildButton.disableProperty().bind(this.itemsEditor.removeButton.disableProperty());
			this.selectionPane = new SelectionPane();
			this.selectionPane.contentPane.disableProperty().bind(this.itemsEditor.removeButton.disableProperty());
			this.selectionPane.inputProperty.bind(this.itemsEditor.selectionAdapter);
			this.contentPane.getChildren().addAll(this.itemsEditor, this.itemsChildButton, this.selectionPane);
			this.setText("Elemente der Auflistung");
			this.expandedProperty().bindBidirectional(MappingEditorTab.ChildrenExpanded);
		}

	}

	/** Diese Klasse implementiert einen Editor zur parallelen Bearbeitung der {@link ItemData} in der iterierbaren Eingabe. */
	public final class SelectionPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link ItemData#FIELD_Name}. */
		public final CustomTitledTextfieldPane<List<ItemData>> nameEditor;

		/** Dieses Feld speichert den Editor für {@link ItemData#GETTER_Data}. */
		public final ArrayListEditor<ItemData> dataEditor;

		/** Dieses Feld speichert das {@link Property} der Eingabe des Editors. */
		public final Property<List<ItemData>> inputProperty;

		public SelectionPane() {
			this.setText("Gewählte Elemente parallel bearbeiten");
			this.dataEditor = new ArrayListEditor<>(ItemData.NAME_DataArray, ItemData.NAME_DataFormat, //
				ItemData.NAME_DataString, ItemData.GETTER_Data);
			this.inputProperty = this.dataEditor.inputProperty;
			this.nameEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Name, BaseData.FIELD_Name, //
				Fields.aggregatedField(BaseData.FIELD_Name, EditorMain.STRING_Empty, EditorMain.STRING_Mixed));
			this.nameEditor.inputProperty.bind(this.inputProperty);
			this.contentPane.getChildren().addAll(this.nameEditor, this.dataEditor);
		}

	}

	{}

	/** Dieses Feld synchronisiert {@link InfosPane#expandedProperty()}. */
	public static final BooleanProperty InfosExpanded = new SimpleBooleanProperty(false);

	/** Dieses Feld synchronisiert {@link ParentPane#expandedProperty()}. */
	public static final BooleanProperty ParentExpanded = new SimpleBooleanProperty(true);

	/** Dieses Feld synchronisiert {@link ChildrenPane#expandedProperty()}. */
	public static final BooleanProperty ChildrenExpanded = new SimpleBooleanProperty(true);

	/** Dieses Feld synchronisiert {@link SelectionPane#expandedProperty()}. */
	public static final BooleanProperty SelectionExpanded = new SimpleBooleanProperty(false);

	static final ExtensionFilter[] fileFilters =
		{new ExtensionFilter("Auflistung-IAM-Datei", "*.listing.iam"), new ExtensionFilter("Auflistung-CSV-Datei", "*.listing.csv")};

	static final ListingSetter[] exportSetters = {ListingData.SETTER_ExportIAM, ListingData.SETTER_ExportCSV};

	static final ListingSetter[] importSetters = {ListingData.SETTER_ImportIAM, ListingData.SETTER_ImportCSV};

	{}

	/** Dieses Feld speichert die {@link ToolPane}. */
	public final ToolPane toolPane;

	/** Dieses Feld speichert die {@link InfosPane}. */
	public final InfosPane infosPane;

	/** Dieses Feld speichert die {@link ParentPane}. */
	public final ParentPane parentPane;

	/** Dieses Feld speichert die {@link ChildrenPane}. */
	public final ChildrenPane childrenPane;

	public ListingEditorTab() {
		this.toolPane = new ToolPane();
		this.infosPane = new InfosPane();
		this.parentPane = new ParentPane();
		this.childrenPane = new ChildrenPane();
		this.contentPane.getChildren().addAll(this.toolPane, this.infosPane, this.parentPane, this.childrenPane);
		this.setGraphic(new ImageView(EditorMain.IMAGE_Editor_Listing));
		this.textProperty().bind(this.parentPane.nameEditor.valueEditor.textProperty());
	}

	{}

	/** Diese Methode exportiert die Elemente des bearbeiteten {@link ListingData} in eine IAM- oder CSV-Datei. */
	public void onExportAction() {
		EditorMain.showFileDialog(false, this.getTabPane(), this.inputProperty.get(), //
			"Elemente der Auflistung exportieren...", ListingEditorTab.fileFilters, ListingEditorTab.exportSetters);
	}

	/** Diese Methode importiert die Elemente eines {@link IAMListing} aus einer IAM- oder CSV-Datei und fügt sie dem bearbeiteten {@link ListingData} an. */
	public void onImportAction() {
		EditorMain.showFileDialog(true, this.getTabPane(), this.inputProperty.get(), //
			"Elemente einer Auflistung importieren...", ListingEditorTab.fileFilters, ListingEditorTab.importSetters);
	}

}