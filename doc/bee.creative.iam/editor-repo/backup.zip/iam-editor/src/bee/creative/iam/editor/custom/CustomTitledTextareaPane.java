package bee.creative.iam.editor.custom;

import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.iam.editor.adapter.PropertyAdapter;
import bee.creative.util.Field;
import javafx.beans.property.Property;
import javafx.scene.control.TextArea;

/** Diese Klasse implementiert ein {@link CustomTitledPane} mit einem Steuerelement zur Bearbeitung einer mehrzeiligen Texteigenschaft der Eingabe.
 *
 * @param <GInput> Typ der Eingabe. */
@SuppressWarnings ("javadoc")
public class CustomTitledTextareaPane<GInput> extends CustomTitledPane {

	/** Dieses Feld speichert das Steuerelement zur Texteingabe. */
	public final TextArea valueEditor;

	/** Dieses Feld speichert den {@link PropertyAdapter}, der den Wert des {@link #valueEditor} über ein gegebenes {@link ObservableField} anbindet. */
	public final PropertyAdapter<GInput, String> valueProperty;

	/** Dieses Feld speichert das {@link Property} zur Eingabe des {@link #valueProperty}. */
	public final Property<GInput> inputProperty;

	public CustomTitledTextareaPane(final Field<? super GInput, String> valueField) {
		this.valueEditor = new TextArea();
		this.valueEditor.setWrapText(true);
		this.valueEditor.setPrefRowCount(4);
		this.valueProperty = new PropertyAdapter<>(valueField);
		this.valueProperty.bindBidirectional(this.valueEditor.textProperty());
		this.inputProperty = this.valueProperty.inputProperty;
		this.contentPane.getChildren().add(this.valueEditor);
	}

	public CustomTitledTextareaPane(final String titleText, final ObservableField<?, ?> observableField, final Field<? super GInput, String> valueField) {
		this(valueField);
		this.titleLabel.setText(titleText);
		this.valueProperty.useObservable(observableField);
	}

}