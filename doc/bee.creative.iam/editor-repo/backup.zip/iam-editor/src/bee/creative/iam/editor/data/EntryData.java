package bee.creative.iam.editor.data;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import bee.creative.iam.IAMMapping;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.util.Field;
import bee.creative.util.Fields;
import bee.creative.util.Getter;
import bee.creative.util.Objects;

/** Diese Klasse implementiert das Datenmodell eins Eintrags eines {@link IAMMapping}. */
@XmlType
@XmlAccessorType (XmlAccessType.FIELD)
@SuppressWarnings ("javadoc")
public final class EntryData extends BaseData {

	/** Dieses Feld speichert das {@link Field} zu {@link #owner}. */
	public static final Field<EntryData, MappingData> FIELD_Owner = Fields.defaultField(EntryData.nativeField("owner"));

	/** Dieses Feld speichert das {@link Field} zur dieses Objekt verwaltenden Liste im {@link #owner}. */
	public static final Field<EntryData, List<EntryData>> FIELD_OwnerList = Fields.navigatedField(EntryData.FIELD_Owner, MappingData.FIELD_EntryList);

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #index}. */
	public static final ObservableField<EntryData, Integer> FIELD_Index = BaseData.indexField(EntryData.FIELD_OwnerList);

	public static final String NAME_Key = "Schlüssel";

	public static final String NAME_KeyArray = "Schlüssel-Zahlenfolge";

	public static final String NAME_KeyString = "Schlüssel-Zeichenkette";

	public static final String NAME_KeyFormat = "Schlüssel-Format";

	public static final String NAME_KeyUpdateArray = "Schlüssel-Zeichenkette-Parsen";

	public static final String NAME_KeyUpdateString = "Schlüssel-Zahlenfolge-Formatieren";

	public static final String NAME_Value = "Wert";

	public static final String NAME_ValueArray = "Wert-Zahlenfolge";

	public static final String NAME_ValueString = "Wert-Zeichenkette";

	public static final String NAME_ValueFormat = "Wert-Format";

	public static final String NAME_ValueUpdateArray = "Wert-Zeichenkette-Parsen";

	public static final String NAME_ValueUpdateString = "Wert-Zahlenfolge-Formatieren";

	/** Dieses Feld speichert die Kopfzeile der CSV-Datei. */
	public static final String[] HEADER_CSV = {BaseData.NAME_Name, EntryData.NAME_KeyArray, EntryData.NAME_KeyString, EntryData.NAME_KeyFormat,
		EntryData.NAME_KeyUpdateArray, EntryData.NAME_KeyUpdateString, EntryData.NAME_ValueArray, EntryData.NAME_ValueString, EntryData.NAME_ValueFormat,
		EntryData.NAME_ValueUpdateArray, EntryData.NAME_ValueUpdateString};

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #key}. */
	public static final Getter<EntryData, ArrayData> GETTER_Key = Fields.setupField(EntryData.nativeField("key"), (i) -> new ArrayData());

	/** Dieses Feld speichert das {@link ObservableField} zu {@link #value}. */
	public static final Getter<EntryData, ArrayData> GETTER_Value = Fields.setupField(EntryData.nativeField("value"), (i) -> new ArrayData());

	{}

	static final <GValue> Field<EntryData, GValue> nativeField(final String name) {
		return BaseData.nativeField(EntryData.class, name);
	}

	static final <GValue> ObservableField<EntryData, GValue> observableField(final String name) {
		return new ObservableField<>(EntryData.nativeField(name));
	}

	{}

	/** Dieses Feld speichert den Besitzer, der dieses Objekts in einer Liste verwaltet. */
	@XmlTransient
	MappingData owner;

	/** Dieses Feld speichert den Schlüssel des Eintrags. */
	@XmlElement
	ArrayData key;

	/** Dieses Feld speichert den Wert des Eintrags. */
	@XmlElement
	ArrayData value;

	{}

	@Override
	public String toString() {
		return Objects.toInvokeString("", this.name);
	}

}