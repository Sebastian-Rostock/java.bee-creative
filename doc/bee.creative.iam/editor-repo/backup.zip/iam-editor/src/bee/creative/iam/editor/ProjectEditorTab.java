package bee.creative.iam.editor;

import java.util.List;
import bee.creative.iam.IAMCodec.IAMByteOrder;
import bee.creative.iam.editor.IndexEditorTab.SelectionPane1;
import bee.creative.iam.editor.custom.CustomButton;
import bee.creative.iam.editor.custom.CustomStringColumn;
import bee.creative.iam.editor.custom.CustomTab;
import bee.creative.iam.editor.custom.CustomTitledCollapsiblePane;
import bee.creative.iam.editor.custom.CustomTitledComboboxPane;
import bee.creative.iam.editor.custom.CustomTitledOrderableTablePane;
import bee.creative.iam.editor.custom.CustomTitledTextfieldPane;
import bee.creative.iam.editor.custom.CustomValueColumn;
import bee.creative.iam.editor.data.BaseData;
import bee.creative.iam.editor.data.IndexData;
import bee.creative.iam.editor.data.ProjectData;
import bee.creative.util.Fields;
import javafx.beans.property.Property;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

/** Diese Klasse implementiert den {@link CustomTab} zur Bearbeitung eines {@link ProjectData}. */
@SuppressWarnings ("javadoc")
public final class ProjectEditorTab extends CustomTab<ProjectData> {

	/** Diese Klasse implementiert den Editor für die Eigenschaften der untergeordneten {@link IndexData}. */
	public final class ChildrenPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link ProjectData#FIELD_IndexList}. */
		public final CustomTitledOrderableTablePane<ProjectData, IndexData> indicesEditor;

		/** Dieses Feld speichert den Editor für {@link IndexData#FIELD_Name}. */
		public final CustomStringColumn<IndexData> indicesNameEditor;

		/** Dieses Feld speichert den Editor für {@link IndexData#FIELD_Byteorder}. */
		public final CustomValueColumn<IndexData, IAMByteOrder> indicesByteorderEditor;

		/** Dieses Feld speichert den {@link CustomButton} zur Auswahl in {@link #indicesEditor}. */
		public final CustomButton indicesChildButton;

		/** Dieses Feld speichert den {@link SelectionPane1} zur Auswahl in {@link #indicesEditor}. */
		public final SelectionPane selectionPane;

		@SuppressWarnings ("unchecked")
		public ChildrenPane() {
			this.indicesNameEditor = new CustomStringColumn<>(BaseData.FIELD_Name);
			this.indicesNameEditor.setText(BaseData.NAME_Name);
			this.indicesNameEditor.setPrefWidth(450);
			this.indicesByteorderEditor = new CustomValueColumn<>(IndexData.FIELD_Byteorder, IAMByteOrder.values());
			this.indicesByteorderEditor.setText(IndexData.NAME_Byteorder);
			this.indicesByteorderEditor.setPrefWidth(160);
			this.indicesEditor = new CustomTitledOrderableTablePane<>(ProjectData.SETTER_RemoveIndex, ProjectData.GETTER_AppendIndex, ProjectData.FIELD_IndexList);
			this.indicesEditor.titleLabel.setText(ProjectData.NAME_IndexList);
			this.indicesEditor.inputProperty.bind(ProjectEditorTab.this.inputProperty);
			this.indicesEditor.tableView.getColumns().addAll(this.indicesNameEditor, this.indicesByteorderEditor);
			VBox.setVgrow(this.indicesEditor, Priority.ALWAYS);
			this.indicesChildButton = new CustomButton(EditorMain.IMAGE_Editor_Index, "Gewählte Verzeichnisse einzeln bearbeiten...");
			this.indicesChildButton.disableProperty().bind(this.indicesEditor.removeButton.disableProperty());
			this.selectionPane = new SelectionPane();
			this.selectionPane.contentPane.disableProperty().bind(this.indicesEditor.removeButton.disableProperty());
			this.selectionPane.inputProperty.bind(this.indicesEditor.selectionAdapter);
			this.contentPane.getChildren().addAll(this.indicesEditor, this.indicesChildButton, this.selectionPane);
			this.setText("Verzeichnisse des Projekts");
			this.setExpanded(true);
			this.setCollapsible(false);
		}

	}

	/** Diese Klasse implementiert einen Editor zur parallelen Bearbeitung der {@link IndexData} in der iterierbaren Eingabe. */
	public final class SelectionPane extends CustomTitledCollapsiblePane {

		/** Dieses Feld speichert den Editor für {@link IndexData#FIELD_Name}. */
		public final CustomTitledTextfieldPane<List<IndexData>> indexNameEditor;

		/** Dieses Feld speichert den Editor für {@link IndexData#FIELD_Byteorder}. */
		public final CustomTitledComboboxPane<List<IndexData>, IAMByteOrder> indexByteorderEditor;

		/** Dieses Feld speichert das {@link Property} der Eingabe des Editors. */
		public final Property<List<IndexData>> inputProperty;

		public SelectionPane() {
			this.setText("Gewählte Verzeichnisse parallel bearbeiten");
			this.indexNameEditor = new CustomTitledTextfieldPane<>(BaseData.NAME_Name, BaseData.FIELD_Name, //
				Fields.aggregatedField(BaseData.FIELD_Name, EditorMain.STRING_Empty, EditorMain.STRING_Mixed));
			this.inputProperty = this.indexNameEditor.inputProperty;
			this.indexByteorderEditor = new CustomTitledComboboxPane<>(IndexData.NAME_Byteorder, IndexData.FIELD_Byteorder, IAMByteOrder.values(), //
				Fields.aggregatedField(IndexData.FIELD_Byteorder));
			this.indexByteorderEditor.inputProperty.bind(this.inputProperty);
			this.contentPane.getChildren().addAll(this.indexNameEditor, this.indexByteorderEditor);
		}

	}

	{}

	/** Dieses Feld speichert die {@link ChildrenPane}. */
	public final ChildrenPane childrenPane;

	public ProjectEditorTab() {
		this.childrenPane = new ChildrenPane();
		this.contentPane.getChildren().addAll(this.childrenPane);
		this.setGraphic(new ImageView(EditorMain.IMAGE_Editor_Project));
		this.setClosable(false);
	}

}