package bee.creative.iam.editor.data;

import java.util.ArrayList;
import bee.creative.util.Objects;

/** Diese Klasse implementiert eine Gruppe zusammengehöroger {@link ChangeEntry Änderungseinträge}, die aus einer logischen Nutzereingabe stammen.
 * 
 * @see ProjectData#logChange(bee.creative.util.Setter, Object, Object)
 * @author [cc-by] 2017 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */
public final class ChangeGroup {

	/** Dieses Feld speichert das Objekt, an welchem Änderungen vorgenommen wurden. */
	public final Object input;

	/** Dieses Feld speichert die initial durch Nutzereingabe geänderte Eigenschaft. */
	public final Object setter;

	/** Dieses Feld speichert die gruppierten Änderungseinträge.. */
	public final ArrayList<ChangeEntry<?, ?>> changes = new ArrayList<>();

	@SuppressWarnings ("javadoc")
	public ChangeGroup(final Object input, final Object setter) {
		this.input = input;
		this.setter = setter;
	}

	{}

	/** Diese Methode stellt alle {@link #changes Änderungen} wieder her. */
	public final void redo() {
		for (final ChangeEntry<?, ?> entry: this.changes) {
			entry.redo();
		}
	}

	/** Diese Methode macht alle {@link #changes Änderungen} rückgängig. */
	public final void undo() {
		for (final ChangeEntry<?, ?> entry: this.changes) {
			entry.undo();
		}
	}

	/** Diese Methode fasst auf einander aufbauende {@link #changes Änderungen} zusammen. */
	public void compact() {
		int count = this.changes.size();
		for (int i = 0; i < count; i++) {
			@SuppressWarnings ("unchecked")
			final ChangeEntry<?, Object> prev = (ChangeEntry<?, Object>)this.changes.get(i);
			for (int j = i + 1; j < count;) {
				final ChangeEntry<?, ?> next = this.changes.get(j);
				if (Objects.equals(prev.setter, next.setter) && Objects.equals(prev.input, next.input) && Objects.equals(prev.newValue, next.oldValue)) {
					prev.newValue = next.newValue;
					count--;
					this.changes.remove(j);
				} else {
					j++;
				}
			}
		}
		this.changes.trimToSize();
	}

	{}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return Objects.toFormatString(true, false, this, this.input, this.setter, this.changes);
	}

}
