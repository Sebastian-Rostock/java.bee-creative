package bee.creative.iam.editor.data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import bee.creative.iam.IAMArray;
import bee.creative.iam.IAMCodec.IAMArrayFormat;
import bee.creative.iam.editor.adapter.FieldListener;
import bee.creative.iam.editor.adapter.ObservableField;
import bee.creative.util.Fields;
import bee.creative.util.Natives;
import bee.creative.util.Objects;

/** Diese Klasse implementiert das Datenmodell zur Bearbeitung eines {@link IAMArray}. */
@XmlType
@XmlAccessorType (XmlAccessType.FIELD)
@SuppressWarnings ("javadoc")
public final class ArrayData {

	/** Dieses Feld speichert den {@link ObservableField} zu {@link #array}. */
	public static final ObservableField<ArrayData, String> FIELD_Array = ArrayData.observableField("array");

	/** Dieses Feld speichert den {@link ObservableField} zu {@link #string}. */
	public static final ObservableField<ArrayData, String> FIELD_String = ArrayData.observableField("string");

	/** Dieses Feld speichert den {@link ObservableField} zu {@link #format}. */
	public static final ObservableField<ArrayData, IAMArrayFormat> FIELD_Format = ArrayData.observableField("format");

	/** Dieses Feld speichert den {@link ObservableField} zu {@link #updateArray}. */
	public static final ObservableField<ArrayData, Boolean> FIELD_UpdateArray = ArrayData.observableField("updateArray");

	/** Dieses Feld speichert den {@link ObservableField} zu {@link #updateString}. */
	public static final ObservableField<ArrayData, Boolean> FIELD_UpdateString = ArrayData.observableField("updateString");

	public static final String NAME_Array = "Zahlenfolge";

	public static final String NAME_String = "Zeichenkette";

	public static final String NAME_Format = "Format";

	public static final String NAME_UpdateArray = "Zahlen. akt.";

	public static final String NAME_UpdateString = "Zeichen. akt.";

	static {
		{
			final FieldListener<ArrayData> arrayUpdater = (input) -> {
				if ((input == null) || !input.updateArray) return;
				input.updateArray();
			};
			ArrayData.FIELD_String.addListener(arrayUpdater);
			ArrayData.FIELD_UpdateArray.addListener(arrayUpdater);
		}
		{
			final FieldListener<ArrayData> stringUpdater = (input) -> {
				if ((input == null) || !input.updateString) return;
				input.updateString();
			};
			ArrayData.FIELD_Array.addListener(stringUpdater);
			ArrayData.FIELD_UpdateString.addListener(stringUpdater);
		}
		{
			ArrayData.FIELD_Format.addListener((input) -> {
				if (input == null) return;
				input.updateFormat();
			});
		}
	}

	static final <GValue> ObservableField<ArrayData, GValue> observableField(final String name) {
		return new ObservableField<>(Fields.defaultField(Fields.nativeField(Natives.parseField(ArrayData.class, name))));
	}

	{}

	/** Dieses Feld speichert die Zahlenfolge im Format {@link IAMArrayFormat#ARRAY}. */
	@XmlElement
	String array = "";

	/** Dieses Feld speichert die Zahlenfolge im Format {@link #format}. */
	@XmlElement
	String string = "";

	/** Dieses Feld speichert das {@link IAMArrayFormat} zur Interpretation der Zahlenfolge in {@link #array}. */
	@XmlAttribute
	IAMArrayFormat format = IAMArrayFormat.ARRAY;

	/** Dieses Feld speichert {@code true}, wenn Änderungen an {@link #string} auf {@link #array} übertragen werden sollen. */
	@XmlAttribute
	boolean updateArray = true;

	/** Dieses Feld speichert {@code true}, wenn Änderungen an {@link #array} auf {@link #string} übertragen werden sollen. */
	@XmlAttribute
	boolean updateString;

	{}

	/** Diese Methode überträgt den Wert von {@link #string} auf {@link #array}. */
	public void updateArray() {
		try {
			ArrayData.FIELD_Array.set(this, IAMArrayFormat.ARRAY.format(this.format.parse(this.string)));
		} catch (final RuntimeException cause) {}
	}

	/** Diese Methode überträgt den Wert von {@link #array} auf {@link #string}. */
	public void updateString() {
		try {
			ArrayData.FIELD_String.set(this, this.format.format(this.toArray()));
		} catch (final RuntimeException cause) {}
	}

	/** Diese Methode gleicht die Werte von {@link #string} und {@link #array} gemäß {@link #format} aufeinander ab. */
	public void updateFormat() {
		if (this.updateArray) {
			this.updateArray();
		} else if (this.updateString) {
			this.updateString();
		}
	}

	{}

	/** Diese Methode gibt die Daten der {@link #array Zahlenfolge} als {@link IAMArray} zurück. */
	public int[] toArray() {
		if (this.array == null) return new int[0];
		return IAMArrayFormat.ARRAY.parse(this.array);
	}

	@Override
	public String toString() {
		return Objects.toString(this.array);
	}

}