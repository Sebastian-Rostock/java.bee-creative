package bee.creative.iam.editor.adapter;

import bee.creative.iam.editor.data.ProjectData;
import bee.creative.util.Field;
import bee.creative.util.Getter;
import bee.creative.util.Setter;
import javafx.beans.binding.Bindings;
import javafx.beans.property.Property;
import javafx.beans.value.ObservableValue;

/** Diese Klasse implementiert ein {@link Property} als Adapter auf ein {@link Field Datenfeld} einer gegebenen {@link #inputProperty Eingabe}.
 *
 * @param <GInput> Typ der Eingabe.
 * @param <GValue> Typ des Werts. */
@SuppressWarnings ("javadoc")
public class PropertyAdapter<GInput, GValue> extends ValueAdapter<GInput, GValue> implements Property<GValue> {

	/** Dieses Feld speichert den {@link Setter} zum {@link #setValue(Object) Setzen des Werts} einer Eigenschaft der {@link #inputProperty Eingabe}. */
	public final Setter<? super GInput, ? super GValue> valueSetter;

	/** Dieser Konstruktor initialisiert das das {@link Field Datenfeld} der Eigenschaft der {@link #inputProperty Eingabe}. */
	public PropertyAdapter(final Field<? super GInput, GValue> valueField) {
		this(valueField, valueField);
	}

	/** Dieser Konstruktor initialisiert {@link #valueGetter} und {@link #valueSetter}. */
	public PropertyAdapter(final Getter<? super GInput, ? extends GValue> valueGetter, final Setter<? super GInput, ? super GValue> valueSetter) {
		super(valueGetter);
		this.valueSetter = valueSetter;
		this.inputProperty.addListener((i) -> this.fireValueChangedEvent());
	}

	{}

	/** {@inheritDoc} */
	@Override
	public PropertyAdapter<GInput, GValue> useInput(final GInput input) {
		super.useInput(input);
		return this;
	}

	/** {@inheritDoc} */
	@Override
	public PropertyAdapter<GInput, GValue> useInput(final ObservableValue<? extends GInput> input) {
		super.useInput(input);
		return this;
	}

	/** Diese Methode {@link Property#bindBidirectional(Property) synchronisiert} die {@link #inputProperty Eingabe} mit dem gegebenen {@link Property} und gibt
	 * {@code this} zurück. */
	public PropertyAdapter<GInput, GValue> useInput(final Property<GInput> input) {
		this.inputProperty.bindBidirectional(input);
		return this;
	}

	/** {@inheritDoc} */
	@Override
	public PropertyAdapter<GInput, GValue> useObservable(final ObservableField<?, ?> sender) {
		super.useObservable(sender);
		return this;
	}

	{}

	/** Diese Methode gibt die {@link #inputProperty Eingabe}zurück */
	@Override
	public GInput getBean() {
		return this.inputProperty.get();
	}

	/** {@inheritDoc} */
	@Override
	public String getName() {
		return "";
	}

	/** {@inheritDoc} */
	@Override
	public void setValue(final GValue value) {
		final GInput input = this.inputProperty.get();
		ProjectData.logChange(this.valueSetter, input, value);
	}

	/** Diese Methode löst eine {@link UnsupportedOperationException} aus. */
	@Override
	public void bind(final ObservableValue<? extends GValue> observable) {
		throw new UnsupportedOperationException();
	}

	/** Diese Methode löst eine {@link UnsupportedOperationException} aus. */
	@Override
	public void unbind() {
		throw new UnsupportedOperationException();
	}

	/** {@inheritDoc} */
	@Override
	public boolean isBound() {
		return false;
	}

	/** {@inheritDoc} */
	@Override
	public void bindBidirectional(final Property<GValue> other) {
		Bindings.bindBidirectional(this, other);
	}

	/** {@inheritDoc} */
	@Override
	public void unbindBidirectional(final Property<GValue> other) {
		Bindings.unbindBidirectional(this, other);
	}

}