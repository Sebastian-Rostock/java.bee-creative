/* [cc-by] 2015 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]*/

#ifndef BEE_CREATIVE_SUC_HPP

#define BEE_CREATIVE_SUC_HPP

#include <string.h>
#include "bee_creative.hpp"
#include <bits/move.h>

namespace bee {

namespace creative {

/**
 * Dieser Namensraum realisiert die <i>SUC – Simple Universal Collections</i>.<br>
 * Diese umfassen generische effiziente Klassen zur Verwaltung von Arrays mit konstanter Elementanzahl (@c SUCArray), Vektoren mit variabler Elementanzahl (@c SUCListing) und Tabellen zur Abbildung von Schlüsseln auf Werte (@c SUCMapping).<br>
 * Alle Instanzen dieser Klassen verwenden referenzgezählte Nutzdaten und können daher leicht direkt als Parameter oder Rückgabewert von Funktionen eingesetzt werden. Ihre Äquivalenz basiert auf der ihrer internen Zeiger.<br>
 * Zur Iteration über die Elemente bzw. Einträge dieser Sammlungen werden entsprechende @c SUCCursor bereitgestellt.<br>
 * Die Bestückung der Speicherbereiche in den Sammlungen kann über @c SUCPolicy geregelt werden.<p>
 * Vorteile der <i>SUC</i> gegenüber den mahr als 10 Jahre alten Alternativen in @c std und @c boost sind:
 * <ul>
 * <li>Die Regelwerke zur Speicherverwaltung (@c SUCPolicy) nutzen ausschließlich statische Methoden.</li>
 * <li>Instanzverwaltung durch Referenzzählung (Achtung: Zirkelbezüge werden nicht automatisch aufgelöst).</li>
 * <li>Geprüfter Zugriff auf Elemente bzw. Einträge mitteld @c [] Operator.</li>
 * <li>@c SUCListing ist im Mittel doppelt so schnellen beim wahlfreieen Einfügen und Entfernen von Elementen.</li>
 * <li>@c SUCMapping reserviert den Speicher für ihre Einträge in (großen) Blöcken.</li>
 * <li>Der Quelltext aller Klassen ist dokumentiert.</li>
 * </ul>
 *
 * @author [cc-by] 2015 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]
 */
namespace suc {

/** Diese Klasse definiert ein Objekt zur Berechnung und Zusammenführung von Streuwerten und ist für den Einsatz in @c SUCHasher::hash() vorgesehen. */
struct SUCHash {

	public:

	/** Dieser Konstruktor initialisiert den Streuwert. */
	SUCHash()
			: _value_(0x811C9DC5) {
	}

	/** Diese Methode gibt den aktuellen Streuwert zurück.
	 * @return Streuwert. */
	inline INT32 value() const {
		return _value_;
	}

	/** Diese Methode führt den aktuellen Streuwert mit dem gegebenen zusammen und ändert damit den aktuellen Streuwert.<br>
	 * Die Reihenfolge mehrerer aufeinander folgender Aufrufe dieser Methode beeinflusst die Zusammenführung.
	 * @param _hash geordnet anzufügender Streuwert. */
	inline void pushHash(INT32 _hash) {
		_value_ = (_value_ * 0x01000193) ^ _hash;
	}

	/** Diese Methode führt den aktuellen Streuwert mit dem gegebenen zusammen und änder damit den aktuellen Streuwert.<br>
	 * Die Reihenfolge mehrerer aufeinander folgender Aufrufe dieser Methode hat keinen Einfluss auf die Zusammenführung.
	 * @param _hash ungeordnet anzufügender Streuwert. */
	inline void mergeHash(INT32 _hash) {
		_value_ = _value_ ^ _hash;
	}

	/** Dieser Operator gibt den Streuwert zurück. */
	inline operator INT32() const {
		return _value_;
	}

	private:

	/** Dieses Feld speichert den Streuwert. */
	INT32 _value_;

};

/** Diese Klasse definiert die Exception, die in den Klasse des <i>SUC</i> eingesetzt wird. */
struct SUCException {

	public:

	/** Dieses Feld identifiziert die Ausnahme bei der Erkennugn eines ungültigen Zustands. */
	static INT8 const ILLEGAL_STATE = 1;

	/** Dieses Feld identifiziert die Ausnahme bei der Erkennugn einer ungültigen Position. */
	static INT8 const ILLEGAL_INDEX = 2;

	/** Dieses Feld identifiziert die Ausnahme bei der Erkennugn einer ungültigen Anzahl. */
	static INT8 const ILLEGAL_COUNT = 3;

	/** Dieses Feld identifiziert die Ausnahme bei der Erkennugn einer ungültigen Ausrichtung. */
	static INT8 const ILLEGAL_ALIGN = 4;

	inline static void checkState(bool _valid) {
		if (!_valid) throw SUCException(SUCException::ILLEGAL_STATE);
	}

	inline static void checkCount(INT32 _count) {
		if (_count < 0) throw SUCException(SUCException::ILLEGAL_COUNT);
	}

	/** Diese Methode prüft den gegebenen Position.
	 * @param _index Position.
	 * @param _count Anzahl.
	 * @throws SUCException Wenn <tt>_index</tt> kleiner <tt>0</tt> oder nicht kleiner <tt>_count</tt> ist. */
	inline static void checkIndex(INT32 _index, INT32 _count) {
		if ((UINT32) _index >= (UINT32) _count) throw SUCException(SUCException::ILLEGAL_INDEX);
	}

	/** Dieser Konstrukteur initialisiert die Fehlerursache.
	 * @param _code Fehlerursache. */
	SUCException(INT8 _code)
			: _code_(_code) {
	}

	/** Diese Methode gibt die Fehlerursache zurück.
	 * @return Fehlerursache. */
	INT8 code() const {
		return _code_;
	}

	private:

	/** Dieses Feld speichert die Fehlerursache. */
	INT8 _code_;

};

/** Diese Klasse definiert ein Regelwerk mit statische Methoden zur Initialisierung, Finalisierung, Bereinigung, Verschiebung und Duplizierung von Arrays und deren Elementen.
 * Darüber hinaus werden statische Methoden zur Ermittlung des Streuwerts sowie der Äquivalenz von Elementen bzw. Arrays bereitgestellt.<p>
 * <i>Initialisierung</i><br>
 * Die Methoden @c createItem() und @c createArray() dienen der Reservierung des Speicherbereichs eines neuen Elements bzw. Arrays sowie der und Initialisierung desselben.
 * Strukturen initialisieren diesen Speicherbereich über ihren Konstruktor.
 * Bei Elementen mit primitive Datentypen ist der Inhalt des Speicherbereicht i.d.R. mit beliebigen Daten gefüllt.<p>
 * <i>Finalisierung</i><br>
 * Die Methoden @c deleteItem() und @c deleteArray() dienen der Finalisierung und Freigabe des Speicherbereichs eines Elements bzw. Arrays und der damit verbundenen Bereinigung des Speicherbereichs.
 * Strukturen finalisieren diesen Speicherbereich über ihren Destruktor.
 * Bei Elementen mit primitive Datentypen erfolgt i.d.R. keine Bereinigung.<p>
 * <i>Bereinigung</i><br>
 * Die Methoden @c resetItem() und @c resetArray() dienen der Bereinigung und Rücksetzung des Speicherbereichs eines Elements bzw. Arrays auf den Zustand, den der Speicherbereich nach seiner Initialisierung hatte.<p>
 * <i>Verschiebung</i><br>
 * TODO<p>
 * <i>Duplizierung</i><br>
 * TODO<p>
 * <i>Streuwert</i><br>
 * TODO<p>
 * <i>Äquivalenz</i><br>
 * TODO<p>
 * <i>Ordnung</i><br>
 * TODO<p>
 *
 * @tparam _ITEM Typ der Elemente.
 * @tparam _ITEM_POLICY Typ des von diesem erbenden Regelwerks, an dessen Methoden delegiert wird. Damit wird der Aufruf virtueller statischer Methoden simuliert. */
template<typename _ITEM, typename _ITEM_POLICY> //
struct SUCPolicy: public DELETE_POLICY<_ITEM> {

	public:

	/** Dieser Datentyp definiert die Elemente. */
	typedef _ITEM ITEM;

	/** Dieser Datentyp definiert die @c SUCPolicy, an welche die Array-Methoden dieser delegieren. Damit wird der Aufruf virtueller statischer Methoden simuliert. */
	typedef _ITEM_POLICY ITEM_POLICY;

	/** Diese Methode initialisiert den Speicherbereich eines neuen Elements und gibt diesen zurück.<p>
	 * Die Implementation in @c SUCPolicy liefert <tt>new ITEM()</tt>.
	 * @return Element. */
	inline static ITEM* createItem() {
		ITEM* _result = new ITEM();
		return _result;
	}

	/** Diese Methode initialisiert den Speicherbereichs eines neuen Arrays und gibt diesen zurück.<br>
	 * Die Implementation in @c SUCPolicy liefert <tt>_length ? new ITEM[_length] : 0</tt>.
	 * @param _length Anzahl der Elemente im Speicherbereich.
	 * @return Beginn des Speicherbereichs.
	 * @throws SUCException Wenn die gegebene Anzahl negativ ist. */
	inline static ITEM* createArray(INT32 _length) {
		SUCException::checkCount(_length);
		ITEM* _result = _length ? new ITEM[_length] : 0;
		return _result;
	}

	/** Diese Methode bereinigt den Speicherbereich des gegebenen Elements.<p>
	 * Die Implementation in @c SUCPolicy ist leer.
	 * @param _item Element. */
	inline static void resetItem(ITEM* _item) {
	}

	/** Diese Methode bereinigt den Speicherbereichs des gegebenen Arrays.<p>
	 * Die Implementation in @c SUCPolicy delegiert an @c resetItem() der @c ITEM_POLICY.
	 * @param _array Beginn des Speicherbereichs.
	 * @param _length Anzahl der Elemente im Speicherbereich.
	 * @throws SUCException Wenn die gegebene Anzahl negativ ist. */
	inline static void resetArray(_ITEM* _array, INT32 _length) {
		SUCException::checkCount(_length);
		_ITEM* _cancel = _array + _length;
		while (_array != _cancel) {
			_ITEM_POLICY::resetItem(_array);
			++_array;
		}
	}

	/** Diese Methode verschiebt das gegebene Quellelement zum Zielelement.<p>
	 * Die Implementation in @c SUCPolicy realisiert <tt>*_target = *_source</tt>.
	 * @param _target Zielelement.
	 * @param _source Quellelement. */
	inline static void moveItem(ITEM* _target, ITEM* _source) {
		*_target = *_source;
	}

	/** Diese Methode verschiebt die gegebene Anzahl an Elementen vom gegebenen Quellarray zum gegebenen Zielarray.<p>
	 * Die Implementation in @c SUCPolicy delegiert im Rahmen des folgenden Algoritmus an @c moveItem() und @c resetArray() der @c ITEM_POLICY:<br>
	 * Es wird davon ausgegangen, dass der sich nicht mit dem Quellarray überlagernde Abschnitt des Zielarray bereinigt/rückgesetzt ist.
	 * Die Elemente werden via @c moveItem() verschoben. Der sich nicht mit dem Zielarray überlagernde Abschnitt des Quellarrays via @c resetArray() bereinigt.
	 * @param _target Zielarray.
	 * @param _source Quellarray.
	 * @param _length Anzahl der Elemente.
	 * @throws SUCException Wenn die gegebene Anzahl negativ ist. */
	inline static void moveArray(ITEM* _target, ITEM* _source, INT32 _length) {
		SUCException::checkCount(_length);
		if (!_length) return;
		if (_target < _source) {
			UINT32 _owned = _source - _target;
			{
				ITEM* _cancel = _target + _length;
				while (_target != _cancel) {
					ITEM_POLICY::moveItem(_target, _source);
					++_target;
					++_source;
				}
			}
			if (_owned > _length) {
				ITEM_POLICY::resetArray(_source - _length, _length);
			} else {
				ITEM_POLICY::resetArray(_source - _owned, _owned);
			}
		} else if (_target > _source) {
			INT32 _owned = _target - _source;
			{
				ITEM* _cancel = _target;
				_target += _length;
				_source += _length;
				while (_target != _cancel) {
					--_target;
					--_source;
					ITEM_POLICY::moveItem(*_target, *_source);
				}
			}
			if (_owned > _length) {
				ITEM_POLICY::resetArray(_source, _length);
			} else {
				ITEM_POLICY::resetArray(_source, _owned);
			}
		}
	}

	/** Diese Methode dupliziert das gegebene Quellelement in das Zielelement.<p>
	 * Die Implementation in @c SUCPolicy realisiert <tt>*_target = *_source</tt>.
	 * @param _target Zielelement.
	 * @param _source Quellelement. */
	inline static void cloneItem(ITEM* _target, ITEM const* _source) {
		*_target = *_source;
	}

	/** Diese Methode dupliziert die gegebene Anzahl an Elementen vom gegebenen Quellarray in das gegebenen Zielarray.<br>
	 * <b>Achtung:</b> Die Speicherbereiche der Arrays dürfen sich nicht überlagern.<p>
	 * Die Implementation in @c SUCPolicy delegiert an @c cloneItem() der @c ITEM_POLICY.
	 * @param _target Zielarray.
	 * @param _source Quellarray.
	 * @param _length Anzahl der Elemente.
	 * @throws SUCException Wenn die gegebene Anzahl negativ ist. */
	inline static void cloneArray(ITEM* _target, ITEM const* _source, INT32 _length) {
		SUCException::checkCount(_length);
		ITEM* _cancel = _target + _length;
		while (_target != _cancel) {
			ITEM_POLICY::cloneItem(_target, _source);
			++_target;
			++_source;
		}
	}

	/** Diese Methode gibt den Streuwert des gegebenen Elements zurück.<p>
	 * Die Implementation in @c SUCPolicy delegiert an @c boost::hash.
	 * @param _item Element.
	 * @return Streuwert des Elements. */
	inline static INT32 hashItem(ITEM const* _item) {
		boost::hash<ITEM> _hash;
		INT32 _result = _hash(*_item);
		return _result;
	}

	/** Diese Methode gibt den Streuwert des gegebenen Arrays zurück.<p>
	 * Die Implementation in @c SUCPolicy delegiert an @c hashItem() der @c ITEM_POLICY und verbindet die Streuwerte der Elemente geordnet über einen @c SUCHash.
	 * @param _array Beginn des Speicherbereichs.
	 * @param _length Anzahl der Elemente im Speicherbereich.
	 * @return Streuwert des Arrays.
	 * @throws SUCException Wenn die gegebene Anzahl negativ ist. */
	inline static INT32 hashArray(_ITEM const* _array, INT32 _length) {
		SUCException::checkCount(_length);
		SUCHash _result;
		_ITEM const* _cancel = _array + _length;
		while (_array != _cancel) {
			INT32 _hash = _ITEM_POLICY::hashItem(_array);
			_result.pushHash(_hash);
			++_array;
		}
		return _result;
	}

	/**Diese Methode gibt nur dann <tt>true</tt> zurück, wenn die gegebenen Element äquivalent sind.<p>
	 * Die Implementation in @c SUCPolicy realisiert <tt>_this == _that</tt>.
	 * @param _this erstes Element.
	 * @param _that zweites Element.
	 * @return <tt>true</tt>, wenn die Elemente äquivalent sind;<br>@c false, wenn sie ungleich sind. */
	inline static bool equalsItem(ITEM const* _this, ITEM const* _that) {
		return (_this == _that) || (*_this == *_that);
	}

	/** Diese Methode gibt nur dann <tt>true</tt> zurück, wenn die gegebenen Arrays äquivalent sind.<p>
	 * Die Implementation in @c SUCPolicy delegiert an @c equalsItem() der @c ITEM_POLICY.
	 * @param _this erstes Array.
	 * @param _that zweites Array.
	 * @param _length Anzahl der Elemente.
	 * @return <tt>true</tt>, wenn die Arrays äquivalent sind;<br>@c false, wenn sie ungleich sind.
	 * @throws SUCException Wenn die gegebene Anzahl negativ ist. */
	inline static bool equalsArray(_ITEM const* _this, _ITEM const* _that, INT32 _length) {
		SUCException::checkCount(_length);
		if (_this == _that) return true;
		_ITEM const* _cancel = _this + _length;
		while (_this != _cancel) {
			if (!_ITEM_POLICY::equalsItem(_this, _that)) return false;
			++_this;
			++_that;
		}
		return true;
	}

	inline static bool equalsArray(_ITEM const* _this, _ITEM const* _that, INT32 _thislength, INT32 _thatlength) {
		if (_thislength == _thatlength) return _ITEM_POLICY::equalsArray(_this, _that, _thislength);
		return false;
	}

	/** Diese Methode gibt eine Zahl kleiner, gleich oder größer als <tt>0</tt> zurück, wenn die Ordnung des ersten Elements kleiner, gleich bzw. größer als die des zweiten Elements ist.
	 * @param _this erstes Element.
	 * @param _that zweites Element.
	 * @return Vergleichswert der Ordnungen. */
	inline static INT32 compareItem(ITEM const* _this, ITEM const* _that) {
		if (_this == _that) return 0;
		if (*_this < *_that) return -1;
		if (*_this > *_that) return +1;
		return 0;
	}

	/** Diese Methode gibt eine Zahl kleiner, gleich oder größer als <tt>0</tt> zurück, wenn die Ordnung des ersten Arrays lexikografisch kleiner, gleich bzw. größer als die des zweiten Arrays ist.<p>
	 * Die Implementation in @c SUCPolicy delegiert an @c compareItem() der @c ITEM_POLICY.
	 * @param _this erstes Array.
	 * @param _that zweites Array.
	 * @param _length Anzahl der Elemente.
	 * @return Vergleichswert der Ordnungen. */
	inline static INT32 compareArray(ITEM const* _this, ITEM const* _that, INT32 _length) {
		SUCException::checkCount(_length);
		if (_this == _that) return 0;
		ITEM const* _cancel = _this + _length;
		while (_this != _cancel) {
			INT32 _result = !ITEM_POLICY::compareItem(_this, _that);
			if (_result) return _result;
			++_this;
			++_that;
		}
		return 0;
	}

	/** Diese Methode gibt eine Zahl kleiner, gleich oder größer als <tt>0</tt> zurück, wenn die Ordnung des ersten Arrays lexikografisch kleiner, gleich bzw. größer als die des zweiten Arrays ist.<p>
	 * Die Implementation in @c SUCPolicy delegiert an @c compareArray() der @c ITEM_POLICY.
	 * @param _this erstes Array.
	 * @param _that zweites Array.
	 * @param _thislength Anzahl der Elemente im ersten Array.
	 * @param _thatlength Anzahl der Elemente im zweiten Array.
	 * @return Vergleichswert der Ordnungen. */
	inline static INT32 compareArray(ITEM const* _this, ITEM const* _that, INT32 _thislength, INT32 _thatlength) {
		if (_thislength == _thatlength) return ITEM_POLICY::compareArray(_this, _that, _thislength);
		if (_thislength < _thatlength) {
			INT32 _result = ITEM_POLICY::compareArray(_this, _that, _thislength);
			return _result ? _result : -1;
		} else {
			INT32 _result = ITEM_POLICY::compareArray(_this, _that, _thatlength);
			return _result ? _result : +1;
		}
	}

};

/** Diese Klasse definiert die @c SUCPolicy für beliebige Datenstrukturen, die ale leer betrachtet werden und damit keinen Speicher reservieren.<br>
 * Interessant ist dies beispielsweise für eine
 * @tparam _ITEM Typ der Elemente (beliebig). */
template<typename _ITEM> //
struct SUCPolicy_EMPTY: public SUCPolicy<_ITEM, SUCPolicy_EMPTY<_ITEM>> {

	public:

	/** Dieser Datentyp definiert die Elemente. */
	typedef _ITEM ITEM;

	/* SUCPolicy */
	inline static ITEM* createItem() {
		return 0;
	}

	/* SUCPolicy */
	inline static ITEM* createArray(INT32 _length) {
		SUCException::checkCount(_length);
		return 0;
	}

	/* SUCPolicy */
	inline static void deleteItem(ITEM* _item) {
	}

	/* SUCPolicy */
	inline static void deleteArray(ITEM* _array, INT32 _length) {
		SUCException::checkCount(_length);
	}

	/* SUCPolicy */
	inline static void resetItem(ITEM* _item) {
	}

	/* SUCPolicy */
	inline static void resetArray(ITEM* _array, INT32 _length) {
		SUCException::checkCount(_length);
	}

	/* SUCPolicy */
	inline static void cloneItem(ITEM* _target, ITEM const* _source) {
	}

	/* SUCPolicy */
	inline static void cloneArray(ITEM* _target, ITEM const* _source, INT32 _length) {
		SUCException::checkCount(_length);
	}

	/* SUCPolicy */
	inline static void moveItem(ITEM* _target, ITEM* _source) {
	}

	/* SUCPolicy */
	inline static void moveArray(ITEM* _target, ITEM* _source, INT32 _length) {
		SUCException::checkCount(_length);
	}

	/* SUCPolicy */
	inline static INT32 hashItem(ITEM const* _item) {
		return 0;
	}

	/* SUCPolicy */
	inline static INT32 hashArray(ITEM const* _array, INT32 _length) {
		SUCException::checkCount(_length);
		return 0;
	}

	/* SUCPolicy */
	inline static bool equalsItem(ITEM const* _this, ITEM const* _that) {
		return true;
	}

	/* SUCPolicy */
	inline static bool equalsArray(ITEM const* _this, ITEM const* _that, INT32 _length) {
		SUCException::checkCount(_length);
		return true;
	}

	/* SUCPolicy */
	inline static INT32 compareItem(ITEM const* _this, ITEM const* _that) {
		return 0;
	}

	/* SUCPolicy */
	inline static INT32 compareArray(ITEM const* _this, ITEM const* _that, INT32 _length) {
		SUCException::checkCount(_length);
		return 0;
	}

};

template<typename _ITEM, typename _ITEM_POLICY> //
struct SUCPolicy_STRUCT;

/** Diese Klasse definiert die @c SUCPolicy für strukturierte Werte.<br>
 * Das Bereinigen eines Elements @c _item erfolgt über <tt>_item = ITEM()</tt>.
 * Das Duplikat eines Elements @c _item wird über <tt>_item.clone()</tt> berechnet.
 * Der Streuwert eines Elements @c _item wird über <tt>_item.hash()</tt> berechnet.
 * Die Äquivalenz zweier Elemente @c _this und @c _that wird über <tt>_this.equals(_that)</tt> berechnet.
 * @tparam _ITEM Typ der Elemente.
 * @tparam _ITEM_POLICY Typ des von diesem erbenden Regelwerks, an dessen Methoden delegiert wird. Damit wird der Aufruf virtueller statischer Methoden simuliert. */
template<typename _ITEM, typename _ITEM_POLICY = SUCPolicy_STRUCT<_ITEM, SUCPolicy_EMPTY<_ITEM>>> //
struct SUCPolicy_STRUCT: public SUCPolicy<_ITEM, _ITEM_POLICY> {

	public:

	/** Dieser Datentyp definiert die Elemente. */
	typedef _ITEM ITEM;

	/** Dieser Datentyp definiert die @c SUCPolicy, an welche die Array-Methoden dieser delegieren. Damit wird der Aufruf virtueller statischer Methoden simuliert. */
	typedef _ITEM_POLICY ITEM_POLICY;

	/* SUCPolicy */
	inline static void resetItem(ITEM* _item) {
		*_item = ITEM();
	}

	/* SUCPolicy */
	inline static void cloneItem(ITEM* _target, ITEM const* _source) {
		*_target = _source->clone();
	}

	/* SUCPolicy */
	inline static INT32 hashItem(ITEM const* _item) {
		INT32 _result = _item->hash();
		return _result;
	}

	/* SUCPolicy */
	inline static bool equalsItem(ITEM const* _this, ITEM const* _that) {
		if (_this == _that) return true;
		bool _result = _this->equals(*_that);
		return _result;
	}

	/* SUCPolicy */
	inline static INT32 compareItem(ITEM const* _this, ITEM const* _that) {
		if (_this == _that) return 0;
		INT32 _result = _this->compare(*_that);
		return _result;
	}

};

template<typename _ITEM, typename _ITEM_POLICY> //
struct SUCPolicy_PRIMITIVE;

/** Diese Klasse definiert die @c SUCPolicy für primitive Datentypen.
 * Das Verschieben und Duplizieren von Arrays erfolgt über @c memcpy().
 * Die Äquivalenz von Arrays wird über @c memcmp() berechnet.
 * @tparam _ITEM Typ der Elemente.
 * @tparam _ITEM_POLICY Typ des von diesem erbenden Regelwerks, an dessen Methoden delegiert wird. Damit wird der Aufruf virtueller statischer Methoden simuliert. */
template<typename _ITEM, typename _ITEM_POLICY = SUCPolicy_PRIMITIVE<_ITEM, SUCPolicy_EMPTY<_ITEM>>> //
struct SUCPolicy_PRIMITIVE: public SUCPolicy<_ITEM, _ITEM_POLICY> {

	public:

	/** Dieser Datentyp definiert die Elemente. */
	typedef _ITEM ITEM;

	/* SUCPolicy */
	inline static void cloneArray(_ITEM* _target, _ITEM const* _source, INT32 const _length) {
		SUCException::checkCount(_length);
		memcpy(_target, _source, _length * sizeof(_ITEM));
	}

	/* SUCPolicy */
	inline static void moveArray(_ITEM* _target, _ITEM* _source, INT32 const _length) {
		SUCException::checkCount(_length);
		memcpy(_target, _source, _length * sizeof(_ITEM));
	}

	/* SUCPolicy */
	inline static bool equalsArray(_ITEM const* _this, _ITEM const* _that, INT32 const _length) {
		SUCException::checkCount(_length);
		bool _result = (_this == _that) || !memcmp(_this, _that, _length * sizeof(_ITEM));
		return _result;
	}

};

/** Dieses Klasse definiert Schalter und Regelwerke zur Anpassung von Algorithmen, Speicherverbrauch und Maximalekapazität eines @c SUCMapping.<br>
 * Der Speicherverbrauch wird hierbei durch die Anzahl der reservierten Einträge und die Verwaltungsdaten je reservierten Eintrag (VJRE = 2..12 Byte) sowie je Iterator (VJI = ) bestimmt.
 * @tparam _TREE_ENABLED Wert für @c TREE_ENABLED.
 * @tparam _HASH_ENABLED Wert für @c HASH_ENABLED.
 * @tparam _CACHE_ENABLED Wert für @c CACHE_ENABLED.
 * @tparam _ITEM Typ der Verweise/Positionen auf Einträge des @c SUCMapping.
 */
template<UINT8 _TREE_ENABLED, UINT8 _HASH_ENABLED, UINT8 _CACHE_ENABLED, typename _ITEM> //
struct SUCMapping_POLICY {

	/** Dieses Feld ist <tt>1</tt>, wenn die Suche der Schlüssel eines @c SUCMapping ordnungsbasiert erfolgt. Sonst ist es <tt>0</tt>. */
	static UINT8 const TREE_ENABLED = _TREE_ENABLED & 1;

	/** Dieses Feld ist <tt>1</tt>, wenn die Suche der Schlüssel eines @c SUCMapping streuwertbasiert erfolgt. Sonst ist es <tt>0</tt>. */
	static UINT8 const HASH_ENABLED = _HASH_ENABLED & 1;

	/** Dieses Feld ist <tt>1</tt>, wenn die Suche ein streuwertbasiertes @c SUCMapping durch Puffern der Streuwerte beschleunigt werden soll. Sonst ist es <tt>0</tt>. */
	static UINT8 const CACHE_ENABLED = _CACHE_ENABLED & 1;

	/** Dieses Regelwerks gilt für die Verweise/Positionen auf Einträge eines @c SUCMapping und begrenzt damit die maximale Anzahl der verwalteten Einträge.<br>
	 * Zulässig sind @c UINT8 (255), @c UINT16 (65535) und @c UINT32 (1073741823).<br> */
	typedef SUCPolicy_PRIMITIVE<_ITEM> INDEX_POLICY;

	/** Dieses Regelwerks gilt für die Tiefe von Knoten eines Baums bei einem ordnungsbasierten @c SUCMapping. */
	typedef SUCPolicy_PRIMITIVE<UINT8> LEVEL_POLICY;

};

/** Dieses Regelwerk konfiguriert ein streuwertbasiertes @c SUCMapping mit bis zu <tt>255</tt> Einträgen ohne Streuwertpuffer (VJRE = 2 Byte, VJI = 16 Byte). */
struct SUCMapping_POLICY_HASH_8: public SUCMapping_POLICY<0, 1, 0, UINT8> {
};

/** Dieses Regelwerk konfiguriert ein streuwertbasiertes @c SUCMapping mit bis zu <tt>65535</tt> Einträgen ohne Streuwertpuffer (VJRE = 4 Byte, VJI = 16 Byte). */
struct SUCMapping_POLICY_HASH_16: public SUCMapping_POLICY<0, 1, 0, UINT16> {
};

/** Dieses Regelwerk konfiguriert ein streuwertbasiertes @c SUCMapping mit bis zu <tt>1073741823</tt> Einträgen ohne Streuwertpuffer (VJRE = 8 Byte, VJI = 20 Byte). */
struct SUCMapping_POLICY_HASH_32: public SUCMapping_POLICY<0, 1, 0, UINT32> {
};

/** Dieses Regelwerk konfiguriert ein streuwertbasiertes @c SUCMapping mit bis zu <tt>255</tt> Einträgen mit Streuwertpuffer (VJRE = 3 Byte, VJI = 16 Byte). */
struct SUCMapping_POLICY_HASH_8_CACHE: public SUCMapping_POLICY<0, 1, 1, UINT8> {
};

/** Dieses Regelwerk konfiguriert ein streuwertbasiertes @c SUCMapping mit bis zu <tt>65535</tt> Einträgen mit Streuwertpuffer (VJRE = 6 Byte, VJI = 16 Byte). */
struct SUCMapping_POLICY_HASH_16_CACHE: public SUCMapping_POLICY<0, 1, 1, UINT16> {
};

/** Dieses Regelwerk konfiguriert ein streuwertbasiertes @c SUCMapping mit bis zu <tt>1073741823</tt> Einträgen mit Streuwertpuffer (VJRE = 12 Byte, VJI = 20 Byte). */
struct SUCMapping_POLICY_HASH_32_CACHE: public SUCMapping_POLICY<0, 1, 1, UINT32> {
};

/** Dieses Regelwerk konfiguriert ein ordnungsbasiertes @c SUCMapping mit bis zu <tt>255</tt> Einträgen (VJRE = 3 Byte, VJI = 28 Byte). */
struct SUCMapping_POLICY_TREE_8: public SUCMapping_POLICY<1, 0, 0, UINT8> {
};

/** Dieses Regelwerk konfiguriert ein ordnungsbasiertes @c SUCMapping mit bis zu <tt>65535</tt> Einträgen (VJRE = 5 Byte, VJI = 52 Byte). */
struct SUCMapping_POLICY_TREE_16: public SUCMapping_POLICY<1, 0, 0, UINT16> {
};

/** Dieses Regelwerk konfiguriert ein ordnungsbasiertes @c SUCMapping mit bis zu <tt>1073741823</tt> Einträgen (VJRE = 9 Byte, VJI = 144 Byte). */
struct SUCMapping_POLICY_TREE_32: public SUCMapping_POLICY<1, 0, 0, UINT32> {
};

/** Diese Klasse dokumentiert die Struktur der Zustandsdaten eines @c SUCCursor. Konkrete Realisierungen können von dieser Klasse erben, müssen es jedoch nicht. Wichtig ist nur, dass sie die beschribenen Methoden umsetzen.
 * @tparam _ITEM Typ der Elemente des @c SUCCursor.
 * @tparam _ITERATOR Typ der konkreten Zustandsdaten, die in dem Methoden @c equals(), @c compare() und @c distance() genutzt werden. */
template<typename _ITEM, typename _ITERATOR> //
struct SUCIterator {

	public:

	/** Dieser Datentyp definiert die Elemente des @c SUCIterator. */
	typedef _ITEM ITEM;

	/** Dieser Datentyp definiert die konkreten Zustandsdaten. */
	typedef _ITERATOR ITERATOR;

	/** Diese Klasse definiert den in die Gegenrichtung laufenden @c SUCIterator zu @c GITERATOR. */
	struct ITERATOR_REVERSE: public SUCIterator<ITEM, ITERATOR_REVERSE> {

		public:

		/* SUCIterator */
		inline static bool equals(ITERATOR_REVERSE const& _this, ITERATOR const& _that) {
			return ITERATOR::equals(_this.iterator, _that);
		}

		/* SUCIterator */
		inline static bool equals(ITERATOR_REVERSE const& _this, ITERATOR_REVERSE const& _that) {
			return ITERATOR::equals(_this.iterator, _that.iterator);
		}

		/* SUCIterator */
		inline static bool compare(ITERATOR_REVERSE const& _this, ITERATOR const& _that, INT32& _result) {
			return ITERATOR::compare(_this.iterator, _that, _result);
		}

		/* SUCIterator */
		inline static bool compare(ITERATOR_REVERSE const& _this, ITERATOR_REVERSE const& _that, INT32& _result) {
			return ITERATOR::compare(_this.iterator, _that.iterator, _result);
		}

		/* SUCIterator */
		inline static bool distance(ITERATOR_REVERSE const& _this, ITERATOR const& _that, INT32& _result) {
			return ITERATOR::distance(_this.iterator, _that, _result);
		}

		/* SUCIterator */
		inline static bool distance(ITERATOR_REVERSE const& _this, ITERATOR_REVERSE const& _that, INT32& _result) {
			return ITERATOR::distance(_this.iterator, _that.iterator, _result);
		}

		/** Dieser Konstruktor initialisiert die konkreten Zustandsdaten.
		 * @param _iterator konkrete Zustandsdaten. */
		inline ITERATOR_REVERSE(ITERATOR const& _iterator)
				: iterator(_iterator) {
		}

		/* SUCIterator */
		inline bool valid() const {
			return iterator.valid();
		}

		/* SUCIterator */
		inline ITEM& value() {
			return iterator.value();
		}

		/* SUCIterator */
		inline ITEM const& value() const {
			return iterator.value();
		}

		/* SUCIterator */
		inline bool move(INT32 const _offset) {
			return iterator.move(-_offset);
		}

		/** Dieses Feld speichert die Zustandsdaten dieses @c SUCCursor. */
		ITERATOR iterator;

	};

	/** Diese Methode gibt nur dann <tt>true</tt> zurück, wenn die Zeiger auf das aktuelle Element bei beiden gegebenen Objekten gleich sind.<br>
	 * Dies ist nur dann der Fall, wenn sich beide Objekte auf die gleichen Datengrundlage beziehen und auf das gleiche Element zeigen.
	 * @param _this erstes Objekt mit Zeiger auf ein aktuelles Element.
	 * @param _that zweites Objekt mit Zeiger auf ein aktuelles Element.
	 * @return <tt>true</tt>, wenn die Zeiger gleich sind. */
	inline static bool equals(ITERATOR const& _this, ITERATOR const& _that) {
		INT32 _result;
		return ITERATOR::compare(_this, _that, _result) && !_result;
	}

	/* SUCIterator */
	inline static bool equals(ITERATOR const& _this, ITERATOR_REVERSE const& _that) {
		return ITERATOR::equals(_this, _that.iterator);
	}

	/** Diese Methode setzt den Vergleichswert @c _result auf einen Wert kleiner als, gleich oder größer als <tt>0</tt>, wenn sich der Zeiger auf das aktuelle Element des ersten gegebenen Objekts vor, bei bzw. nach dem des zweiten gegebenen Objekts befindet und gibt nur dann <tt>true</tt> zurück, wenn dieser Wert berechnet werden konnte.<br>
	 * Der Vergleichswert kann i.d.R. über @c distance() ermittelt werden.
	 * @param _this erstes Objekt mit Zeiger auf ein aktuelles Element.
	 * @param _that zweites Objekt mit Zeiger auf ein aktuelles Element.
	 * @param _result Vergleichswert.
	 * @return <tt>true</tt>, wenn der Vergleichswert berechnet wurde.@c false, wenn die Berechnung nicht möglich ist. */
	inline static bool compare(ITERATOR const& _this, ITERATOR const& _that, INT32& _result) {
		return ITERATOR::distance(_this, _that, _result);
	}

	/* SUCIterator */
	inline static bool compare(ITERATOR const& _this, ITERATOR_REVERSE const& _that, INT32& _result) {
		return ITERATOR::compare(_this, _that.iterator, _result);
	}

	/** Diese Methode setzt den Distanzwert @c _result auf die Anzahl der Elemente zwischen dem Zeiger auf das aktuelle Element des zweiten und ersten gegebenen Objekts und gibt nur dann <tt>true</tt> zurück, wenn dieser Wert berechnet werden konnte.<br>
	 * Der Distanzwert ist negativ, wenn der Zeiger dieses Objekts vor dem des gegebenen liegt.
	 * @param _this erstes Objekt mit Zeiger auf ein aktuelles Element.
	 * @param _that zweites Objekt mit Zeiger auf ein aktuelles Element.
	 * @param _result Distanzwert.
	 * @return <tt>true</tt>, wenn der Distanzwert berechnet wurde.@c false, wenn die Berechnung nicht möglich ist. */
	inline static bool distance(ITERATOR const& _this, ITERATOR const& _that, INT32& _result);

	/* SUCIterator */
	inline static bool distance(ITERATOR const& _this, ITERATOR_REVERSE const& _that, INT32& _result) {
		return ITERATOR::distance(_this, _that.iterator, _result);
	}

	/** Diese Methode gibt nur dann <tt>true</tt> zurück, es ein aktuelles Element gibt, dass von @c value() geliefert werden kann.
	 * @return Validität der Referenz auf das aktuelle Element. */
	inline bool valid() const;

	/** Diese Methode gibt die Referenz auf das aktuelle Element zurück.<br>
	 * Wenn es kein aktuelles Element gibt, ist der Rückgabewert unbestimmt bzw.  kann eine @c SUCException ausgelöst werden.
	 * @see valid()
	 * @return Referenz auf das aktuelle Element. */
	inline ITEM& value();

	/** @copydoc value() */
	inline ITEM const& value() const;

	/** Diese Methode bewegt den auf das aktuelle Element verweisenden Zeiger um die gegebenen Anzahl an Elementen weiter und gibt nur dann <tt>true</tt> zurück, wenn dies erfolgreich war.<br>
	 * Eine Positive Anzahl bewegt den Zeiger vorwärts, eine negative rückwärts.
	 * @param _offset Anzahl an Elementen.
	 * @return <tt>true</tt>, wenn der Zeiger erfolgreich bewegt wurde.<br>@c false, wenn die Bewegung nicht möglich ist. */
	inline bool move(INT32 const _offset);

};

/** Diese Klasse implementiert einen <i>cursor</i> als beweglichen Zeiger, der durch eine Sammlung von Elementen navigiert werden kann.<br>
 * Die Navigation kann dabei über Methoden sowie Operatoren erfolgen. Der Einsatz in einer <tt>for</tt>-Schleife kann so aussehen:<p>
 * @code for (SUCCursor cur = ...; cur; ++cur) ...; @endcode
 * Die Operatoren dieses @c SUCCursor delegieren an seine Methoden, welche an analoge Methoden der internen Zustandsdaten delegieren.
 * Die Struktur dieser Zustandsdaten wird in der Klasse @c SUCIterator dokumentiert.<p>
 * Die Prefixoperatoren @c ++cur und @c --cur eines @c SUCCursor @c cur sind i.d.R. effizienter als die Suffixoperatoren @c cur++ und @c cur--.
 * @tparam _ITEM Typ der Elemente in der Sammlung.
 * @tparam _ITERATOR Typ der Zustandsdaten. */
template<typename _ITEM, typename _ITERATOR> //
struct SUCCursor {

	public:

	/** Dieser Datentyp definiert die Elemente. */
	typedef _ITEM ITEM;

	/** Dieser Datentyp definiert die Zustandsdaten. */
	typedef _ITERATOR ITERATOR;

	/** Dieser Datentyp definiert die rückwärts gerichteten Zustandsdaten. */
	typedef typename SUCIterator<ITEM, ITERATOR>::ITERATOR_REVERSE ITERATOR_REVERSE;

	/** Dieser Datentyp definiert diesen @c SUCCursor. */
	typedef SUCCursor<ITEM, ITERATOR> CURSOR;

	/** Dieser Datentyp definiert den rückwärts gerichteten @c SUCCursor. */
	typedef SUCCursor<ITEM, ITERATOR_REVERSE> CURSOR_REVERSE;

	/** Dieser Konstruktor initialisiert die Zustandsdaten.
	 * @param _iterator Zustandsdaten. */
	SUCCursor(ITERATOR const& _iterator)
			: iterator(_iterator) {
	}

	/** Diese Methode gibt einen ab der aktuellen Position in die entgegengesetzte Richtung laufenden @c SUCCursor zurück.
	 * @return @c SUCCursor in die Gegenrichtung. */
	inline CURSOR_REVERSE reverse() {
		return CURSOR_REVERSE(ITERATOR_REVERSE(iterator));
	}

	/** Dieser Operator delegiert an @c valid() des @c iterator. */
	inline operator bool() const {
		return iterator.valid();
	}

	/** Dieser Operator delegiert an @c value() des @c iterator.
	 * @throws SUCException Wenn es kein aktuelles Element gibt. */
	inline ITEM& operator*() {
		return iterator.value();
	}

	/** @copydoc operator*() */
	inline ITEM const& operator*() const {
		return iterator.value();
	}

	/** @copydoc operator*() */
	inline ITEM* operator->() {
		return &iterator.value();
	}

	/** @copydoc operator*() */
	inline ITEM const* operator->() const {
		return &iterator.value();
	}

	/** @copydoc operator++(INT32) */
	inline CURSOR operator+(INT32 _offset) const {
		CURSOR _result(*this);
		SUCException::checkState(_result.iterator.move(+_offset));
		return _result;
	}

	/** @copydoc operator++() */
	inline CURSOR& operator+=(INT32 _offset) {
		SUCException::checkState(iterator.move(+_offset));
		return *this;
	}

	/** Dieser Operator delegiert an @c move() des @c iterator.
	 * @throws SUCException Wenn die Bewegung des Zeigers nicht möglich ist. */
	inline CURSOR& operator++() {
		SUCException::checkState(iterator.move(+1));
		return *this;
	}

	/** Dieser Operator delegiert an @c move() des @c iterator.
	 * @throws SUCException Wenn die Bewegung des Zeigers nicht möglich ist. */
	inline CURSOR operator++(int) {
		CURSOR _result(*this);
		SUCException::checkState(iterator.move(+1));
		return _result;
	}

	/** @copydoc operator++(INT32) */
	inline CURSOR operator-(INT32 _offset) const {
		CURSOR _result(*this);
		SUCException::checkState(_result.iterator.move(-_offset));
		return _result;
	}

	/** @copydoc operator++() */
	inline CURSOR& operator-=(INT32 _offset) {
		SUCException::checkState(iterator.move(-_offset));
		return *this;
	}

	/** @copydoc operator++() */
	inline CURSOR& operator--() {
		SUCException::checkState(iterator.move(-1));
		return *this;
	}

	/** @copydoc operator++(INT32) */
	inline CURSOR operator--(int) {
		CURSOR _result(*this);
		SUCException::checkState(iterator.move(-1));
		return _result;
	}

	/** Dieses Feld speichert die Zustandsdaten dieses @c SUCCursor. */
	ITERATOR iterator;

};

/* Dieser Operator delegiert an @c SUCIterator::equals() des linken @c SUCCursor. */
template<typename _ITEM, typename _ITERATOR1, typename _ITERATOR2> //
bool operator ==(SUCCursor<_ITEM, _ITERATOR1> const& _this, SUCCursor<_ITEM, _ITERATOR2> const& _that) {
	return _ITERATOR1::equals(_this.iterator, _that.iterator);
}

/* Dieser Operator delegiert an @c SUCIterator::equals() des linken @c SUCCursor. */
template<typename _ITEM, typename _ITERATOR1, typename _ITERATOR2> //
bool operator !=(SUCCursor<_ITEM, _ITERATOR1> const& _this, SUCCursor<_ITEM, _ITERATOR2> const& _that) {
	return !_ITERATOR1::equals(_this.iterator, _that.iterator);
}

/* Dieser Operator delegiert an @c SUCIterator::compare() des linken @c SUCCursor. */
template<typename _ITEM, typename _ITERATOR1, typename _ITERATOR2> //
bool operator <(SUCCursor<_ITEM, _ITERATOR1> const& _this, SUCCursor<_ITEM, _ITERATOR2> const& _that) {
	INT32 _result;
	SUCException::checkState(_ITERATOR1::compare(_this.iterator, _that.iterator, _result));
	return _result < 0;
}

/* Dieser Operator delegiert an @c SUCIterator::compare() des linken @c SUCCursor. */
template<typename _ITEM, typename _ITERATOR1, typename _ITERATOR2> //
bool operator <=(SUCCursor<_ITEM, _ITERATOR1> const& _this, SUCCursor<_ITEM, _ITERATOR2> const& _that) {
	INT32 _result;
	SUCException::checkState(_ITERATOR1::compare(_this.iterator, _that.iterator, _result));
	return _result <= 0;
}

/* Dieser Operator delegiert an @c SUCIterator::compare() des linken @c SUCCursor. */
template<typename _ITEM, typename _ITERATOR1, typename _ITERATOR2> //
bool operator >=(SUCCursor<_ITEM, _ITERATOR1> const& _this, SUCCursor<_ITEM, _ITERATOR2> const& _that) {
	INT32 _result;
	SUCException::checkState(_ITERATOR1::compare(_this.iterator, _that.iterator, _result));
	return _result >= 0;
}

/* Dieser Operator delegiert an @c SUCIterator::compare() des linken @c SUCCursor. */
template<typename _ITEM, typename _ITERATOR1, typename _ITERATOR2> //
bool operator >(SUCCursor<_ITEM, _ITERATOR1> const& _this, SUCCursor<_ITEM, _ITERATOR2> const& _that) {
	INT32 _result;
	SUCException::checkState(_ITERATOR1::compare(_this.iterator, _that.iterator, _result));
	return _result > 0;
}

/* Dieser Operator delegiert an @c SUCIterator::distance() des ersten @c SUCCursor. */
template<typename _ITEM, typename _ITERATOR1, typename _ITERATOR2> //
INT32 operator -(SUCCursor<_ITEM, _ITERATOR1> const& _this, SUCCursor<_ITEM, _ITERATOR2> const& _that) {
	INT32 _result;
	SUCException::checkState(_ITERATOR1::distance(_this.iterator, _that.iterator, _result));
	return _result;
}

/** Diese Klasse implementiert ein Array mit konstanter Elementanzahl.<br>
 * Das Array kann den Speicherbereich mit den Elementen selbst verwalten oder auf einen gegebenen Speicherbereich verweisen.
 * @tparam _ITEM Typ der Elemente.
 * @tparam _ITEM_POLICY Typ des Regelwerks zur Handhabung der Elemente (@c SUCPolicy). */
template<typename _ITEM, typename _ITEM_POLICY = SUCPolicy_PRIMITIVE<_ITEM>> //
struct SUCArray {

	public:

	/** Dieser Datentyp definiert die Elemente des @c SUCArray. */
	typedef _ITEM ITEM;

	/** Dieser Datentyp definiert die @c SUCPolicy der Elemente des @c SUCArray. */
	typedef _ITEM_POLICY ITEM_POLICY;

	/** Dieser Datentyp definiert dieses @c SUCArray. */
	typedef SUCArray<ITEM, ITEM_POLICY> ARRAY;

	struct ITERATOR;

	/** Diese Klasse definiert die referenzgezählten Nutzdaten eines @c SUCArray. */
	struct OBJECT: public RCObject<OBJECT> {

		public:

		OBJECT(INT32 _length)
				: _delete_(true), _itemCount_(_length), _itemArray_(0) {
			_itemArray_ = ITEM_POLICY::createArray(_length);
		}

		OBJECT(ITEM* _array, INT32 _length, bool _clone)
				: _delete_(_clone), _itemCount_(_length), _itemArray_(0) {
			SUCException::checkCount(_length);
			if (_clone) {
				ITEM_POLICY::cloneArray(_itemArray_ = ITEM_POLICY::createArray(_length), _array, _length);
			} else {
				_itemArray_ = _array;
			}
		}

		~OBJECT() {
			if (!_delete_) return;
			ITEM_POLICY::deleteArray(_itemArray_);
		}

		private:

		friend ARRAY;

		friend ITERATOR;

		OBJECT()
				: _delete_(false), _itemCount_(0), _itemArray_(0) {
			this->counter().inc();
		}

		inline ITEM& _item_(INT32 _index) {
			SUCException::checkIndex(_index, _itemCount_);
			ITEM& _result = _itemArray_[_index];
			return _result;
		}

		/** Dieses Feld speichert <tt>true</tt>, wenn der Speicherbereich im Destruktor freigegeben werden soll. */
		bool _delete_;

		/** Dieses Feld speichert die Anzahl der Element im Speicherbereich. */
		INT32 _itemCount_;

		/** Dieses Feld speichert den Beginn des Speicherbereichs. */
		ITEM* _itemArray_;

	};

	/** Diese Klasse definiert die Zustandsdaten des @c SUCCursor dieses @c SUCArray. */
	struct ITERATOR: public SUCIterator<ITEM, ITERATOR> {

		public:

		/* SUCIterator */
		static bool distance(ITERATOR const& _this, ITERATOR const& _that, INT32& _result) {
			if (_this._minValue_ != _that._minValue_) return false;
			_result = _this._curValue_ - _that._curValue_;
			return true;
		}

		/** Dieser Konstruktor initialisiert das @c SUCArray und die aktuelle Position.
		 * @param _array @c SUCArray.
		 * @param _index aktuelle Position. */
		ITERATOR(ARRAY const& _array, INT32 _index)
				: _array_(_array) {
			OBJECT& _that = *_array._object_;
			_minValue_ = _that._itemArray_;
			_curValue_ = _minValue_ + _index;
			_maxValue_ = _minValue_ + _that._itemCount_;
		}

		/* SUCIterator */
		inline bool valid() const {
			return (_minValue_ <= _curValue_) && (_curValue_ < _maxValue_);
		}

		/* SUCIterator */
		inline ITEM& value() {
			return *_curValue_;
		}

		/* SUCIterator */
		inline ITEM const& value() const {
			return *_curValue_;
		}

		/* SUCIterator */
		inline bool move(INT32 _offset) {
			_curValue_ += _offset;
			return true;
		}

		private:

		/** Dieses Feld speichert das @c SUCArray als Besitzer. */
		ARRAY _array_;

		/** Dieses Feld speichert das erste Element. */
		ITEM* _minValue_;

		/** Dieses Feld speichert das aktuelle Element. */
		ITEM* _curValue_;

		/** Dieses Feld speichert das Element nach dem letzten. */
		ITEM* _maxValue_;

	};

	public:

	/** Dieser Datentyp definiert den @c SUCCursor des @c SUCArray. */
	typedef SUCCursor<ITEM, ITERATOR> CURSOR;

	/** Dieser Datentyp definiert den @c SUCCursor des @c SUCArray (@c const). */
	typedef SUCCursor<ITEM const, ITERATOR> CURSOR_CONST;

	/** Dieser Konstruktor erzeugt ein leeres @c SUCArray ohne Elemente. */
	SUCArray()
			: _object_(&_EMPTY_) {
	}

	/** Dieser Konstruktor erzeugt ein @c SUCArray mit der gegebenen Anzahl an Elementen.
	 * @param _length Anzahl der Elemente. */
	SUCArray(INT32 _length)
			: _object_(_length ? new OBJECT(_length) : &_EMPTY_) {
	}

	/** Dieser Konstruktor erzeugt ein @c SUCArray mit den Elementen des gegebenen Speicherbereichs.
	 * @param _array Beginn des Speicherbereichs.
	 * @param _length Anzahl der Elemente im Speicherbereich.
	 * @param _clone <tt>true</tt>, wenn die Elemente des gegebenen Speicherbereich in einen intern verwalteten Speicherbereich dupliziert werden sollen.<br>@c false, wenn intern auf den gegebenen Speicherbereich verwiesen werden soll. */
	SUCArray(ITEM* _array, INT32 _length, bool _clone = true)
			: _object_(_length ? new OBJECT(_array, _length, _clone) : &_EMPTY_) {
	}

	/** Diese Methode gibt eie Kopie des Element an der gegebenen Position zurück.
	 * @see SUCPolicy.cloneItem()
	 * @param _index Position (<tt>0...length()-1</tt>).
	 * @return Kopie des <tt>_index</tt>-ten Elements.
	 * @throws SUCException Wenn die Position ungültig ist. */
	ITEM get(INT32 _index) const {
		ITEM _result;
		ITEM_POLICY::cloneItem(&_result, &this[_index]);
		return _result;
	}

	/** Diese Methode setzt das Element an der gegebenen Position.
	 * @param _index Position (<tt>0...length()-1</tt>).
	 * @param _item Element.
	 * @throws SUCException Wenn die Position ungültig ist. */
	void set(INT32 _index, ITEM const& _item) {
		ITEM_POLICY::cloneItem(&this[_index], &_item);
	}

	/** Diese Methode gibt den Zeiger auf das erste Element dieses @c SUCArray zurück.<br>
	 * Wenn dieses @c SUCArray leer ist, wird <tt>0</tt> geliefert.
	 * @return Zeiger auf erstes Element oder <tt>0</tt>. */
	ITEM* data() {
		OBJECT& _this = *_object_;
		return _this._itemArray_;
	}

	/** @copydoc data() */
	ITEM const* data() const {
		OBJECT& _this = *_object_;
		return _this._itemArray_;
	}

	/** Diese Methode gibt die Anzahl der Elemente dieses @c SUCArray zurück.
	 * @return Anzahl der Elemente. */
	INT32 length() const {
		OBJECT& _this = *_object_;
		return _this._itemCount_;
	}

	/** Diese Methode gibt den Streuwert dieses @c SUCArray zurück.
	 * @see SUCPolicy.hashArray()
	 * @return Streuwert dieses @c SUCArray. */
	INT32 hash() const {
		OBJECT& _this = *_object_;
		INT32 _result = ITEM_POLICY::hashArray(_this._itemArray_, _this._itemCount_);
		return _result;
	}

	/** Diese Methode gibt eine Kopie dieses @c SUCArray zurück.<br>
	 * Die Kopie verwaltet intern einen neuen Speicherbereich, in welchen die Elemente abgeschrieben werden.
	 * @see SUCPolicy.cloneArray()
	 * @return Kopie dieses @c SUCArray. */
	ARRAY clone() const {
		OBJECT& _this = *_object_;
		return ARRAY(_this._itemArray_, _this._itemCount_, true);
	}

	/** Diese Methode gibt nur dann <tt>true</tt> zurück, wenn dieses @c SUCArray äquivalent zu dem gegebenen ist.
	 * @see SUCPolicy.equalsArray()
	 * @param _that @c SUCArray.
	 * @return <tt>true</tt>, wenn dieses und das gegebene @c SUCArray äquivalent sind. */
	bool equals(ARRAY const& _that) const {
		OBJECT& _this = *_that._object_;
		return equals(_this._itemArray_, _this._itemCount_);
	}

	/** Diese Methode gibt nur dann <tt>true</tt> zurück, wenn die Elemente dieses @c SUCArray äquivalent zu den gegebenen sind.
	 * @see SUCPolicy.equalsArray()
	 * @param _array Array der Elemente.
	 * @param _length Anzahl der Elemente.
	 * @return <tt>true</tt>, wenn die Elemente dieses @c SUCArray äquivalent zu den gegebene sind. */
	bool equals(ITEM const* _array, INT32 _length) const {
		OBJECT& _this = *_object_;
		if (_this._itemCount_ != _length) return false;
		return ITEM_POLICY::equalsArray(_this._itemArray_, _array, _length);
	}

	INT32 compare(ARRAY const& _that) const {
		OBJECT& _this = *_that._object_;
		return compare(_this._itemArray_, _this._itemCount_);
	}

	INT32 compare(ITEM const* _array, INT32 _length) const {
		OBJECT& _this = *_object_;
		return ITEM_POLICY::compareArray(_this._itemArray_, _array, _this._itemCount_, _length);
	}

	/** Diese Methode gibt den an der gegebenen Position stehenden @c SUCCursor dieses @c SUCArray zurück.
	 * @param _index Startposition.
	 * @return @c SUCCursor dieses @c SUCArray. */
	CURSOR cursor(INT32 _index = 0) {
		return CURSOR(ITERATOR(*this, _index));
	}

	/** @copydoc cursor() */
	CURSOR_CONST cursor(INT32 _index = 0) const {
		return CURSOR_CONST(ITERATOR(*this, _index));
	}

	/** Dieser Operator gibt die Referenz auf das Element an der gegebenen Position zurück.
	 * @param _index Position (<tt>0...length()-1</tt>).
	 * @return Referenz auf das Element an der gegebenen Position.
	 * @throws SUCException Wenn die Position ungültig ist. */
	ITEM& operator[](INT32 _index) {
		OBJECT& _this = *_object_;
		return _this._item_(_index);
	}

	/** @copydoc operator[](INT32 const) */
	ITEM const& operator[](INT32 _index) const {
		OBJECT& _this = *_object_;
		return _this._item_(_index);
	}

	private:

	/** Dieses Feld speichert die leeren Nutzdaten. */
	static OBJECT _EMPTY_;

	/** Dieses Feld speichert die referenzgezählten Nutzdaten. */
	RCPointer<OBJECT> _object_;

};

template<typename ITEM, typename ITEM_POLICY>
typename SUCArray<ITEM, ITEM_POLICY>::OBJECT SUCArray<ITEM, ITEM_POLICY>::_EMPTY_ = OBJECT();

/** Diese Klasse implementiert ein Array mit variabler Elementanzahl.<p>
 * Das Einfügen und Entfernen von Elementen verändern in dieser Implementation nicht nur die Größe des mit den Elementen belegten Abschnitts im internen Speicherbereich, sondern auch dessen Position.<br>
 * Beim Entfernen von Elementen, werden die wenigen Elemente vor bzw. nach dem zu entfernenden Bereich verschoben. Dadurch vergrößert sich entweder der Leerraum vor oder nach dem Nutzdatenbereich.
 * Reicht der verfügbare Leerraum zum Verschieben dieser wenigen Elemente nicht aus, werden alle Elemente verschoben und im internen Speicherbereich ausgerichtet.
 * Jenachdem, ob der Nutzdatenabschnitt zu Beginn, in der Mitte oder am Ende des internen Speicherbereichs ausgerichtet wird, wird das häufige Einfügen von Elementen am Ende, in der Mitte bzw. zu Beginn beschleunigt.
 * Die Änderung der Kapazität des internen Speicherbereichs führ in jedem Fall zu einer erneuten Ausrichtung.
 * @tparam _ITEM Typ der Elemente.
 * @tparam _ITEM_POLICY Typ des Regelwerks zur Handhabung der Elemente (@c SUCPolicy). */
template<typename _ITEM, typename _ITEM_POLICY = SUCPolicy_PRIMITIVE<_ITEM>> //
struct SUCListing {

	public:

	/** Dieser Datentyp definiert die Elemente des @c SUCListing. */
	typedef _ITEM ITEM;

	/** Dieser Datentyp definiert die @c SUCPolicy der Elemente des @c SUCListing. */
	typedef _ITEM_POLICY ITEM_POLICY;

	/** Dieser Datentyp definiert das @c SUCArray zur @c SUCPolicy dieses @c SUCListing. */
	typedef SUCArray<ITEM, ITEM_POLICY> ARRAY;

	/** Dieser Datentyp definiert dieses @c SUCListing. */
	typedef SUCListing<ITEM, ITEM_POLICY> LISTING;

	struct ITERATOR;

	/** Diese Klasse definiert die referenzgezählten Nutzdaten eines @c SUCListing. */
	struct OBJECT: public RCObject<OBJECT> {

		public:

		OBJECT(INT32 _capacity)
				: _itemAlign_(0), _itemArray_(0), _itemCount_(0), _itemOffset_(0), _itemCapacity_(_capacity) {
			_itemArray_ = ITEM_POLICY::createArray(_capacity);
		}

		~OBJECT() {
			ITEM_POLICY::deleteArray(_itemArray_ - _itemOffset_);
		}

		private:

		friend LISTING;

		friend ITERATOR;

		inline ITEM& _item_(INT32 _index) {
			SUCException::checkIndex(_index, _itemCount_);
			ITEM& _result = _itemArray_[_index];
			return _result;
		}

		/** Diese Methode setzt die Kapazität und kopiert hierfür alle Elemente in einen neu erzeugten Speicherbereich.<br>
		 * Es werden keine Wertebereichsprüfungen vorgenommen!
		 * @param _capacity Kapazität. */
		void _resize_(INT32 _capacity) {
			INT32 _length = _itemCount_, _oldOffset = _itemOffset_, _newOffset = _calcOffset_(_capacity - _length);
			ITEM* _oldArray = _itemArray_;
			ITEM* _newArray = ITEM_POLICY::createArray(_capacity) + _newOffset;
			DELETE_ARRAY<ITEM, ITEM_POLICY> _deleteValues(_oldArray - _oldOffset);
			_itemArray_ = _newArray;
			_itemOffset_ = _newOffset;
			_itemCapacity_ = _capacity;
			ITEM_POLICY::moveArray(_newArray, _oldArray, _length);
		}

		/** Diese Methode fügt an der gegebenen Position die gegebene Anzahl an Elementen ein und verschiebt dazu die umliegenden Elemente im aktuellen oder einen neuen Speicherbereich.<br>
		 * Es werden keine Wertebereichsprüfungen vorgenommen!
		 * @param _index Beginn des Bereichs mit den einzufügenden Elementen.
		 * @param _count Größe des Bereichs. */
		void _putItem_(INT32 _index, INT32 _count) {
			INT32 _oldCount = _itemCount_, _newCount = _oldCount + _count, _oldOffset = _itemOffset_, _oldCapacity = _itemCapacity_;
			ITEM* _oldArray = _itemArray_;
			if (_oldCapacity < _newCount) { // neuen Speicherbereich bestücken
				INT32 _newCapacity = _oldCapacity + (_oldCapacity >> 1);
				if (_newCapacity < _newCount) _newCapacity = _newCount;
				INT32 _newOffset = _calcOffset_(_newCapacity - _newCount);
				ITEM* _newArray = ITEM_POLICY::createArray(_newCapacity) + _newOffset;
				DELETE_ARRAY<ITEM, ITEM_POLICY> _deleteValues(_oldArray - _oldOffset);
				_itemArray_ = _newArray;
				_itemCount_ = _newCount;
				_itemOffset_ = _newOffset;
				_itemCapacity_ = _newCapacity;
				ITEM_POLICY::moveArray(_newArray, _oldArray, _index);
				ITEM_POLICY::moveArray(_newArray + _index + _count, _oldArray + _index, _oldCount - _index);
				return;
			}
			if (_index >= (_oldCount >> 1)) { // Hinten einfügen
				if ((_oldOffset + _newCount) <= _oldCapacity) { // Platz ausreichend
					ITEM* _newArray = _oldArray + _index;
					_itemCount_ = _newCount;
					ITEM_POLICY::moveArray(_newArray + _count, _newArray, _oldCount - _index);
					return;
				}
			} else { // Vorn einfügen
				INT32 _newOffset = _oldOffset - _count;
				if (_newOffset >= 0) { // Platz ausreichend
					ITEM* _newArray = _oldArray - _count;
					_itemArray_ = _newArray;
					_itemCount_ = _newCount;
					_itemOffset_ = _newOffset;
					ITEM_POLICY::moveArray(_newArray, _oldArray, _index);
					return;
				}
			}
			{ // Elemente im Speicherbereich neu ausrichten
				INT32 _newOffset = _calcOffset_(_oldCapacity - _newCount);
				INT32 _shiftL = _newOffset - _oldOffset, _shiftR = _shiftL + _count;
				ITEM* _newArray = _oldArray + _shiftL;
				ITEM* _midArray = _oldArray + _index;
				_itemArray_ = _newArray;
				_itemCount_ = _newCount;
				_itemOffset_ = _newOffset;
				if (_shiftL < 0) { // vordere Elemente nach Vorn verlagern, Elemente dahinter behalten
					ITEM_POLICY::moveArray(_newArray, _oldArray, _index);
				}
				if (_shiftR < 0) { // hintere Elemente nach Vorn verlagern, Elemente dahinter bereinigen
					ITEM_POLICY::moveArray(_midArray + _shiftR, _midArray, _oldCount - _index);
				}
				if (_shiftR > 0) { // hintere Elemente nach Hinten verlagern, Elemente davor behalten
					ITEM_POLICY::moveArray(_midArray + _shiftR, _midArray, _oldCount - _index);
				}
				if (_shiftL > 0) { // vordere Elemente nach Hinten verlagern, Elemente davor bereinigen
					ITEM_POLICY::moveArray(_newArray, _oldArray, _index);
				}
			}
		}

		/** Diese Methode entfernt ab der gegebenen Position die gegebene Anzahl an Elementen und verschiebt dazu die umliegenden Elemente im aktuellen Speicherbereich.<br>
		 * Es werden keine Wertebereichsprüfungen vorgenommen!
		 * @param _index Beginn des Bereichs mit den zu entfernenden Elementen.
		 * @param _count Größe des Bereichs. */
		void _popItem_(INT32 _index, INT32 _count) {
			ITEM* _oldArray = _itemArray_;
			INT32 _oldOffset = _itemOffset_, _newCount = _itemCount_ - _count;
			if (_newCount == 0) { // alle Elemente entfernen
				INT32 _newOffset = _calcOffset_(_itemCapacity_);
				_itemArray_ = _oldArray - _oldOffset + _newOffset;
				_itemCount_ = _newCount;
				_itemOffset_ = _newOffset;
				ITEM_POLICY::resetArray(_oldArray, _count);
			} else if (_index > (_newCount >> 1)) { // Elemente in der hinteren Hälfte entfernen
				ITEM* _target = _oldArray + _index;
				_itemCount_ = _newCount;
				ITEM_POLICY::moveArray(_target, _target + _count, _newCount - _index);
			} else { // Elemente in der vorderen Hälfte entfernen
				ITEM* _newValues = _oldArray + _count;
				_itemArray_ = _newValues;
				_itemCount_ = _newCount;
				_itemOffset_ = _oldOffset + _count;
				ITEM_POLICY::moveArray(_newValues, _oldArray, _index);
			}
		}

		/** Diese Methode gibt das Produkt aus der der gegebenen Anzahl und dem Prozentsatz @c _itemAlign_ zurück.<br>
		 * Es werden keine Wertebereichsprüfungen vorgenommen!
		 * @param _count Anzahl der vorderen und hinteren ungenutzten Elemente (<tt>_itemCapacity_ - _itemCount_</tt>).
		 * @return Anzahl der vorderen ungenutzten Elemente (<tt>_offset_</tt>). */
		INT32 _calcOffset_(INT32 _count) const {
			INT32 _align = _itemAlign_;
			return ((_count >> 8) * _align) + (((_count & 255) * _align) >> 8);
		}

		/** Dieses Feld speichert die relative Ausrichtungsposition (<tt>0...256</tt>). */
		INT32 _itemAlign_;

		/** -Dieses Feld speichert den Zeiger auf das erste Element im Speicherbereich. */
		ITEM* _itemArray_;

		/** Dieses Feld speichert die Anzahl der genutzten Elemente im Speicherbereich ab @c _values_. */
		UINT32 _itemCount_;

		/** Dieses Feld speichert die Anzahl der verfügbaren Elemente im Speicherbereich vor @c _values_. */
		INT32 _itemOffset_;

		/** Dieses Feld speichert die Anzahl der Elemente in dem Speicherbereich, der bei <tt>_values_ - _offset_</tt> beginnt. */
		UINT32 _itemCapacity_;

	};

	/** Diese Klasse definiert die Zustandsdaten des @c SUCCursor dieses @c SUCListing. */
	struct ITERATOR: public SUCIterator<ITEM, ITERATOR> {

		public:

		/* SUCIterator */
		static bool distance(ITERATOR const& _this, ITERATOR const& _that, INT32& _result) {
			if (_this._minValue_ != _that._minValue_) return false;
			_result = _this._curValue_ - _that._curValue_;
			return true;
		}

		/** Dieser Konstruktor initialisiert den @c SUCListing und die aktuelle Position.
		 * @param _listing @c SUCListing.
		 * @param _index aktuelle Position. */
		ITERATOR(LISTING const& _listing, INT32 _index)
				: _listing_(_listing) {
			OBJECT& _this = *_listing._object_;
			_minValue_ = _this._itemArray_;
			_curValue_ = _minValue_ + _index;
			_maxValue_ = _minValue_ + _this._itemCount_;
		}

		/* SUCIterator */
		bool valid() const {
			return (_minValue_ <= _curValue_) && (_curValue_ < _maxValue_);
		}

		/* SUCIterator */
		ITEM& value() {
			return *_curValue_;
		}

		/* SUCIterator */
		ITEM const& value() const {
			return *_curValue_;
		}

		/* SUCIterator */
		bool move(INT32 _offset) {
			_curValue_ += _offset;
			return true;
		}

		private:

		/** Dieses Feld speichert das @c SUCArray als Besitzer. */
		LISTING _listing_;

		/** Dieses Feld speichert das erste Element. */
		ITEM* _minValue_;

		/** Dieses Feld speichert das aktuelle Element. */
		ITEM* _curValue_;

		/** Dieses Feld speichert das Element nach dem letzten. */
		ITEM* _maxValue_;

	};

	public:

	/** Dieser Datentyp definiert den @c SUCCursor eines @c SUCListing. */
	typedef SUCCursor<ITEM, ITERATOR> CURSOR;

	/** Dieser Datentyp definiert den @c SUCCursor eines @c SUCListing (@c const). */
	typedef SUCCursor<ITEM const, ITERATOR> CURSOR_CONST;

	/** Dieser Konstruktor erzeugt einen @c SUCListing mit der gegebenen Kapazität.
	 * @param _capacity Kapazität. */
	SUCListing(INT32 _capacity = 16)
			: _object_(new OBJECT(_capacity)) {
	}

	/** Diese Methode gibt eie Kopie des Element an der gegebenen Position zurück.
	 * @see SUCPolicy.cloneItem()
	 * @param _index Position (<tt>0...length()-1</tt>).
	 * @return Kopie des <tt>_index</tt>-ten Elements.
	 * @throws SUCException Wenn die Position ungültig ist. */
	ITEM get(INT32 _index) const {
		ITEM _result;
		ITEM_POLICY::cloneItem(&_result, &this[_index]);
		return _result;
	}

	/** Diese Methode kopiert die Elementen ab der gegebenen Position in das gegebene @c SUCArray.<br>
	 * Sie ist eine Abkürzung für <tt>get(_index, _target.data(), _target.length())</tt>.
	 * @param _index Position (<tt>0...length()</tt>).
	 * @param _target @c SUCArray, in welches die Elemente kopiert werden sollen.
	 * @throws SUCException Wenn der gelesene Bereich außerhalb dieses @c SUCListing liegt. */
	void getAll(INT32 _index, ARRAY& _target) const {
		getAll(_index, _target.data(), _target.length());
	}

	/** Diese Methode kopiert die Elementen ab der gegebenen Position in den gegebenen @c SUCListing.<br>
	 * Sie ist eine Abkürzung für <tt>get(_index, _target.data(), _target.length())</tt>.
	 * @param _index Position (<tt>0...length()</tt>).
	 * @param _target @c SUCListing, in welchen die Elemente kopiert werden sollen.
	 * @throws SUCException Wenn der gelesene Bereich außerhalb dieses @c SUCListing liegt. */
	void getAll(INT32 _index, LISTING& _target) const {
		getAll(_index, _target.data(), _target.length());
	}

	/** Diese Methode kopiert die gegebene Anzahl an Elementen ab der gegebenen Position in den gegebenen Speicherbereich.
	 * @param _index Position (<tt>0...length()</tt>).
	 * @param _target Zeiger auf den Beginn des Speicherbereichs, in welchen die Elemente kopiert werden sollen.
	 * @param _count Anzahl der Elemente.
	 * @throws SUCException Wenn der gelesene Bereich außerhalb dieses @c SUCListing liegt. */
	void getAll(INT32 _index, ITEM* _target, INT32 _count) const {
		OBJECT& _this = *_object_;
		INT32 _length = _this._itemCount_ + 1;
		SUCException::checkIndex(_index, _length);
		if (!_count) return;
		SUCException::checkIndex(_index + _count, _length);
		SUCException::checkCount(_count);
		ITEM_POLICY::cloneArray(_target, _this._itemArray_ + _index, _count);
	}

	/** Diese Methode setzt das Element an der gegebenen Position.
	 * @param _index Position (<tt>0...length()-1</tt>).
	 * @param _item Element.
	 * @throws SUCException Wenn die Position ungültig ist. */
	void set(INT32 _index, ITEM const& _item) {
		ITEM_POLICY::cloneItem(&this[_index], &_item);
	}

	/** Diese Methode kopiert die Elemente des gegebenen @c SUCArray an die gegebenen Position.<br>
	 * Sie ist eine Abkürzung für <tt>set(_index, _source.data(), _source.length())</tt>.
	 * @param _index Position (<tt>0...length()</tt>).
	 * @param _source @c SUCArray, aus welchem die Elemente kopiert werden sollen.
	 * @throws SUCException Wenn der geschriebene Bereich außerhalb dieses @c SUCListing liegt. */
	void setAll(INT32 _index, ARRAY const& _source) {
		setAll(_index, _source.data(), _source.length());
	}

	/** Diese Methode kopiert die Elemente des gegebenen @c SUCListing an die gegebenen Position.<br>
	 * Sie ist eine Abkürzung für <tt>set(_index, _source.data(), _source.length())</tt>.
	 * @param _index Position (<tt>0...length()</tt>).
	 * @param _source @c SUCListing, aus welchem die Elemente kopiert werden sollen.
	 * @throws SUCException Wenn der geschriebene Bereich außerhalb dieses @c SUCListing liegt. */
	void setAll(INT32 _index, LISTING const& _source) {
		setAll(_index, _source.data(), _source.length());
	}

	/** Diese Methode kopiert die Elemente des gegebenen Speicherbereich an die gegebenen Position.
	 * @param _index Position (<tt>0...length()</tt>).
	 * @param _source Zeiger auf den Beginn des Speicherbereichs, aus welchem die Elemente kopiert werden sollen.
	 * @param _count Anzahl der Elemente.
	 * @throws SUCException Wenn der geschriebene Bereich außerhalb dieses @c SUCListing liegt. */
	void setAll(INT32 const _index, ITEM const* _source, INT32 _count) {
		OBJECT& _this = *_object_;
		INT32 _length = _this._itemCount_ + 1;
		SUCException::checkIndex(_index, _length);
		if (!_count) return;
		SUCException::checkIndex(_index + _count, _length);
		SUCException::checkCount(_count);
		ITEM_POLICY::cloneArray(_this._itemArray_ + _index, _source, _count);
	}

	/** Diese Methode fügt das gegebene Element am Ende dieses @c SUCListing an.<br>
	 * Sie ist eine Abkürzung für <tt>add(length(), _value)</tt>.
	 * @param _value Element. */
	void add(ITEM const& _value) {
		OBJECT& _this = *_object_;
		INT32 _index = _this._itemCount_;
		_this._putItem_(_index, 1);
		ITEM_POLICY::cloneItem(_this._itemArray_ + _index, &_value);
	}

	/** Diese Methode fügt die gegebenen Elemente am Ende dieses @c SUCListing an.<br>
	 * Sie ist eine Abkürzung für <tt>addAll(_source.data(), _source.length())</tt>.
	 * @param _source @c SUCArray, dessen Elemente angefügt werden sollen. */
	void addAll(ARRAY const& _source) {
		addAll(_source.data(), _source.length());
	}

	/** Diese Methode fügt die gegebenen Elemente am Ende dieses @c SUCListing an.<br>
	 * Sie ist eine Abkürzung für <tt>addAll(_source.data(), _source.length())</tt>.
	 * @param _source @c SUCListing, dessen Elemente angefügt werden sollen. */
	void addAll(LISTING const& _source) {
		addAll(_source.data(), _source.length());
	}

	/** Diese Methode fügt die gegebenen Elemente am Ende dieses @c SUCListing an.<br>
	 * Sie ist eine Abkürzung für <tt>addAll(length(), _array, _count)</tt>.
	 * @param _array Zeiger auf den Beginn des Speicherbereichs, aus welchem die Elemente kopiert werden sollen.
	 * @param _count Anzahl der Elemente. */
	void addAll(ITEM const* _array, INT32 _count) {
		if (!_count) return;
		OBJECT& _this = *_object_;
		INT32 _index = _this._itemCount_;
		SUCException::checkCount(_count);
		_this._putItem_(_index, _count);
		ITEM_POLICY::cloneArray(_this._itemArray_ + _index, _array, _count);
	}

	/** Diese Methode fügt das gegebene Element an der gegebenen Position ein.
	 * @param _index Position (<tt>0...length()</tt>).
	 * @param _value Element.
	 * @throws SUCException Wenn die gegebene Position ungültig ist. */
	void add(INT32 _index, ITEM const& _value) {
		OBJECT& _this = *_object_;
		SUCException::checkIndex(_index, _this._itemCount_ + 1);
		_this._putItem_(_index, 1);
		ITEM_POLICY::cloneItem(_this._itemArray_ + _index, &_value);
	}

	/** Diese Methode fügt die Elemente des gegebenen @c SUCArray an der gegebenen Position ein.
	 * Sie ist eine Abkürzung für <tt>add(_index, _source.data(), _source.length())</tt>.
	 * @param _index Position (<tt>0...length()</tt>).
	 * @param _source @c SUCArray, dessen Elemente angefügt werden sollen.
	 * @throws SUCException Wenn die gegebene Position ungültig ist. */
	void addAll(INT32 const _index, ARRAY const& _source) {
		addAll(_index, _source.data(), _source.length());
	}

	/** Diese Methode fügt die Elemente des gegebenen @c SUCListing an der gegebenen Position ein.
	 * Sie ist eine Abkürzung für <tt>add(_index, _source.data(), _source.length())</tt>.
	 * @param _index Position (<tt>0...length()</tt>).
	 * @param _source @c SUCListing, dessen Elemente angefügt werden sollen.
	 * @throws SUCException Wenn die gegebene Position ungültig ist. */
	void addAll(INT32 const _index, LISTING const& _source) {
		addAll(_index, _source.data(), _source.length());
	}

	/** Diese Methode fügt die Elemente des gegebenen Speicherbereichs an der gegebenen Position ein.
	 * @param _index Position (<tt>0...length()</tt>).
	 * @param _source Zeiger auf den Beginn des Speicherbereichs, aus welchem die Elemente kopiert werden sollen.
	 * @param _count Anzahl der Elemente.
	 * @throws SUCException Wenn die gegebene Position ungültig ist. */
	void addAll(INT32 _index, ITEM const* _source, INT32 _count) {
		OBJECT& _this = *_object_;
		SUCException::checkIndex(_index, _this._itemCount_ + 1);
		if (!_count) return;
		SUCException::checkCount(_count);
		_this._putItem_(_index, _count);
		ITEM_POLICY::cloneArray(_this._itemArray_ + _index, _source, _count);
	}

	/** Diese Methode fügt die gegebene Anzahl an Elementen an der gegebenen Position ein.<p>
	 * Dabei werden im internen Speicherbereich die wenigen Elemente vor bzw. nach der gegebenen Position um die gegebene Anzahl zu verschieben.
	 * Reicht der vor bzw. nach den genutzten Elementen verfügbare Speicher hierfür nicht aus, werden alle Elemente gemäß der Ausrichtung (@c align()) verschoben.
	 * Reicht die Kapazität hierfür nicht aus, werden die Kapazität um 50% bzw. auf die notwendige Größe angehoben und die Elemente der Ausrichtung entsprechend positioniert.
	 * @see SUCPolicy::moveArray()
	 * @param _index Position (<tt>0...length()</tt>).
	 * @param _count Anzahl der Elemente.
	 * @throws SUCException Wenn Position bzw. Anzahl ungültig ist. */
	void insert(INT32 _index, INT32 _count) {
		OBJECT& _this = *_object_;
		SUCException::checkIndex(_index, _this._itemCount_ + 1);
		if (!_count) return;
		SUCException::checkCount(_count);
		_this._putItem_(_index, _count);
	}

	/** Diese Methode entfernt die gegebene Anzahl an Elementen ab der gegebenen Position.<p>
	 * Dabei werden im internen Speicherbereich die wenigen Elemente vor bzw. nach dem zu entfernenden Bereich um die gegebene Anzahl verschoben.<br>
	 * Ungenutzte Elemente werden ggf. über @c SUCArray::resetItem() bereinigt.
	 * @see SUCPolicy::moveArray()
	 * @see SUCPolicy::resetArray()
	 * @param _index Beginn des Bereichs mit den zu entfernenden Elementen.
	 * @param _count Größe des Bereichs.
	 * @throws SUCException Wenn der Bereich außerhalb dieses @c SUCListing liegt. */
	void remove(INT32 _index, UINT32 _count) {
		OBJECT& _this = *_object_;
		_this._checkArray_(_index, _count);
		if (!_count) return;
		_this._popItem_(_index, _count);
	}

	/** Diese Methode gibt den Zeiger auf das erste Element dieses @c SUCListing zurück.<br>
	 * Wenn dieser @c SUCListing leer ist, wird <tt>0</tt> geliefert.
	 * @return Zeiger auf erstes Element oder <tt>0</tt>. */
	ITEM* data() {
		OBJECT& _this = *_object_;
		return _this._itemCount_ ? _this._itemArray_ : 0;
	}

	/** @copydoc data() */
	ITEM const* data() const {
		OBJECT& _this = *_object_;
		return _this._itemCount_ ? _this._itemArray_ : 0;
	}

	/** Diese Methode gibt die relative Ausrichtungsposition der Elemente im internen Speicherbereich zurück.
	 * @return relative Ausrichtungsposition (<tt>0...100</tt>). */
	INT32 align() const {
		OBJECT& _this = *_object_;
		return (_this._itemAlign_ * 100) >> 8;
	}

	/** Diese Methode setzt die relative Ausrichtungsposition der Elemente im internen Speicherbereich.<br>
	 * Bei der relativen Ausrichtungsposition <tt>0</tt> werden die Elemente am des Speicherbereich ausgerichtet, wodurch das häufige Einfügen von Elementen am Ende des beschleunigt wird (<tt>add(length(), ...)</tt>).
	 * Für die relative Ausrichtungsposition @c 100 gilt das Gegenteil, da hier die Elemente am Ende des Speicherbereich ausgerichtet werden, wodurch das häufige Einfügen von Elementen am Anfang beschleunigt wird (<tt>add(0, ...)</tt>).
	 * @param _percent Prozentsatz (<tt>0...100</tt>).
	 * @throws SUCException Wenn der gegebene Prozentsatz ungültig ist. */
	void align(INT32 const _percent) {
		if ((_percent < 0) || (_percent > 100)) throw SUCException(SUCException::ILLEGAL_ALIGN);
		OBJECT& _this = *_object_;
		_this._itemAlign_ = (_percent << 8) / 100;
	}

	/** Diese Methode entfernt alle Elemente dieses @c SUCListing.<br>
	 * Sie ist eine Abkürzung für <tt>remove(0, length())</tt>. */
	void clear() {
		OBJECT& _this = *_object_;
		if (!_this._itemCount_) return;
		_this._popItem_(0, _this._itemCount_);
	}

	/** Diese Methode gibt eine Kopie der Elemente dieses @c SUCListing als @c SUCArray zurück.
	 * @return Kopie der Elemente als @c SUCArray. */
	ARRAY values() const {
		OBJECT& _this = *_object_;
		return ARRAY(_this._itemArray_, _this._itemCount_, true);
	}

	/** Diese Methode gibt die Anzahl der Elemente dieses @c SUCListing zurück.
	 * @return Anzahl der Elemente. */
	INT32 length() const {
		OBJECT& _this = *_object_;
		return _this._itemCount_;
	}

	/** Diese Methode gibt die Kapazität des internen Speicherbereichs zurück.
	 * @return Kapazität. */
	INT32 capacity() const {
		OBJECT& _this = *_object_;
		return _this._itemCapacity_;
	}

	/** Diese Methode setzt die Größe des internen Speicherbereichs, in welchem die Elemente dieses @c SUCListing verwaltet werden.<br>
	 * Wenn die gegebenen Kapazität von der aktuellen abweicht, werden die Elemente in einem neuen Speicherbereich entsprechend der Ausrichtung (@c align()) positioniert.
	 * @param _capacity Kapazität.
	 * @throws SUCException Wenn <tt>_capacity</tt> kleiner @c length() ist. */
	void allocate(INT32 _capacity) {
		OBJECT& _this = *_object_;
		if (_capacity == _this._itemCapacity_) return;
		SUCException::checkCount(_capacity - _this._itemCount_);
		_this._resize_(_capacity);
	}

	/** Diese Methode reduziert die Größe des internen Speicherbereichs auf das Minimum.<br>
	 * Sie ist eine Abkürzung für <tt>allocate(length())</tt>. */
	void compact() {
		OBJECT& _this = *_object_;
		UINT32 _length = _this._itemCount_;
		if (_length == _this._itemCapacity_) return;
		_this._resize_(_length);
	}

	/** Diese Methode gibt den Streuwert dieses @c SUCListing zurück.
	 * @return Streuwert dieses @c SUCListing. */
	INT32 hash() const {
		OBJECT& _this = *_object_;
		return ITEM_POLICY::hashArray(_this._itemArray_, _this._itemCount_);
	}

	/** Diese Methode gibt eine kompakte Kopie dieses @c SUCListing zurück.
	 * @return Kopie dieses @c SUCListing. */
	LISTING clone() const {
		OBJECT& _this = *_object_;
		LISTING _result(_this._itemCount_);
		_result.align(_this._itemAlign_);
		_result.addAll(_this._itemArray_, _this._itemCount_);
		return _result;
	}

	/** Diese Methode gibt nur dann <tt>true</tt> zurück, wenn dieser @c SUCListing äquivalent zu dem gegebenen ist.
	 * @param _that @c SUCListing.
	 * @return <tt>true</tt>, wenn dieses und das gegebene @c SUCListing äquivalent sind. */
	bool equals(LISTING const& _that) const {
		OBJECT& _this = *_that._object_;
		return equals(_this._itemArray_, _this._itemCount_);
	}

	/** Diese Methode gibt nur dann <tt>true</tt> zurück, wenn die Elemente dieses @c SUCArray äquivalent zu den gegebenen sind.
	 * @param _array Array der Elemente.
	 * @param _length Anzahl der Elemente.
	 * @return <tt>true</tt>, wenn die Elemente dieses @c SUCArray äquivalent zu den gegebene sind. */
	bool equals(ITEM const* _array, INT32 _length) const {
		OBJECT& _this = *_object_;
		if (_this._itemCount_ != _length) return false;
		return ITEM_POLICY::equalsArray(_this._itemArray_, _array, _length);
	}

	INT32 compare(LISTING const& _that) const {
		OBJECT& _this = *_that._object_;
		return compare(_this._itemArray_, _this._itemCount_);
	}

	INT32 compare(ITEM const* _array, INT32 _length) const {
		OBJECT& _this = *_object_;
		return ITEM_POLICY::compareArray(_this._itemArray_, _array, _this._itemCount_, _length);
	}

	/** Diese Methode gibt den an der gegebenen Position stehenden @c SUCCursor dieses @c SUCListing zurück.
	 * @param _index Startposition.
	 * @return @c SUCCursor dieses @c SUCListing. */
	CURSOR cursor(INT32 _index = 0) {
		return CURSOR(ITERATOR(*this, _index));
	}

	/** @copydoc cursor() */
	CURSOR_CONST cursor(INT32 _index = 0) const {
		return CURSOR_CONST(ITERATOR(*this, _index));
	}

	/** Dieser Operator gibt die Referenz auf das Element an der gegebenen Position zurück.
	 * @param _index Position (<tt>0...length()-1</tt>).
	 * @return Referenz auf das Element an der gegebenen Position.
	 * @throws SUCException Wenn die Position ungültig ist. */
	ITEM& operator[](INT32 const _index) {
		OBJECT& _this = *_object_;
		return _this._item_(_index);
	}

	/** @copydoc operator[](INT32 const) */
	ITEM const& operator[](INT32 const _index) const {
		OBJECT& _this = *_object_;
		return _this._item_(_index);
	}

	private:

	/** Dieses Feld speichert die referenzgezählten Nutzdaten. */
	typename OBJECT::POINTER _object_;

};

/**
 * Diese Klasse definiert eine Tabelle als streuwertbasierte Abbildung von Schlüsseln auf Werte.<p>
 * Die Rechenzeit zur Suche eines Wert zu einem gegebenen Schlüssel ist nahezu unabhängig von der Anzahl der Einträge in der @c SUCMapping abhämgig.
 *
 *
 * @tparam _KEY Typ der Schlüssel.
 * @tparam _VALUE Typ der Werte.
 * @tparam _KEY_POLICY Regelwerk zur Handhabung der Schlüssel. Dieses muss ein Nachfahre von @c SUCPolicy sein.
 * @tparam _VALUE_POLICY Regelwerk zur Handhabung der Werte. Dieses muss ein Nachfahre von @c SUCPolicy sein.
 * @tparam _MAPPING_POLICY Schalter und Regelwerke zur Steuerung von Algorithmen, Speicherverbrauch und Maximalekapazität. Dieses muss ein Nachfahre von @c SUCMapping_POLICY sein. */
template<typename _KEY, typename _VALUE, typename _KEY_POLICY = SUCPolicy_PRIMITIVE<_KEY>, typename _VALUE_POLICY = SUCPolicy_PRIMITIVE<_VALUE>, typename _MAPPING_POLICY = SUCMapping_POLICY_HASH_32_CACHE>
struct SUCMapping {

	public:

	/** Dieser Datentyp definiert die Schlüssel der @c SUCMapping. */
	typedef _KEY KEY;

	/** Dieser Datentyp definiert die @c SUCPolicy der Schlüssel dieser @c SUCMapping. */
	typedef _KEY_POLICY KEY_POLICY;

	/** Dieser Datentyp definiert die Werte der @c SUCMapping. */
	typedef _VALUE VALUE;

	/** Dieser Datentyp definiert die @c SUCPolicy der Werte dieser @c SUCMapping. */
	typedef _VALUE_POLICY VALUE_POLICY;

	typedef _MAPPING_POLICY MAPPING_POLICY;

	typedef typename MAPPING_POLICY::INDEX_POLICY::ITEM INDEX;

	typedef typename MAPPING_POLICY::INDEX_POLICY INDEX_POLICY;

	typedef typename MAPPING_POLICY::LEVEL_POLICY::ITEM LEVEL;

	typedef typename MAPPING_POLICY::LEVEL_POLICY LEVEL_POLICY;

	typedef SUCMapping<KEY, VALUE, KEY_POLICY, VALUE_POLICY, MAPPING_POLICY> MAPPING;

	struct ENTRY;

	typedef ENTRY const ENTRY_CONST;

	struct ITERATOR;

	/**
	 * Diese Klasse definiert die referenzgezählten Nutzdaten einer @c SUCMapping.
	 */
	struct OBJECT: public RCObject<OBJECT> {

		public:

		static INT32 const MAX_CAPACITY = (INDEX) 1073741823;

		static INT32 const MAX_LEVEL = MAX_CAPACITY > 65536 ? 32 : MAX_CAPACITY > 256 ? 18 : 10;

		OBJECT(INT32 const _capacity) {
			_keyArray_ = ((KEY*) 0) - 1;
			_valueArray_ = ((VALUE*) 0) - 1;
			if (MAPPING_POLICY::HASH_ENABLED) {
				_hashRootArray_[0] = 0;
				_hashNextArray_[0] = ((INDEX*) 0) - 1;
				if (MAPPING_POLICY::CACHE_ENABLED) _hashCacheArray_[0] = ((INDEX*) 0) - 1;
			}
			if (MAPPING_POLICY::TREE_ENABLED) {
				_treePrevArray_[0] = ((INDEX*) 0) - 1;
				_treeNextArray_[0] = ((INDEX*) 0) - 1;
				_treeLevelArray_[0] = ((LEVEL*) 0) - 1;
			}
			SUCException::checkCount(_capacity);
			SUCException::checkCount(MAX_CAPACITY - _capacity);
			_keyArray_ = KEY_POLICY::createArray(_capacity) - 1;
			_valueArray_ = VALUE_POLICY::createArray(_capacity) - 1;
			_entryCount_ = 0;
			_entryCapacity_ = (INDEX) _capacity;
			if (MAPPING_POLICY::HASH_ENABLED) {
				SUCException::checkState(!MAPPING_POLICY::TREE_ENABLED);
				INT32 _length = _calcMask_HASH_(_capacity) + 1;
				_hashNew_[0] = 1;
				_hashMask_[0] = _length - 1;
				_hashRootArray_[0] = INDEX_POLICY::createArray(_length);
				_hashNextArray_[0] = INDEX_POLICY::createArray(_capacity) - 1;
				if (MAPPING_POLICY::CACHE_ENABLED) _hashCacheArray_[0] = INDEX_POLICY::createArray(_capacity) - 1;
				_clearArray_(_hashRootArray_[0], _length);
				_countArray_(_hashNextArray_[0], _capacity);
			}
			if (MAPPING_POLICY::TREE_ENABLED) {
				SUCException::checkState(!MAPPING_POLICY::HASH_ENABLED);
				_treeNew_[0] = 1;
				_treeRoot_[0] = 0;
				_treePrevArray_[0] = INDEX_POLICY::createArray(_capacity) - 1;
				_treeNextArray_[0] = INDEX_POLICY::createArray(_capacity) - 1;
				_treeLevelArray_[0] = LEVEL_POLICY::createArray(_capacity) - 1;
				_countArray_(_treeNextArray_[0], _capacity);
			}
		}

		~OBJECT() {
			DELETE_ARRAY<KEY, KEY_POLICY> _deleteKeyArray(_keyArray_ + 1);
			DELETE_ARRAY<VALUE, VALUE_POLICY> _deleteValueArray(_valueArray_ + 1);
			if (MAPPING_POLICY::HASH_ENABLED) {
				DELETE_ARRAY<INDEX, INDEX_POLICY> _deleteRootArray(_hashRootArray_[0]);
				DELETE_ARRAY<INDEX, INDEX_POLICY> _deleteNextArray(_hashNextArray_[0] + 1);
				if (MAPPING_POLICY::CACHE_ENABLED) {
					DELETE_ARRAY<INDEX, INDEX_POLICY> _deleteCacheArray(_hashCacheArray_[0] + 1);
				}
			} else {
				DELETE_ARRAY<INDEX, INDEX_POLICY> _deletePrevArray(_treePrevArray_[0] + 1);
				DELETE_ARRAY<INDEX, INDEX_POLICY> _deleteNextArray(_treeNextArray_[0] + 1);
				DELETE_ARRAY<INDEX, LEVEL_POLICY> _deleteLevelArray(_treeLevelArray_[0] + 1);
			}
		}

		private:

		friend ENTRY;

		friend MAPPING;

		friend ITERATOR;

		VALUE& _item_(KEY const& _key) {
			VALUE* _result = _get_(_key);
			SUCException::checkState(_result);
			return *_result;
		}

		KEY& _key_(INDEX _index) {
			SUCException::checkState(_index);
			KEY& _result = _keyArray_[_index];
			return _result;
		}

		INT32 _keyHash_(INDEX _index) {
			SUCException::checkState(_index);
			INT32 _result = (MAPPING_POLICY::HASH_ENABLED & MAPPING_POLICY::CACHE_ENABLED) ? _hashCacheArray_[0][_index] : KEY_POLICY::hashItem(_keyArray_ + _index);
			return _result;
		}

		VALUE& _value_(INDEX _index) {
			SUCException::checkState(_index);
			VALUE& _result = _valueArray_[_index];
			return _result;
		}

		INT32 _valueHash_(INDEX _index) {
			SUCException::checkState(_index);
			INT32 _result = VALUE_POLICY::hashItem(_valueArray_ + _index);
			return _result;
		}

		VALUE* _get_(KEY const& _key) {
			INDEX _index = _getIndex_(_key);
			if (!_index) return 0;
			VALUE* _result = _valueArray_ + _index;
			return _result;
		}

		VALUE* _get_HASH_(KEY const& _key, INDEX _keyHash) {
			INDEX _index = _getIndex_HASH_(_key, _keyHash);
			if (!_index) return 0;
			VALUE* _result = _valueArray_ + _index;
			return _result;
		}

		/** Diese Methode gibt den Position des Eintrags mit dem gegebenen Schlüssel zurück. Wenn kein solcher Eintrag existiert, wird <tt>0</tt> geliefert.
		 * @param _key Schlüssel.
		 * @return Position des Eintrags mit diesem Schlüssel oder <tt>0</tt>. */
		INDEX _getIndex_(KEY const& _key) {
			INDEX _result = MAPPING_POLICY::HASH_ENABLED ? _getIndex_HASH_(_key, (INDEX) KEY_POLICY::hashItem(&_key)) : _getIndex_TREE_(_key);
			return _result;
		}

		INDEX _getIndex_HASH_(KEY const& _key, INDEX _keyHash) {
			KEY* _keyArray = _keyArray_;
			INDEX* _nextArray = _hashNextArray_[0];
			INDEX* _cacheArray = MAPPING_POLICY::CACHE_ENABLED ? _hashCacheArray_[0] : 0;
			INDEX _rootIndex = _keyHash & _hashMask_[0];
			INDEX _itemIndex = _hashRootArray_[0][_rootIndex];
			while (_itemIndex) {
				KEY* _entryKey = _keyArray + _itemIndex;
				INDEX _entryHash = MAPPING_POLICY::CACHE_ENABLED ? _cacheArray[_itemIndex] : _keyHash;
				bool _equals = (_keyHash == _entryHash) && KEY_POLICY::equalsItem(&_key, _entryKey);
				if (_equals) return _itemIndex;
				_itemIndex = _nextArray[_itemIndex];
			}
			return 0;
		}

		INDEX _getIndex_TREE_(KEY const& _key) {
			KEY* _keyArray = _keyArray_;
			INDEX* _prevArray = _treePrevArray_[0];
			INDEX* _nextArray = _treeNextArray_[0];
			INDEX _itemIndex = _treeRoot_[0];
			while (_itemIndex) {
				INT32 _compare = KEY_POLICY::compareItem(&_key, _keyArray + _itemIndex);
				if (!_compare) return _itemIndex;
				_itemIndex = _compare < 0 ? _prevArray[_itemIndex] : _nextArray[_itemIndex];
			}
			return 0;
		}

		void _put_(KEY const& _key, VALUE const& _value) {
			INDEX _entry = _putIndex_(_key);
			VALUE_POLICY::cloneItem(_valueArray_ + _entry, &_value);
		}

		void _put_HASH_(KEY const& _key, INDEX _keyHash, VALUE const& _value) {
			INDEX _entry = _putIndex_HASH_(_key, _keyHash);
			VALUE_POLICY::cloneItem(_valueArray_ + _entry, &_value);
		}

		/** Diese Methode gibt den Position des Eintrags mit dem gegebenen Schlüssel zurück. Wenn kein solcher Eintrag existiert, wird er angelegt.
		 * @param _key Schlüssel.
		 * @return Position des Eintrags mit diesem Schlüssel.
		 * @throws SUCException Wenn keine neuer Eintrag angelegt werden kann. */
		INDEX _putIndex_(KEY const& _key) {
			INT32 _length = _entryCount_;
			if (_length == MAX_CAPACITY) {
				INDEX _result = _getIndex_(_key);
				if (_result) return _result;
				throw SUCException(SUCException::ILLEGAL_STATE);
			}
			INT32 _capacity = _entryCapacity_;
			if (_length == _capacity) {
				_capacity += _capacity >> 1;
				if (_length >= _capacity) _capacity = _length + 1;
				if (_capacity > MAX_CAPACITY) _capacity = MAX_CAPACITY;
				SUCException::checkState(_length < _capacity);
				_resize_(_capacity);
			}
			INDEX _result = MAPPING_POLICY::HASH_ENABLED ? _putIndex_HASH_(_key, (INDEX) KEY_POLICY::hashItem(&_key)) : _putIndex_TREE_(_key, _treeRoot_);
			return _result;
		}

		INDEX _putIndex_HASH_(KEY const& _key, INDEX _keyHash) {
			KEY* _keyArray = _keyArray_;
			INDEX* _rootArray = _hashRootArray_[0];
			INDEX* _nextArray = _hashNextArray_[0];
			INDEX* _cacheArray = MAPPING_POLICY::CACHE_ENABLED ? _hashCacheArray_[0] : 0;
			INDEX _rootIndex = _keyHash & _hashMask_[0];
			INDEX _itemIndex = _rootArray[_rootIndex];
			while (_itemIndex) {
				KEY* _entryKey = _keyArray + _itemIndex;
				INDEX _entryHash = MAPPING_POLICY::CACHE_ENABLED ? _cacheArray[_itemIndex] : _keyHash;
				bool _equals = (_keyHash == _entryHash) && KEY_POLICY::equalsItem(&_key, _entryKey);
				if (_equals) return _itemIndex;
				_itemIndex = _nextArray[_itemIndex];
			}
			_itemIndex = _hashNew_[0];
			_hashNew_[0] = _nextArray[_itemIndex];
			_entryCount_++;
			_nextArray[_itemIndex] = _rootArray[_rootIndex];
			_rootArray[_rootIndex] = _itemIndex;
			KEY_POLICY::cloneItem(_keyArray + _itemIndex, &_key);
			if (MAPPING_POLICY::CACHE_ENABLED) _cacheArray[_itemIndex] = _keyHash;
			return _itemIndex;
		}

		INDEX _putIndex_TREE_(KEY const& _key, INDEX* _itemField) {
			INDEX _itemIndex = _itemField[0];
			INDEX* _prevArray = _treePrevArray_[0];
			INDEX* _nextArray = _treeNextArray_[0];
			LEVEL* _levelArray = _treeLevelArray_[0];
			if (!_itemIndex) {
				_itemIndex = _treeNew_[0];
				_treeNew_[0] = _nextArray[_itemIndex];
				_entryCount_++;
				_itemField[0] = _itemIndex;
				_prevArray[_itemIndex] = 0;
				_nextArray[_itemIndex] = 0;
				_levelArray[_itemIndex] = 1;
				KEY_POLICY::cloneItem(_keyArray_ + _itemIndex, &_key);
				return _itemIndex;
			}
			INT32 _compare = KEY_POLICY::compareItem(&_key, _keyArray_ + _itemIndex);
			if (!_compare) return _itemIndex;
			INDEX _result = _compare < 0 ? _putIndex_TREE_(_key, _prevArray + _itemIndex) : _putIndex_TREE_(_key, _nextArray + _itemIndex);
			_calcShape_TREE_(_itemField, _prevArray, _nextArray, _levelArray);
			return _result;
		}

		void _pop_(KEY const& _key) {
			_popIndex_(_key);
		}

		/** Diese Methode entfernt des Eintrags mit dem gegebenen Schlüssel.
		 * @param _key Schlüssel.
		 * @return <tt>true</tt>, wenn der Eintrags gefunden und entfernt wurde;<br><tt>false</tt> sonst. */
		bool _popIndex_(KEY const& _key) {
			bool _result = MAPPING_POLICY::HASH_ENABLED ? _popIndex_HASH_(_key, (INDEX) KEY_POLICY::hashItem(&_key)) : _popIndex_TREE_(_key, _treeRoot_);
			return _result;
		}

		bool _popIndex_HASH_(KEY const& _key, INDEX _keyHash) {
			KEY* _keyArray = _keyArray_;
			INDEX* _nextArray = _hashNextArray_[0];
			INDEX* _cacheArray = MAPPING_POLICY::CACHE_ENABLED ? _hashCacheArray_[0] : 0;
			INDEX _rootIndex = _keyHash & _hashMask_[0];
			INDEX* _itemField = _hashRootArray_[0] + _rootIndex;
			INDEX _itemIndex = *_itemField;
			while (_itemIndex) {
				KEY* _entryKey = _keyArray + _itemIndex;
				INDEX _entryHash = MAPPING_POLICY::CACHE_ENABLED ? _cacheArray[_itemIndex] : _keyHash;
				INDEX* _entryNextField = _nextArray + _itemIndex;
				bool _equals = (_keyHash == _entryHash) && KEY_POLICY::equalsItem(&_key, _entryKey);
				if (_equals) {
					_itemField[0] = _entryNextField[0];
					_entryNextField[0] = _hashNew_[0];
					_hashNew_[0] = _itemIndex;
					_entryCount_--;
					KEY_POLICY::resetItem(_keyArray_ + _itemIndex);
					VALUE_POLICY::resetItem(_valueArray_ + _itemIndex);
					return true;
				}
				_itemIndex = _entryNextField[0];
			}
			return false;
		}

		bool _popIndex_TREE_(KEY const& _key, INDEX* _itemField) {
			INDEX _itemIndex = _itemField[0];
			if (!_itemIndex) return false;
			INDEX* _prevArray = _treePrevArray_[0];
			INDEX* _nextArray = _treeNextArray_[0];
			LEVEL* _levelArray = _treeLevelArray_[0];
			INT32 _compare = KEY_POLICY::compareItem(&_key, _keyArray_ + _itemIndex);
			if (!_compare) {
				INDEX _prevIndex = _prevArray[_itemIndex];
				INDEX _nextIndex = _nextArray[_itemIndex];
				if (_nextIndex) {
					if (_prevIndex) _movIndex_TREE_(_prevIndex, _nextArray + _itemIndex);
					_itemField[0] = _nextIndex;
				} else {
					_itemField[0] = _prevIndex;
				}
				_nextArray[_itemIndex] = _treeNew_[0];
				_treeNew_[0] = _itemIndex;
				_entryCount_--;
				KEY_POLICY::resetItem(_keyArray_ + _itemIndex);
				VALUE_POLICY::resetItem(_valueArray_ + _itemIndex);
				return true;
			}
			bool _result = _compare < 0 ? _popIndex_TREE_(_key, _prevArray + _itemIndex) : _popIndex_TREE_(_key, _nextArray + _itemIndex);
			_calcShape_TREE_(_itemField, _prevArray, _nextArray, _levelArray);
			return _result;
		}

		/** Diese Methode setzt den kleinsten Kindknoten des gegebenen Teilbaums. */
		void _movIndex_TREE_(INDEX _prevIndex, INDEX* _itemField) {
			INDEX _itemIndex = _itemField[0];
			if (_itemIndex) {
				INDEX* _prevArray = _treePrevArray_[0];
				_movIndex_TREE_(_prevIndex, _prevArray + _itemIndex);
				_calcShape_TREE_(_itemField, _prevArray, _treeNextArray_[0], _treeLevelArray_[0]);
			} else {
				_itemField[0] = _prevIndex;
			}
		}

		/** Diese Methode gibt die Bitmaske für die Streuwerte Kindbaumtiefen zurück. */
		inline INDEX _calcMask_HASH_(INT32 _capacity) {
			UINT32 _result = 1;
			while (_result < _capacity) {
				_result = _result << 1;
			}
			return (INDEX) (_result - 1);
		}

		/** Diese Methode gibt die Tiefe des Teilbaums mit den gegebenen Kindbaumtiefen zurück. */
		inline LEVEL _calcLevel_TREE_(LEVEL _prevLevel, LEVEL _nextLevel) {
			return (_prevLevel > _nextLevel ? _prevLevel : _nextLevel) + 1;
		}

		/** Diese Methode aktualisiert die Tiefe des gegebenen Teilbaums und balanziert diesen falls nötig aus. */
		inline void _calcShape_TREE_(INDEX* _itemField, INDEX* _prevArray, INDEX* _nextArray, LEVEL* _levelArray) {
			INDEX _itemIndex = _itemField[0];
			INDEX _prevIndex = _prevArray[_itemIndex];
			INDEX _nextIndex = _nextArray[_itemIndex];
			LEVEL _prevLevel = _prevIndex ? _levelArray[_prevIndex] : 0;
			LEVEL _nextLevel = _nextIndex ? _levelArray[_nextIndex] : 0;
			if (_nextLevel + 1 < _prevLevel) {
				INDEX _prevPrevIndex = _prevArray[_prevIndex];
				INDEX _prevNextIndex = _nextArray[_prevIndex];
				_prevArray[_itemIndex] = _prevNextIndex;
				_nextArray[_prevIndex] = _itemIndex;
				_itemField[0] = _prevIndex;
				_nextLevel = _calcLevel_TREE_(_prevNextIndex ? _levelArray[_prevNextIndex] : 0, _nextLevel);
				_levelArray[_itemIndex] = _nextLevel;
				_prevLevel = _calcLevel_TREE_(_prevPrevIndex ? _levelArray[_prevPrevIndex] : 0, _nextLevel);
				_levelArray[_prevIndex] = _prevLevel;
				return;
			}
			if (_prevLevel + 1 < _nextLevel) {
				INDEX _nextPrevIndex = _prevArray[_nextIndex];
				INDEX _nextNextIndex = _nextArray[_nextIndex];
				_nextArray[_itemIndex] = _nextPrevIndex;
				_prevArray[_nextIndex] = _itemIndex;
				_itemField[0] = _nextIndex;
				_prevLevel = _calcLevel_TREE_(_prevLevel, _nextPrevIndex ? _levelArray[_nextPrevIndex] : 0);
				_levelArray[_itemIndex] = _prevLevel;
				_nextLevel = _calcLevel_TREE_(_prevLevel, _nextNextIndex ? _levelArray[_nextNextIndex] : 0);
				_levelArray[_nextIndex] = _nextLevel;
				return;
			}
			_levelArray[_itemIndex] = _calcLevel_TREE_(_prevLevel, _nextLevel);
		}

		inline void _clearArray_(INDEX* _array, INT32 _length) {
			memset(_array, 0, _length * sizeof(INDEX));
		}

		inline void _countArray_(INDEX* _array, INT32 _length) {
			for (INT32 _item = 1, _next; _item <= _length; _item = _next) {
				_next = _item + 1;
				_array[_item] = (INDEX) _next;
			}
		}

		void _resize_(INT32 _capacity) {
			OBJECT _that(_capacity);
			if (MAPPING_POLICY::HASH_ENABLED) {
				_resize_HASH_(_that);
			} else {
				_resize_TREE_(_that);
			}
			std::swap(_keyArray_, _that._keyArray_);
			std::swap(_valueArray_, _that._valueArray_);
			_entryCapacity_ = _that._entryCapacity_;
		}

		void _resize_HASH_(OBJECT& _that) {
			KEY* _oldKeyArray = _keyArray_;
			KEY* _newKeyArray = _that._keyArray_;
			VALUE* _oldValueArray = _valueArray_;
			VALUE* _newValueArray = _that._valueArray_;
			INDEX _oldMask = _hashMask_[0];
			INDEX _newMask = _that._hashMask_[0];
			INDEX* _oldRootArray = _hashRootArray_[0];
			INDEX* _newRootArray = _that._hashRootArray_[0];
			INDEX* _oldNextArray = _hashNextArray_[0];
			INDEX* _newNextArray = _that._hashNextArray_[0];
			INDEX* _oldCacheArray = MAPPING_POLICY::CACHE_ENABLED ? _hashCacheArray_[0] : 0;
			INDEX* _newCacheArray = MAPPING_POLICY::CACHE_ENABLED ? _that._hashCacheArray_[0] : 0;
			INDEX _newItem = _that._hashNew_[0];
			for (INDEX _oldIndex = 0; _oldIndex <= _oldMask; _oldIndex++) {
				for (INDEX _oldItem = _oldRootArray[_oldIndex]; _oldItem; _oldItem = _oldNextArray[_oldItem]) {
					INDEX _keyHash = MAPPING_POLICY::CACHE_ENABLED ? _oldCacheArray[_oldItem] : (INDEX) KEY_POLICY::hashItem(_oldKeyArray + _oldItem);
					INDEX _newIndex = _keyHash & _newMask;
					_newNextArray[_newItem] = _newRootArray[_newIndex];
					_newRootArray[_newIndex] = _newItem;
					if (MAPPING_POLICY::CACHE_ENABLED) _newCacheArray[_newItem] = _keyHash;
					KEY_POLICY::moveItem(_newKeyArray + _newItem, _oldKeyArray + _oldItem);
					VALUE_POLICY::moveItem(_newValueArray + _newItem, _oldValueArray + _oldItem);
					_newItem++;
				}
			}
			_hashNew_[0] = _newItem;
			_hashMask_[0] = _newMask;
			std::swap(_hashRootArray_[0], _that._hashRootArray_[0]);
			std::swap(_hashNextArray_[0], _that._hashNextArray_[0]);
			if (MAPPING_POLICY::CACHE_ENABLED) std::swap(_hashCacheArray_[0], _that._hashCacheArray_[0]);
		}

		void _resize_TREE_(OBJECT& _that) {
			_resize_TREE_(_that, _treeRoot_[0]);
			_treeNew_[0] = _that._treeNew_[0];
			_treeRoot_[0] = _that._treeRoot_[0];
			std::swap(_treeNextArray_[0], _that._treeNextArray_[0]);
			std::swap(_treePrevArray_[0], _that._treePrevArray_[0]);
			std::swap(_treeLevelArray_[0], _that._treeLevelArray_[0]);
		}

		void _resize_TREE_(OBJECT& _that, INDEX _oldItem) {
			if (!_oldItem) return;
			INDEX newItem = _that._putIndex_TREE_(_keyArray_[_oldItem], _that._treeRoot_);
			VALUE_POLICY::moveItem(_that._valueArray_ + newItem, _valueArray_ + _oldItem);
			_resize_TREE_(_that, _treePrevArray_[0][_oldItem]);
			_resize_TREE_(_that, _treeNextArray_[0][_oldItem]);
		}

		KEY const* _lowerKey_TREE_(KEY const& _key) const {
			INDEX _itemIndex = _lowerIndex_TREE_(_key);
			return _itemIndex ? _keyArray_ + _itemIndex : 0;
		}

		INDEX _lowerIndex_TREE_(KEY const& _key) const {
			return _nearIndex_TREE_(_key, true);
		}

		KEY const* _lowestKey_TREE_() const {
			INDEX _itemIndex = _lowestIndex_TREE_();
			return _itemIndex ? _keyArray_ + _itemIndex : 0;
		}

		INDEX _lowestIndex_TREE_() const {
			return _lastIndex_TREE_(_treeRoot_[0], _treePrevArray_[0]);
		}

		KEY const* _higherKey_TREE_(KEY const& _key) const {
			INDEX _itemIndex = _higherIndex_TREE_(_key);
			return _itemIndex ? _keyArray_ + _itemIndex : 0;
		}

		INDEX _higherIndex_TREE_(KEY const& _key) const {
			return _nearIndex_TREE_(_key, false);
		}

		KEY const* _highestKey_TREE_() const {
			INDEX _itemIndex = _highestIndex_TREE_();
			return _itemIndex ? _keyArray_ + _itemIndex : 0;
		}

		INDEX _highestIndex_TREE_() const {
			return _lastIndex_TREE_(_treeRoot_[0], _treeNextArray_[0]);
		}

		inline INDEX _lastIndex_TREE_(INDEX _lastIndex, INDEX* _lastArray) const {
			if (!_lastIndex) return 0;
			while (true) {
				INDEX _nextIndex = _lastArray[_lastIndex];
				if (!_nextIndex) break;
				_lastIndex = _nextIndex;
			}
			return _lastIndex;
		}

		inline INT32 _nearIndex_TREE_(KEY const& _key, bool nearPrev) const {
			KEY* _keyArray = _keyArray_;
			INDEX* _prevArray = _treePrevArray_[0];
			INDEX* _nextArray = _treeNextArray_[0];
			INDEX _itemIndex = _treeRoot_[0];
			INDEX _nearIndex = 0;
			while (_itemIndex) {
				INT32 _compare = KEY_POLICY::compareItem(&_key, _keyArray + _itemIndex);
				if (!_compare) {
					_itemIndex = nearPrev ? _lastIndex_TREE_(_prevArray[_itemIndex], _nextArray) : _lastIndex_TREE_(_nextArray[_itemIndex], _prevArray);
					if (_itemIndex) return _itemIndex;
					return _nearIndex;
				}
				if (_compare < 0) {
					if (!nearPrev) _nearIndex = _itemIndex;
					_itemIndex = _prevArray[_itemIndex];
				} else {
					if (nearPrev) _nearIndex = _itemIndex;
					_itemIndex = _nextArray[_itemIndex];
				}
			}
			return _nearIndex;
		}

		/** Dieses Feld speichert die Schlüssel. */
		KEY* _keyArray_; // (1...capacity)

		/** Dieses Feld speichert die Werte. */
		VALUE* _valueArray_; // (1...capacity)

		/** Dieses Feld speichert die Anzahl der genutzten Einträge in @c _keyArray_. */
		INDEX _entryCount_;

		/** Dieses Feld speichert die Anzahl der Einträge in in @c _keyArray_. */
		INDEX _entryCapacity_;

		/** Dieses Feld speichert im einzigen Element die Position des nächsten ungenutzten Eintrags.<br>
		 * Die ungenutzten Einträge bilden über @c _hashEntryNextArray_ eine einfach verkettete Liste. */
		INDEX _hashNew_[MAPPING_POLICY::HASH_ENABLED];

		/** Dieses Feld speichert im einzigen Element die Bitmaske zur Umrechnung eines Streuwerts in eine Position in @c _hashTableArray_.<br>
		 * Die Bitmaske ist immer um eins kleiner als die Länge von @c _hashTableArray_. */
		INDEX _hashMask_[MAPPING_POLICY::HASH_ENABLED];

		/** Dieses Feld speichert im einzigen Element das Array der Positionen der Kopfelemente einfach verketteter Listen.<br>
		 * Die Länge dieses Arrays ist immer eine Potenz von <tt>2</tt>. */
		INDEX* _hashRootArray_[MAPPING_POLICY::HASH_ENABLED]; // (0...mask)

		/** Dieses Feld speichert im einzigen Element die Position des nächsten Eintrag. */
		INDEX* _hashNextArray_[MAPPING_POLICY::HASH_ENABLED]; // (1...capacity)

		/** Dieses Feld speichert im einzigen Element die Streuwerte der Schlüssel. */
		INDEX* _hashCacheArray_[MAPPING_POLICY::HASH_ENABLED & MAPPING_POLICY::CACHE_ENABLED]; // (1...capacity)

		/** Dieses Feld speichert im einzigen Element die Position des nächsten ungenutzten Eintrag.<br>
		 * Die ungenutzten Einträge bilden über @c _treeEntryNextArray_ eine einfach verkettete Liste. */
		INDEX _treeNew_[MAPPING_POLICY::TREE_ENABLED];

		/** Dieses Feld speichert im einzigen Element die Position des Wurzelelknoten. */
		INDEX _treeRoot_[MAPPING_POLICY::TREE_ENABLED];

		/** Dieses Feld speichert im einzigen Element die Position des kleineren Kindknoten. */
		INDEX* _treePrevArray_[MAPPING_POLICY::TREE_ENABLED]; // (1...capacity)

		/** Dieses Feld speichert im einzigen Element die Position des größeren Kindknoten. */
		INDEX* _treeNextArray_[MAPPING_POLICY::TREE_ENABLED]; // (1...capacity)

		/** Dieses Feld speichert im einzigen Element die Tiefe des Knoten. */
		UINT8* _treeLevelArray_[MAPPING_POLICY::TREE_ENABLED]; // (1...capacity)

	};

	struct ENTRY {

		public:

		/** Dieser Konstruktor initialisiert einen leeren Eintrag, dessen Methoden stets eine Ausnahme auslösen. */
		ENTRY()
				: _object_(0), _index_(0) {
		}

		/** Diese Methode gibt die Referenz auf den Schlüssel zurück.
		 * @return Referenz auf den Schlüssel. */
		KEY const& key() const {
			OBJECT& _object = *_object_;
			return _object._key_(_index_);
		}

		/** Diese Methode gibt die Referenz auf den Wert zurück.
		 * @return Referenz auf den Wert. */
		VALUE& value() {
			OBJECT& _object = *_object_;
			return _object._value_(_index_);
		}

		/** @copydoc value() */
		VALUE const& value() const {
			OBJECT& _object = *_object_;
			return _object._value_(_index_);
		}

		/** Diese Methode setzt den Wert.
		 * @param _value neuer Wert. */
		void value(VALUE const& _value) {
			VALUE_POLICY::cloneItem(&value(), &_value);
		}

		/** Diese Methode gibt den Streuwert dieses Eintrags zurück.
		 * @return Streuwert dieses Eintrags. */
		INT32 hash() const {
			INDEX _index = _index_;
			OBJECT& _object = *_object_;
			SUCHash _result;
			_result.pushHash(_object._keyHash_(_index));
			_result.pushHash(_object._valueHash_(_index));
			return _result;
		}

		/** Diese Methode gibt nur dann <tt>true</tt> zurück, wenn dieses @c ENTRY äquivalent zum gegebenen ist.
		 * @param _that @c ENTRY.
		 * @return <tt>true</tt>, wenn dieses und das gegebene @c ENTRY äquivalent sind. */
		bool equals(ENTRY const& _that) const {
			INDEX _index = _index_;
			OBJECT& _thisObject = *_object_;
			OBJECT& _thatObject = *_that._object_;
			if (!KEY_POLICY::equalsItem(&_thisObject._key_(_index), &_thatObject._key_(_index))) return false;
			if (!VALUE_POLICY::equalsItem(&_thisObject._value_(_index), &_thatObject._value_(_index))) return false;
			return true;
		}

		private:

		friend MAPPING;

		friend ITERATOR;

		ENTRY(OBJECT* _object, INDEX _index)
				: _object_(_object), _index_(_index) {
		}

		/** Dieses Feld verweist auf die Nutzdaten der Abbildung. */
		OBJECT* _object_;

		/** Dieses Feld speichert den Index des Eintrags. */
		INDEX _index_;

	};

	/**
	 * Diese Klasse definiert die Zustandsdaten des @c SUCCursor dieser @c SUCMapping.
	 */
	struct ITERATOR: public SUCIterator<ENTRY, ITERATOR> {

		public:

		/* SUCIterator */
		inline static bool equals(ITERATOR const& _this, ITERATOR const& _that) {
			return _this._value_ == _that._value_;
		}

		/* SUCIterator */
		inline static bool compare(ITERATOR const& _this, ITERATOR const& _that, INT32& _result) {
			return false;
		}

		/* SUCIterator */
		inline static bool distance(ITERATOR const& _this, ITERATOR const& _that, INT32& _result) {
			return false;
		}

		/** Dieser Konstruktor initialisiert das @c SUCMapping.
		 * @param _mapping @c SUCMapping. */
		ITERATOR(MAPPING const& _mapping)
				: _mapping_(_mapping) {
			_value_._object_ = _mapping._object_.get();
			moveToFirst();
		}

		/* SUCIterator */
		bool valid() const {
			return _value_._index_;
		}

		/* SUCIterator */
		ENTRY& value() {
			return _value_;
		}

		/* SUCIterator */
		ENTRY const& value() const {
			return _value_;
		}

		/* SUCIterator */
		bool move(INT32 const _offset) {
			OBJECT& _object = *_mapping_._object_.get();
			for (INT32 _count = _offset; _count < 0; ++_count) {
				if (MAPPING_POLICY::HASH_ENABLED) {
					_seekPrev_HASH_(_object._hashMask_[0], _object._hashRootArray_[0], _object._hashNextArray_[0]);
				} else {
					_seekItem_TREE_(_object._treeNextArray_[0], _object._treePrevArray_[0]);
				}
			}
			for (INT32 _count = _offset; _count > 0; --_count) {
				if (MAPPING_POLICY::HASH_ENABLED) {
					_seekNext_HASH_(_object._hashRootArray_[0], _object._hashNextArray_[0]);
				} else {
					_seekItem_TREE_(_object._treePrevArray_[0], _object._treeNextArray_[0]);
				}
			}
			return true;
		}

		void moveToFirst() {
			OBJECT& _object = *_mapping_._object_.get();
			if (MAPPING_POLICY::HASH_ENABLED) {
				_hashRootIndex_[0] = _object._hashMask_[0] + 1;
				_seekNext_HASH_ROOT_(_object._hashRootArray_[0], _object._hashNextArray_[0]);
			} else {
				_treeRootIndex_[0] = 0;
				_treeRootArray_[0][0] = 0;
				INDEX _itemIndex = _object._treeRoot_[0];
				if (_itemIndex) _seekItem_TREE_ITEM_(_itemIndex, 0, _treeRootArray_[0], _object._treePrevArray_[0]);
			}

		}

		void moveToLast() {
			OBJECT& _object = *_mapping_._object_.get();
			if (MAPPING_POLICY::HASH_ENABLED) {
				_hashRootIndex_[0] = -1;
				_seekPrev_HASH_ROOT_(_object._hashMask_[0], _object._hashRootArray_[0], _object._hashNextArray_[0]);
			} else {
				_treeRootIndex_[0] = 0;
				_treeRootArray_[0][0] = 0;
				INDEX _itemIndex = _object._treeRoot_[0];
				if (_itemIndex) _seekItem_TREE_ITEM_(_itemIndex, 0, _treeRootArray_[0], _object._treeNextArray_[0]);
			}
		}

		private:

		inline void _seekPrev_HASH_(INDEX _rootMask, INDEX* _rootArray, INDEX* _nextArray) {
			INDEX _itemIndex = _hashItemIndex_[0];
			if (!_itemIndex) return;
			INDEX _rootIndex = _hashRootIndex_[0];
			_rootIndex = _rootArray[_rootIndex];
			if (_rootIndex != _itemIndex) {
				while (true) {
					INDEX _nextIndex = _nextArray[_rootIndex];
					if (_nextIndex == _itemIndex) break;
					_rootIndex = _nextIndex;
				}
				_value_._index_ = _rootIndex;
				_hashItemIndex_[0] = _rootIndex;
			} else {
				_seekPrev_HASH_ROOT_(_rootMask, _rootArray, _nextArray);
			}
		}

		inline void _seekPrev_HASH_ROOT_(INDEX _rootMask, INDEX* _rootArray, INDEX* _nextArray) {
			INDEX _rootIndex = _hashRootIndex_[0];
			INDEX _itemIndex = 0;
			while (_rootMask != _rootIndex) {
				++_rootIndex;
				_itemIndex = _rootArray[_rootIndex];
				if (!_itemIndex) continue;
				while (true) {
					INDEX _nextIndex = _nextArray[_itemIndex];
					if (!_nextIndex) break;
					_itemIndex = _nextIndex;
				}
				if (_itemIndex) break;
			}
			_value_._index_ = _itemIndex;
			_hashItemIndex_[0] = _itemIndex;
			_hashRootIndex_[0] = _rootIndex;
		}

		inline void _seekNext_HASH_(INDEX* _rootArray, INDEX* _nextArray) {
			INDEX _itemIndex = _hashItemIndex_[0];
			if (!_itemIndex) return;
			_itemIndex = _nextArray[_itemIndex];
			if (_itemIndex) {
				_value_._index_ = _itemIndex;
				_hashItemIndex_[0] = _itemIndex;
			} else {
				_seekNext_HASH_ROOT_(_rootArray, _nextArray);
			}
		}

		inline void _seekNext_HASH_ROOT_(INDEX* _rootArray, INDEX* _nextArray) {
			INDEX _rootIndex = _hashRootIndex_[0];
			INDEX _itemIndex = 0;
			while (_rootIndex && !_itemIndex) {
				--_rootIndex;
				_itemIndex = _rootArray[_rootIndex];
			}
			_value_._index_ = _itemIndex;
			_hashItemIndex_[0] = _itemIndex;
			_hashRootIndex_[0] = _rootIndex;
		}

		inline void _seekItem_TREE_(INDEX* _prevArray, INDEX* _nextArray) {
			INT32 _rootIndex = _treeRootIndex_[0];
			INDEX* _rootArray = _treeRootArray_[0];
			INDEX _itemIndex = _rootArray[_rootIndex];
			if (!_itemIndex) return;
			INDEX _nextIndex = _nextArray[_itemIndex];
			if (_nextIndex) _seekItem_TREE_ITEM_(_nextIndex, _rootIndex, _rootArray, _prevArray);
			else _seekItem_TREE_ROOT_(_itemIndex, _rootIndex, _rootArray, _prevArray, _nextArray);
		}

		inline void _seekItem_TREE_ROOT_(INDEX _itemIndex, INT32 _rootIndex, INDEX* _rootArray, INDEX* _prevArray, INDEX* _nextArray) {
			INDEX _gotoIndex;
			while (true) {
				--_rootIndex;
				_gotoIndex = _rootArray[_rootIndex];
				if (!_gotoIndex) break;
				if (_itemIndex == _prevArray[_gotoIndex]) break;
				_itemIndex = _gotoIndex;
			}
			_value_._index_ = _gotoIndex;
			_treeRootIndex_[0] = _rootIndex;
		}

		inline void _seekItem_TREE_ITEM_(INDEX _itemIndex, INT32 _rootIndex, INDEX* _rootArray, INDEX* _prevArray) {
			while (true) {
				++_rootIndex;
				_rootArray[_rootIndex] = _itemIndex;
				INDEX _gotoIndex = _prevArray[_itemIndex];
				if (!_gotoIndex) break;
				_itemIndex = _gotoIndex;
			}
			_value_._index_ = _itemIndex;
			_treeRootIndex_[0] = _rootIndex;
		}

		/** Dieses Feld speichert das @c SUCMapping. */
		MAPPING _mapping_;

		/** Dieses Feld speichert den aktuellen Eintrag als Element des Iterators. */
		ENTRY _value_;

		INDEX _hashItemIndex_[MAPPING_POLICY::HASH_ENABLED];

		INDEX _hashRootIndex_[MAPPING_POLICY::HASH_ENABLED];

		INT32 _treeRootIndex_[MAPPING_POLICY::TREE_ENABLED];

		INDEX _treeRootArray_[MAPPING_POLICY::TREE_ENABLED][OBJECT::MAX_LEVEL];

	};

	public:

	/** Dieser Datentyp definiert den @c SUCCursor einer @c SUCMapping. */
	typedef SUCCursor<ENTRY, ITERATOR> CURSOR;

	/** Dieser Datentyp definiert den @c SUCCursor einer @c SUCMapping (@c const). */
	typedef SUCCursor<ENTRY_CONST, ITERATOR> CURSOR_CONST;

	/** Dieser Konstruktor erzeugt eine @c SUCMapping mit der gegebenen Kapazität.
	 * @param _capacity Kapazität.
	 * @throws SUCException Wenn @c _capacity kleiner <tt>0</tt> ist. */
	SUCMapping(INT32 const _capacity = 16) {
		SUCException::checkCount(_capacity);
		_object_.set(new OBJECT(_capacity));
	}

	/** Diese Methode entfernt alle Einträge dieser @c SUCMapping. */
	void clear() {
		OBJECT& _this = *_object_;
		if (!_this._entryCount_) return;
		_object_.set(new OBJECT((INT32) _this._entryCapacity_));
	}

	/** Diese Methode gibt eine kompakte Kopie dieser @c SUCMapping zurück.
	 * @return Kopie dieser @c SUCMapping. */
	MAPPING clone() const {
		OBJECT& _this = *_object_;
		MAPPING _result((INT32) _this._entryCount_);
		_result.putAll(*this);
		return _result;
	}

	/** Diese Methode gibt die Anzahl der Einträge dieser @c SUCMapping zurück.
	 * @return Anzahl der Einträge. */
	INT32 length() const {
		OBJECT& _this = *_object_;
		return (INT32) _this._entryCount_;
	}

	/** Diese Methode gibt die Kapazität des internen Speicherbereichs zurück.
	 * @return Kapazität. */
	INT32 capacity() const {
		OBJECT& _this = *_object_;
		return (INT32) _this._entryCapacity_;
	}

	/** Diese Methode setzt die Größe des internen Speicherbereichs, in welchem die Einträge dieser @c SUCMapping verwaltet werden.<br>
	 * Wenn die gegebenen Kapazität von der aktuellen abweicht, werden die Einträge in einen neuen Speicherbereich übertragen.
	 * @param _capacity Kapazität.
	 * @throws SUCException Wenn @c _capacity kleiner @c length() ist. */
	void allocate(INT32 const _capacity) {
		SUCException::checkCount(_capacity);
		OBJECT& _this = *_object_;
		INT32 _length = _this._entryCount_;
		if (_capacity == _this._entryCapacity_) return;
		SUCException::checkCount(_capacity - _length);
		_this._resize_(_capacity);
	}

	/** Diese Methode reduziert die Größe des internen Speicherbereichs auf das Minimum.<br>
	 * Sie ist eine Abkürzung für @c allocate(length()). */
	void compact() {
		OBJECT& _this = *_object_;
		INT32 _length = _this._entryCount_;
		if (_length == _this._entryCapacity_) return;
		_this._resize_(_length);
	}

	/**
	 * Diese Methode gibt den auf den ersten Eintrag zeigenden @c SUCCursor dieser @c SUCMapping zurück.<br>
	 * Der @c SUCCursor unterstützt nur die positive Bewegungsrichtung.
	 *
	 * @return @c SUCCursor dieser @c SUCMapping.
	 */
	CURSOR cursor() {
		return CURSOR(ITERATOR(*this));
	}

	/** @copydoc cursor() */
	CURSOR_CONST cursor() const {
		return CURSOR_CONST(ITERATOR(*this));
	}

	/** Diese Methode gibt eine Kopie des Wert des Eintrags zurück, der unter dem gegebenen Schlüssel hinterlegt wurde.
	 * @param _key Schlüssel.
	 * @return Referenz auf einen Wert.
	 * @throws SUCException Wenn unter dem Schlüssel kein Eintrag hinterlegt wurde. */
	VALUE get(KEY const& _key) const {
		OBJECT& _this = *_object_;
		VALUE _result;
		VALUE& _value = _this._item_(_key);
		VALUE_POLICY::cloneItem(&_result, &_value);
		return _result;
	}

	/** Diese Methode gibt die Referenz auf den Wert des Eintrags mit dem gegebenen Schlüssel zurück.<br>
	 * Wenn es noch keinen solchen Eintrag gibt, wird ein neuer angelegt.
	 * @param _key Schlüssel.
	 * @return Regerenz auf den Wert des Eintrags mit dem gegebenen Schlüssel. */
	VALUE& put(KEY const& _key) {
		OBJECT& _this = *_object_;
		INDEX _entry = _this._find_(_key, true);
		VALUE& _result = _this._value_(_entry);
		return _result;
	}

	/** Diese Methode setzt den Wert des Eintrags mit dem gegebenen Schlüssel.<br>
	 * Wenn es noch keinen solchen Eintrag gibt, wird ein neuer angelegt.
	 * @param _key Schlüssel.
	 * @param _value Wert. */
	void put(KEY const& _key, VALUE const& _value) {
		OBJECT& _this = *_object_;
		_this._put_(_key, _value);
	}

	/** Diese Methode kopiert alle Einträge des gegebenen @c SUCMapping.<br>
	 * Hierzu werden alle Einträge in @c _table an @c put(KEY const&, VALUE const&) delegiert.
	 * @param _mapping @c SUCMapping. */
	void putAll(MAPPING const& _mapping) {
		OBJECT& _this = *_object_;
		OBJECT& _that = *_mapping._object_;
		for (CURSOR_CONST cur = _mapping.cursor(); cur; ++cur) {
			ENTRY_CONST& _entry = *cur;
			INDEX _index = _entry._index_;
			if (MAPPING_POLICY::HASH_ENABLED & MAPPING_POLICY::CACHE_ENABLED) {
				_this._put_HASH_(_that._keyArray_[_index], _that._hashCacheArray_[0][_index], _that._valueArray_[_index]);
			} else {
				_this._put_(_that._keyArray_[_index], _that._valueArray_[_index]);
			}
		}
	}

	/** Diese Methode entfernt den Eintrag mit dem gegebenen Schlüssel.
	 * @param _key Schlüssel. */
	void pop(KEY const& _key) {
		OBJECT& _this = *_object_;
		if (!_this._entryCount_) return;
		_this._pop_(_key);
	}

	/** Diese Methode entfernt alle Einträge mit den Schlüsseln, die in der gegebenen @c SUCMapping vorkommen.<br>
	 * Hierzu werden die Schlüssel aller Einträge in @c _table an @c pop(GKEY const&) delegiert.
	 * @param _mapping @c SUCMapping. */
	void popAll(MAPPING const& _mapping) {
		OBJECT& _this = *_object_;
		OBJECT& _that = *_mapping._object_;
		for (CURSOR_CONST cur = _mapping.cursor(); cur; ++cur) {
			ENTRY_CONST& _entry = cur;
			if (!_this._entryCount_) return;
			INDEX _index = _entry._index_;
			if (MAPPING_POLICY::HASH_ENABLED & MAPPING_POLICY::CACHE_ENABLED) {
				_this._popIndex_HASH_(_that._keyArray_[_index], _that._hashCacheArray_[0][_index]);
			} else {
				_this._pop_(_that._keyArray_[_index]);
			}
		}
	}

	/** Diese Methode gibt einen Zeiger auf den Wert zurück, der unter dem gegebenen Schlüssel hinterlegt wurde.<br>
	 * Bei erfolgloser Suche wird <tt>0</tt> geliefert.
	 * @param _key Schlüssel.
	 * @return Zeiger auf einen Wert oder <tt>0</tt>. */
	VALUE* find(KEY const& _key) {
		OBJECT& _this = *_object_;
		return _this._get_(_key);
	}

	/** @copydoc find(KEY const&) */
	VALUE const* find(KEY const& _key) const {
		OBJECT& _this = *_object_;
		return _this._get_(_key);
	}

	/** Diese Methode gibt einen Zeiger auf den Schlüssel mit der höchsten Ordnung zurück, dessen Ordnung geringer als die des gegebenen Referenzschlüssels ist.<br>
	 * Bei erfolgloser Suche wird <tt>0</tt> geliefert.
	 * @param _key Referenzschlüssel.
	 * @return Zeiger auf einen Schlüssel oder <tt>0</tt>.
	 * @throws SUCException Wenn die Abbildung nicht ordnungsbasiert ist. */
	KEY const* lowerKey(_KEY const& _key) const {
		SUCException::checkState(MAPPING_POLICY::TREE_ENABLED);
		OBJECT& _this = *_object_;
		return _this._lowerKey_TREE_(_key);
	}

	/** Diese Methode gibt einen Zeiger auf den Schlüssel mit der geringsten Ordnung zurück.<br>
	 * Bei einer leeren Abbildung wird <tt>0</tt> geliefert.
	 * @return Zeiger auf einen Schlüssel oder <tt>0</tt>.
	 * @throws SUCException Wenn die Abbildung nicht ordnungsbasiert ist. */
	KEY const* lowestKey() const {
		SUCException::checkState(MAPPING_POLICY::TREE_ENABLED);
		OBJECT& _this = *_object_;
		return _this._lowestKey_TREE_();
	}

	/** Diese Methode gibt einen Zeiger auf den Schlüssel mit der geringsten Ordnung zurück, dessen Ordnung höher als die des gegebenen Referenzschlüssels ist.<br>
	 * Bei erfolgloser Suche wird <tt>0</tt> geliefert.
	 * @param _key Referenzschlüssel.
	 * @return Zeiger auf einen Schlüssel oder <tt>0</tt>.
	 * @throws SUCException Wenn die Abbildung nicht ordnungsbasiert ist. */
	KEY const* higherKey(_KEY const& _key) const {
		SUCException::checkState(MAPPING_POLICY::TREE_ENABLED);
		OBJECT& _this = *_object_;
		return _this._higherKey_TREE_(_key);
	}

	/** Diese Methode gibt einen Zeiger auf den Schlüssel mit der höchsten Ordnung zurück.<br>
	 * Bei einer leeren Abbildung wird <tt>0</tt> geliefert.
	 * @return Zeiger auf einen Schlüssel oder <tt>0</tt>.
	 * @throws SUCException Wenn die Abbildung nicht ordnungsbasiert ist. */
	KEY const* highestKey() const {
		SUCException::checkState(MAPPING_POLICY::TREE_ENABLED);
		OBJECT& _this = *_object_;
		return _this._highestKey_TREE_();
	}

	/** Diese Methode gibt den Streuwert dieser @c SUCMapping zurück.
	 * @tparam GHASHER2 @c SUCHasher zur berechnung der Streuwerte des Werts.
	 * @return Streuwert dieser @c SUCMapping. */
	INT32 hash() const {
		SUCHash _hash;
		for (CURSOR_CONST _cur = cursor(); _cur; ++_cur) {
			_hash.mergeHash(_cur->hash());
		}
		return _hash;
	}

	/** Diese Methode gibt nur dann <tt>true</tt> zurück, wenn diese @c SUCMapping äquivalent zur gegebenen ist.
	 * @param _mapping @c SUCMapping.
	 * @return <tt>true</tt>, wenn diese und die gegebene @c SUCMapping äquivalent sind. */
	bool equals(MAPPING const& _mapping) const {
		OBJECT& _this = *_object_;
		OBJECT& _that = *_mapping._object_;
		if (_this._entryCount_ != _that._entryCount_) return false;
		if (_this._keyArray_ == _that._keyArray_) return true;
		for (CURSOR_CONST _cur = _mapping.cursor(); _cur; ++_cur) {
			ENTRY_CONST& _entry = *_cur;
			INDEX _index = _entry._index_;
			VALUE const* _value;
			if (MAPPING_POLICY::HASH_ENABLED) {
				_value = _this._get_HASH_(_that._key_(_index), (INDEX) _that._keyHash_(_index));
			} else {
				_value = _this._get_(_that._key_(_index));
			}
			if (!_value || !VALUE_POLICY::equalsItem(_value, _that._value_(_index))) return false;
		}
		return true;
	}

	/** Diese Operator gibt die Referenz auf den Wert des Eintrags zurück, der unter dem gegebenen Schlüssel hinterlegt wurde.
	 * @param _key Schlüssel.
	 * @return Referenz auf einen Wert.
	 * @throws SUCException Wenn unter dem Schlüssel kein Wert hinterlegt wurde. */
	VALUE& operator[](KEY const& _key) {
		OBJECT& _this = *_object_;
		return _this._item_(_key);
	}

	/** @copydoc operator[](KEY const&) */
	VALUE const& operator[](KEY const& _key) const {
		OBJECT& _this = *_object_;
		return _this._item_(_key);
	}

	private:

	/** Dieses Feld speichert die referenzgezählten Nutzdaten. */
	RCPointer<OBJECT> _object_;

}
;

}

}

}

#endif
