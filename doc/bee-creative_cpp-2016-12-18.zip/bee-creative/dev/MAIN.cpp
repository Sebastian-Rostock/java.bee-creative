//============================================================================
// Name        : BEX.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

//#include <bee-creative/dev/bee_creative_mmf.hpp>
#include "MAIN.hpp"
#include <iostream>
#include <boost/functional/hash.hpp>

using namespace bee::creative;
//using namespace bee::creative::fem;
//using namespace bee::creative::iam;
using namespace bee::creative::suc;

template<typename T>
void print(T* p) {
	cout << p << ':' << (p ? p[0] : 0) << '\n';
}

struct A: public RCObject<A> {

	int f = 132;

};

struct B {

	RCPointer<A> a;

};

B tob() {
	A* a = new A();
	RCPointer<A> p(a);

	return ((B*) &p)[0];

}

using namespace bee::creative::fem;

int main() {

	fem_main();

	FEMInteger _p1 = FEMInteger::from(123);
	FEMInteger _p2 = FEMInteger::from(456);


	cout << "femc \n";

	cout << "integer \n";
	cout << _p1.value() << '\n';
	cout << _p2.value() << '\n';
	cout << _p1.equals(_p2) << '\n';
	cout << _p1.compare(_p2) << '\n';

	return 0;

	FEMValue::ARRAY params(2);

	params[0] = _p1;

	FEMFrame f;
	f = f.newFrame(params);
	FEMValue x = f.get(0);
	cout << &x << '\n';

	B b = tob();

	cout << b.a->f << '\n';

	// 1

	typedef SUCArray<INT32> INT_ARRAY;
	INT_ARRAY array_1(2);
	array_1[0] = 123;
	array_1[1] = 465;
	INT_ARRAY array_2 = array_1.clone();
	cout << array_1.hash() << ' ' << array_2.hash() << ' ' << array_2.equals(array_1) << '\n';
	for (INT_ARRAY::CURSOR c = array_1.cursor(); c; ++c) {
		cout << *c << '\n';
	}

	// 2

	typedef SUCListing<INT32> INT_LISTING;
	INT_LISTING listing_1(2000);
	listing_1.addAll(array_1);
	listing_1.compact();
	INT_LISTING listing_2 = listing_1.clone();
	cout << listing_1.hash() << ' ' << listing_2.hash() << ' ' << listing_2.equals(listing_1) << '\n';
	for (INT_LISTING::CURSOR c = listing_1.cursor(); c; ++c) {
		cout << *c << '\n';
	}

	// 3

//	typedef SUCMapping<INT32, INT32, SUCPolicy_PRIMITIVE<INT32>, SUCPolicy_PRIMITIVE<INT32>, SUCMapping_POLICY_HASH_8> INT_MAPPING;
	typedef SUCMapping<INT32, INT32, SUCPolicy_PRIMITIVE<INT32>, SUCPolicy_PRIMITIVE<INT32>, SUCMapping_POLICY_TREE_8> INT_MAPPING;

	INT_MAPPING test(4);

	test.put(20, 22);
	test.put(30, 33);
	test.put(40, 33);

//	cout << "mapping\n";
//	print(test.lowestKey());
//	print(test.highestKey());
//
//	cout << "mapping.lowerKey\n";
//	print(test.lowerKey(15));
//	print(test.lowerKey(20));
//	print(test.lowerKey(25));
//	print(test.lowerKey(30));
//	print(test.lowerKey(35));
//	print(test.lowerKey(40));
//	print(test.lowerKey(45));
//
//	cout << "mapping.higherKey\n";
//	print(test.higherKey(15));
//	print(test.higherKey(20));
//	print(test.higherKey(25));
//	print(test.higherKey(30));
//	print(test.higherKey(35));
//	print(test.higherKey(40));
//	print(test.higherKey(45));

	test.pop(30);

	print(test.find(20));
	print(test.find(30));
	print(test.find(40));

	test.clear();

	cout.flush();

	INT_MAPPING::CURSOR c = test.cursor();
//	c.iterator.moveToLast();
	for (; c; --c) {
		cout << c->key() << ' ' << c->value() << '\n';

	}

	return 0;
}

/*

 void printIAM(IAMArray const& _array) {
 cout << "[ ";
 for (int i = 0, l = _array.length(); i < l; i++)
 cout << _array.get(i) << " ";
 cout << "]";
 }

 template<typename T>
 void printSUC(SUCArray<T> const& _array) {
 cout << "[ ";
 for (int i = 0, l = _array.length(); i < l; i++)
 cout << _array[i] << " ";
 cout << "]\n";
 cout.flush();
 }

 ptime now() {
 return ptime(microsec_clock::local_time());
 }


 template <typename X>
 class MP: private boost::intrusive_ptr<X> {

 };

 class A {

 public:
 class B {
 public:

 int sdfd;

 };

 B dd;

 };







 void xx(){




 typedef SUCArray<INT32> ITEM;
 {
 RCCount c;

 ITEM sss(12);

 c.inc();

 cout << c.count() << '\n' <<
 (sss.cursor() == sss.cursor().reverse())
 << '\n';

 }

 {
 A d;
 d.dd.sdfd = 32423;

 typedef std::vector<ITEM> V1;

 typedef SUCVector<ITEM, SUC_POLICY_STRUCT<ITEM> > V2;

 INT32 _max = 100;

 //tab.find(213)->;

 ptime s1 = now();
 V1 _target1;
 _target1.reserve(1);
 for (INT32 _val = 0; _val < _max; ++_val) {
 INT32 _pos = rand() % (_val + 1);
 //		_target1.insert(_target1.begin() + _pos, ITEM(_val));
 _target1.insert(_target1.begin(), ITEM(_val));
 }
 ptime f1 = now();
 cout << "V1: " << (f1 - s1) << '\n';
 cout.flush();

 ptime s2 = now();
 V2 _target2;
 _target2.align(100);
 _target2.allocate(1);
 for (INT32 _val = 0; _val < _max; ++_val) {
 INT32 _pos = rand() % (_val + 1);
 //	_target2.add(_pos, ITEM(_val));
 _target2.add(0, ITEM(_val));
 }
 ptime f2 = now();
 cout << "V2: " << (f2 - s2) << '\n';
 cout.flush();

 typedef SUCTable<int, int> TAB;
 TAB tab(7);
 tab.put(1, 4);
 tab.put(3, 34);
 tab.put(9, 354657);

 //		TAB::ENTRY s(465,789);
 //
 //		TAB::ENTRY t(1,454);
 //
 //		t=s;
 //		t.value()=99;
 //		s=t;

 //boost::unordered::unordered_map

 for (TAB::CURSOR cur = tab.clone().cursor(); cur; ++cur) {
 cout << cur->key() << ':' << cur->value() << '\n';
 cout.flush();
 }
 tab.compact();

 vector<INT32> ss;

 ss.reserve(0);
 ss.push_back(123);
 ss.push_back(456);
 ss.push_back(789);

 IAMArrayBuilder array;

 array.add(132);
 array.add(465);
 array.add(789);

 IAMArray key = array.build();

 array.add(ss[0]);
 array.clear();

 IAMArray value = array.build();

 printIAM(key);
 cout << '\n';
 printIAM(value);
 cout << '\n';

 IAMMapBuilder map;

 map.put(key, value);

 IAMIndexBuilder index;

 index.maps().add(map);

 IAMArray src = index.build();

 IAMIndex i(src);

 cout << i.map(0).find(key) << '\n';
 return 0;
 }

 {

 IAMArrayBuilder ab;

 ab.add(123);
 ab.add(456);
 ab.add(789);

 IAMArray a = ab.build();

 cout << a.length() << '\n';

 }

 {

 signed int data[3] = { 123, 456, 789 };

 IAMArray arr(data, 3, true);
 IAMArray arr2(data, 3);

 {
 IAMArray a2;

 a2 = arr;

 a2 = arr2;

 cout << a2.length() << '\n';
 cout << a2.get(0) << '\n';
 cout << a2.get(1) << '\n';
 cout << a2.get(2) << '\n';
 }
 cout.flush();
 //	exit(0);
 }
 if (0) {

 ptime t1(microsec_clock::local_time());
 string name = "_a.iam";
 PCVOID x = &name;
 PCVOID y = (UINT32 const*) x + 1;
 cout << x << " " << y << '\n';
 MMFView view(name.c_str());
 ptime t2(microsec_clock::local_time());
 //	IAMIndex index(view);
 ptime t3(microsec_clock::local_time());
 cout << "1..2: " << (t2 - t1) << '\n';
 cout << "2..3: " << (t3 - t2) << '\n';
 cout << "view.size: " << view.size() << '\n';
 //		cout << "index.mapCount: " << index.mapCount() << '\n';
 //		cout << "index.listCount: " << index.listCount() << '\n';
 }

 //	{
 //
 //		MMF_DataPtr _file(new MMFData());
 //
 //		_file->open((PCCHAR)"_2.bex");
 //
 //		cout << "data: " << (int) _file->data() << " size: " << _file->size() << "\n";
 //
 //		ptime t1(microsec_clock::local_time());
 //
 //		BEX_DataPtr data(new BEX_Data(_file));
 //
 //		BEX_NodePtr docu = data->document();
 //
 //		ptime t2(microsec_clock::local_time());
 //
 //		cout << "1..2: " << (t2 - t1) << '\n';
 //
 //		for (int i = 0; i < 5; i++) {
 //			ptime A(microsec_clock::local_time());
 //			pn(docu, 0);
 //			ptime B(microsec_clock::local_time());
 //
 //			cout << "2..3: " << (B - A) << '\n';
 //		}
 //
 //		// alte IMPL war 2.15
 //		// neu 0.58
 //	}

 return 0;
 }
 */
