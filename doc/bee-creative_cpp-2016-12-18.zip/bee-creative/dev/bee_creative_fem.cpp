/* [cc-by] 2013..2016 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#include "bee_creative_fem.hpp"
#include <string.h>
#include <iostream>

#define FEM_BREAK_CALL(_CASTFIELD_,_METHODCALL_) \
	femCast(this)->_CASTFIELD_->_METHODCALL_;

#define FEM_CASE_BREAK_CALL(_DATATYPE_,_CASTFIELD_,_METHODCALL_) \
	case _DATATYPE_:\
		FEM_BREAK_CALL(_CASTFIELD_,_METHODCALL_)

#define FEM_CASE_RETURN(_DATATYPE_,_RESULT_) \
	case _DATATYPE_: return _RESULT_;

#define FEM_RETURN_CALL(_CASTFIELD_,_METHODCALL_) \
	return femCast(this)->_CASTFIELD_->_METHODCALL_;

#define FEM_CASE_RETURN_CALL(_DATATYPE_,_CASTFIELD_,_METHODCALL_) \
	case _DATATYPE_: FEM_RETURN_CALL(_CASTFIELD_,_METHODCALL_)

namespace bee {

namespace creative {

namespace fem {

typedef FEMFrame::OBJECT FEMFrameOBJ;
typedef RCPointer<FEMFrameOBJ> FEMFramePTR;
typedef FEMContext::OBJECT FEMContextOBJ;
typedef RCPointer<FEMContextOBJ> FEMContextPTR;
typedef FEMFunction::OBJECT FEMFunctionOBJ;
typedef RCPointer<FEMFunctionOBJ> FEMFunctionPTR;
struct FEMArrayCYCLIC;
struct FEMContextBASE;

struct __________;

/** Diese Klasse definiert die abstrakte Grundlage der Nutzdaten von Stapelrahmen, Funktionen und Werten. */
struct FEMFrameBASE: public RCObject<FEMFrameBASE> { // DONE

	/** Dieser Datentyp definiert die Auflistung der Typkennungen. */
	enum FRAME_TYPE {
		FRAME_ARRAY, // konst value
		FRAME_CYCLIC, //
		FRAME_INVOKE, // funkt
		FRAME_CONTEXT, // leer mit ctxt
		FRAME_CUSTOM1, // ? iam paams
		FRAME_CUSTOM2, // ?
		FRAME_CUSTOM3
	};

	/** Dieses Feld speichert die Typkennung, mit der Fallunterscheidungen erfolgen. */
	FRAME_TYPE const dataType;

	/** Dieses Feld speichert die Anzahl der Parameter. */
	INT32 frameSize;

	/** Dieses Feld speichert den Verweis auf den übergeordneten Stapelrahmen. */
	FEMFramePTR parentFrame;

	/** Dieses Feld speichert den Verweis auf den Kontext. */
	FEMContextBASE const* ownerContext;

	FEMFrameBASE(FRAME_TYPE _dataType, INT32 const _frameSize, FEMFramePTR const& _parentFrame);

	FEMFrameBASE(FRAME_TYPE _dataType, INT32 const _frameSize, FEMContextBASE const& _ownerContext);

	FEMValue getBASE(INT32 const _index) const;

	FEMArray paramsBASE() const;

};

struct FEMFrameARRAY: public FEMFrameBASE { // DONE

	/** Dieses Feld speichert die Parameterwerte. */
	FEMArray paramArray;

	FEMFrameARRAY(FEMFramePTR const& _parentFrame, FEMArray const& _paramArray);

	FEMValue getARRAY(INT32 const _index) const;

	FEMArray paramsARRAY() const;

};

/** Diese Klasse implementiert die Nutzdaten eines Parameterwerts, der über eine Parameterfunktion berechnet werden kann. */
struct FEMFramePARAM { // DONE

	/** Dieses Feld speichert den Parameterwert zur Wiederverwendung. */
	FEMFunctionPTR paramValue;

	/** Dieses Feld speichert die Funktion zur Berechnung des Parameterwerts. */
	FEMFunction paramFunction;

	FEMFramePARAM(FEMFunction const& _paramFunction);

};

/** Diese Klasse implementiert die Nutzdaten eines Stapelrahmen, desses Parameterwerte über Parameterfunktionen bereitgestellt werden. */

struct FEMFrameCYCLIC: public FEMFrameBASE { // DONE

	/** Dieses Feld speichert die Wertliste als Sicht auf die Parameterwert. */
	FEMArrayCYCLIC* cyclicArray;

	FEMFrameCYCLIC(FEMContextBASE const& _ownerContext);

	FEMFrameCYCLIC(FRAME_TYPE const _dataType, INT32 const _frameSize, FEMFramePTR const& _parentFrame);

	FEMArray paramsCYCLIC() const;

};

/** Diese Klasse implementiert die Nutzdaten eines Stapelrahmen, desses Parameterwerte über Parameterfunktionen bereitgestellt werden. */
struct FEMFrameINVOKE: public FEMFrameCYCLIC { // DONE

	/** Dieses Feld speichert Paare aus Parameterwert und Parameterfunktion. */
	FEMFramePARAM paramArray[0];

	FEMFrameINVOKE(FEMFramePTR const& _parentFrame, FEMFunction const* _paramArray, INT32 const _paramCount);

	~FEMFrameINVOKE();

	FEMValue getINVOKE(INT32 const _index) const;

};

struct FEMFrameCONTEXT: public FEMFrameBASE { // DONE

	FEMContext parentContext;

	FEMFrameCONTEXT(FEMContext const& _parentContext);

	FEMValue getCONTEXT(INT32 const _index) const;

	FEMArray paramsCONTEXT() const;

};

struct FEMFrameCUSTOM1: public FEMFrameCYCLIC { // TODO

	FEMFrameCUSTOM1();

	~FEMFrameCUSTOM1();

	FEMValue getCUSTOM1(INT32 const _index) const;

};

struct FEMFrameCUSTOM2: public FEMFrameCYCLIC { //

	FEMFrameCUSTOM2();
	~FEMFrameCUSTOM2();
	FEMValue getCUSTOM2(INT32 const _index) const;

};

struct FEMFrameCUSTOM3: public FEMFrameCYCLIC { //

	FEMFrameCUSTOM3();

	~FEMFrameCUSTOM3();

	FEMValue getCUSTOM3(INT32 const _index) const;

};

struct __________;

struct FEMFunctionBASE: public RCObject<FEMFunctionBASE> {

	enum DATA_TYPE {
		FUNCTION_PROXY, //
		FUNCTION_PARAM, //
		FUNCTION_FRAME, //
		FUNCTION_METHOD, //
		FUNCTION_CONCAT, //
		FUNCTION_COMPOSE, //
		FUNCTION_CUSTOM1, // systemfun
		FUNCTION_CUSTOM2, // ?
		FUNCTION_CUSTOM3, // ?
		VALUE_VOID,
		VALUE_TRUE,
		VALUE_FALSE,
		ARRAY_VALUE,
		ARRAY_CYCLIC,
		ARRAY_CONCAT,
		ARRAY_SECTION,
		ARRAY_REVERSE,
		ARRAY_UNIFORM,
		ARRAY_CUSTOM1, // binary as array of boolean
		ARRAY_CUSTOM2, // iam-array as array of value-ref
		ARRAY_CUSTOM3, // iam_array as array of object-ref
		STRING_BYTES,
		STRING_CHARS,
		STRING_VALUE,
		STRING_CONCAT,
		STRING_SECTION,
		STRING_REVERSE,
		STRING_UNIFORM,
		STRING_CUSTOM1, // iam_array as utf16 mit länge im ersten element
		STRING_CUSTOM2, //
		STRING_CUSTOM3,
		BINARY_VALUE,
		BINARY_CONCAT,
		BINARY_SECTION,
		BINARY_REVERSE,
		BINARY_UNIFORM,
		BINARY_CUSTOM1, // array as binary view
		BINARY_CUSTOM2, // iam_array als uint8 ohne kopie
		BINARY_CUSTOM3, // integer als binary[8]
		OBJECT_BASE,
		HANDLER_BASE,
		INTEGER_BASE,
		DECIMAL_BASE,
		DURATION_BASE,
		DATETIME_BASE
	};

	/** Dieses Feld speichert die Typkennung. */
	DATA_TYPE const dataType;

	FEMFunctionBASE(DATA_TYPE const _dataType);
	FEMFunction::TYPE functionType() const;
	INT32 hashBASE() const;
	FEMString scriptBASE() const;
	bool equalsBASE(FEMFunctionBASE const& _that) const;
	FEMValue invokeBASE(FEMFrame const& _frame) const;

};

/** Diese Klasse definiert die Nutzdaten eines FEMProxy. */
struct FEMFunctionPROXY: public FEMFunctionBASE { // DONE

	/** Dieses Feld speichert den Namen des Platzhalters. */
	FEMString proxyName;

	/** Dieses Feld speichert die Funktion, die der Platzhalter aufruft. */
	FEMFunction proxyTarget;

	FEMFunctionPROXY(FEMString const& _proxyName);
	INT32 hashPROXY() const;
	FEMString scriptPROXY() const;
	bool equalsPROXY(FEMFunctionPROXY const& _that) const;
	FEMValue invokePROXY(FEMFrame const& _frame) const;

};

/** Diese Klasse definiert die Nutzdaten eines FEMParam. */
struct FEMFunctionPARAM: public FEMFunctionBASE { // DONE

	/** Dieses Feld speichert den Parameterindex. */
	INT32 paramIndex;

	FEMFunctionPARAM(UINT32 const& _paramIndex);
	INT32 hashPARAM() const;
	FEMString scriptPARAM() const;
	bool equalsPARAM(FEMFunctionPARAM const& _that) const;
	FEMValue invokePARAM(FEMFrame const& _frame) const;

};

/** Diese Klasse implementiert einen Puffer zur Wiederverwendung von FEMParam-Instanzen. */
struct FEMFunctionCACHE {

	/** Dieses Feld speichert die Anzahl der FEMParam-Instanzen. */
	static UINT8 const functionCount = 16;

	/** Dieses Feld speichert die FEMParam-Instanzen. */
	FEMFunctionPTR functionArray[functionCount];

	/** Dieser Konstruktor initialisiert die FEMParam-Instanzen. */
	FEMFunctionCACHE();

};

struct FEMFunctionFRAME: public FEMFunctionBASE {

	FEMFunctionFRAME();
	INT32 hashFRAME() const;
	FEMString scriptFRAME() const;
	bool equalsFRAME(FEMFunctionFRAME const& _that) const;
	FEMValue invokeFRAME(FEMFrame const& _frame) const;

};

struct FEMFunctionMETHOD: public FEMFunctionBASE {

	FEMFunction::METHOD invokeMethod;

	FEMFunctionMETHOD(FEMFunction::METHOD _invokeMethod);
	INT32 hashMETHOD() const;
	FEMString scriptMETHOD() const;
	bool equalsMETHOD(FEMFunctionMETHOD const& _that) const;
	FEMValue invokeMETHOD(FEMFrame const& _frame) const;

};

struct FEMFunctionINVOKE: public FEMFunctionBASE {

	FEMFunction invokeMethod;

	INT32 paramCount;

	FEMFunction paramArray[0];

	FEMFunctionINVOKE(DATA_TYPE _dataType, FEMFunction const& _invokeMethod, FEMFunction const* _paramArray, INT32 _paramCount);
	~FEMFunctionINVOKE();
	INT32 hashINVOKE() const;
	FEMString scriptINVOKE() const;
	bool equalsINVOKE(FEMFunctionINVOKE const& _that) const;

};

struct FEMFunctionCONCAT: public FEMFunctionINVOKE {

	FEMFunctionCONCAT(FEMFunction const& _invokeMethod, FEMFunction const* _paramArray, INT32 _paramCount);

	FEMValue invokeCONCAT(FEMFrame const& _frame) const;

};

struct FEMFunctionCOMPOSE: public FEMFunctionINVOKE {

	FEMFunctionCOMPOSE(FEMFunction const& _invokeMethod, FEMFunction const* _paramArray, INT32 _paramCount);

	FEMValue invokeCOMPOSE(FEMFrame const& _frame) const;

};

struct FEMFunctionCUSTOM1: public FEMFunctionBASE {

	FEMFunctionCUSTOM1();
	~FEMFunctionCUSTOM1();
	INT32 hashCUSTOM1() const;
	FEMString scriptCUSTOM1() const;
	bool equalsCUSTOM1(FEMFunctionCUSTOM1 const& _that) const;
	FEMValue invokeCUSTOM1(FEMFrame const& _frame) const;

};

struct FEMFunctionCUSTOM2: public FEMFunctionBASE {

	FEMFunctionCUSTOM2();
	~FEMFunctionCUSTOM2();
	INT32 hashCUSTOM2() const;
	FEMString scriptCUSTOM2() const;
	bool equalsCUSTOM2(FEMFunctionCUSTOM2 const& _that) const;
	FEMValue invokeCUSTOM2(FEMFrame const& _frame) const;

};

struct FEMFunctionCUSTOM3: public FEMFunctionBASE {

	FEMFunctionCUSTOM3();
	~FEMFunctionCUSTOM3();
	INT32 hashCUSTOM3() const;
	FEMString scriptCUSTOM3() const;
	bool equalsCUSTOM3(FEMFunctionCUSTOM3 const& _that) const;
	FEMValue invokeCUSTOM3(FEMFrame const& _frame) const;

};

struct __________;

struct FEMValueBASE: public FEMFunctionBASE { // DONE

	FEMValueBASE(DATA_TYPE const _dataType);
	FEMValue::TYPE valueType() const;

};

struct __________;

struct FEMValueVOID: public FEMValueBASE { // DONE

	FEMValueVOID();
	FEMString scriptVOID() const;

};

struct FEMValueTRUE: public FEMValueBASE { // DONE

	FEMValueTRUE();
	FEMString scriptTRUE() const;

};

struct FEMValueFALSE: public FEMValueBASE { // DONE

	FEMValueFALSE();
	FEMString scriptFALSE() const;

};

struct __________;

struct FEMArrayBASE: public FEMValueBASE { // DONE

	INT32 arrayLength;

	FEMArrayBASE(DATA_TYPE const _dataType, INT32 const _arrayLength);
	FEMValue getBASE(INT32 const _index) const;
	bool extractBASE(PVOID _context, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMArray sectionBASE(INT32 const _offset, INT32 const _length) const;
	FEMArray compactBASE() const;
	FEMArray reverseBASE() const;
	INT32 hashARRAY() const;
	FEMString scriptARRAY() const;
	bool equalsARRAY(FEMArrayBASE const& _that) const;
	bool extractARRAY(PVOID _target, FEMArray::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;
	FEMArray sectionARRAY(INT32 const _offset, INT32 const _length) const;
	FEMArray compactARRAY() const;
	FEMArray reverseARRAY() const;

};

struct FEMArrayVALUE: public FEMArrayBASE { // DONE

	FEMValue valueArray[0];

	FEMArrayVALUE(INT32 const _arrayLength);
	FEMArrayVALUE(FEMValue const* _valueArray, INT32 const _valueCount);
	~FEMArrayVALUE();
	FEMValue getVALUE(INT32 const _index) const;
	bool extractVALUE(PVOID _target, FEMArray::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;
	FEMArray compactVALUE() const;

};

/** Diese Klasse implementiert die Nutzdaten einer Wertliste, deren Elemente den zugesicherten Parameterwerten eines Stapelraumen entsprechen. */
struct FEMArrayCYCLIC: public FEMArrayBASE { // DONE

	/** Dieses Feld verweist auf die Nutzdaten des Stapelrahmen, dessen Parameterwerte als Elemente der Wertliste mit diesen Nutzdaten genutzt werden.
	 *  Dieser Verweis ist niemals @c null. */
	FEMFramePTR cyclicFrame;

	/** Dieses Feld verweist auf die vorherigen Nutzdaten in der doppelt verketteten und im Kontextobjekt verwalteten Liste.
	 *  Dieser Verweis ist niemals @c null. */
	FEMArrayCYCLIC* cyclicPrev;

	/** Dieses Feld verweist auf die nächsten Nutzdaten in der doppelt verketteten und im Kontextobjekt verwalteten Liste.
	 *  Dieser Verweis ist niemals @c null. */
	FEMArrayCYCLIC* cyclicNext;

	/** Dieses Feld verweist auf die Nutzdaten des Kontextobjekts, in welchem der Lebenslauf dieser Nutzdaten verwaltet wird.
	 *  Dieser Verweis ist niemals @c null. */
	FEMContextBASE const* cyclicContext;

	/** Dieser Kontruktor initialisiert den gezählten Verweis auf den Stapelrahmen.
	 * Als Kontextobjekt wird das des Stapelrahmen verwendet.
	 * Die Länge der Wertliste entspricht der Anzahl der zugesicherten Parameter des Stapelrahmen.
	 * Diese Nutzdaten werden in die doppelt verketteten Liste im Kontextobjekt eingefügt.
	 * Der Aufruf darf nur im Rahmen des kritischen Abschnitts des Kontextobjekts erfolgen. */
	FEMArrayCYCLIC(FEMFrameCYCLIC const& _cyclicFrame);

	/** Dieser Kontruktor initialisiert den gezählten Verweis auf das Kontextobjekt.
	 *  Die Länge der Wertliste ist @c 0.
	 *  Diese Nutzdaten werden als Wurzel de doppelt verketteten Liste im Kontextobjekt initialisiert und nutzen daher nicht den kritischen Abschnitt im Kontextobjekt. */
	FEMArrayCYCLIC(FEMContextBASE const& _ownerContext);

	/** Dieser Destruktor löst via @c deleteCYCLIC() die Verbindung zum Stapelrahmen sowie zum Kontextobjekt. */
	~FEMArrayCYCLIC();

	FEMValue getCYCLIC(INT32 const _index) const;

	/** Diese Methode löst die Verbindung zum Stapelrahmen sowie zur doppelt verketteten Liste im Kontextobjekt.
	 *  Der Aufruf darf zwar beliebig oft jedoch nur im Rahmen des kritischen Abschnitts des Kontextobjekts erfolgen. */
	void deleteCYCLIC();

};

struct FEMArrayCONCAT: public FEMArrayBASE { // DONE

	FEMArray array1;

	FEMArray array2;

	FEMArrayCONCAT(INT32 const _arrayLength, FEMArray const& _array1, FEMArray const& _array2);
	FEMValue getCONCAT(INT32 const _index) const;
	bool extractCONCAT(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMArray sectionCONCAT(INT32 _offset, INT32 _length) const;

};

struct FEMArraySECTION: public FEMArrayBASE { // DONE

	FEMArray array;

	INT32 offset;

	FEMArraySECTION(FEMArray const& _array, INT32 const _offset, INT32 const _length);
	FEMValue getSECTION(INT32 const _index) const;
	bool extractSECTION(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMArray sectionSECTION(INT32 _offset, INT32 _length) const;

};

struct FEMArrayREVERSE: public FEMArrayBASE { // DONE

	FEMArray array;

	FEMArrayREVERSE(FEMArray const& _array);
	FEMValue getREVERSE(INT32 const _index) const;
	bool extractREVERSE(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMArray sectionREVERSE(INT32 _offset, INT32 _length) const;
	FEMArray reverseREVERSE() const;

};

struct FEMArrayUNIFORM: public FEMArrayBASE { // DONE

	FEMValue value;

	FEMArrayUNIFORM(FEMValue const& _value, INT32 const _length);
	FEMValue getUNIFORM(INT32 const _index) const;
	bool extractUNIFORM(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMArray sectionUNIFORM(INT32 _offset, INT32 _length) const;
	FEMArray compactUNIFORM() const;
	FEMArray reverseUNIFORM() const;

};

struct FEMArrayCUSTOM1: public FEMArrayBASE { // TODO

	FEMArrayCUSTOM1();
	~FEMArrayCUSTOM1();
	FEMValue getCUSTOM1(INT32 const _index) const;

};

struct FEMArrayCUSTOM2: public FEMArrayBASE { //

	FEMArrayCUSTOM2();
	~FEMArrayCUSTOM2();
	FEMValue getCUSTOM2(INT32 const _index) const;

};

struct FEMArrayCUSTOM3: public FEMArrayBASE { //

	FEMArrayCUSTOM3();
	~FEMArrayCUSTOM3();
	FEMValue getCUSTOM3(INT32 const _index) const;

};

struct __________;

struct FEMStringBASE: public FEMValueBASE { //

	INT32 stringLength;

	FEMStringBASE(DATA_TYPE const _dataType, INT32 const _stringLength);
	UINT32 getBASE(INT32 const _index) const;
	bool extractBASE(PVOID _context, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMString sectionBASE(INT32 const _offset, INT32 const _length) const;
	FEMString reverseBASE() const;
	FEMString compactBASE() const;
	FEMString scriptSTRING() const;
	INT32 hashSTRING() const;
	bool equalsSTRING(FEMStringBASE const& _that) const;
	bool extractSTRING(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;
	FEMString sectionSTRING(INT32 const _offset, INT32 const _length) const;
	FEMString reverseSTRING() const;
	FEMString compactSTRING() const;

};

struct FEMStringBYTES: public FEMStringBASE {

	UINT8 itemArray[0];

	FEMStringBYTES(INT32 const _stringLength, UINT8 const* _itemArray, INT32 const _itemCount);
	UINT32 getBYTES(INT32 _index) const;
	bool extractBYTES(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;

};

struct FEMStringCHARS: public FEMStringBASE {

	UINT16 itemArray[0];

	FEMStringCHARS(INT32 const _stringLength, UINT16 const* _itemArray, INT32 const _itemCount);
	UINT32 getCHARS(INT32 _index) const;
	bool extractCHARS(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;

};

struct FEMStringVALUE: public FEMStringBASE { // OKAY

	UINT32 itemArray[0];

	FEMStringVALUE(INT32 const _length);
	FEMStringVALUE(UINT32 const* _itemArray, INT32 const _itemCount);
	UINT32 getVALUE(INT32 const _index) const;
	bool extractVALUE(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;
	FEMString compactVALUE() const;

};

struct FEMStringCONCAT: public FEMStringBASE { // OKAY

	FEMString string1;

	FEMString string2;

	FEMStringCONCAT(INT32 const _stringLength, FEMString const& _string1, FEMString const& _string2);
	UINT32 getCONCAT(INT32 const _index) const;
	bool extractCONCAT(PVOID _context, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMString sectionCONCAT(INT32 const _offset, INT32 const _length) const;

};

struct FEMStringSECTION: public FEMStringBASE { // OKAY

	FEMString string;

	UINT32 offset;

	FEMStringSECTION(FEMString const& _string, INT32 const _offset, INT32 const _length);
	UINT32 getSECTION(INT32 const _index) const;
	bool extractSECTION(PVOID _context, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMString sectionSECTION(INT32 const _offset, INT32 const _length) const;

};

struct FEMStringREVERSE: public FEMStringBASE { // OKAY

	FEMString string;

	FEMStringREVERSE(FEMString const& _string);
	UINT32 getREVERSE(INT32 const _index) const;
	bool extractREVERSE(PVOID _context, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMString sectionREVERSE(INT32 const _offset, INT32 const _length) const;
	FEMString reverseREVERSE() const;

};

struct FEMStringUNIFORM: public FEMStringBASE { // OKAY

	UINT32 value;

	FEMStringUNIFORM(UINT32 const& _value, INT32 const _stringLength);
	UINT32 getUNIFORM(INT32 const _index) const;
	bool extractUNIFORM(PVOID _context, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMString sectionUNIFORM(INT32 const _offset, INT32 const _length) const;
	FEMString reverseUNIFORM() const;
	FEMString compactUNIFORM() const;

};

struct FEMStringCUSTOM1: public FEMStringBASE { // TODO

	FEMStringCUSTOM1();
	UINT32 getCUSTOM1(INT32 const _index) const;

};

struct FEMStringCUSTOM2: public FEMStringBASE { //

	FEMStringCUSTOM2();
	UINT32 getCUSTOM2(INT32 const _index) const;

};

struct FEMStringCUSTOM3: public FEMStringBASE { //

	FEMStringCUSTOM3();
	UINT32 getCUSTOM3(INT32 const _index) const;

};

struct __________;

struct FEMBinaryBASE: public FEMValueBASE {

	INT32 binaryLength;

	FEMBinaryBASE(DATA_TYPE const _dataType, INT32 const _binaryLength);
	UINT32 getBASE(INT32 const _index) const;
	bool extractBASE(PVOID _target, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMBinary sectionBASE(INT32 const _offset, INT32 const _length) const;
	FEMBinary compactBASE() const;
	FEMBinary reverseBASE() const;

	INT32 hashBINARY() const;
	FEMString scriptBINARY() const;
	bool equalsBINARY(FEMBinaryBASE const& _that) const;
	bool extractBINARY(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;
	FEMBinary sectionBINARY(INT32 const _offset, INT32 const _length) const;

	FEMBinary compactBINARY() const;
	FEMBinary reverseBINARY() const;

};

struct FEMBinaryVALUE: public FEMBinaryBASE { // OKAY

	UINT32 itemArray[0];

	FEMBinaryVALUE(INT32 const _length);
	FEMBinaryVALUE(UINT32 const* _itemArray, INT32 const _itemCount);
	UINT32 getVALUE(INT32 const _index) const;
	bool extractVALUE(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;
	FEMBinary compactVALUE() const;

};

struct FEMBinaryCONCAT: public FEMBinaryBASE { // OKAY

	FEMBinary binary1;

	FEMBinary binary2;

	FEMBinaryCONCAT(INT32 const _binaryLength, FEMBinary const& _binary1, FEMBinary const& _binary2);
	UINT32 getCONCAT(INT32 const _index) const;
	bool extractCONCAT(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMBinary sectionCONCAT(INT32 const _offset, INT32 const _length) const;

};

struct FEMBinarySECTION: public FEMBinaryBASE { // OKAY

	FEMBinary binary;

	UINT32 offset;

	FEMBinarySECTION(FEMBinary const& _binary, INT32 const _offset, INT32 const _length);
	UINT32 getSECTION(INT32 const _index) const;
	bool extractSECTION(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMBinary sectionSECTION(INT32 const _offset, INT32 const _length) const;

};

struct FEMBinaryREVERSE: public FEMBinaryBASE { // OKAY

	FEMBinary binary;

	FEMBinaryREVERSE(FEMBinary const& _binary);
	UINT32 getREVERSE(INT32 const _index) const;
	bool extractREVERSE(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMBinary sectionREVERSE(INT32 const _offset, INT32 const _length) const;
	FEMBinary reverseREVERSE() const;

};

struct FEMBinaryUNIFORM: public FEMBinaryBASE { // OKAY

	UINT32 value;

	FEMBinaryUNIFORM(UINT32 const& _value, INT32 const _binaryLength);
	UINT32 getUNIFORM(INT32 const _index) const;
	bool extractUNIFORM(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMBinary sectionUNIFORM(INT32 const _offset, INT32 const _length) const;
	FEMBinary reverseUNIFORM() const;
	FEMBinary compactUNIFORM() const;

};

struct FEMBinaryCUSTOM1: public FEMBinaryBASE { // TODO

	FEMBinaryCUSTOM1();
	UINT32 getCUSTOM1(INT32 const _index) const;

};

struct FEMBinaryCUSTOM2: public FEMBinaryBASE { //

	FEMBinaryCUSTOM2();
	UINT32 getCUSTOM2(INT32 const _index) const;

};

struct FEMBinaryCUSTOM3: public FEMBinaryBASE { //

	FEMBinaryCUSTOM3();
	UINT32 getCUSTOM3(INT32 const _index) const;

};

struct __________;

struct FEMObjectBASE: public FEMValueBASE {

	INT32 refValue;

	UINT16 typeValue;

	UINT16 ownerValue;

	FEMObjectBASE(INT32 const _refValue, UINT16 const _typeValue, UINT16 const _ownerValue);
	INT32 hashOBJECT() const;
	FEMString scriptOBJECT() const;
	bool equalsOBJECT(FEMObjectBASE const& _that) const;

};

struct __________;

struct FEMHandlerBASE: public FEMValueBASE {

	FEMFunction handlerValue;

	FEMHandlerBASE(FEMFunction const& _handlerValue);
	INT32 hashHANDLER() const;
	FEMString scriptHANDLER() const;
	bool equalsHANDLER(FEMHandlerBASE const& _that) const;

};

struct __________;

struct FEMIntegerBASE: public FEMValueBASE {

	INT64 value;

	FEMIntegerBASE(INT64 const& _value);
	INT32 hashINTEGER() const;
	FEMString scriptINTEGER() const;
	bool equalsINTEGER(FEMIntegerBASE const& _that) const;

};

struct __________;

struct FEMDecimalBASE: public FEMValueBASE {

	double value;

	FEMDecimalBASE(double const& _value);
	INT32 hashDECIMAL() const;
	FEMString scriptDECIMAL() const;
	bool equalsDECIMAL(FEMDecimalBASE const& _that) const;

};

struct __________;

struct FEMDatetimeBASE: public FEMValueBASE {

	INT32 valueL;

	INT32 valueH;

	FEMDatetimeBASE(INT32 const _valueL, INT32 const _valueH);
	INT32 hashDATETIME() const;
	FEMString scriptDATETIME() const;
	bool equalsDATETIME(FEMDatetimeBASE const& _that) const;

};

struct __________;

struct FEMDurationBASE: public FEMValueBASE {

	INT32 valueL;

	INT32 valueH;

	FEMDurationBASE(INT32 const valueL, INT32 const valueH);
	INT32 hashDURATION() const;
	FEMString scriptDURATION() const;
	bool equalsDURATION(FEMDurationBASE const& _that) const;

};

struct I_____I;

struct FEMContextBASE: public RCObject<FEMContextBASE> {

	CSObject cyclicSection;

	/** Dieses Feld speichert den Kopf der doppelt verketteten Liste, in welcher die zyklisch referenzierten Nutzdaten  von Wertlisten verwaltet werden. */
	FEMArrayCYCLIC cyclicList;

	FEMContextBASE();
	~FEMContextBASE();
	void deleteCYCLIC();

};

struct __________;

struct FEM_CAST {
	FEMValue toValue[0];
	FEMValueBASE toValueBASE[0];
	FEMValueVOID toValueVOID[0];
	FEMValueTRUE toValueTRUE[0];
	FEMValueFALSE toValueFALSE[0];
	FEMProxy toProxy[0];
	FEMParam toParam[0];
	FEMFunction toFunction[0];
	FEMFunctionOBJ toFunctionOBJ[0];
	FEMFunctionPTR toFunctionPTR[0];
	FEMFunctionBASE toFunctionBASE[0];
	FEMFunctionPROXY toFunctionPROXY[0];
	FEMFunctionPARAM toFunctionPARAM[0];
	FEMFunctionFRAME toFunctionFRAME[0];
	FEMFunctionMETHOD toFunctionMETHOD[0];
	FEMFunctionCONCAT toFunctionCONCAT[0];
	FEMFunctionCOMPOSE toFunctionCOMPOSE[0];
	FEMFunctionCUSTOM1 toFunctionCUSTOM1[0];
	FEMFunctionCUSTOM2 toFunctionCUSTOM2[0];
	FEMFunctionCUSTOM3 toFunctionCUSTOM3[0];
	FEMVoid toVoid[0];
	FEMArray toArray[0];
	FEMArrayBASE toArrayBASE[0];
	FEMArrayVALUE toArrayVALUE[0];
	FEMArrayCONCAT toArrayCONCAT[0];
	FEMArrayCYCLIC toArrayCYCLIC[0];
	FEMArraySECTION toArraySECTION[0];
	FEMArrayREVERSE toArrayREVERSE[0];
	FEMArrayUNIFORM toArrayUNIFORM[0];
	FEMArrayCUSTOM1 toArrayCUSTOM1[0];
	FEMArrayCUSTOM2 toArrayCUSTOM2[0];
	FEMArrayCUSTOM3 toArrayCUSTOM3[0];
	FEMString toString[0];
	FEMStringBASE toStringBASE[0];
	FEMStringBYTES toStringBYTES[0];
	FEMStringCHARS toStringCHARS[0];
	FEMStringVALUE toStringVALUE[0];
	FEMStringCONCAT toStringCONCAT[0];
	FEMStringSECTION toStringSECTION[0];
	FEMStringREVERSE toStringREVERSE[0];
	FEMStringUNIFORM toStringUNIFORM[0];
	FEMStringCUSTOM1 toStringCUSTOM1[0];
	FEMStringCUSTOM2 toStringCUSTOM2[0];
	FEMStringCUSTOM3 toStringCUSTOM3[0];
	FEMBinary toBinary[0];
	FEMBinaryBASE toBinaryBASE[0];
	FEMBinaryVALUE toBinaryVALUE[0];
	FEMBinaryCONCAT toBinaryCONCAT[0];
	FEMBinarySECTION toBinarySECTION[0];
	FEMBinaryREVERSE toBinaryREVERSE[0];
	FEMBinaryUNIFORM toBinaryUNIFORM[0];
	FEMBinaryCUSTOM1 toBinaryCUSTOM1[0];
	FEMBinaryCUSTOM2 toBinaryCUSTOM2[0];
	FEMBinaryCUSTOM3 toBinaryCUSTOM3[0];
	FEMObject toObject[0];
	FEMObjectBASE toObjectBASE[0];
	FEMHandler toHandler[0];
	FEMHandlerBASE toHandlerBASE[0];
	FEMInteger toInteger[0];
	FEMIntegerBASE toIntegerBASE[0];
	FEMDecimal toDecimal[0];
	FEMDecimalBASE toDecimalBASE[0];
	FEMBoolean toBoolean[0];
	FEMDatetime toDatetime[0];
	FEMDatetimeBASE toDatetimeBASE[0];
	FEMDuration toDuration[0];
	FEMDurationBASE toDurationBASE[0];
	FEMContext toContext[0];
	FEMContextOBJ toContextOBJ[0];
	FEMContextPTR toContextPTR[0];
	FEMContextBASE toContextBASE[0];
	FEMFrame toFrame[0];
	FEMFrameOBJ toFrameOBJ[0];
	FEMFramePTR toFramePTR[0];
	FEMFrameBASE toFrameBASE[0];
	FEMFrameARRAY toFrameARRAY[0];
	FEMFrameCYCLIC toFrameCYCLIC[0];
	FEMFrameINVOKE toFrameINVOKE[0];
	FEMFrameCUSTOM1 toFrameCUSTOM1[0];
	FEMFrameCUSTOM2 toFrameCUSTOM2[0];
	FEMFrameCUSTOM3 toFrameCUSTOM3[0];
	FEMFrameCONTEXT toFrameCONTEXT[0];
	FEMFramePARAM toFramePARAM[0];
	INT8S toINT8S[0];
	INT16S toINT16S[0];
	INT32S toINT32S[0];
	INT64S toINT64S[0];
	FEM_CAST* toPointerAndCastItsTarget;
	FEM_CAST()
			: toPointerAndCastItsTarget(0) {
	}
};

inline FEM_CAST* femCast(PCVOID _this) {
	return ((FEM_CAST*) _this);
}

void fem_main() {
	using namespace std;

	FEMContext con;
	FEMFrame frm = con.newFrame();

	cout << frm.size() << '\n';
	cout << frm.withParams(&FEMVoid::INSTANCE, 1).params().get(0).hash() << '\n';

#define PRINTSIZE(X) cout << #X << "  " << sizeof(X) << '\n';

	PRINTSIZE(FEM_CAST)

	PRINTSIZE(FEMFrame)
	PRINTSIZE(FEMFrameOBJ)
	PRINTSIZE(FEMFramePTR)
	PRINTSIZE(FEMFrameBASE)
	PRINTSIZE(FEMFrameARRAY)
	PRINTSIZE(FEMFrameCYCLIC)
	PRINTSIZE(FEMFrameINVOKE)
	PRINTSIZE(FEMFrameCONTEXT)
	PRINTSIZE(FEMFrameCUSTOM1)
	PRINTSIZE(FEMFrameCUSTOM2)
	PRINTSIZE(FEMFrameCUSTOM3)

	PRINTSIZE(FEMFunction)
	PRINTSIZE(FEMFunctionOBJ)
	PRINTSIZE(FEMFunctionPTR)
	PRINTSIZE(FEMFunctionBASE)
	PRINTSIZE(FEMFunctionPROXY)
	PRINTSIZE(FEMFunctionPARAM)
	PRINTSIZE(FEMFunctionCACHE)
	PRINTSIZE(FEMFunctionFRAME)
	PRINTSIZE(FEMFunctionMETHOD)
	PRINTSIZE(FEMFunctionINVOKE)
	PRINTSIZE(FEMFunctionCONCAT)
	PRINTSIZE(FEMFunctionCOMPOSE)
	PRINTSIZE(FEMFunctionCUSTOM1)
	PRINTSIZE(FEMFunctionCUSTOM2)
	PRINTSIZE(FEMFunctionCUSTOM3)

	FEM_CAST test;

	cout << "cast test\n";
	cout << (INT32(&test.toPointerAndCastItsTarget) - INT32(&test)) << '\n';
	cout << sizeof(FEM_CAST) << '\n';
	cout.flush();
}

struct __________;

static FEMContextBASE* _FEMContext_EMPTY_ = new FEMContextBASE();

static FEMFramePTR _FEMFrame_EMPTY_ = FEMFramePTR(femCast(new FEMFrameCYCLIC(*_FEMContext_EMPTY_))->toFrameOBJ);

FEMContext const FEMContext::EMPTY = FEMContext(*femCast(&_FEMContext_EMPTY_)->toContext);

struct __________;

FEMFrame::FEMFrame() // DONE
		: _object_(_FEMFrame_EMPTY_) {
}

FEMValue FEMFrame::get(INT32 const _index) const { // DONE
	FEMFrameBASE* _this = femCast(this)->toPointerAndCastItsTarget->toFrameBASE;
	INT32 _thisIndex = _index;
	while (true) {
		INT32 _nextIndex = _thisIndex - _this->frameSize;
		if (_nextIndex < 0) return _this->getBASE(_thisIndex);
		_this = femCast(&_this->parentFrame)->toPointerAndCastItsTarget->toFrameBASE;
		_thisIndex = _nextIndex;
		FEMException::checkState(_this);
	}
	return FEMVoid::INSTANCE;
}

INT32 FEMFrame::size() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFrameBASE->frameSize;
}

FEMArray FEMFrame::params() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFrameBASE->paramsBASE();
}

FEMFrame const& FEMFrame::parent() const { // DONE
	FEMFrameBASE* _data = femCast(this)->toPointerAndCastItsTarget->toFrameBASE;
	FEMFrame* _parentFrame = femCast(&_data->parentFrame)->toFrame;
	if (!femCast(_parentFrame)->toPointerAndCastItsTarget) return *this;
	return *_parentFrame;
}

FEMContext const& FEMFrame::context() const { // DONE
	FEMFrameBASE* _this = femCast(this)->toPointerAndCastItsTarget->toFrameBASE;
	return *femCast(&_this->ownerContext)->toContext;
}

FEMFrame FEMFrame::newFrame(FEMArray const& _paramArray) const { // DONE
	FEMFrameARRAY* _result = new FEMFrameARRAY(_object_, _paramArray);
	return FEMFrame(*femCast(&_result)->toFrame);
}

FEMFrame FEMFrame::newFrame(FEMValue::ARRAY const& _paramArray) const { // DONE
	return newFrame(_paramArray.data(), _paramArray.length());
}

FEMFrame FEMFrame::newFrame(FEMFunction::ARRAY const& _paramArray) const { // DONE
	return newFrame(_paramArray.data(), _paramArray.length());
}

FEMFrame FEMFrame::newFrame(FEMValue const* _paramArray, INT32 const _paramCount) const { // DONE
	return newFrame(FEMArray::from(_paramArray, _paramCount));
}

FEMFrame FEMFrame::newFrame(FEMFunction const* _paramArray, INT32 const _paramCount) const { // DONE
	FEMException::checkNull(_paramArray);
	FEMException::checkCount(_paramCount);
	FEMFrameINVOKE* _result = new (new INT8[sizeof(FEMFrameINVOKE) + _paramCount * sizeof(FEMFramePARAM)]) FEMFrameINVOKE(_object_, _paramArray, _paramCount);
	return FEMFrame(*femCast(&_result)->toFrame);
}

FEMFrame FEMFrame::withParams(FEMArray const& _params) const { // DONE
	return parent().newFrame(_params);
}

FEMFrame FEMFrame::withParams(FEMValue::ARRAY const& _params) const { // DONE
	return parent().newFrame(_params);
}

FEMFrame FEMFrame::withParams(FEMFunction::ARRAY const& _params) const { // DONE
	return parent().newFrame(_params);
}

FEMFrame FEMFrame::withParams(FEMValue const* _paramArray, INT32 const _paramCount) const { // DONE
	return parent().newFrame(_paramArray, _paramCount);
}

FEMFrame FEMFrame::withParams(FEMFunction const* _paramArray, INT32 const _paramCount) const { // DONE
	return parent().newFrame(_paramArray, _paramCount);
}

struct __________;

FEMFrameOBJ::~OBJECT() { // DONE
	switch (femCast(this)->toFrameBASE->dataType) {
		case FEMFrameBASE::FRAME_ARRAY:
			femCast(this)->toFrameARRAY->~FEMFrameARRAY();
			break;
		case FEMFrameBASE::FRAME_CYCLIC:
			femCast(this)->toFrameCYCLIC->~FEMFrameCYCLIC();
			break;
		case FEMFrameBASE::FRAME_INVOKE:
			femCast(this)->toFrameINVOKE->~FEMFrameINVOKE();
			break;
		case FEMFrameBASE::FRAME_CONTEXT:
			femCast(this)->toFrameCONTEXT->~FEMFrameCONTEXT();
			break;
		case FEMFrameBASE::FRAME_CUSTOM1:
			femCast(this)->toFrameCUSTOM1->~FEMFrameCUSTOM1();
			break;
		case FEMFrameBASE::FRAME_CUSTOM2:
			femCast(this)->toFrameCUSTOM2->~FEMFrameCUSTOM2();
			break;
		case FEMFrameBASE::FRAME_CUSTOM3:
			femCast(this)->toFrameCUSTOM3->~FEMFrameCUSTOM3();
			break;
	}
}

struct __________;

inline FEMFrameBASE::FEMFrameBASE(FRAME_TYPE const _dataType, INT32 const _frameSize, FEMFramePTR const& _parentFrame) // DONE
		: dataType(_dataType), frameSize(_frameSize), parentFrame(_parentFrame), ownerContext(femCast(&_parentFrame)->toPointerAndCastItsTarget->toFrameBASE->ownerContext) {
}

inline FEMFrameBASE::FEMFrameBASE(FRAME_TYPE const _dataType, INT32 const _frameSize, FEMContextBASE const& _ownerContext) // DONE
		: dataType(_dataType), frameSize(_frameSize), parentFrame(), ownerContext(&_ownerContext) {
}

inline FEMValue FEMFrameBASE::getBASE(INT32 const _index) const { // DONE
	switch (dataType) {
		case FRAME_ARRAY:
			return femCast(this)->toFrameARRAY->getARRAY(_index);
		case FRAME_INVOKE:
			return femCast(this)->toFrameINVOKE->getINVOKE(_index);
		case FRAME_CONTEXT:
			return femCast(this)->toFrameCONTEXT->getCONTEXT(_index);
		case FRAME_CUSTOM1:
			return femCast(this)->toFrameCUSTOM1->getCUSTOM1(_index);
		case FRAME_CUSTOM2:
			return femCast(this)->toFrameCUSTOM2->getCUSTOM2(_index);
		case FRAME_CUSTOM3:
			return femCast(this)->toFrameCUSTOM3->getCUSTOM3(_index);
		case FRAME_CYCLIC:
			;
	}
	throw FEMException();
}

inline FEMArray FEMFrameBASE::paramsBASE() const { // DONE
	switch (dataType) {
		case FRAME_ARRAY:
			return femCast(this)->toFrameARRAY->paramsARRAY();
		case FRAME_CONTEXT:
			return femCast(this)->toFrameCONTEXT->paramsCONTEXT();
		case FRAME_CYCLIC:
		case FRAME_INVOKE:
		case FRAME_CUSTOM1:
		case FRAME_CUSTOM2:
		case FRAME_CUSTOM3:
			return femCast(this)->toFrameCYCLIC->paramsCYCLIC();
	}
	throw FEMException();
}

struct __________;

inline FEMFrameARRAY::FEMFrameARRAY(FEMFramePTR const& _parentFrame, FEMArray const& _paramArray) // DONE
		: FEMFrameBASE(FRAME_ARRAY, _paramArray.length(), _parentFrame), paramArray(_paramArray) {
}

inline FEMValue FEMFrameARRAY::getARRAY(INT32 const _index) const { // DONE
	return paramArray.get(_index);
}

inline FEMArray FEMFrameARRAY::paramsARRAY() const { // DONE
	return paramArray;
}

struct __________;

inline FEMFramePARAM::FEMFramePARAM(FEMFunction const& _paramFunction) // DONE
		: paramValue(), paramFunction(_paramFunction) {
}

struct __________;

inline FEMFrameCYCLIC::FEMFrameCYCLIC(FEMContextBASE const& _ownerContext)
		: FEMFrameBASE(FRAME_CYCLIC, 0, _ownerContext), cyclicArray(0) {
}

inline FEMFrameCYCLIC::FEMFrameCYCLIC(FRAME_TYPE const _dataType, INT32 const _frameSize, FEMFramePTR const& _parentFrame) // DONE
		: FEMFrameBASE(_dataType, _frameSize, _parentFrame), cyclicArray(0) {
}

inline FEMArray FEMFrameCYCLIC::paramsCYCLIC() const { // DONE
	CSGuard _cleanupGuard(femCast(ownerContext)->toContextBASE->cyclicSection);
	if (!cyclicArray) new FEMArrayCYCLIC(*this);
	return *femCast(&cyclicArray)->toArray;
}

struct __________;

inline FEMFrameINVOKE::FEMFrameINVOKE(FEMFramePTR const& _parentFrame, FEMFunction const* _paramArray, INT32 const _paramCount) // DONE
		: FEMFrameCYCLIC(FRAME_INVOKE, _paramCount, _parentFrame) {
	setupArray<FEMFunction, FEMFramePARAM>(_paramArray, paramArray, _paramCount);
}

inline FEMFrameINVOKE::~FEMFrameINVOKE() { // DONE
	resetArray<FEMFramePARAM>(paramArray, frameSize);
}

FEMValue FEMFrameINVOKE::getINVOKE(INT32 const _index) const { // DONE
	CSGuard _cleanupGuard(femCast(ownerContext)->toContextBASE->cyclicSection);
	FEM_CAST* _cacheItem = femCast(paramArray + _index);
	if (_cacheItem->toPointerAndCastItsTarget) return *_cacheItem->toValue;
	FEMValue _cacheValue = _cacheItem->toFramePARAM->paramFunction.functionInvoke(*femCast(&parentFrame)->toFrame);
	*_cacheItem->toValue = _cacheValue;
	return _cacheValue;
}

struct __________;

inline FEMFrameCUSTOM1::FEMFrameCUSTOM1()
		: FEMFrameCYCLIC(FRAME_CUSTOM1, 0, _FEMFrame_EMPTY_) {
}

inline FEMFrameCUSTOM1::~FEMFrameCUSTOM1() {
}

inline FEMValue FEMFrameCUSTOM1::getCUSTOM1(INT32 const _index) const {
	throw FEMException();
}

struct __________;

inline FEMFrameCUSTOM2::FEMFrameCUSTOM2() //
		: FEMFrameCYCLIC(FRAME_CUSTOM2, 0, _FEMFrame_EMPTY_) {
}

inline FEMFrameCUSTOM2::~FEMFrameCUSTOM2() { //
}

inline FEMValue FEMFrameCUSTOM2::getCUSTOM2(INT32 const _index) const { //
	throw FEMException();
}

struct __________;

inline FEMFrameCUSTOM3::FEMFrameCUSTOM3() //
		: FEMFrameCYCLIC(FRAME_CUSTOM3, 0, _FEMFrame_EMPTY_) {
}

inline FEMFrameCUSTOM3::~FEMFrameCUSTOM3() { //
}

inline FEMValue FEMFrameCUSTOM3::getCUSTOM3(INT32 const _index) const { //
	throw FEMException();
}

struct __________;

inline FEMFrameCONTEXT::FEMFrameCONTEXT(FEMContext const& _parentContext) // DONE
		: FEMFrameBASE(FRAME_CONTEXT, 0, *femCast(&_parentContext)->toPointerAndCastItsTarget->toContextBASE), parentContext(_parentContext) {
}

inline FEMValue FEMFrameCONTEXT::getCONTEXT(INT32 const _index) const { // DONE
	throw FEMException();
}

inline FEMArray FEMFrameCONTEXT::paramsCONTEXT() const { // DONE
	return FEMArray::EMPTY;
}

struct __________;

FEMFunction FEMFunction::from(METHOD _method) { // DONE
	FEMFunctionMETHOD* _result = new FEMFunctionMETHOD(_method);
	return FEMFunction(*femCast(&_result)->toFunction);
}

FEMFunction::FEMFunction()
		: FEMFunction(FEMVoid::INSTANCE) {
}

FEMFunction::TYPE FEMFunction::functionType() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFunctionBASE->functionType();
}

bool FEMFunction::functionIsValue() const { // DONE
	return functionType() == FUNCTION_TYPE_VALUE;
}

bool FEMFunction::functionIsProxy() const { // DONE
	return functionType() == FUNCTION_TYPE_PROXY;
}

bool FEMFunction::functionIsParam() const { // DONE
	return functionType() == FUNCTION_TYPE_PARAM;
}

bool FEMFunction::functionIsOther() const { // DONE
	return functionType() == FUNCTION_TYPE_OTHER;
}

FEMValue const& FEMFunction::functionAsValue() const { // DONE
	return *femCast(this)->toValue;
}

FEMProxy const& FEMFunction::functionAsProxy() const { // DONE
	return *femCast(this)->toProxy;
}

FEMParam const& FEMFunction::functionAsParam() const { // DONE
	return *femCast(this)->toParam;
}

FEMHandler FEMFunction::functionToHandler() const { // DONE
	return FEMHandler::from(*this);
}

FEMFunction FEMFunction::functionConcat(ARRAY const& _paramArray) const { // DONE
	return functionConcat(_paramArray.data(), _paramArray.length());
}

FEMFunction FEMFunction::functionConcat(FEMFunction const* _paramArray, INT32 _paramCount) const { // DONE
	FEMException::checkNull(_paramArray);
	FEMException::checkCount(_paramCount);
	FEMFunctionCONCAT* _result = new (new UINT8[sizeof(FEMFunctionCONCAT) + _paramCount * sizeof(FEMFunction)]) FEMFunctionCONCAT(*this, _paramArray, _paramCount);
	return FEMFunction(*femCast(&_result)->toFunction);
}

FEMFunction FEMFunction::functionCompose(ARRAY const& _paramArray) const { // DONE
	return functionCompose(_paramArray.data(), _paramArray.length());
}

FEMFunction FEMFunction::functionCompose(FEMFunction const* _paramArray, INT32 _paramCount) const { // DONE
	FEMException::checkNull(_paramArray);
	FEMException::checkCount(_paramCount);
	FEMFunctionCOMPOSE* _result = new (new UINT8[sizeof(FEMFunctionCOMPOSE) + _paramCount * sizeof(FEMFunction)]) FEMFunctionCOMPOSE(*this, _paramArray, _paramCount);
	return FEMFunction(*femCast(&_result)->toFunction);
}

FEMValue FEMFunction::functionInvoke(FEMFrame const& _frame) const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFunctionBASE->invokeBASE(_frame);
}

INT32 FEMFunction::hash() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFunctionBASE->hashBASE();
}

FEMFunction FEMFunction::clone() const { // DONE
	return *this;
}

bool FEMFunction::equals(FEMFunction const& _that) const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFunctionBASE->equalsBASE(*femCast(&_that)->toPointerAndCastItsTarget->toFunctionBASE);
}

FEMString FEMFunction::toScript() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFunctionBASE->scriptBASE();
}

struct __________;

FEMFunctionOBJ::~OBJECT() { // DONE
	switch (femCast(this)->toFunctionBASE->dataType) {
		case FEMFunctionBASE::FUNCTION_PROXY:
			femCast(this)->toFunctionPROXY->~FEMFunctionPROXY();
			break;
		case FEMFunctionBASE::FUNCTION_PARAM:
			femCast(this)->toFunctionPARAM->~FEMFunctionPARAM();
			break;
		case FEMFunctionBASE::FUNCTION_FRAME:
			femCast(this)->toFunctionFRAME->~FEMFunctionFRAME();
			break;
		case FEMFunctionBASE::FUNCTION_METHOD:
			femCast(this)->toFunctionMETHOD->~FEMFunctionMETHOD();
			break;
		case FEMFunctionBASE::FUNCTION_CONCAT:
			femCast(this)->toFunctionCONCAT->~FEMFunctionCONCAT();
			break;
		case FEMFunctionBASE::FUNCTION_COMPOSE:
			femCast(this)->toFunctionCOMPOSE->~FEMFunctionCOMPOSE();
			break;
		case FEMFunctionBASE::FUNCTION_CUSTOM1:
			femCast(this)->toFunctionCUSTOM1->~FEMFunctionCUSTOM1();
			break;
		case FEMFunctionBASE::FUNCTION_CUSTOM2:
			femCast(this)->toFunctionCUSTOM2->~FEMFunctionCUSTOM2();
			break;
		case FEMFunctionBASE::FUNCTION_CUSTOM3:
			femCast(this)->toFunctionCUSTOM3->~FEMFunctionCUSTOM3();
			break;
		case FEMFunctionBASE::VALUE_VOID:
			femCast(this)->toValueVOID->~FEMValueVOID();
			break;
		case FEMFunctionBASE::VALUE_TRUE:
			femCast(this)->toValueTRUE->~FEMValueTRUE();
			break;
		case FEMFunctionBASE::VALUE_FALSE:
			femCast(this)->toValueFALSE->~FEMValueFALSE();
			break;
		case FEMFunctionBASE::ARRAY_VALUE:
			femCast(this)->toArrayVALUE->~FEMArrayVALUE();
			break;
		case FEMFunctionBASE::ARRAY_CYCLIC:
			femCast(this)->toArrayCYCLIC->~FEMArrayCYCLIC();
			break;
		case FEMFunctionBASE::ARRAY_CONCAT:
			femCast(this)->toArrayCONCAT->~FEMArrayCONCAT();
			break;
		case FEMFunctionBASE::ARRAY_SECTION:
			femCast(this)->toArraySECTION->~FEMArraySECTION();
			break;
		case FEMFunctionBASE::ARRAY_REVERSE:
			femCast(this)->toArrayREVERSE->~FEMArrayREVERSE();
			break;
		case FEMFunctionBASE::ARRAY_UNIFORM:
			femCast(this)->toArrayUNIFORM->~FEMArrayUNIFORM();
			break;
		case FEMFunctionBASE::ARRAY_CUSTOM1:
			femCast(this)->toArrayCUSTOM1->~FEMArrayCUSTOM1();
			break;
		case FEMFunctionBASE::ARRAY_CUSTOM2:
			femCast(this)->toArrayCUSTOM2->~FEMArrayCUSTOM2();
			break;
		case FEMFunctionBASE::ARRAY_CUSTOM3:
			femCast(this)->toArrayCUSTOM3->~FEMArrayCUSTOM3();
			break;
		case FEMFunctionBASE::STRING_BYTES:
			femCast(this)->toStringBYTES->~FEMStringBYTES();
			break;
		case FEMFunctionBASE::STRING_CHARS:
			femCast(this)->toStringCHARS->~FEMStringCHARS();
			break;
		case FEMFunctionBASE::STRING_VALUE:
			femCast(this)->toStringVALUE->~FEMStringVALUE();
			break;
		case FEMFunctionBASE::STRING_CONCAT:
			femCast(this)->toStringCONCAT->~FEMStringCONCAT();
			break;
		case FEMFunctionBASE::STRING_SECTION:
			femCast(this)->toStringSECTION->~FEMStringSECTION();
			break;
		case FEMFunctionBASE::STRING_REVERSE:
			femCast(this)->toStringREVERSE->~FEMStringREVERSE();
			break;
		case FEMFunctionBASE::STRING_UNIFORM:
			femCast(this)->toStringUNIFORM->~FEMStringUNIFORM();
			break;
		case FEMFunctionBASE::STRING_CUSTOM1:
			femCast(this)->toStringCUSTOM1->~FEMStringCUSTOM1();
			break;
		case FEMFunctionBASE::STRING_CUSTOM2:
			femCast(this)->toStringCUSTOM2->~FEMStringCUSTOM2();
			break;
		case FEMFunctionBASE::STRING_CUSTOM3:
			femCast(this)->toStringCUSTOM3->~FEMStringCUSTOM3();
			break;
		case FEMFunctionBASE::BINARY_VALUE:
			femCast(this)->toBinaryVALUE->~FEMBinaryVALUE();
			break;
		case FEMFunctionBASE::BINARY_CONCAT:
			femCast(this)->toBinaryCONCAT->~FEMBinaryCONCAT();
			break;
		case FEMFunctionBASE::BINARY_SECTION:
			femCast(this)->toBinarySECTION->~FEMBinarySECTION();
			break;
		case FEMFunctionBASE::BINARY_REVERSE:
			femCast(this)->toBinaryREVERSE->~FEMBinaryREVERSE();
			break;
		case FEMFunctionBASE::BINARY_UNIFORM:
			femCast(this)->toBinaryUNIFORM->~FEMBinaryUNIFORM();
			break;
		case FEMFunctionBASE::BINARY_CUSTOM1:
			femCast(this)->toBinaryCUSTOM1->~FEMBinaryCUSTOM1();
			break;
		case FEMFunctionBASE::BINARY_CUSTOM2:
			femCast(this)->toBinaryCUSTOM2->~FEMBinaryCUSTOM2();
			break;
		case FEMFunctionBASE::BINARY_CUSTOM3:
			femCast(this)->toBinaryCUSTOM3->~FEMBinaryCUSTOM3();
			break;
		case FEMFunctionBASE::OBJECT_BASE:
			femCast(this)->toObjectBASE->~FEMObjectBASE();
			break;
		case FEMFunctionBASE::HANDLER_BASE:
			femCast(this)->toHandlerBASE->~FEMHandlerBASE();
			break;
		case FEMFunctionBASE::INTEGER_BASE:
			femCast(this)->toIntegerBASE->~FEMIntegerBASE();
			break;
		case FEMFunctionBASE::DECIMAL_BASE:
			femCast(this)->toDecimalBASE->~FEMDecimalBASE();
			break;
		case FEMFunctionBASE::DURATION_BASE:
			femCast(this)->toDurationBASE->~FEMDurationBASE();
			break;
		case FEMFunctionBASE::DATETIME_BASE:
			femCast(this)->toDatetimeBASE->~FEMDatetimeBASE();
			break;
	}
}

struct __________;

inline FEMFunctionBASE::FEMFunctionBASE(DATA_TYPE const _dataType) // DONE
		: dataType(_dataType) {
}

inline FEMFunction::TYPE FEMFunctionBASE::functionType() const { // DONE
	switch (dataType) {
		case FUNCTION_PROXY:
			return FEMFunction::FUNCTION_TYPE_PROXY;
		case FUNCTION_PARAM:
			return FEMFunction::FUNCTION_TYPE_PARAM;
		case FUNCTION_FRAME:
		case FUNCTION_METHOD:
		case FUNCTION_CONCAT:
		case FUNCTION_COMPOSE:
		case FUNCTION_CUSTOM1:
		case FUNCTION_CUSTOM2:
		case FUNCTION_CUSTOM3:
			return FEMFunction::FUNCTION_TYPE_OTHER;
		default:
			return FEMFunction::FUNCTION_TYPE_VALUE;
	}
}

inline INT32 FEMFunctionBASE::hashBASE() const {
	switch (dataType) {
		case FUNCTION_PROXY:
			return femCast(this)->toFunctionPROXY->hashPROXY();
		case FUNCTION_PARAM:
			return femCast(this)->toFunctionPARAM->hashPARAM();
		case FUNCTION_FRAME:
			return femCast(this)->toFunctionFRAME->hashFRAME();
		case FUNCTION_METHOD:
			return femCast(this)->toFunctionMETHOD->hashMETHOD();
		case FUNCTION_CONCAT:
			return femCast(this)->toFunctionCOMPOSE->hashINVOKE();
		case FUNCTION_COMPOSE:
			return femCast(this)->toFunctionCOMPOSE->hashINVOKE();
		case FUNCTION_CUSTOM1:
			return femCast(this)->toFunctionCUSTOM1->hashCUSTOM1();
		case FUNCTION_CUSTOM2:
			return femCast(this)->toFunctionCUSTOM2->hashCUSTOM2();
		case FUNCTION_CUSTOM3:
			return femCast(this)->toFunctionCUSTOM3->hashCUSTOM3();
		case VALUE_VOID:
			return VALUE_VOID;
		case VALUE_TRUE:
			return VALUE_TRUE;
		case VALUE_FALSE:
			return VALUE_FALSE;
		case ARRAY_VALUE:
		case ARRAY_CYCLIC:
		case ARRAY_CONCAT:
		case ARRAY_SECTION:
		case ARRAY_REVERSE:
		case ARRAY_UNIFORM:
		case ARRAY_CUSTOM1:
		case ARRAY_CUSTOM2:
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayBASE->hashARRAY();
		case STRING_BYTES:
		case STRING_CHARS:
		case STRING_VALUE:
		case STRING_CONCAT:
		case STRING_SECTION:
		case STRING_REVERSE:
		case STRING_UNIFORM:
		case STRING_CUSTOM1:
		case STRING_CUSTOM2:
		case STRING_CUSTOM3:
			return femCast(this)->toStringBASE->hashSTRING();
		case BINARY_VALUE:
		case BINARY_CONCAT:
		case BINARY_SECTION:
		case BINARY_REVERSE:
		case BINARY_UNIFORM:
		case BINARY_CUSTOM1:
		case BINARY_CUSTOM2:
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryBASE->hashBINARY();
		case OBJECT_BASE:
			return femCast(this)->toObjectBASE->hashOBJECT();
		case HANDLER_BASE:
			return femCast(this)->toHandlerBASE->hashHANDLER();
		case INTEGER_BASE:
			return femCast(this)->toIntegerBASE->hashINTEGER();
		case DECIMAL_BASE:
			return femCast(this)->toDecimalBASE->hashDECIMAL();
		case DURATION_BASE:
			return femCast(this)->toDurationBASE->hashDURATION();
		case DATETIME_BASE:
			return femCast(this)->toDatetimeBASE->hashDATETIME();
	}
	throw FEMException();
}

inline FEMString FEMFunctionBASE::scriptBASE() const { // DONE
	switch (dataType) {
		case FUNCTION_PROXY:
			return femCast(this)->toFunctionPROXY->scriptPROXY();
		case FUNCTION_PARAM:
			return femCast(this)->toFunctionPARAM->scriptPARAM();
		case FUNCTION_FRAME:
			return femCast(this)->toFunctionFRAME->scriptFRAME();
		case FUNCTION_METHOD:
			return femCast(this)->toFunctionMETHOD->scriptMETHOD();
		case FUNCTION_CONCAT:
			return femCast(this)->toFunctionCOMPOSE->scriptINVOKE();
		case FUNCTION_COMPOSE:
			return femCast(this)->toFunctionCOMPOSE->scriptINVOKE();
		case FUNCTION_CUSTOM1:
			return femCast(this)->toFunctionCUSTOM1->scriptCUSTOM1();
		case FUNCTION_CUSTOM2:
			return femCast(this)->toFunctionCUSTOM2->scriptCUSTOM2();
		case FUNCTION_CUSTOM3:
			return femCast(this)->toFunctionCUSTOM3->scriptCUSTOM3();
		case VALUE_VOID:
			return femCast(this)->toValueVOID->scriptVOID();
		case VALUE_TRUE:
			return femCast(this)->toValueTRUE->scriptTRUE();
		case VALUE_FALSE:
			return femCast(this)->toValueFALSE->scriptFALSE();
		case ARRAY_VALUE:
		case ARRAY_CYCLIC:
		case ARRAY_CONCAT:
		case ARRAY_SECTION:
		case ARRAY_REVERSE:
		case ARRAY_UNIFORM:
		case ARRAY_CUSTOM1:
		case ARRAY_CUSTOM2:
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayBASE->scriptARRAY();
		case STRING_BYTES:
		case STRING_CHARS:
		case STRING_VALUE:
		case STRING_CONCAT:
		case STRING_SECTION:
		case STRING_REVERSE:
		case STRING_UNIFORM:
		case STRING_CUSTOM1:
		case STRING_CUSTOM2:
		case STRING_CUSTOM3:
			return femCast(this)->toStringBASE->scriptSTRING();
		case BINARY_VALUE:
		case BINARY_CONCAT:
		case BINARY_SECTION:
		case BINARY_REVERSE:
		case BINARY_UNIFORM:
		case BINARY_CUSTOM1:
		case BINARY_CUSTOM2:
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryBASE->scriptBINARY();
		case OBJECT_BASE:
			return femCast(this)->toObjectBASE->scriptOBJECT();
		case HANDLER_BASE:
			return femCast(this)->toHandlerBASE->scriptHANDLER();
		case INTEGER_BASE:
			return femCast(this)->toIntegerBASE->scriptINTEGER();
		case DECIMAL_BASE:
			return femCast(this)->toDecimalBASE->scriptDECIMAL();
		case DURATION_BASE:
			return femCast(this)->toDurationBASE->scriptDURATION();
		case DATETIME_BASE:
			return femCast(this)->toDatetimeBASE->scriptDATETIME();
	}
	throw FEMException();
}

inline bool FEMFunctionBASE::equalsBASE(FEMFunctionBASE const& _that) const {
	if (this == &_that) return true;
	switch (dataType) {
		case FUNCTION_PROXY:
			if (_that.dataType != FUNCTION_PROXY) return false;
			return femCast(this)->toFunctionPROXY->equalsPROXY(*femCast(&_that)->toFunctionPROXY);
		case FUNCTION_PARAM:
			if (_that.dataType != FUNCTION_PARAM) return false;
			return femCast(this)->toFunctionPARAM->equalsPARAM(*femCast(&_that)->toFunctionPARAM);
		case FUNCTION_FRAME:
			if (_that.dataType != FUNCTION_FRAME) return false;
			return femCast(this)->toFunctionFRAME->equalsFRAME(*femCast(&_that)->toFunctionFRAME);
		case FUNCTION_METHOD:
			if (_that.dataType != FUNCTION_METHOD) return false;
			return femCast(this)->toFunctionMETHOD->equalsMETHOD(*femCast(&_that)->toFunctionMETHOD);
		case FUNCTION_CONCAT:
			if (_that.dataType != FUNCTION_CONCAT) return false;
			return femCast(this)->toFunctionCONCAT->equalsINVOKE(*femCast(&_that)->toFunctionCONCAT);
		case FUNCTION_COMPOSE:
			if (_that.dataType != FUNCTION_COMPOSE) return false;
			return femCast(this)->toFunctionCOMPOSE->equalsINVOKE(*femCast(&_that)->toFunctionCOMPOSE);
		case FUNCTION_CUSTOM1:
			if (_that.dataType != FUNCTION_CUSTOM1) return false;
			return femCast(this)->toFunctionCUSTOM1->equalsCUSTOM1(*femCast(&_that)->toFunctionCUSTOM1);
		case FUNCTION_CUSTOM2:
			if (_that.dataType != FUNCTION_CUSTOM2) return false;
			return femCast(this)->toFunctionCUSTOM2->equalsCUSTOM2(*femCast(&_that)->toFunctionCUSTOM2);
		case FUNCTION_CUSTOM3:
			if (_that.dataType != FUNCTION_CUSTOM3) return false;
			return femCast(this)->toFunctionCUSTOM3->equalsCUSTOM3(*femCast(&_that)->toFunctionCUSTOM3);
		case VALUE_VOID:
			return _that.dataType == VALUE_VOID;
		case VALUE_TRUE:
			return _that.dataType == VALUE_TRUE;
		case VALUE_FALSE:
			return _that.dataType == VALUE_FALSE;
		case ARRAY_VALUE:
		case ARRAY_CYCLIC:
		case ARRAY_CONCAT:
		case ARRAY_SECTION:
		case ARRAY_REVERSE:
		case ARRAY_UNIFORM:
		case ARRAY_CUSTOM1:
		case ARRAY_CUSTOM2:
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayBASE->equalsARRAY(*femCast(&_that)->toArrayBASE);
		case STRING_BYTES:
		case STRING_CHARS:
		case STRING_VALUE:
		case STRING_CONCAT:
		case STRING_SECTION:
		case STRING_REVERSE:
		case STRING_UNIFORM:
		case STRING_CUSTOM1:
		case STRING_CUSTOM2:
		case STRING_CUSTOM3:
			return femCast(this)->toStringBASE->equalsSTRING(*femCast(&_that)->toStringBASE);
		case BINARY_VALUE:
		case BINARY_CONCAT:
		case BINARY_SECTION:
		case BINARY_REVERSE:
		case BINARY_UNIFORM:
		case BINARY_CUSTOM1:
		case BINARY_CUSTOM2:
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryBASE->equalsBINARY(*femCast(&_that)->toBinaryBASE);
		case OBJECT_BASE:
			return femCast(this)->toObjectBASE->equalsOBJECT(*femCast(&_that)->toObjectBASE);
		case HANDLER_BASE:
			return femCast(this)->toHandlerBASE->equalsHANDLER(*femCast(&_that)->toHandlerBASE);
		case INTEGER_BASE:
			return femCast(this)->toIntegerBASE->equalsINTEGER(*femCast(&_that)->toIntegerBASE);
		case DECIMAL_BASE:
			return femCast(this)->toDecimalBASE->equalsDECIMAL(*femCast(&_that)->toDecimalBASE);
		case DURATION_BASE:
			return femCast(this)->toDurationBASE->equalsDURATION(*femCast(&_that)->toDurationBASE);
		case DATETIME_BASE:
			return femCast(this)->toDatetimeBASE->equalsDATETIME(*femCast(&_that)->toDatetimeBASE);
	}
	throw FEMException();
}

inline FEMValue FEMFunctionBASE::invokeBASE(FEMFrame const& _frame) const { // DONE
	switch (dataType) {
		case FUNCTION_PROXY:
			return femCast(this)->toFunctionPROXY->invokePROXY(_frame);
		case FUNCTION_PARAM:
			return femCast(this)->toFunctionPARAM->invokePARAM(_frame);
		case FUNCTION_FRAME:
			return femCast(this)->toFunctionFRAME->invokeFRAME(_frame);
		case FUNCTION_CONCAT:
			return femCast(this)->toFunctionCONCAT->invokeCONCAT(_frame);
		case FUNCTION_COMPOSE:
			return femCast(this)->toFunctionCOMPOSE->invokeCOMPOSE(_frame);
		case FUNCTION_CUSTOM1:
			return femCast(this)->toFunctionCUSTOM1->invokeCUSTOM1(_frame);
		case FUNCTION_CUSTOM2:
			return femCast(this)->toFunctionCUSTOM2->invokeCUSTOM2(_frame);
		case FUNCTION_CUSTOM3:
			return femCast(this)->toFunctionCUSTOM3->invokeCUSTOM3(_frame);
		default:
			FEMFunctionBASE const* _result = this;
			return FEMValue(*femCast(&_result)->toValue);
	}
}

struct __________;

inline FEMFunctionPROXY::FEMFunctionPROXY(FEMString const& _proxyName) // DONE
		: FEMFunctionBASE(FUNCTION_PROXY), proxyName(_proxyName), proxyTarget(FEMVoid::INSTANCE) {
}

inline INT32 FEMFunctionPROXY::hashPROXY() const { // DONE
	return proxyName.hash();
}

inline FEMString FEMFunctionPROXY::scriptPROXY() const { // DONE
	return proxyName;
}

bool FEMFunctionPROXY::equalsPROXY(FEMFunctionPROXY const& _that) const { // DONE
	return proxyName.equals(_that.proxyName);
}

inline FEMValue FEMFunctionPROXY::invokePROXY(FEMFrame const& _frame) const { // DONE
	return proxyTarget.functionInvoke(_frame);
}

struct __________;

static FEMString _FEMFunctionPARAM_SCRIPT_ = FEMString::from("$");

inline FEMFunctionPARAM::FEMFunctionPARAM(UINT32 const& _paramIndex) // DONE
		: FEMFunctionBASE(FUNCTION_PARAM), paramIndex(_paramIndex) {
}

inline INT32 FEMFunctionPARAM::hashPARAM() const { // DONE
	return paramIndex;
}

inline FEMString FEMFunctionPARAM::scriptPARAM() const { // DONE
	return _FEMFunctionPARAM_SCRIPT_.concat(FEMInteger::from(paramIndex + 1).toScript());
}

inline bool FEMFunctionPARAM::equalsPARAM(FEMFunctionPARAM const& _that) const { // DONE
	return paramIndex == _that.paramIndex;
}

inline FEMValue FEMFunctionPARAM::invokePARAM(FEMFrame const& _frame) const { // DONE
	return _frame.get(paramIndex);
}

struct __________;

inline FEMFunctionCACHE::FEMFunctionCACHE() { // DONE
	for (INT32 i = 0; i < functionCount; ++i) {
		functionArray[i].set(femCast(new FEMFunctionPARAM(i))->toFunctionOBJ);
	}
}

struct __________;

static FEMString _FEMFunctionFRAME_SCRIPT_ = FEMString::from("$");

inline FEMFunctionFRAME::FEMFunctionFRAME() // DONE
		: FEMFunctionBASE(FUNCTION_FRAME) {
}

inline INT32 FEMFunctionFRAME::hashFRAME() const { // DONE
	return FUNCTION_FRAME;
}

inline FEMString FEMFunctionFRAME::scriptFRAME() const { // DONE
	return _FEMFunctionFRAME_SCRIPT_;
}

inline bool FEMFunctionFRAME::equalsFRAME(FEMFunctionFRAME const& _that) const { // DONE
	return true;
}

inline FEMValue FEMFunctionFRAME::invokeFRAME(FEMFrame const& _frame) const { // DONE
	return _frame.params();
}

struct __________;

inline FEMFunctionMETHOD::FEMFunctionMETHOD(FEMFunction::METHOD _invokeMethod) // DONE
		: FEMFunctionBASE(FUNCTION_METHOD), invokeMethod(_invokeMethod) {
}

inline INT32 FEMFunctionMETHOD::hashMETHOD() const { // DONE
	return (INT32) invokeMethod;
}

inline FEMString FEMFunctionMETHOD::scriptMETHOD() const { // TODO
	return FEMString::EMPTY;
}

inline bool FEMFunctionMETHOD::equalsMETHOD(FEMFunctionMETHOD const& _that) const { // DONE
	return invokeMethod == _that.invokeMethod;
}

inline FEMValue FEMFunctionMETHOD::invokeMETHOD(FEMFrame const& _frame) const { // DONE
	return (*invokeMethod)(_frame);
}

struct __________;

static FEMString _FEMFunctionINVOKE_SCRIPT_OPEN_ = FEMString::from("(");

static FEMString _FEMFunctionINVOKE_SCRIPT_CLOSE_ = FEMString::from(")");

static FEMString _FEMFunctionINVOKE_SCRIPT_COMMA_ = FEMString::from("; ");

static FEMString _FEMFunctionINVOKE_SCRIPT_EMPTY_ = FEMString::from("()");

inline FEMFunctionINVOKE::FEMFunctionINVOKE(DATA_TYPE _dataType, FEMFunction const& _invokeMethod, FEMFunction const* _paramArray, INT32 _paramCount) // DONE
		: FEMFunctionBASE(_dataType), invokeMethod(_invokeMethod), paramCount(_paramCount) {
	setupArray<FEMFunction, FEMFunction>(_paramArray, paramArray, _paramCount);
}

inline FEMFunctionINVOKE::~FEMFunctionINVOKE() { // DONE
	resetArray<FEMFunction>(paramArray, paramCount);
}

inline INT32 FEMFunctionINVOKE::hashINVOKE() const { // DONE
	return invokeMethod.hash() ^ FEMFunction::POLICY::hashArray(paramArray, paramCount);
}

inline FEMString FEMFunctionINVOKE::scriptINVOKE() const { // DONE
	FEMString _result = invokeMethod.toScript();
	FEMFunction const* _array = paramArray;
	FEMFunction const* _cancel = _array + paramCount;
	if (_array == _cancel) return _result.concat(_FEMFunctionINVOKE_SCRIPT_EMPTY_);
	_result = _result.concat(_FEMFunctionINVOKE_SCRIPT_OPEN_).concat(_array->toScript());
	_array++;
	while (_array != _cancel) {
		_result = _result.concat(_FEMFunctionINVOKE_SCRIPT_COMMA_).concat(_array->toScript());
		++_array;
	}
	return _result.concat(_FEMFunctionINVOKE_SCRIPT_CLOSE_);
}

inline bool FEMFunctionINVOKE::equalsINVOKE(FEMFunctionINVOKE const& _that) const { // DONE
	if (!invokeMethod.equals(_that.invokeMethod)) return false;
	return FEMFunction::POLICY::equalsArray(paramArray, _that.paramArray, paramCount, _that.paramCount);
}

struct __________;

inline FEMFunctionCONCAT::FEMFunctionCONCAT(FEMFunction const& _invokeMethod, FEMFunction const* _paramArray, INT32 _paramCount) // DONE
		: FEMFunctionINVOKE(FUNCTION_CONCAT, _invokeMethod, _paramArray, _paramCount) {
}

inline FEMValue FEMFunctionCONCAT::invokeCONCAT(FEMFrame const& _frame) const { // DONE
	return FEMVoid::INSTANCE;
	// TODO evtl Prüfung
//	return invokeMethod.functionInvoke(_frame).valueToHandler().value().functionInvoke(_frame.newFrame(paramArray, paramCount));
}

struct __________;

inline FEMFunctionCOMPOSE::FEMFunctionCOMPOSE(FEMFunction const& _invokeMethod, FEMFunction const* _paramArray, INT32 _paramCount) // DONE
		: FEMFunctionINVOKE(FUNCTION_COMPOSE, _invokeMethod, _paramArray, _paramCount) {
}

inline FEMValue FEMFunctionCOMPOSE::invokeCOMPOSE(FEMFrame const& _frame) const { // DONE
	return invokeMethod.functionInvoke(_frame.newFrame(paramArray, paramCount));
}

struct __________;

inline FEMFunctionCUSTOM1::FEMFunctionCUSTOM1()
		: FEMFunctionBASE(FUNCTION_CUSTOM1) {
}

inline FEMFunctionCUSTOM1::~FEMFunctionCUSTOM1() {
}

inline INT32 FEMFunctionCUSTOM1::hashCUSTOM1() const {
	return 0;
}

inline FEMString FEMFunctionCUSTOM1::scriptCUSTOM1() const {
	return FEMString::EMPTY;
}

inline bool FEMFunctionCUSTOM1::equalsCUSTOM1(FEMFunctionCUSTOM1 const& _that) const {
	return false;
}

inline FEMValue FEMFunctionCUSTOM1::invokeCUSTOM1(FEMFrame const& _frame) const {
	return FEMVoid::INSTANCE;
}

struct __________;

inline FEMFunctionCUSTOM2::FEMFunctionCUSTOM2()
		: FEMFunctionBASE(FUNCTION_CUSTOM2) {
}

inline FEMFunctionCUSTOM2::~FEMFunctionCUSTOM2() {
}

inline INT32 FEMFunctionCUSTOM2::hashCUSTOM2() const {
	return 0;
}

inline FEMString FEMFunctionCUSTOM2::scriptCUSTOM2() const {
	return FEMString::EMPTY;
}

inline bool FEMFunctionCUSTOM2::equalsCUSTOM2(FEMFunctionCUSTOM2 const& _that) const {
	return false;
}

inline FEMValue FEMFunctionCUSTOM2::invokeCUSTOM2(FEMFrame const& _frame) const {
	return FEMVoid::INSTANCE;
}

struct __________;

inline FEMFunctionCUSTOM3::FEMFunctionCUSTOM3()
		: FEMFunctionBASE(FUNCTION_CUSTOM3) {
}

inline FEMFunctionCUSTOM3::~FEMFunctionCUSTOM3() {
}

inline INT32 FEMFunctionCUSTOM3::hashCUSTOM3() const {
	return 0;
}

inline FEMString FEMFunctionCUSTOM3::scriptCUSTOM3() const {
	return FEMString::EMPTY;
}

inline bool FEMFunctionCUSTOM3::equalsCUSTOM3(FEMFunctionCUSTOM3 const& _that) const {
	return false;
}

inline FEMValue FEMFunctionCUSTOM3::invokeCUSTOM3(FEMFrame const& _frame) const {
	return FEMVoid::INSTANCE;
}

struct __________;

FEMValue::FEMValue() {
}

FEMValue::TYPE FEMValue::valueType() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toValueBASE->valueType();
}

bool FEMValue::valueIsVoid() const { // DONE
	return valueType() == VALUE_TYPE_VOID;
}

bool FEMValue::valueIsArray() const { // DONE
	return valueType() == VALUE_TYPE_ARRAY;
}

bool FEMValue::valueIsString() const { // DONE
	return valueType() == VALUE_TYPE_STRING;
}

bool FEMValue::valueIsBinary() const { // DONE
	return valueType() == VALUE_TYPE_BINARY;
}

bool FEMValue::valueIsObject() const { // DONE
	return valueType() == VALUE_TYPE_OBJECT;
}

bool FEMValue::valueIsHandler() const { // DONE
	return valueType() == VALUE_TYPE_HANDLER;
}

bool FEMValue::valueIsInteger() const { // DONE
	return valueType() == VALUE_TYPE_INTEGER;
}

bool FEMValue::valueIsDecimal() const { // DONE
	return valueType() == VALUE_TYPE_DECIMAL;
}

bool FEMValue::valueIsBoolean() const { // DONE
	return valueType() == VALUE_TYPE_BOOLEAN;
}

bool FEMValue::valueIsDuration() const { // DONE
	return valueType() == VALUE_TYPE_DURATION;
}

bool FEMValue::valueIsDatetime() const { // DONE
	return valueType() == VALUE_TYPE_DATETIME;
}

bool FEMValue::valueIsOther() const { // DONE
	return valueType() == VALUE_TYPE_OTHER;
}

FEMVoid const& FEMValue::valueAsVoid() const { // DONE
	return *femCast(this)->toVoid;
}

FEMArray const& FEMValue::valueAsArray() const { // DONE
	return *femCast(this)->toArray;
}

FEMString const& FEMValue::valueAsString() const { // DONE
	return *femCast(this)->toString;
}

FEMBinary const& FEMValue::valueAsBinary() const { // DONE
	return *femCast(this)->toBinary;
}

FEMObject const& FEMValue::valueAsObject() const { // DONE
	return *femCast(this)->toObject;
}

FEMHandler const& FEMValue::valueAsHandler() const { // DONE
	return *femCast(this)->toHandler;
}

FEMInteger const& FEMValue::valueAsInteger() const { // DONE
	return *femCast(this)->toInteger;
}

FEMDecimal const& FEMValue::valueAsDecimal() const { // DONE
	return *femCast(this)->toDecimal;
}

FEMBoolean const& FEMValue::valueAsBoolean() const { // DONE
	return *femCast(this)->toBoolean;
}

FEMDuration const& FEMValue::valueAsDuration() const { // DONE
	return *femCast(this)->toDuration;
}

FEMDatetime const& FEMValue::valueAsDatetime() const { // DONE
	return *femCast(this)->toDatetime;
}

FEMValue FEMValue::clone() const { // DONE
	return *this;
}

struct __________;

inline FEMValueBASE::FEMValueBASE(DATA_TYPE const _dataType)
		: FEMFunctionBASE(_dataType) {
}

inline FEMValue::TYPE FEMValueBASE::valueType() const { // DONE
	switch (dataType) {
		case VALUE_VOID:
			return FEMValue::VALUE_TYPE_VOID;
		case VALUE_TRUE:
		case VALUE_FALSE:
			return FEMValue::VALUE_TYPE_BOOLEAN;
		case ARRAY_VALUE:
		case ARRAY_CYCLIC:
		case ARRAY_CONCAT:
		case ARRAY_SECTION:
		case ARRAY_REVERSE:
		case ARRAY_UNIFORM:
		case ARRAY_CUSTOM1:
		case ARRAY_CUSTOM2:
		case ARRAY_CUSTOM3:
			return FEMValue::VALUE_TYPE_ARRAY;
		case STRING_BYTES:
		case STRING_CHARS:
		case STRING_VALUE:
		case STRING_CONCAT:
		case STRING_SECTION:
		case STRING_REVERSE:
		case STRING_UNIFORM:
		case STRING_CUSTOM1:
		case STRING_CUSTOM2:
		case STRING_CUSTOM3:
			return FEMValue::VALUE_TYPE_STRING;
		case BINARY_VALUE:
		case BINARY_CONCAT:
		case BINARY_SECTION:
		case BINARY_REVERSE:
		case BINARY_UNIFORM:
		case BINARY_CUSTOM1:
		case BINARY_CUSTOM2:
		case BINARY_CUSTOM3:
			return FEMValue::VALUE_TYPE_BINARY;
		case OBJECT_BASE:
			return FEMValue::VALUE_TYPE_OBJECT;
		case HANDLER_BASE:
			return FEMValue::VALUE_TYPE_HANDLER;
		case INTEGER_BASE:
			return FEMValue::VALUE_TYPE_INTEGER;
		case DECIMAL_BASE:
			return FEMValue::VALUE_TYPE_DECIMAL;
		case DURATION_BASE:
			return FEMValue::VALUE_TYPE_DURATION;
		case DATETIME_BASE:
			return FEMValue::VALUE_TYPE_DATETIME;
		default:
			return FEMValue::VALUE_TYPE_OTHER;
	}
}

struct __________;

static FEMValueVOID const* _FEMVoid_INSTANCE_ = new FEMValueVOID();

FEMVoid const FEMVoid::INSTANCE = FEMVoid(*femCast(&_FEMVoid_INSTANCE_)->toVoid);

FEMVoid::FEMVoid()
		: FEMVoid(INSTANCE) {
}

struct __________;

static FEMString const _FEMValueVOID_SCRIPT_ = FEMString::from("undefined");

inline FEMValueVOID::FEMValueVOID() // DONE
		: FEMValueBASE(VALUE_VOID) {
}

inline FEMString FEMValueVOID::scriptVOID() const { // DONE
	return _FEMValueVOID_SCRIPT_;
}

struct __________;

static FEMString const _FEMValueTRUE_SCRIPT_ = FEMString::from("true");

inline FEMValueTRUE::FEMValueTRUE() // DONE
		: FEMValueBASE(VALUE_TRUE) {
}

inline FEMString FEMValueTRUE::scriptTRUE() const { // DONE
	return _FEMValueTRUE_SCRIPT_;
}

struct __________;

static FEMString const _FEMValueFALSE_SCRIPT_ = FEMString::from("false");

inline FEMValueFALSE::FEMValueFALSE() // DONE
		: FEMValueBASE(VALUE_FALSE) {
}

inline FEMString FEMValueFALSE::scriptFALSE() const { // DONE
	return _FEMValueFALSE_SCRIPT_;
}

struct __________;

static FEMArrayUNIFORM const* _FEMArray_EMPTY_ = new FEMArrayUNIFORM(FEMVoid::INSTANCE, 0);

FEMArray const FEMArray::EMPTY = FEMArray(*femCast(&_FEMArray_EMPTY_)->toArray);

FEMArray FEMArray::from(VALUE const& _array) { // DONE
	return from(_array.data(), _array.length());
}

FEMArray FEMArray::from(FEMValue const* _itemArray, INT32 const _itemCount) { // DONE
	FEMException::checkNull(_itemArray);
	if (!_itemCount) return EMPTY;
	if (_itemCount == 1) return from(*_itemArray, 1);
	FEMException::checkCount(_itemCount);
	DELETE_ARRAY<INT8> _resultGuard(new INT8[sizeof(FEMArrayVALUE) + _itemCount * sizeof(FEMValue)]);
	FEMArrayVALUE* _result = new (_resultGuard.array()) FEMArrayVALUE(_itemArray, _itemCount);
	_resultGuard.cancel();
	return FEMArray(*femCast(&_result)->toArray);
}

FEMArray FEMArray::from(FEMValue const& _item, INT32 const _itemCount) { // DONE
	if (!_itemCount) return EMPTY;
	FEMException::checkCount(_itemCount);
	FEMArrayUNIFORM* _result = new FEMArrayUNIFORM(_item, _itemCount);
	return FEMArray(*femCast(&_result)->toArray);
}

FEMArray::FEMArray() // DONE
		: FEMArray(EMPTY) {
}

bool FEMArray_value(PVOID _target, FEMValue const& _value) { // DONE
	FEMValue** _cursor = (FEMValue**) _target;
	**_cursor = _value;
	*_cursor += 1;
	return true;
}

FEMArray::VALUE FEMArray::value() const { // DONE
	VALUE _result(length());
	FEMValue* _context = _result.data();
	extract(&_context, FEMArray_value);
	return _result;
}

FEMValue FEMArray::get(INT32 const _index) const { // DONE
	FEMArrayBASE* _thisArray = femCast(this)->toPointerAndCastItsTarget->toArrayBASE;
	FEMException::checkIndex(_index, _thisArray->arrayLength);
	return _thisArray->getBASE(_index);
}

INT32 FEMArray::length() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toArrayBASE->arrayLength;
}

FEMArray FEMArray::concat(FEMArray const& _that) const { // DONE
	INT32 _thisLength = length();
	if (!_thisLength) return _that;
	INT32 _thatLength = _that.length();
	if (!_thatLength) return *this;
	FEMArrayCONCAT* _result = new FEMArrayCONCAT(_thisLength + _thatLength, *this, _that);
	return FEMArray(*femCast(&_result)->toArray);
}

FEMArray FEMArray::section(INT32 const _offset, INT32 const _length) const { // DONE
	FEMArrayBASE* _thisArray = femCast(this)->toPointerAndCastItsTarget->toArrayBASE;
	INT32 _thisLength = _thisArray->arrayLength;
	if ((_offset == 0) && (_length == _thisLength)) return *this;
	if ((_offset < 0) || (_length < 0) || ((_offset + _length) > _thisLength)) throw FEMException();
	if (_length == 0) return EMPTY;
	return _thisArray->sectionBASE(_offset, _length);
}

FEMArray FEMArray::reverse() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toArrayBASE->reverseBASE();
}

FEMArray FEMArray::compact() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toArrayBASE->compactBASE();
}

INT32 FEMArray::find(FEMValue const& _that, INT32 const _offset) const { // DONE
	struct FEMArray_findValue {

		FEMValue const& value;

		INT32 index;

		FEMArray_findValue(FEMValue const& _value)
				: value(_value), index(0) {
		}

		static bool collector(PVOID _context, FEMValue const& _value) {
			FEMArray_findValue* _result = (FEMArray_findValue*) _context;
			if (_result->value.equals(_value)) return false;
			_result->index++;
			return true;
		}

	};
	FEMArrayBASE* _thisArray = femCast(this)->toPointerAndCastItsTarget->toArrayBASE;
	INT32 _length = _thisArray->arrayLength - _offset;
	if ((_offset < 0) || (_length < 0)) throw FEMException();
	FEMArray_findValue _context(_that);
	if (_thisArray->extractBASE(&_context, FEMArray_findValue::collector, _offset, _length, true)) return -1;
	return _context.index + _offset;
}

INT32 FEMArray::find(FEMArray const& _that, INT32 const _offset) const {
	FEMArrayBASE* _thisArray = femCast(this)->toPointerAndCastItsTarget->toArrayBASE;
	FEMArrayBASE* _thatArray = femCast(&_that)->toPointerAndCastItsTarget->toArrayBASE;
	if ((_offset < 0) || (_offset > _thisArray->arrayLength)) throw FEMException();
	INT32 _thatLength = _thatArray->arrayLength;
	if (_thatLength == 0) return _offset;
	INT32 _thisLength = _thisArray->arrayLength - _thatLength;
	FEMValue _thatValue = _thatArray->getBASE(0);
	for (int _thisIndex = _offset; _thisIndex < _thisLength; _thisIndex++) {
		if (_thatValue.equals(_thisArray->getBASE(_thisIndex))) {
			for (int _thatIndex = 1; _thatIndex < _thatLength; _thatIndex++) {
				if (!_thisArray->getBASE(_thisIndex + _thatIndex).equals(_thatArray->getBASE(_thatIndex))) {
					goto FIND;
				}
			}
			return _thisIndex;
		}
		FIND: ;
	}
	return -1;

}

bool FEMArray::extract(PVOID _target, COLLECTOR _collector) const { // DONE
	FEMArrayBASE* _thisArray = femCast(this)->toPointerAndCastItsTarget->toArrayBASE;
	return _thisArray->extractBASE(_target, _collector, 0, _thisArray->arrayLength, true);
}

INT32 FEMArray::compare(FEMArray const& _that, PVOID _context, COMPARATOR _comparator) const {
	FEMArrayBASE* _thisArray = femCast(this)->toPointerAndCastItsTarget->toArrayBASE;
	FEMArrayBASE* _thatArray = femCast(&_that)->toPointerAndCastItsTarget->toArrayBASE;
	INT32 _thisLength = _thisArray->arrayLength;
	INT32 _thatLength = _thatArray->arrayLength;
	INT32 _length = _thisLength < _thatLength ? _thisLength : _thatLength;
	for (INT32 _index = 0; _index < _length; _index++) {
		FEMValue _thisValue = _thisArray->getBASE(_index);
		FEMValue _thatValue = _thatArray->getBASE(_index);
		INT32 _result = _comparator(_context, _thisValue, _thatValue);
		if (_result < 0) return -1;
		if (_result > 0) return +1;
	}
	INT32 _result = _thisLength - _thatLength;
	if (_result < 0) return -1;
	if (_result > 0) return +1;
	return 0;
}

struct __________;

static FEMString const _FEMArrayBASE_SCRIPT_OPEN_ = FEMString::from("[");

static FEMString const _FEMArrayBASE_SCRIPT_CLOSE_ = FEMString::from("]");

static FEMString const _FEMArrayBASE_SCRIPT_COMMA_ = FEMString::from("; ");

inline FEMArrayBASE::FEMArrayBASE(DATA_TYPE const _dataType, INT32 const _arrayLength) // DONE
		: FEMValueBASE(_dataType), arrayLength(_arrayLength) {
}

inline FEMValue FEMArrayBASE::getBASE(INT32 const _index) const { // DONE
	switch (dataType) {
		case ARRAY_VALUE:
			return femCast(this)->toArrayVALUE->getVALUE(_index);
		case ARRAY_CYCLIC:
			return femCast(this)->toArrayCYCLIC->getCYCLIC(_index);
		case ARRAY_CONCAT:
			return femCast(this)->toArrayCONCAT->getCONCAT(_index);
		case ARRAY_SECTION:
			return femCast(this)->toArraySECTION->getSECTION(_index);
		case ARRAY_REVERSE:
			return femCast(this)->toArrayREVERSE->getREVERSE(_index);
		case ARRAY_UNIFORM:
			return femCast(this)->toArrayUNIFORM->getUNIFORM(_index);
		case ARRAY_CUSTOM1:
			return femCast(this)->toArrayCUSTOM1->getCUSTOM1(_index);
		case ARRAY_CUSTOM2:
			return femCast(this)->toArrayCUSTOM2->getCUSTOM2(_index);
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayCUSTOM3->getCUSTOM3(_index);
		default:
			throw FEMException();
	}
}

inline bool FEMArrayBASE::extractBASE(PVOID _context, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	switch (dataType) {
		case ARRAY_VALUE:
			return femCast(this)->toArrayVALUE->extractVALUE(_context, _collector, _offset, _length, _foreward);
		case ARRAY_CYCLIC:
			return femCast(this)->toArrayCYCLIC->extractARRAY(_context, _collector, _offset, _length, _foreward);
		case ARRAY_CONCAT:
			return femCast(this)->toArrayCONCAT->extractCONCAT(_context, _collector, _offset, _length, _foreward);
		case ARRAY_SECTION:
			return femCast(this)->toArraySECTION->extractSECTION(_context, _collector, _offset, _length, _foreward);
		case ARRAY_REVERSE:
			return femCast(this)->toArrayREVERSE->extractREVERSE(_context, _collector, _offset, _length, _foreward);
		case ARRAY_UNIFORM:
			return femCast(this)->toArrayUNIFORM->extractUNIFORM(_context, _collector, _offset, _length, _foreward);
		case ARRAY_CUSTOM1:
			return femCast(this)->toArrayCUSTOM1->extractARRAY(_context, _collector, _offset, _length, _foreward);
		case ARRAY_CUSTOM2:
			return femCast(this)->toArrayCUSTOM2->extractARRAY(_context, _collector, _offset, _length, _foreward);
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayCUSTOM3->extractARRAY(_context, _collector, _offset, _length, _foreward);
		default:
			throw FEMException();
	}
}

inline FEMArray FEMArrayBASE::sectionBASE(INT32 const _offset, INT32 const _length) const { // DONE
	switch (dataType) {
		case ARRAY_VALUE:
			return femCast(this)->toArrayVALUE->sectionARRAY(_offset, _length);
		case ARRAY_CYCLIC:
			return femCast(this)->toArrayCYCLIC->sectionARRAY(_offset, _length);
		case ARRAY_CONCAT:
			return femCast(this)->toArrayCONCAT->sectionCONCAT(_offset, _length);
		case ARRAY_SECTION:
			return femCast(this)->toArraySECTION->sectionSECTION(_offset, _length);
		case ARRAY_REVERSE:
			return femCast(this)->toArrayREVERSE->sectionREVERSE(_offset, _length);
		case ARRAY_UNIFORM:
			return femCast(this)->toArrayUNIFORM->sectionUNIFORM(_offset, _length);
		case ARRAY_CUSTOM1:
			return femCast(this)->toArrayCUSTOM1->sectionARRAY(_offset, _length);
		case ARRAY_CUSTOM2:
			return femCast(this)->toArrayCUSTOM2->sectionARRAY(_offset, _length);
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayCUSTOM3->sectionARRAY(_offset, _length);
		default:
			throw FEMException();
	}
}

inline FEMArray FEMArrayBASE::compactBASE() const { // DONE
	switch (dataType) {
		case ARRAY_VALUE:
			return femCast(this)->toArrayVALUE->compactVALUE();
		case ARRAY_CYCLIC:
			return femCast(this)->toArrayCYCLIC->compactARRAY();
		case ARRAY_CONCAT:
			return femCast(this)->toArrayCONCAT->compactARRAY();
		case ARRAY_SECTION:
			return femCast(this)->toArraySECTION->compactARRAY();
		case ARRAY_REVERSE:
			return femCast(this)->toArrayREVERSE->compactARRAY();
		case ARRAY_UNIFORM:
			return femCast(this)->toArrayUNIFORM->compactUNIFORM();
		case ARRAY_CUSTOM1:
			return femCast(this)->toArrayCUSTOM1->compactARRAY();
		case ARRAY_CUSTOM2:
			return femCast(this)->toArrayCUSTOM2->compactARRAY();
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayCUSTOM3->compactARRAY();
		default:
			throw FEMException();
	}
}

inline FEMArray FEMArrayBASE::reverseBASE() const { // DONE
	switch (dataType) {
		case ARRAY_VALUE:
			return femCast(this)->toArrayVALUE->reverseARRAY();
		case ARRAY_CYCLIC:
			return femCast(this)->toArrayCYCLIC->reverseARRAY();
		case ARRAY_CONCAT:
			return femCast(this)->toArrayCONCAT->reverseARRAY();
		case ARRAY_SECTION:
			return femCast(this)->toArraySECTION->reverseARRAY();
		case ARRAY_REVERSE:
			return femCast(this)->toArrayREVERSE->reverseREVERSE();
		case ARRAY_UNIFORM:
			return femCast(this)->toArrayUNIFORM->reverseUNIFORM();
		case ARRAY_CUSTOM1:
			return femCast(this)->toArrayCUSTOM1->reverseARRAY();
		case ARRAY_CUSTOM2:
			return femCast(this)->toArrayCUSTOM2->reverseARRAY();
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayCUSTOM3->reverseARRAY();
		default:
			throw FEMException();
	}
}

inline bool FEMArrayBASE_hash(PVOID _target, FEMValue const& _value) { // DONE
	SUCHash* _result = (SUCHash*) _target;
	_result->pushHash(_value.hash());
	return true;
}

inline INT32 FEMArrayBASE::hashARRAY() const { // DONE
	SUCHash _result;
	extractBASE(&_result, FEMArrayBASE_hash, 0, arrayLength, true);
	return _result;
}

inline bool FEMArrayBASE_script(PVOID _context, FEMValue const& _value) { // DONE
	FEMString* _result = (FEMString*) _context;
	*_result = _result->concat(_value.toScript()).concat(_FEMArrayBASE_SCRIPT_COMMA_);
	return true;
}

inline FEMString FEMArrayBASE::scriptARRAY() const { // DONE
	FEMString _result = _FEMArrayBASE_SCRIPT_OPEN_;
	extractBASE(&_result, FEMArrayBASE_script, 0, arrayLength, true);
	return _result.section(0, _result.length() - _FEMArrayBASE_SCRIPT_COMMA_.length()).concat(_FEMArrayBASE_SCRIPT_CLOSE_);
}

inline bool FEMArrayBASE::equalsARRAY(FEMArrayBASE const& _that) const { // DONE
	INT32 _length = arrayLength;
	if (_that.arrayLength != _length) return false;
	for (INT32 _index = 0; _index < _length; _index++) {
		FEMValue _thisValue = getBASE(_index);
		FEMValue _thatValue = _that.getBASE(_index);
		if (!_thisValue.equals(_thatValue)) return false;
	}
	return true;
}

inline bool FEMArrayBASE::extractARRAY(PVOID _target, FEMArray::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const { // DONE
	if (_foreward) {
		for (_length += _offset; _offset < _length; _offset++) {
			if (!_collector(_target, getBASE(_offset))) return false;
		}
	} else {
		for (_length += _offset - 1; _offset <= _length; _length--) {
			if (!_collector(_target, getBASE(_length))) return false;
		}
	}
	return true;
}

inline FEMArray FEMArrayBASE::sectionARRAY(INT32 const _offset, INT32 const _length) const { // DONE
	FEMArrayBASE const* _this = this;
	FEMArraySECTION* _result = new FEMArraySECTION(*femCast(&_this)->toArray, _offset, _length);
	return FEMArray(*femCast(&_result)->toArray);
}

inline FEMArray FEMArrayBASE::compactARRAY() const { // DONE
	FEMArrayBASE const* _this = this;
	return FEMArray::from(femCast(&_this)->toArray->value());
}

inline FEMArray FEMArrayBASE::reverseARRAY() const { // DONE
	FEMArrayBASE const* _this = this;
	FEMArrayREVERSE* _result = new FEMArrayREVERSE(*femCast(&_this)->toArray);
	return FEMArray(*femCast(&_result)->toArray);
}

struct __________;

inline FEMArrayVALUE::FEMArrayVALUE(INT32 const _arrayLength) // DONE
		: FEMArrayBASE(ARRAY_VALUE, _arrayLength) {
	setupArray<FEMValue>(valueArray, _arrayLength);
}

inline FEMArrayVALUE::FEMArrayVALUE(FEMValue const* _valueArray, INT32 const _valueCount) // DONE
		: FEMArrayBASE(ARRAY_VALUE, _valueCount) {
	setupArray<FEMValue, FEMValue>(_valueArray, valueArray, _valueCount);
}

inline FEMArrayVALUE::~FEMArrayVALUE() { // DONE
	resetArray<FEMValue>(valueArray, arrayLength);
}

inline FEMValue FEMArrayVALUE::getVALUE(INT32 const _index) const { // DONE
	return valueArray[_index];
}

inline bool FEMArrayVALUE::extractVALUE(PVOID _target, FEMArray::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const { // DONE
	if (_foreward) {
		for (_length += _offset; _offset < _length; _offset++) {
			if (!_collector(_target, valueArray[_offset])) return false;
		}
	} else {
		for (_length += _offset - 1; _offset <= _length; _length--) {
			if (!_collector(_target, valueArray[_length])) return false;
		}
	}
	return true;
}

inline FEMArray FEMArrayVALUE::compactVALUE() const { // DONE
	FEMArrayVALUE const* _result = this;
	return FEMArray(*femCast(&_result)->toArray);
}

struct __________;

inline FEMArrayCYCLIC::FEMArrayCYCLIC(FEMFrameCYCLIC const& _cyclicFrame) // DONE
		: FEMArrayBASE(ARRAY_CYCLIC, _cyclicFrame.frameSize), cyclicFrame(femCast(&_cyclicFrame)->toFrameOBJ), cyclicPrev(this), cyclicNext(this), cyclicContext(_cyclicFrame.ownerContext) {
	FEMArrayCYCLIC* _cyclicList = &femCast(cyclicContext)->toContextBASE->cyclicList;
	_cyclicList->cyclicNext = ((cyclicNext = (cyclicPrev = _cyclicList)->cyclicNext)->cyclicPrev = this);
	femCast(&_cyclicFrame)->toFrameCYCLIC->cyclicArray = this;
}

inline FEMArrayCYCLIC::FEMArrayCYCLIC(FEMContextBASE const& _ownerContext)
		: FEMArrayBASE(ARRAY_CYCLIC, 0), cyclicFrame(femCast(new FEMFrameCYCLIC(_ownerContext))->toFrameOBJ), cyclicPrev(this), cyclicNext(this), cyclicContext(&_ownerContext) {
}

inline FEMArrayCYCLIC::~FEMArrayCYCLIC() { // DONE
	CSGuard _cyclicGuard = CSGuard(femCast(cyclicContext)->toContextBASE->cyclicSection);
	deleteCYCLIC();
}

inline FEMValue FEMArrayCYCLIC::getCYCLIC(INT32 const _index) const { // DONE
	return femCast(&cyclicFrame)->toPointerAndCastItsTarget->toFrameCYCLIC->getBASE(_index);
}

void FEMArrayCYCLIC::deleteCYCLIC() { // DONE
	(cyclicPrev->cyclicNext = cyclicNext)->cyclicPrev = cyclicPrev;
	cyclicPrev = (cyclicNext = this);
	femCast(&cyclicFrame)->toPointerAndCastItsTarget->toFrameCYCLIC->cyclicArray = 0;
	cyclicFrame = _FEMFrame_EMPTY_;
}

struct __________;

inline FEMArrayCONCAT::FEMArrayCONCAT(INT32 const _arrayLength, FEMArray const& _array1, FEMArray const& _array2) // DONE
		: FEMArrayBASE(ARRAY_CONCAT, _arrayLength), array1(_array1), array2(_array2) {
}

inline FEMValue FEMArrayCONCAT::getCONCAT(INT32 const _index) const { // DONE
	FEMArrayBASE* _array1 = femCast(&array1)->toPointerAndCastItsTarget->toArrayBASE;
	INT32 _index2 = _index - _array1->arrayLength;
	if (_index2 < 0) return _array1->getBASE(_index);
	FEMArrayBASE* _array2 = femCast(&array2)->toPointerAndCastItsTarget->toArrayBASE;
	return _array2->getBASE(_index2);
}

inline bool FEMArrayCONCAT::extractCONCAT(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	FEMArrayBASE* _array1 = femCast(&array1)->toPointerAndCastItsTarget->toArrayBASE;
	FEMArrayBASE* _array2 = femCast(&array2)->toPointerAndCastItsTarget->toArrayBASE;
	INT32 _offset2 = _offset - _array1->arrayLength, _length2 = _offset2 + _length;
	if (_offset2 >= 0) return _array2->extractBASE(_target, _collector, _offset2, _length, _foreward);
	if (_length2 <= 0) return _array1->extractBASE(_target, _collector, _offset, _length, _foreward);
	if (_foreward) {
		if (!_array1->extractBASE(_target, _collector, _offset, -_offset2, true)) return false;
		return _array2->extractBASE(_target, _collector, 0, _length2, true);
	} else {
		if (!_array2->extractBASE(_target, _collector, 0, _length2, false)) return false;
		return _array1->extractBASE(_target, _collector, _offset, -_offset2, false);
	}
}

inline FEMArray FEMArrayCONCAT::sectionCONCAT(INT32 _offset, INT32 _length) const { // DONE
	FEMArrayBASE* _array1 = femCast(&array1)->toPointerAndCastItsTarget->toArrayBASE;
	FEMArrayBASE* _array2 = femCast(&array2)->toPointerAndCastItsTarget->toArrayBASE;
	INT32 _offset2 = _offset - _array1->arrayLength, _length2 = _offset2 + _length;
	if (_offset2 >= 0) return _array2->sectionBASE(_offset2, _length);
	if (_length2 <= 0) return _array1->sectionBASE(_offset, _length);
	return _array1->sectionBASE(_offset, -_offset2).concat(_array2->sectionBASE(0, _length2));
}

struct __________;

inline FEMArraySECTION::FEMArraySECTION(FEMArray const& _array, INT32 const _offset, INT32 const _length) // DONE
		: FEMArrayBASE(ARRAY_SECTION, _length), array(_array), offset(_offset) {
}

inline FEMValue FEMArraySECTION::getSECTION(INT32 const _index) const { // DONE
	return femCast(&array)->toPointerAndCastItsTarget->toArrayBASE->getBASE(_index + offset);
}

inline bool FEMArraySECTION::extractSECTION(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	return femCast(&array)->toPointerAndCastItsTarget->toArrayBASE->extractBASE(_target, _collector, offset + _offset, _length, _foreward);
}

inline FEMArray FEMArraySECTION::sectionSECTION(INT32 _offset, INT32 _length) const { // DONE
	return femCast(&array)->toPointerAndCastItsTarget->toArrayBASE->sectionBASE(offset + _offset, _length);
}

struct __________;

inline FEMArrayREVERSE::FEMArrayREVERSE(FEMArray const& _array) // DONE
		: FEMArrayBASE(ARRAY_REVERSE, _array.length()), array(_array) {
}

inline FEMValue FEMArrayREVERSE::getREVERSE(INT32 const _index) const { // DONE
	return femCast(&array)->toPointerAndCastItsTarget->toArrayBASE->getBASE(arrayLength - _index - 1);
}

inline bool FEMArrayREVERSE::extractREVERSE(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	return femCast(&array)->toPointerAndCastItsTarget->toArrayBASE->extractBASE(_target, _collector, arrayLength - _offset - _length, _length, !_foreward);
}

inline FEMArray FEMArrayREVERSE::sectionREVERSE(INT32 _offset, INT32 _length) const { // DONE
	return femCast(&array)->toPointerAndCastItsTarget->toArrayBASE->sectionBASE(arrayLength - _offset - _length, _length).reverse();
}

inline FEMArray FEMArrayREVERSE::reverseREVERSE() const { // DONE
	return array;
}

struct __________;

inline FEMArrayUNIFORM::FEMArrayUNIFORM(FEMValue const& _value, INT32 const _length) // DONE
		: FEMArrayBASE(ARRAY_UNIFORM, _length), value(_value) {
}

inline FEMValue FEMArrayUNIFORM::getUNIFORM(INT32 const _index) const { // DONE
	return value;
}

inline bool FEMArrayUNIFORM::extractUNIFORM(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	for (INT32 i = _length; i > 0; --i) {
		if (!(*_collector)(_target, value)) return false;
	}
	return true;
}

inline FEMArray FEMArrayUNIFORM::sectionUNIFORM(INT32 _offset, INT32 _length) const { // DONE
	FEMArrayUNIFORM* _result = new FEMArrayUNIFORM(value, _length);
	return FEMArray(*femCast(&_result)->toArray);
}

inline FEMArray FEMArrayUNIFORM::compactUNIFORM() const { // DONE
	FEMArrayUNIFORM const* _result = this;
	return FEMArray(*femCast(&_result)->toArray);
}

inline FEMArray FEMArrayUNIFORM::reverseUNIFORM() const { // DONE
	FEMArrayUNIFORM const* _result = this;
	return FEMArray(*femCast(&_result)->toArray);
}

struct __________;

inline FEMArrayCUSTOM1::FEMArrayCUSTOM1() // DONE
		: FEMArrayBASE(ARRAY_CUSTOM1, 0) {
}

inline FEMArrayCUSTOM1::~FEMArrayCUSTOM1() { // DONE
}

inline FEMValue FEMArrayCUSTOM1::getCUSTOM1(INT32 const _index) const { // DONE
	throw FEMException();
}

struct __________;

inline FEMArrayCUSTOM2::FEMArrayCUSTOM2() // DONE
		: FEMArrayBASE(ARRAY_CUSTOM2, 0) {
}

inline FEMArrayCUSTOM2::~FEMArrayCUSTOM2() { // DONE
}

inline FEMValue FEMArrayCUSTOM2::getCUSTOM2(INT32 const _index) const { // DONE
	throw FEMException();
}

struct __________;

inline FEMArrayCUSTOM3::FEMArrayCUSTOM3() // DONE
		: FEMArrayBASE(ARRAY_CUSTOM3, 0) {
}

inline FEMArrayCUSTOM3::~FEMArrayCUSTOM3() { // DONE
}

inline FEMValue FEMArrayCUSTOM3::getCUSTOM3(INT32 const _index) const { // DONE
	throw FEMException();
}

struct __________;

inline static UINT8 _FEMString_UTF8_Size_(UINT8 const _item) {
	switch ((_item >> 4) & 15) {
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
			return 1;
		case 12:
		case 13:
			return 2;
		case 14:
			return 3;
		case 15:
			return 4;
	}
	throw FEMException();
}

inline static bool _FEMString_UTF8_Start_(UINT8 const _item) {
	return (_item & 192) != 128;
}

inline static UINT32 _FEMString_UTF8_Value_(UINT8 const* _itemArray) {
	switch ((_itemArray[0] >> 4) & 15) {
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
			return _itemArray[0] & 127;
		case 12:
		case 13:
			return ((_itemArray[0] & 31) << 6) | (_itemArray[1] & 63);
		case 14:
			return ((_itemArray[0] & 15) << 12) | ((_itemArray[1] & 63) << 6) | (_itemArray[2] & 63);
		case 15:
			return ((_itemArray[0] & 7) << 18) | ((_itemArray[1] & 63) << 12) | ((_itemArray[2] & 63) << 6) | (_itemArray[3] & 63);
	}
	throw FEMException();
}

inline static INT32 _FEMString_UTF8_Count_(UINT8 const* _itemArray, INT32 const _itemCount) {
	INT32 _result = 0;
	UINT8 const* _itemLimit = _itemArray + _itemCount;
	while (_itemArray < _itemLimit) {
		_result++;
		_itemArray += _FEMString_UTF8_Size_(*_itemArray);
	}
	if (_itemArray != _itemLimit) throw FEMException();
	return _result;
}

inline static INT32 _FEMString_UTF16_Size_(UINT16 token) {
	UINT16 value = token & 64512;
	if (value == 55296) return 2;
	if (value != 56320) return 1;
	throw FEMException();
}

inline static bool _FEMString_UTF16_Start_(UINT16 const _item) {
	return (_item & 64512) != 56320;
}

inline static UINT32 _FEMString_UTF16_Value_(UINT16 const* _itemArray) {
	int token = _itemArray[0], value = token & 64512;
	if (value == 55296) return (((token & 1023) << 10) | (_itemArray[1] & 1023)) + 65536;
	if (value != 56320) return token;
	throw FEMException();
}

inline static INT32 _FEMString_UTF16_Count_(UINT16 const* _itemArray, INT32 const _itemCount) {
	INT32 _result = 0;
	UINT16 const* _itemLimit = _itemArray + _itemCount;
	while (_itemArray < _itemLimit) {
		_result++;
		_itemArray += _FEMString_UTF16_Size_(*_itemArray);
	}
	if (_itemArray != _itemLimit) throw FEMException();
	return _result;
}

static FEMStringUNIFORM const* _FEMString_EMPTY_ = new FEMStringUNIFORM(0, 0);

FEMString const FEMString::EMPTY = FEMString(*femCast(&_FEMString_EMPTY_)->toString);

FEMString FEMString::from(BYTES const& _array) { // DONE
	return from(_array.data(), _array.length());
}

FEMString FEMString::from(CHARS const& _array) { // DONE
	return from(_array.data(), _array.length());
}

FEMString FEMString::from(VALUE const& _array) { // DONE
	return from(_array.data(), _array.length());
}

FEMString FEMString::from(UINT32 const _item, INT32 const _itemCount) {
	if (!_itemCount) return EMPTY;
	FEMException::checkCount(_itemCount);
	FEMStringUNIFORM* _result = new FEMStringUNIFORM(_item, _itemCount);
	return FEMString(*femCast(&_result)->toString);
}

FEMString FEMString::from(CHAR const* _string) { // DONE
	FEMException::checkNull(_string);
	return from((UINT8 const*) _string, strlen(_string));
}

FEMString FEMString::from(UINT8 const* _itemArray, INT32 const _itemCount) { // DONE
	FEMException::checkNull(_itemArray);
	FEMException::checkCount(_itemCount);
	INT32 _stringLength = _FEMString_UTF8_Count_(_itemArray, _itemCount);
	if (!_stringLength) return EMPTY;
	if (_stringLength == 1) return from(_FEMString_UTF8_Value_(_itemArray), 1);
	FEMStringBYTES* _result = new (new UINT8[sizeof(FEMStringBYTES) + _stringLength * sizeof(UINT8)]) FEMStringBYTES(_stringLength, _itemArray, _itemCount);
	return FEMString(*femCast(&_result)->toString);
}

FEMString FEMString::from(UINT16 const* _itemArray, INT32 const _itemCount) { // DONE
	FEMException::checkNull(_itemArray);
	FEMException::checkCount(_itemCount);
	INT32 _stringLength = _FEMString_UTF16_Count_(_itemArray, _itemCount);
	if (!_stringLength) return EMPTY;
	if (_stringLength == 1) return from(_FEMString_UTF16_Value_(_itemArray), 1);
	FEMStringCHARS* _result = new (new UINT8[sizeof(FEMStringCHARS) + _stringLength * sizeof(UINT16)]) FEMStringCHARS(_stringLength, _itemArray, _itemCount);
	return FEMString(*femCast(&_result)->toString);
}

FEMString FEMString::from(UINT32 const* _itemArray, INT32 const _itemCount) { // DONE
	FEMException::checkNull(_itemArray);
	FEMException::checkCount(_itemCount);
	if (!_itemCount) return EMPTY;
	if (_itemCount == 1) return from(*_itemArray, 1);
	FEMStringVALUE* _result = new (new UINT8[sizeof(FEMStringVALUE) + _itemCount * sizeof(UINT32)]) FEMStringVALUE(_itemArray, _itemCount);
	return FEMString(*femCast(&_result)->toString);
}

FEMString FEMString::from(FEMString const& _script) { // TODO
	return EMPTY;
}

FEMString::FEMString() // DONE
		: FEMString(EMPTY) {
}

bool FEMString_value(PVOID _target, UINT32 const _value) { // DONE
	UINT32** _cursor = (UINT32**) _target;
	**_cursor = _value;
	*_cursor += 1;
	return true;
}

FEMString::VALUE FEMString::value() const { // DONE
	VALUE _result(length());
	UINT32* _context = _result.data();
	extract(&_context, FEMString_value);
	return _result;
}

UINT32 FEMString::get(INT32 const _index) const {
	FEMStringBASE* _this = femCast(this)->toPointerAndCastItsTarget->toStringBASE;
	FEMException::checkIndex(_index, _this->stringLength);
	return _this->getBASE(_index);
}

INT32 FEMString::length() const {
	return femCast(this)->toPointerAndCastItsTarget->toStringBASE->stringLength;
}

FEMString FEMString::concat(FEMString const& _that) const { // DONE
	INT32 _thisLength = length();
	if (!_thisLength) return _that;
	INT32 _thatLength = _that.length();
	if (!_thatLength) return *this;
	PCVOID _this = new FEMStringCONCAT(_thisLength + _thatLength, *this, _that);
	return FEMString(*femCast(&_this)->toString);
}

FEMString FEMString::section(INT32 const _offset, INT32 const _length) const { // DONE
	FEMStringBASE* _thisString = femCast(this)->toPointerAndCastItsTarget->toStringBASE;
	INT32 _thisLength = _thisString->stringLength;
	if ((_offset == 0) && (_length == _thisLength)) return *this;
	if ((_offset < 0) || (_length < 0) || ((_offset + _length) > _thisLength)) throw FEMException();
	if (_length == 0) return EMPTY;
	return _thisString->sectionBASE(_offset, _length);
}

FEMString FEMString::reverse() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toStringBASE->reverseBASE();
}

FEMString FEMString::compact() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toStringBASE->compactBASE();
}

INT32 FEMString::find(UINT32 const _that, INT32 const _offset) const { // DONE
	struct FEMString_findValue {

		UINT32 value;

		INT32 index;

		FEMString_findValue(UINT32 _value)
				: value(_value), index(0) {
		}

		static bool collector(PVOID _context, UINT32 const _value) {
			FEMString_findValue* _result = (FEMString_findValue*) _context;
			if (_result->value == _value) return false;
			_result->index++;
			return true;
		}

	};
	FEMStringBASE* _thisString = femCast(this)->toPointerAndCastItsTarget->toStringBASE;
	INT32 _length = _thisString->stringLength - _offset;
	if ((_offset < 0) || (_length < 0)) throw FEMException();
	FEMString_findValue _context(_that);
	if (_thisString->extractBASE(&_context, FEMString_findValue::collector, _offset, _length, true)) return -1;
	return _context.index + _offset;
}

INT32 FEMString::find(FEMString const& _that, INT32 const _offset) const {
	FEMStringBASE* _thisString = femCast(this)->toPointerAndCastItsTarget->toStringBASE;
	FEMStringBASE* _thatString = femCast(&_that)->toPointerAndCastItsTarget->toStringBASE;
	if ((_offset < 0) || (_offset > _thisString->stringLength)) throw FEMException();
	INT32 _thatLength = _thatString->stringLength;
	if (_thatLength == 0) return _offset;
	INT32 _thisLength = _thisString->stringLength - _thatLength;
	UINT32 _thatValue = _thatString->getBASE(0);
	for (int _thisIndex = _offset; _thisIndex < _thisLength; _thisIndex++) {
		if (_thatValue == _thisString->getBASE(_thisIndex)) {
			for (int _thatIndex = 1; _thatIndex < _thatLength; _thatIndex++) {
				if (!_thisString->getBASE(_thisIndex + _thatIndex) == _thatString->getBASE(_thatIndex)) {
					goto FIND;
				}
			}
			return _thisIndex;
		}
		FIND: ;
	}
	return -1;

}

bool FEMString::extract(PVOID _target, COLLECTOR _collector) const { // DONE
	FEMStringBASE* _thisString = femCast(this)->toPointerAndCastItsTarget->toStringBASE;
	return _thisString->extractBASE(_target, _collector, 0, _thisString->stringLength, true);
}

INT32 FEMString::compare(FEMString const& _that) const {
	FEMStringBASE* _thisString = femCast(this)->toPointerAndCastItsTarget->toStringBASE;
	FEMStringBASE* _thatString = femCast(&_that)->toPointerAndCastItsTarget->toStringBASE;
	INT32 _thisLength = _thisString->stringLength;
	INT32 _thatLength = _thatString->stringLength;
	INT32 _length = _thisLength < _thatLength ? _thisLength : _thatLength;
	for (INT32 _index = 0; _index < _length; _index++) {
		UINT32 _thisValue = _thisString->getBASE(_index);
		UINT32 _thatValue = _thatString->getBASE(_index);
		INT32 _result = _thisValue - _thatValue;
		if (_result < 0) return -1;
		if (_result > 0) return +1;
	}
	INT32 _result = _thisLength - _thatLength;
	if (_result < 0) return -1;
	if (_result > 0) return +1;
	return 0;
}

FEMString::BYTES FEMString::toBytes() const { // TODO
	// länge berechnen, alloc, extraxt
	BYTES _result;
	return _result;
}

FEMString::CHARS FEMString::toChars() const { // TODO
	// länge berechnen, alloc, extraxt
	CHARS _result;
	return _result;
}

struct __________;

inline FEMStringBASE::FEMStringBASE(DATA_TYPE const _dataType, INT32 const _stringLength) // DONE
		: FEMValueBASE(_dataType), stringLength(_stringLength) {
}

inline UINT32 FEMStringBASE::getBASE(INT32 const _index) const { // DONE
	switch (dataType) {
		case STRING_BYTES:
			return femCast(this)->toStringBYTES->getBYTES(_index);
		case STRING_CHARS:
			return femCast(this)->toStringCHARS->getCHARS(_index);
		case STRING_VALUE:
			return femCast(this)->toStringVALUE->getVALUE(_index);
		case STRING_CONCAT:
			return femCast(this)->toStringCONCAT->getCONCAT(_index);
		case STRING_SECTION:
			return femCast(this)->toStringSECTION->getSECTION(_index);
		case STRING_REVERSE:
			return femCast(this)->toStringREVERSE->getREVERSE(_index);
		case STRING_UNIFORM:
			return femCast(this)->toStringUNIFORM->getUNIFORM(_index);
		case STRING_CUSTOM1:
			return femCast(this)->toStringCUSTOM1->getCUSTOM1(_index);
		case STRING_CUSTOM2:
			return femCast(this)->toStringCUSTOM2->getCUSTOM2(_index);
		case STRING_CUSTOM3:
			return femCast(this)->toStringCUSTOM3->getCUSTOM3(_index);
		default:
			throw FEMException();
	}
}

inline bool FEMStringBASE::extractBASE(PVOID _target, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	switch (dataType) {
		case STRING_BYTES:
			return femCast(this)->toStringBYTES->extractBYTES(_target, _collector, _offset, _length, _foreward);
		case STRING_CHARS:
			return femCast(this)->toStringCHARS->extractCHARS(_target, _collector, _offset, _length, _foreward);
		case STRING_VALUE:
			return femCast(this)->toStringVALUE->extractVALUE(_target, _collector, _offset, _length, _foreward);
		case STRING_CONCAT:
			return femCast(this)->toStringCONCAT->extractCONCAT(_target, _collector, _offset, _length, _foreward);
		case STRING_SECTION:
			return femCast(this)->toStringSECTION->extractSECTION(_target, _collector, _offset, _length, _foreward);
		case STRING_REVERSE:
			return femCast(this)->toStringREVERSE->extractREVERSE(_target, _collector, _offset, _length, _foreward);
		case STRING_UNIFORM:
			return femCast(this)->toStringUNIFORM->extractUNIFORM(_target, _collector, _offset, _length, _foreward);
		case STRING_CUSTOM1:
			return femCast(this)->toStringCUSTOM1->extractSTRING(_target, _collector, _offset, _length, _foreward);
		case STRING_CUSTOM2:
			return femCast(this)->toStringCUSTOM2->extractSTRING(_target, _collector, _offset, _length, _foreward);
		case STRING_CUSTOM3:
			return femCast(this)->toStringCUSTOM3->extractSTRING(_target, _collector, _offset, _length, _foreward);
		default:
			throw FEMException();
	}
}

inline FEMString FEMStringBASE::sectionBASE(INT32 const _offset, INT32 const _length) const { // DONE
	switch (dataType) {
		case STRING_BYTES:
			return femCast(this)->toStringBYTES->sectionSTRING(_offset, _length);
		case STRING_CHARS:
			return femCast(this)->toStringCHARS->sectionSTRING(_offset, _length);
		case STRING_VALUE:
			return femCast(this)->toStringVALUE->sectionSTRING(_offset, _length);
		case STRING_CONCAT:
			return femCast(this)->toStringCONCAT->sectionCONCAT(_offset, _length);
		case STRING_SECTION:
			return femCast(this)->toStringSECTION->sectionSECTION(_offset, _length);
		case STRING_REVERSE:
			return femCast(this)->toStringREVERSE->sectionREVERSE(_offset, _length);
		case STRING_UNIFORM:
			return femCast(this)->toStringUNIFORM->sectionUNIFORM(_offset, _length);
		case STRING_CUSTOM1:
			return femCast(this)->toStringCUSTOM1->sectionSTRING(_offset, _length);
		case STRING_CUSTOM2:
			return femCast(this)->toStringCUSTOM2->sectionSTRING(_offset, _length);
		case STRING_CUSTOM3:
			return femCast(this)->toStringCUSTOM3->sectionSTRING(_offset, _length);
		default:
			throw FEMException();
	}
}

inline FEMString FEMStringBASE::compactBASE() const { // DONE
	switch (dataType) {
		case STRING_BYTES:
			return femCast(this)->toStringBYTES->compactSTRING();
		case STRING_CHARS:
			return femCast(this)->toStringCHARS->compactSTRING();
		case STRING_VALUE:
			return femCast(this)->toStringVALUE->compactVALUE();
		case STRING_CONCAT:
			return femCast(this)->toStringCONCAT->compactSTRING();
		case STRING_SECTION:
			return femCast(this)->toStringSECTION->compactSTRING();
		case STRING_REVERSE:
			return femCast(this)->toStringREVERSE->compactSTRING();
		case STRING_UNIFORM:
			return femCast(this)->toStringUNIFORM->compactUNIFORM();
		case STRING_CUSTOM1:
			return femCast(this)->toStringCUSTOM1->compactSTRING();
		case STRING_CUSTOM2:
			return femCast(this)->toStringCUSTOM2->compactSTRING();
		case STRING_CUSTOM3:
			return femCast(this)->toStringCUSTOM3->compactSTRING();
		default:
			throw FEMException();
	}
}

inline FEMString FEMStringBASE::reverseBASE() const { // DONE
	switch (dataType) {
		case STRING_BYTES:
			return femCast(this)->toStringBYTES->reverseSTRING();
		case STRING_CHARS:
			return femCast(this)->toStringCHARS->reverseSTRING();
		case STRING_VALUE:
			return femCast(this)->toStringVALUE->reverseSTRING();
		case STRING_CONCAT:
			return femCast(this)->toStringCONCAT->reverseSTRING();
		case STRING_SECTION:
			return femCast(this)->toStringSECTION->reverseSTRING();
		case STRING_REVERSE:
			return femCast(this)->toStringREVERSE->reverseREVERSE();
		case STRING_UNIFORM:
			return femCast(this)->toStringUNIFORM->reverseUNIFORM();
		case STRING_CUSTOM1:
			return femCast(this)->toStringCUSTOM1->reverseSTRING();
		case STRING_CUSTOM2:
			return femCast(this)->toStringCUSTOM2->reverseSTRING();
		case STRING_CUSTOM3:
			return femCast(this)->toStringCUSTOM3->reverseSTRING();
		default:
			throw FEMException();
	}
}

inline bool FEMStringBASE_hash(PVOID _context, UINT32 const _value) { // DONE
	SUCHash* _result = (SUCHash*) _context;
	_result->pushHash(_value);
	return true;
}

inline INT32 FEMStringBASE::hashSTRING() const { // DONE
	SUCHash _result;
	extractBASE(&_result, FEMStringBASE_hash, 0, stringLength, true);
	return _result;
}

inline bool FEMStringBASE_scriptCount(PVOID _context, UINT32 const _value) {
	INT32* _cursor = (INT32*) _context;
	switch (_value) {
		case '\"':
		case '\\':
		case '\r':
		case '\n':
		case '\t':
			++*_cursor;
	}
	return true;
}

inline bool FEMStringBASE_scriptWrite(PVOID _context, UINT32 const _value) {
	UINT32** _cursor = (UINT32**) _context;
	switch (_value) {
		case '\"':
			**_cursor = '\\';
			++*_cursor;
			**_cursor = '\"';
			++*_cursor;
			return true;
		case '\\':
			**_cursor = '\\';
			++*_cursor;
			**_cursor = '\\';
			++*_cursor;
			return true;
		case '\r':
			**_cursor = '\\';
			++*_cursor;
			**_cursor = 'r';
			++*_cursor;
			return true;
		case '\n':
			**_cursor = '\\';
			++*_cursor;
			**_cursor = 'n';
			++*_cursor;
			return true;
		case '\t':
			**_cursor = '\\';
			++*_cursor;
			**_cursor = 't';
			++*_cursor;
			return true;
		default:
			**_cursor = _value;
			++*_cursor;
			return true;
	}
}

inline FEMString FEMStringBASE::scriptSTRING() const { // DONE
	INT32 _thisLength = stringLength, _thatLength = _thisLength + 2;
	extractBASE(&_thatLength, FEMStringBASE_scriptCount, 0, _thisLength, true);
	FEMStringVALUE* _result = new FEMStringVALUE(_thatLength);
	_result->itemArray[0] = '\"';
	_result->itemArray[_thatLength - 1] = '\"';
	extractBASE(_result->itemArray + 1, FEMStringBASE_scriptWrite, 0, _thisLength, true);
	return FEMString(*femCast(&_result)->toString);
}

inline bool FEMStringBASE::equalsSTRING(FEMStringBASE const& _that) const { // DONE
	INT32 _length = stringLength;
	if (_that.stringLength != _length) return false;
	for (INT32 _index = 0; _index < _length; _index++) {
		UINT32 _thisValue = getBASE(_index);
		UINT32 _thatValue = _that.getBASE(_index);
		if (_thisValue != _thatValue) return false;
	}
	return true;
}

inline bool FEMStringBASE::extractSTRING(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const { // DONE
	if (_foreward) {
		for (_length += _offset; _offset < _length; _offset++) {
			if (!_collector(_context, getBASE(_offset))) return false;
		}
	} else {
		for (_length += _offset - 1; _offset <= _length; _length--) {
			if (!_collector(_context, getBASE(_length))) return false;
		}
	}
	return true;
}

inline FEMString FEMStringBASE::sectionSTRING(INT32 const _offset, INT32 const _length) const { // DONE
	FEMStringBASE const* _this = this;
	FEMStringSECTION* _result = new FEMStringSECTION(*femCast(&_this)->toString, _offset, _length);
	return FEMString(*femCast(&_result)->toString);
}

inline FEMString FEMStringBASE::compactSTRING() const { // DONE
	FEMStringBASE const* _this = this;
	return FEMString::from(femCast(&_this)->toString->value()); // TODO faster
}

inline FEMString FEMStringBASE::reverseSTRING() const { // DONE
	FEMStringBASE const* _this = this;
	FEMStringREVERSE* _result = new FEMStringREVERSE(*femCast(&_this)->toString);
	return FEMString(*femCast(&_result)->toString);
}

struct __________;

FEMStringBYTES::FEMStringBYTES(INT32 const _stringLength, UINT8 const* _itemArray, INT32 const _itemCount)
		: FEMStringBASE(STRING_BYTES, _stringLength) {
	memcpy(itemArray, _itemArray, _itemCount * sizeof(UINT8));
}

UINT32 FEMStringBYTES::getBYTES(INT32 _index) const {
	int _offset = 0;
	while (_index > 0) {
		_index--;
		_offset += _FEMString_UTF8_Size_(itemArray[_offset]);
	}
	return _FEMString_UTF8_Value_(itemArray + _offset);
}

bool FEMStringBYTES::extractBYTES(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const {
	if (_foreward) {
		UINT8 const* _array = itemArray;
		while (_offset > 0) {
			_offset--;
			_array += _FEMString_UTF8_Size_(*_array);
		}
		while (_length > 0) {
			if (!_collector(_context, _FEMString_UTF8_Value_(_array))) return false;
			_length--;
			_array += _FEMString_UTF8_Size_(*_array);
		}
	} else {
		UINT8 const* _array = itemArray;
		_offset += _length;
		while (_offset > 0) {
			_offset--;
			_array += _FEMString_UTF8_Size_(*_array);
		}
		while (_length > 0) {
			while (!_FEMString_UTF8_Start_(*(--_array))) {
			}
			if (!_collector(_context, _FEMString_UTF8_Value_(_array))) return false;
			_length--;
		}
	}
	return true;
}

struct __________;

FEMStringCHARS::FEMStringCHARS(INT32 const _stringLength, UINT16 const* _itemArray, INT32 const _itemCount)
		: FEMStringBASE(STRING_CHARS, _stringLength) {
	memcpy(itemArray, _itemArray, _itemCount * sizeof(UINT16));
}

UINT32 FEMStringCHARS::getCHARS(INT32 _index) const {
	int _offset = 0;
	while (_index > 0) {
		_index--;
		_offset += _FEMString_UTF16_Size_(itemArray[_offset]);
	}
	return _FEMString_UTF16_Value_(itemArray + _offset);
}

bool FEMStringCHARS::extractCHARS(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const {
	if (_foreward) {
		UINT16 const* _array = itemArray;
		while (_offset > 0) {
			_offset--;
			_array += _FEMString_UTF8_Size_(*_array);
		}
		while (_length > 0) {
			if (!_collector(_context, _FEMString_UTF16_Value_(_array))) return false;
			_length--;
			_array += _FEMString_UTF16_Size_(*_array);
		}
	} else {
		UINT16 const* _array = itemArray;
		_offset += _length;
		while (_offset > 0) {
			_offset--;
			_array += _FEMString_UTF16_Size_(*_array);
		}
		while (_length > 0) {
			while (!_FEMString_UTF16_Start_(*(--_array))) {
			}
			if (!_collector(_context, _FEMString_UTF16_Value_(_array))) return false;
			_length--;
		}
	}
	return true;
}

struct __________;

inline FEMStringVALUE::FEMStringVALUE(INT32 const _length)
		: FEMStringBASE(STRING_VALUE, _length) {
}

inline FEMStringVALUE::FEMStringVALUE(UINT32 const* _itemArray, INT32 const _itemCount)
		: FEMStringBASE(STRING_VALUE, _itemCount) {
	memcpy(itemArray, _itemArray, _itemCount * sizeof(UINT32));
}

inline UINT32 FEMStringVALUE::getVALUE(INT32 const _index) const {
	return itemArray[_index];
}

inline bool FEMStringVALUE::extractVALUE(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const {
	if (_foreward) {
		for (_length += _offset; _offset < _length; _offset++) {
			if (!_collector(_context, itemArray[_offset])) return false;
		}
	} else {
		for (_length += _offset - 1; _offset <= _length; _length--) {
			if (!_collector(_context, itemArray[_length])) return false;
		}
	}
	return true;
}

inline FEMString FEMStringVALUE::compactVALUE() const {
	FEMStringVALUE const* _result = this;
	return FEMString(*femCast(&_result)->toString);
}

struct __________;

inline FEMStringCONCAT::FEMStringCONCAT(INT32 const _stringLength, FEMString const& _string1, FEMString const& _string2)
		: FEMStringBASE(STRING_CONCAT, _stringLength), string1(_string1), string2(_string2) {
}

inline UINT32 FEMStringCONCAT::getCONCAT(INT32 const _index) const {
	FEMStringBASE* _string1 = femCast(&string1)->toPointerAndCastItsTarget->toStringBASE;
	INT32 _index2 = _index - _string1->stringLength;
	if (_index2 < 0) return _string1->getBASE(_index);
	FEMStringBASE* _string2 = femCast(&string2)->toPointerAndCastItsTarget->toStringBASE;
	return _string2->getBASE(_index2);
}

inline bool FEMStringCONCAT::extractCONCAT(PVOID _context, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const {
	FEMStringBASE* _string1 = femCast(&string1)->toPointerAndCastItsTarget->toStringBASE;
	FEMStringBASE* _string2 = femCast(&string2)->toPointerAndCastItsTarget->toStringBASE;
	INT32 _offset2 = _offset - _string1->stringLength, _length2 = _offset2 + _length;
	if (_offset2 >= 0) return _string2->extractBASE(_context, _collector, _offset2, _length, _foreward);
	if (_length2 <= 0) return _string1->extractBASE(_context, _collector, _offset, _length, _foreward);
	if (_foreward) {
		if (!_string1->extractBASE(_context, _collector, _offset, -_offset2, true)) return false;
		return _string2->extractBASE(_context, _collector, 0, _length2, true);
	} else {
		if (!_string2->extractBASE(_context, _collector, 0, _length2, false)) return false;
		return _string1->extractBASE(_context, _collector, _offset, -_offset2, false);
	}
}

inline FEMString FEMStringCONCAT::sectionCONCAT(INT32 const _offset, INT32 const _length) const {
	FEMStringBASE* _string1 = femCast(&string1)->toPointerAndCastItsTarget->toStringBASE;
	FEMStringBASE* _string2 = femCast(&string2)->toPointerAndCastItsTarget->toStringBASE;
	INT32 _offset2 = _offset - _string1->stringLength, _length2 = _offset2 + _length;
	if (_offset2 >= 0) return _string2->sectionBASE(_offset2, _length);
	if (_length2 <= 0) return _string1->sectionBASE(_offset, _length);
	return _string1->sectionBASE(_offset, -_offset2).concat(_string2->sectionBASE(0, _length2));
}

struct __________;

inline FEMStringSECTION::FEMStringSECTION(FEMString const& _string, INT32 const _offset, INT32 const _length)
		: FEMStringBASE(STRING_SECTION, _length), string(_string), offset(_offset) {
}

inline UINT32 FEMStringSECTION::getSECTION(INT32 const _index) const { // DONE
	return femCast(&string)->toPointerAndCastItsTarget->toStringBASE->getBASE(_index + offset);
}

inline bool FEMStringSECTION::extractSECTION(PVOID _target, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	return femCast(&string)->toPointerAndCastItsTarget->toStringBASE->extractBASE(_target, _collector, offset + _offset, _length, _foreward);
}

inline FEMString FEMStringSECTION::sectionSECTION(INT32 _offset, INT32 _length) const { // DONE
	return femCast(&string)->toPointerAndCastItsTarget->toStringBASE->sectionBASE(offset + _offset, _length);
}

struct __________;

inline FEMStringREVERSE::FEMStringREVERSE(FEMString const& _string)
		: FEMStringBASE(STRING_REVERSE, _string.length()), string(_string) {
}

inline UINT32 FEMStringREVERSE::getREVERSE(INT32 const _index) const { // DONE
	return femCast(&string)->toPointerAndCastItsTarget->toStringBASE->getBASE(stringLength - _index - 1);
}

inline bool FEMStringREVERSE::extractREVERSE(PVOID _target, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	return femCast(&string)->toPointerAndCastItsTarget->toStringBASE->extractBASE(_target, _collector, stringLength - _offset - _length, _length, !_foreward);
}

inline FEMString FEMStringREVERSE::sectionREVERSE(INT32 _offset, INT32 _length) const { // DONE
	return femCast(&string)->toPointerAndCastItsTarget->toStringBASE->sectionBASE(stringLength - _offset - _length, _length).reverse();
}

inline FEMString FEMStringREVERSE::reverseREVERSE() const { // DONE
	return string;
}

struct __________;

inline FEMStringUNIFORM::FEMStringUNIFORM(UINT32 const& _value, INT32 const _stringLength)
		: FEMStringBASE(STRING_UNIFORM, _stringLength), value(_value) {
}

inline UINT32 FEMStringUNIFORM::getUNIFORM(INT32 const _index) const { // DONE
	return value;
}

inline bool FEMStringUNIFORM::extractUNIFORM(PVOID _target, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	for (INT32 i = _length; i > 0; --i) {
		if (!(*_collector)(_target, value)) return false;
	}
	return true;
}

inline FEMString FEMStringUNIFORM::sectionUNIFORM(INT32 const _offset, INT32 const _length) const { // DONE
	FEMStringUNIFORM* _result = new FEMStringUNIFORM(value, _length);
	return FEMString(*femCast(&_result)->toString);
}

inline FEMString FEMStringUNIFORM::compactUNIFORM() const { // DONE
	FEMStringUNIFORM const* _result = this;
	return FEMString(*femCast(&_result)->toString);
}

inline FEMString FEMStringUNIFORM::reverseUNIFORM() const { // DONE
	FEMStringUNIFORM const* _result = this;
	return FEMString(*femCast(&_result)->toString);
}

struct __________;

inline FEMStringCUSTOM1::FEMStringCUSTOM1()
		: FEMStringBASE(STRING_CUSTOM1, 0) {
}

inline UINT32 FEMStringCUSTOM1::getCUSTOM1(INT32 const _index) const {
	return 0;
}

struct __________;

inline FEMStringCUSTOM2::FEMStringCUSTOM2()
		: FEMStringBASE(STRING_CUSTOM2, 0) {
}

inline UINT32 FEMStringCUSTOM2::getCUSTOM2(INT32 const _index) const {
	return 0;
}

struct __________;

inline FEMStringCUSTOM3::FEMStringCUSTOM3()
		: FEMStringBASE(STRING_CUSTOM3, 0) {
}

inline UINT32 FEMStringCUSTOM3::getCUSTOM3(INT32 const _index) const {
	return 0;
}

struct __________;

inline FEMBinaryBASE::FEMBinaryBASE(DATA_TYPE const _dataType, INT32 const _binaryLength) // DONE
		: FEMValueBASE(_dataType), binaryLength(_binaryLength) {
}

inline UINT32 FEMBinaryBASE::getBASE(INT32 const _index) const { // DONE
	switch (dataType) {
		case BINARY_VALUE:
			return femCast(this)->toBinaryVALUE->getVALUE(_index);
		case BINARY_CONCAT:
			return femCast(this)->toBinaryCONCAT->getCONCAT(_index);
		case BINARY_SECTION:
			return femCast(this)->toBinarySECTION->getSECTION(_index);
		case BINARY_REVERSE:
			return femCast(this)->toBinaryREVERSE->getREVERSE(_index);
		case BINARY_UNIFORM:
			return femCast(this)->toBinaryUNIFORM->getUNIFORM(_index);
		case BINARY_CUSTOM1:
			return femCast(this)->toBinaryCUSTOM1->getCUSTOM1(_index);
		case BINARY_CUSTOM2:
			return femCast(this)->toBinaryCUSTOM2->getCUSTOM2(_index);
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryCUSTOM3->getCUSTOM3(_index);
		default:
			throw FEMException();
	}
}

inline bool FEMBinaryBASE::extractBASE(PVOID _target, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	switch (dataType) {
		case BINARY_VALUE:
			return femCast(this)->toBinaryVALUE->extractVALUE(_target, _collector, _offset, _length, _foreward);
		case BINARY_CONCAT:
			return femCast(this)->toBinaryCONCAT->extractCONCAT(_target, _collector, _offset, _length, _foreward);
		case BINARY_SECTION:
			return femCast(this)->toBinarySECTION->extractSECTION(_target, _collector, _offset, _length, _foreward);
		case BINARY_REVERSE:
			return femCast(this)->toBinaryREVERSE->extractREVERSE(_target, _collector, _offset, _length, _foreward);
		case BINARY_UNIFORM:
			return femCast(this)->toBinaryUNIFORM->extractUNIFORM(_target, _collector, _offset, _length, _foreward);
		case BINARY_CUSTOM1:
			return femCast(this)->toBinaryCUSTOM1->extractBINARY(_target, _collector, _offset, _length, _foreward);
		case BINARY_CUSTOM2:
			return femCast(this)->toBinaryCUSTOM2->extractBINARY(_target, _collector, _offset, _length, _foreward);
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryCUSTOM3->extractBINARY(_target, _collector, _offset, _length, _foreward);
		default:
			throw FEMException();
	}
}

inline FEMBinary FEMBinaryBASE::sectionBASE(INT32 const _offset, INT32 const _length) const { // DONE
	switch (dataType) {
		case BINARY_VALUE:
			return femCast(this)->toBinaryVALUE->sectionBINARY(_offset, _length);
		case BINARY_CONCAT:
			return femCast(this)->toBinaryCONCAT->sectionCONCAT(_offset, _length);
		case BINARY_SECTION:
			return femCast(this)->toBinarySECTION->sectionSECTION(_offset, _length);
		case BINARY_REVERSE:
			return femCast(this)->toBinaryREVERSE->sectionREVERSE(_offset, _length);
		case BINARY_UNIFORM:
			return femCast(this)->toBinaryUNIFORM->sectionUNIFORM(_offset, _length);
		case BINARY_CUSTOM1:
			return femCast(this)->toBinaryCUSTOM1->sectionBINARY(_offset, _length);
		case BINARY_CUSTOM2:
			return femCast(this)->toBinaryCUSTOM2->sectionBINARY(_offset, _length);
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryCUSTOM3->sectionBINARY(_offset, _length);
		default:
			throw FEMException();
	}
}

inline FEMBinary FEMBinaryBASE::compactBASE() const { // DONE
	switch (dataType) {
		case BINARY_VALUE:
			return femCast(this)->toBinaryVALUE->compactVALUE();
		case BINARY_CONCAT:
			return femCast(this)->toBinaryCONCAT->compactBINARY();
		case BINARY_SECTION:
			return femCast(this)->toBinarySECTION->compactBINARY();
		case BINARY_REVERSE:
			return femCast(this)->toBinaryREVERSE->compactBINARY();
		case BINARY_UNIFORM:
			return femCast(this)->toBinaryUNIFORM->compactUNIFORM();
		case BINARY_CUSTOM1:
			return femCast(this)->toBinaryCUSTOM1->compactBINARY();
		case BINARY_CUSTOM2:
			return femCast(this)->toBinaryCUSTOM2->compactBINARY();
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryCUSTOM3->compactBINARY();
		default:
			throw FEMException();
	}
}

inline FEMBinary FEMBinaryBASE::reverseBASE() const { // DONE
	switch (dataType) {
		case BINARY_VALUE:
			return femCast(this)->toBinaryVALUE->reverseBINARY();
		case BINARY_CONCAT:
			return femCast(this)->toBinaryCONCAT->reverseBINARY();
		case BINARY_SECTION:
			return femCast(this)->toBinarySECTION->reverseBINARY();
		case BINARY_REVERSE:
			return femCast(this)->toBinaryREVERSE->reverseREVERSE();
		case BINARY_UNIFORM:
			return femCast(this)->toBinaryUNIFORM->reverseUNIFORM();
		case BINARY_CUSTOM1:
			return femCast(this)->toBinaryCUSTOM1->reverseBINARY();
		case BINARY_CUSTOM2:
			return femCast(this)->toBinaryCUSTOM2->reverseBINARY();
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryCUSTOM3->reverseBINARY();
		default:
			throw FEMException();
	}
}

inline bool FEMBinaryBASE_hash(PVOID _context, UINT8 const _value) { // DONE
	SUCHash* _result = (SUCHash*) _context;
	_result->pushHash(_value);
	return true;
}

inline INT32 FEMBinaryBASE::hashBINARY() const { // DONE
	SUCHash _result;
	extractBASE(&_result, FEMBinaryBASE_hash, 0, binaryLength, true);
	return _result;
}

inline bool FEMBinaryBASE_scriptWrite(PVOID _context, UINT8 const _value) {
	UINT8** _cursor = (UINT8**) _context;
	// TODO hex
	**_cursor = '\\';
	++*_cursor;
	**_cursor = '\"';
	++*_cursor;
	return true;
}

inline FEMString FEMBinaryBASE::scriptBINARY() const { // DONE
//TODO	return FEMBinary(*femCast(&_result)->toBinary);
	return FEMString();

}

inline bool FEMBinaryBASE::equalsBINARY(FEMBinaryBASE const& _that) const { // DONE
	INT32 _length = binaryLength;
	if (_that.binaryLength != _length) return false;
	for (INT32 _index = 0; _index < _length; _index++) {
		UINT32 _thisValue = getBASE(_index);
		UINT32 _thatValue = _that.getBASE(_index);
		if (_thisValue != _thatValue) return false;
	}
	return true;
}

inline bool FEMBinaryBASE::extractBINARY(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const { // DONE
	if (_foreward) {
		for (_length += _offset; _offset < _length; _offset++) {
			if (!_collector(_context, getBASE(_offset))) return false;
		}
	} else {
		for (_length += _offset - 1; _offset <= _length; _length--) {
			if (!_collector(_context, getBASE(_length))) return false;
		}
	}
	return true;
}

inline FEMBinary FEMBinaryBASE::sectionBINARY(INT32 const _offset, INT32 const _length) const { // DONE
	FEMBinaryBASE const* _this = this;
	FEMBinarySECTION* _result = new FEMBinarySECTION(*femCast(&_this)->toBinary, _offset, _length);
	return FEMBinary(*femCast(&_result)->toBinary);
}

inline FEMBinary FEMBinaryBASE::compactBINARY() const { // DONE
	FEMBinaryBASE const* _this = this;
	return FEMBinary::from(femCast(&_this)->toBinary->value()); // TODO faster
}

inline FEMBinary FEMBinaryBASE::reverseBINARY() const { // DONE
	FEMBinaryBASE const* _this = this;
	FEMBinaryREVERSE* _result = new FEMBinaryREVERSE(*femCast(&_this)->toBinary);
	return FEMBinary(*femCast(&_result)->toBinary);
}

struct __________;

inline FEMBinaryVALUE::FEMBinaryVALUE(INT32 const _length)
		: FEMBinaryBASE(BINARY_VALUE, _length) {
}

inline FEMBinaryVALUE::FEMBinaryVALUE(UINT32 const* _itemArray, INT32 const _itemCount)
		: FEMBinaryBASE(BINARY_VALUE, _itemCount) {
	memcpy(itemArray, _itemArray, _itemCount * sizeof(UINT32));
}

inline UINT32 FEMBinaryVALUE::getVALUE(INT32 const _index) const {
	return itemArray[_index];
}

inline bool FEMBinaryVALUE::extractVALUE(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const {
	if (_foreward) {
		for (_length += _offset; _offset < _length; _offset++) {
			if (!_collector(_context, itemArray[_offset])) return false;
		}
	} else {
		for (_length += _offset - 1; _offset <= _length; _length--) {
			if (!_collector(_context, itemArray[_length])) return false;
		}
	}
	return true;
}

inline FEMBinary FEMBinaryVALUE::compactVALUE() const {
	FEMBinaryVALUE const* _result = this;
	return FEMBinary(*femCast(&_result)->toBinary);
}

struct __________;

inline FEMBinaryCONCAT::FEMBinaryCONCAT(INT32 const _binaryLength, FEMBinary const& _binary1, FEMBinary const& _binary2)
		: FEMBinaryBASE(BINARY_CONCAT, _binaryLength), binary1(_binary1), binary2(_binary2) {
}

inline UINT32 FEMBinaryCONCAT::getCONCAT(INT32 const _index) const {
	FEMBinaryBASE* _binary1 = femCast(&binary1)->toPointerAndCastItsTarget->toBinaryBASE;
	INT32 _index2 = _index - _binary1->binaryLength;
	if (_index2 < 0) return _binary1->getBASE(_index);
	FEMBinaryBASE* _binary2 = femCast(&binary2)->toPointerAndCastItsTarget->toBinaryBASE;
	return _binary2->getBASE(_index2);
}

inline bool FEMBinaryCONCAT::extractCONCAT(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const {
	FEMBinaryBASE* _binary1 = femCast(&binary1)->toPointerAndCastItsTarget->toBinaryBASE;
	FEMBinaryBASE* _binary2 = femCast(&binary2)->toPointerAndCastItsTarget->toBinaryBASE;
	INT32 _offset2 = _offset - _binary1->binaryLength, _length2 = _offset2 + _length;
	if (_offset2 >= 0) return _binary2->extractBASE(_context, _collector, _offset2, _length, _foreward);
	if (_length2 <= 0) return _binary1->extractBASE(_context, _collector, _offset, _length, _foreward);
	if (_foreward) {
		if (!_binary1->extractBASE(_context, _collector, _offset, -_offset2, true)) return false;
		return _binary2->extractBASE(_context, _collector, 0, _length2, true);
	} else {
		if (!_binary2->extractBASE(_context, _collector, 0, _length2, false)) return false;
		return _binary1->extractBASE(_context, _collector, _offset, -_offset2, false);
	}
}

inline FEMBinary FEMBinaryCONCAT::sectionCONCAT(INT32 const _offset, INT32 const _length) const {
	FEMBinaryBASE* _binary1 = femCast(&binary1)->toPointerAndCastItsTarget->toBinaryBASE;
	FEMBinaryBASE* _binary2 = femCast(&binary2)->toPointerAndCastItsTarget->toBinaryBASE;
	INT32 _offset2 = _offset - _binary1->binaryLength, _length2 = _offset2 + _length;
	if (_offset2 >= 0) return _binary2->sectionBASE(_offset2, _length);
	if (_length2 <= 0) return _binary1->sectionBASE(_offset, _length);
	return _binary1->sectionBASE(_offset, -_offset2).concat(_binary2->sectionBASE(0, _length2));
}

struct __________;

inline FEMBinarySECTION::FEMBinarySECTION(FEMBinary const& _binary, INT32 const _offset, INT32 const _length)
		: FEMBinaryBASE(BINARY_SECTION, _length), binary(_binary), offset(_offset) {
}

inline UINT32 FEMBinarySECTION::getSECTION(INT32 const _index) const { // DONE
	return femCast(&binary)->toPointerAndCastItsTarget->toBinaryBASE->getBASE(_index + offset);
}

inline bool FEMBinarySECTION::extractSECTION(PVOID _target, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	return femCast(&binary)->toPointerAndCastItsTarget->toBinaryBASE->extractBASE(_target, _collector, offset + _offset, _length, _foreward);
}

inline FEMBinary FEMBinarySECTION::sectionSECTION(INT32 _offset, INT32 _length) const { // DONE
	return femCast(&binary)->toPointerAndCastItsTarget->toBinaryBASE->sectionBASE(offset + _offset, _length);
}

struct __________;

inline FEMBinaryREVERSE::FEMBinaryREVERSE(FEMBinary const& _binary)
		: FEMBinaryBASE(BINARY_REVERSE, _binary.length()), binary(_binary) {
}

inline UINT32 FEMBinaryREVERSE::getREVERSE(INT32 const _index) const { // DONE
	return femCast(&binary)->toPointerAndCastItsTarget->toBinaryBASE->getBASE(binaryLength - _index - 1);
}

inline bool FEMBinaryREVERSE::extractREVERSE(PVOID _target, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	return femCast(&binary)->toPointerAndCastItsTarget->toBinaryBASE->extractBASE(_target, _collector, binaryLength - _offset - _length, _length, !_foreward);
}

inline FEMBinary FEMBinaryREVERSE::sectionREVERSE(INT32 _offset, INT32 _length) const { // DONE
	return femCast(&binary)->toPointerAndCastItsTarget->toBinaryBASE->sectionBASE(binaryLength - _offset - _length, _length).reverse();
}

inline FEMBinary FEMBinaryREVERSE::reverseREVERSE() const { // DONE
	return binary;
}

struct __________;

inline FEMBinaryUNIFORM::FEMBinaryUNIFORM(UINT32 const& _value, INT32 const _binaryLength)
		: FEMBinaryBASE(BINARY_UNIFORM, _binaryLength), value(_value) {
}

inline UINT32 FEMBinaryUNIFORM::getUNIFORM(INT32 const _index) const { // DONE
	return value;
}

inline bool FEMBinaryUNIFORM::extractUNIFORM(PVOID _target, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	for (INT32 i = _length; i > 0; --i) {
		if (!(*_collector)(_target, value)) return false;
	}
	return true;
}

inline FEMBinary FEMBinaryUNIFORM::sectionUNIFORM(INT32 const _offset, INT32 const _length) const { // DONE
	FEMBinaryUNIFORM* _result = new FEMBinaryUNIFORM(value, _length);
	return FEMBinary(*femCast(&_result)->toBinary);
}

inline FEMBinary FEMBinaryUNIFORM::compactUNIFORM() const { // DONE
	FEMBinaryUNIFORM const* _result = this;
	return FEMBinary(*femCast(&_result)->toBinary);
}

inline FEMBinary FEMBinaryUNIFORM::reverseUNIFORM() const { // DONE
	FEMBinaryUNIFORM const* _result = this;
	return FEMBinary(*femCast(&_result)->toBinary);
}

struct __________;

inline FEMBinaryCUSTOM1::FEMBinaryCUSTOM1()
		: FEMBinaryBASE(BINARY_CUSTOM1, 0) {
}

inline UINT32 FEMBinaryCUSTOM1::getCUSTOM1(INT32 const _index) const {
	return 0;
}

struct __________;

inline FEMBinaryCUSTOM2::FEMBinaryCUSTOM2()
		: FEMBinaryBASE(BINARY_CUSTOM2, 0) {
}

inline UINT32 FEMBinaryCUSTOM2::getCUSTOM2(INT32 const _index) const {
	return 0;
}

struct __________;

inline FEMBinaryCUSTOM3::FEMBinaryCUSTOM3()
		: FEMBinaryBASE(BINARY_CUSTOM3, 0) {
}

inline UINT32 FEMBinaryCUSTOM3::getCUSTOM3(INT32 const _index) const {
	return 0;
}

struct __________;

FEMObject const FEMObject::EMPTY = FEMObject::from(0, 0, 0);

FEMObject FEMObject::from(INT64 const _value) { // DONE
	return from((INT32) (_value >> 32), (UINT16) (_value >> 0), (UINT16) (_value >> 16));
}

FEMObject FEMObject::from(INT32 const _valueL, INT32 const _valueH) { // DONE
	return from(_valueH, (UINT16) (_valueL >> 0), (UINT16) (_valueL >> 16));
}

FEMObject FEMObject::from(INT32 const _ref, INT32 const _type, INT32 const _owner) { // DONE
	FEMException::checkCount(_ref);
	FEMException::checkIndex(_type, 65536);
	FEMException::checkIndex(_owner, 65536);
	FEMObjectBASE* _result = new FEMObjectBASE(_ref, _type, _owner);
	return FEMObject(*femCast(&_result)->toObject);
}

FEMObject::FEMObject() // DONE
		: FEMObject(EMPTY) {
}

INT64 FEMObject::value() const { // DONE
	FEMObjectBASE const* _thisObject = femCast(this)->toPointerAndCastItsTarget->toObjectBASE;
	return (((INT64) _thisObject->refValue) << 32) | (_thisObject->ownerValue << 16) | (_thisObject->typeValue << 0);
}

INT32 FEMObject::refValue() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toObjectBASE->refValue;
}

INT32 FEMObject::typeValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toObjectBASE->typeValue;
}

INT32 FEMObject::ownerValue() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toObjectBASE->ownerValue;
}

FEMObject FEMObject::withRef(INT32 const _ref) const { // DONE
	FEMObjectBASE const* _thisObject = femCast(this)->toPointerAndCastItsTarget->toObjectBASE;
	return from(_ref, _thisObject->typeValue, _thisObject->ownerValue);
}

FEMObject FEMObject::withType(INT32 const _type) const { // DONE
	FEMObjectBASE const* _thisObject = femCast(this)->toPointerAndCastItsTarget->toObjectBASE;
	return from(_thisObject->refValue, _type, _thisObject->ownerValue);
}

FEMObject FEMObject::withOwner(INT32 const _owner) const { // DONE
	FEMObjectBASE const* _thisObject = femCast(this)->toPointerAndCastItsTarget->toObjectBASE;
	return from(_thisObject->refValue, _thisObject->typeValue, _owner);
}

INT32 FEMObject::compare(FEMObject const& _that) const { // DONE
	FEMObjectBASE const* _thisObject = femCast(this)->toPointerAndCastItsTarget->toObjectBASE;
	FEMObjectBASE const* _thatObject = femCast(&_that)->toPointerAndCastItsTarget->toObjectBASE;
	INT32 result = _thisObject->refValue - _thatObject->refValue;
	if (result < 0) return -1;
	if (result > 0) return +1;
	result = _thisObject->ownerValue - _thatObject->ownerValue;
	if (result < 0) return -1;
	if (result > 0) return +1;
	result = _thisObject->typeValue - _thatObject->typeValue;
	if (result < 0) return -1;
	if (result > 0) return +1;
	return 0;
}

struct __________;

inline FEMObjectBASE::FEMObjectBASE(INT32 const _refValue, UINT16 const _typeValue, UINT16 const _ownerValue) // DONE
		: FEMValueBASE(OBJECT_BASE), refValue(_refValue), typeValue(_typeValue), ownerValue(_ownerValue) {
}

inline INT32 FEMObjectBASE::hashOBJECT() const { // DONE
	return refValue ^ typeValue ^ ownerValue;
}

inline FEMString FEMObjectBASE::scriptOBJECT() const { // TODO
	return FEMString();
}

inline bool FEMObjectBASE::equalsOBJECT(FEMObjectBASE const& _that) const { // DONE
	return (refValue == _that.refValue) && (typeValue == _that.typeValue) && (ownerValue == _that.ownerValue);
}

struct __________;

FEMHandler const FEMHandler::EMPTY = FEMHandler::from(FEMFunction());

FEMHandler FEMHandler::from(FEMFunction const& _value) { // DONE
	PCVOID _this = new FEMHandlerBASE(_value);
	return FEMHandler(*femCast(&_this)->toPointerAndCastItsTarget->toHandler);
}

FEMHandler::FEMHandler() // DONE
		: FEMHandler(EMPTY) {
}
FEMFunction FEMHandler::value() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toHandlerBASE->handlerValue;
}

struct __________;

static FEMString _FEMHandlerBASE_SCRIPT_OPEN_ = FEMString::from("{:");

static FEMString _FEMHandlerBASE_SCRIPT_CLOSE_ = FEMString::from("}");

inline FEMHandlerBASE::FEMHandlerBASE(FEMFunction const& _handlerValue) // DONE
		: FEMValueBASE(HANDLER_BASE), handlerValue(_handlerValue) {
}

inline INT32 FEMHandlerBASE::hashHANDLER() const { // DONE
	return handlerValue.hash();
}

inline FEMString FEMHandlerBASE::scriptHANDLER() const { // DONE
	return _FEMHandlerBASE_SCRIPT_OPEN_.concat(handlerValue.toScript()).concat(_FEMHandlerBASE_SCRIPT_CLOSE_);
}

inline bool FEMHandlerBASE::equalsHANDLER(FEMHandlerBASE const& _that) const { // DONE
	return handlerValue.equals(_that.handlerValue);
}

struct __________;

FEMInteger const FEMInteger::EMPTY = FEMInteger::from(0);

FEMInteger FEMInteger::from(INT64 const& _value) { // DONE
	FEMIntegerBASE* _result = new FEMIntegerBASE(_value);
	return FEMInteger(*femCast(&_result)->toInteger);
}

FEMInteger FEMInteger::from(FEMString const& _script) { // TODO
	return FEMInteger::EMPTY;
}

FEMInteger::FEMInteger() // DONE
		: FEMInteger(EMPTY) {
}

INT64 FEMInteger::value() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toIntegerBASE->value;
}

INT32 FEMInteger::compare(FEMInteger const& _that) const { // DONE
	INT64 _thisValue = value();
	INT64 _thatValue = _that.value();
	return _thisValue < _thatValue ? -1 : _thisValue > _thatValue ? +1 : 0;
}

struct __________;

inline FEMIntegerBASE::FEMIntegerBASE(INT64 const& _value) // DONE
		: FEMValueBASE(INTEGER_BASE), value(_value) {
}

inline INT32 FEMIntegerBASE::hashINTEGER() const { // DONE
	INT64S const* _value = femCast(&value)->toINT64S;
	return _value->getLO.asINT32 ^ _value->getHI.asINT32;
}

inline FEMString FEMIntegerBASE::scriptINTEGER() const { // TODO
	return FEMString::EMPTY;
}

inline bool FEMIntegerBASE::equalsINTEGER(FEMIntegerBASE const& _that) const { // DONE
	return value == _that.value;
}

struct __________;

FEMDecimal const FEMDecimal::EMPTY = FEMDecimal::from(0);

FEMDecimal FEMDecimal::from(double const& _value) { // DONE
	FEMDecimalBASE* _result = new FEMDecimalBASE(_value);
	return FEMDecimal(*femCast(&_result)->toDecimal);
}

FEMDecimal FEMDecimal::from(FEMString const& _script) { // TODO
	return EMPTY;
}

FEMDecimal::FEMDecimal() // DONE
		: FEMDecimal(EMPTY) {
}

double FEMDecimal::value() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toDecimalBASE->value;
}

INT32 FEMDecimal::compare(FEMDecimal const& _that) const { // DONE
	double _thisValue = value();
	double _thatValue = _that.value();
	return _thisValue < _thatValue ? -1 : _thisValue > _thatValue ? +1 : 0;
}

struct __________;

FEMDecimalBASE::FEMDecimalBASE(double const& _value) // DONE
		: FEMValueBASE(DECIMAL_BASE), value(_value) {
}

INT32 FEMDecimalBASE::hashDECIMAL() const { // DONE
	INT64S const* _value = femCast(&value)->toINT64S;
	return _value->getLO.asINT32 ^ _value->getHI.asINT32;
}

FEMString FEMDecimalBASE::scriptDECIMAL() const { // TODO
	return FEMString::EMPTY;
}

bool FEMDecimalBASE::equalsDECIMAL(FEMDecimalBASE const& _that) const { // DONE
	return value == _that.value || ((value != value) && (_that.value != _that.value));
}

struct __________;


static FEMValueBASE const* _FEMBoolean_TRUE_ = new FEMValueTRUE();

static FEMValueBASE const* _FEMBoolean_FALSE_ = new FEMValueFALSE();

FEMBoolean const FEMBoolean::TRUE = FEMBoolean(*femCast(&_FEMBoolean_TRUE_)->toBoolean);

FEMBoolean const FEMBoolean::FALSE = FEMBoolean(*femCast(&_FEMBoolean_FALSE_)->toBoolean);

FEMBoolean FEMBoolean::from(bool const _value) { // DONE
	return _value ? TRUE : FALSE;
}

FEMBoolean FEMBoolean::from(FEMString const& _script){ // TODO
	return TRUE;
}

bool FEMBoolean::value() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toValueBASE->dataType == FEMValueBASE::VALUE_TRUE;
}

INT32 FEMBoolean::compare(FEMBoolean const& _that) const {

}


struct __________;
struct __________;

struct __________;

FEMDatetimeBASE::FEMDatetimeBASE(INT32 const _valueL, INT32 const _valueH) // DONE
		: FEMValueBASE(DATETIME_BASE), valueL(_valueL), valueH(_valueH) {
}

INT32 FEMDatetimeBASE::hashDATETIME() const { // DONE
	return valueL ^ valueH;
}

FEMString FEMDatetimeBASE::scriptDATETIME() const { // TODO
	return FEMString();
}

bool FEMDatetimeBASE::equalsDATETIME(FEMDatetimeBASE const& _that) const { // TODO
	return false;
}

struct __________;

struct __________;

FEMDurationBASE::FEMDurationBASE(INT32 const _valueL, INT32 const _valueH) // DONE
		: FEMValueBASE(DURATION_BASE), valueL(_valueL), valueH(_valueH) {
}

INT32 FEMDurationBASE::hashDURATION() const { // DONE
	return valueL ^ valueH;
}

FEMString FEMDurationBASE::scriptDURATION() const { // TODO
	return FEMString();
}

bool FEMDurationBASE::equalsDURATION(FEMDurationBASE const& _that) const { // TODO
	return false;
}

struct __________;

struct __________;

struct __________;

struct I_____I;

struct I_____I;

struct I___constext__I;

struct I_____I;

struct I___value__I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

FEMProxy FEMProxy::from(FEMString const& _name) {
	PCVOID _this = new FEMFunctionPROXY(_name);
	return FEMProxy(*femCast(&_this)->toPointerAndCastItsTarget->toProxy);
}
//
//FEMValue FEMProxy::invoke(FEMFrame const& _frame) const {
//	return femCast(this)->toPointerAndCastItsTarget->toFunctionPROXY->proxyTarget.functionInvoke(_frame);
//}
//
//FEMString FEMProxy::name() const {
//	return femCast(this)->toPointerAndCastItsTarget->toFunctionPROXY->proxyName;
//}
//
//FEMFunction FEMProxy::target() const {
//	return femCast(this)->toPointerAndCastItsTarget->toFunctionPROXY->proxyTarget;
//}
//
//void FEMProxy::update(FEMFunction const& _target) {
//	femCast(this)->toPointerAndCastItsTarget->toFunctionPROXY->proxyTarget = _target;
//}
//
//INT32 FEMProxy::hash() const {
//	return (INT32) this;
//}
//
//bool FEMProxy::equals(FEMProxy const& _that) const {
//	return this == &_that;
//}

struct I_____I;

FEMFunctionCACHE FEMParam_INSTANCE;

FEMParam FEMParam::from(INT32 const _index) { // DONE
	SUCException::checkCount(_index);
	if (_index < FEMParam_INSTANCE.functionCount) return FEMParam(*femCast(FEMParam_INSTANCE.functionArray + _index)->toParam);
	FEMFunctionPARAM* _result = new FEMFunctionPARAM(_index);
	return FEMParam(*femCast(&_result)->toParam);
}
//
//FEMValue FEMParam::invoke(FEMFrame const& _frame) const {
//	return _frame.get(index());
//}
//
//INT32 FEMParam::index() const {
//	return femCast(this)->toPointerAndCastItsTarget->toBASE->size();
//}
//
//INT32 FEMParam::hash() const {
//	return index();
//}
//
//bool FEMParam::equals(FEMParam const& _that) const {
//	return index() == _that.index();
//}

struct I_____I;

static FEMFunctionFRAME* FEMParam_FRAME = new FEMFunctionFRAME();
FEMFunction const FEMParam::FRAME = FEMFunction(*femCast(&FEMParam_FRAME)->toFunction);
//
//FEMValue FEMArrayFunction::invoke(FEMFrame const& _frame) const {
//// TODO
//	return FEMValue();
//}
//
//INT32 FEMArrayFunction::hash() const {
//	return (INT32) this;
//}
//
//bool FEMArrayFunction::equals(FEMArrayFunction const& _that) const {
//	return this == &_that;
//}

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

FEMContext::FEMContext()
		: _object_(femCast(new FEMContextBASE())->toContextOBJ) {
}

FEMFrame FEMContext::newFrame() { // DONE
	FEMFrameCONTEXT* _result = new FEMFrameCONTEXT(*this);
	return FEMFrame(*femCast(&_result)->toFrame);
}

FEMContextOBJ::~OBJECT() {
	femCast(this)->toContextBASE->~FEMContextBASE();
}

inline FEMContextBASE::FEMContextBASE()
		: cyclicSection(), cyclicList(*this) {

}

inline FEMContextBASE::~FEMContextBASE() {
	deleteCYCLIC();
}

inline void FEMContextBASE::deleteCYCLIC() {
	while (true) {
		CSGuard _cyclicGuard = CSGuard(cyclicSection);
		FEMArrayCYCLIC* _next = cyclicList.cyclicNext;
		if (_next == _next) return;
		_next->deleteCYCLIC();
	}
}

struct __________;

}

}

}

