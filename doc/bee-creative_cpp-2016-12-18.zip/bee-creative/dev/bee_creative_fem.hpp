/* [cc-by] 2013..2016 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#ifndef BEE_CREATIVE_FEM_HPP
#define BEE_CREATIVE_FEM_HPP

#include "bee_creative.hpp"
#include "bee_creative_suc.hpp"

#undef TRUE
#undef FALSE

namespace bee {

namespace creative {

namespace fem {

using namespace bee::creative;
using namespace bee::creative::suc;

void fem_main();

struct FEMVoid;
struct FEMArray;
struct FEMValue;
struct FEMProxy;
struct FEMParam;
struct FEMString;
struct FEMBinary;
struct FEMObject;
struct FEMHandler;
struct FEMInteger;
struct FEMDecimal;
struct FEMBoolean;
struct FEMDuration;
struct FEMDatetime;
struct FEMFrame;
struct FEMContext;
struct FEMFunction;
struct FEMException;

struct __________;

struct FEMFunction {

	enum TYPE {
		FUNCTION_TYPE_VALUE, //
		FUNCTION_TYPE_PROXY,
		FUNCTION_TYPE_PARAM,
		FUNCTION_TYPE_METHOD,
		FUNCTION_TYPE_OTHER
	};

	/** Diese Methode gibt die Typkennung der gegebenen Funktion zurück. Diese wird in den Funktionsklassen stets als <tt>TYPE</tt> bezeichnet.
	 * @param _instance Funktion.
	 * @return Typkennung.
	 */

	struct OBJECT: public RCObject<OBJECT> { // FEMFunction_BASE
		~OBJECT();
	};

	/** Diese Klasse definiert die @c SUCPolicy von Funktionen. */
	struct POLICY: public SUCPolicy_STRUCT<FEMFunction, POLICY> {

	};

	/** Diese Klasse definiert ein @c SUCArray von Funktionen. */
	typedef SUCArray<FEMFunction, POLICY> ARRAY;

	typedef FEMValue (*METHOD)(FEMFrame const& _frame);

	static FEMFunction from(METHOD _method);

	FEMFunction();
	TYPE functionType() const;
	bool functionIsValue() const;
	bool functionIsProxy() const;
	bool functionIsParam() const;
	bool functionIsOther() const;
	FEMValue const& functionAsValue() const;
	FEMProxy const& functionAsProxy() const;
	FEMParam const& functionAsParam() const;
	FEMHandler functionToHandler() const; // FEMHandler_BASE
	FEMFunction functionConcat(ARRAY const& _paramArray) const; // FEMFunction_CONCAT
	FEMFunction functionConcat(FEMFunction const* _paramArray, INT32 _paramCount) const; // FEMFunction_CONCAT
	FEMFunction functionCompose(ARRAY const& _paramArray) const; // FEMFunction_COMPOSE
	FEMFunction functionCompose(FEMFunction const* _paramArray, INT32 _paramCount) const; // FEMFunction_COMPOSE
	FEMValue functionInvoke(FEMFrame const& _frame) const;

	INT32 hash() const;
	FEMFunction clone() const;
	bool equals(FEMFunction const& _that) const;
	FEMString toScript() const;

	protected:
	RCPointer<OBJECT> _object_;

};

struct FEMProxy: public FEMFunction {

	/** Diese Methode gibt eine neue @c FEMProxyFunction mit dem gegebenen Namen zurück.
	 * @param _name Name.
	 * @return @c FEMProxyFunction. */
	static FEMProxy from(FEMString const& _name); // FEMFunction_PROXY

	FEMProxy() = delete;

	/** Diese Methode gibt den Namen zurück, der in @c from(FEMString const&) initialisiert wurde.
	 * @return Name. */
	FEMString proxyName() const;

	FEMFunction proxyTarget() const;

	void proxyTarget(FEMFunction const& _target);

};

struct FEMParam: public FEMFunction {

	static FEMFunction const FRAME; // FEMFunction_FRAME

	static FEMParam from(INT32 const _index); // FEMFunction_PARAM

	FEMParam() = delete;
	INT32 index() const;

};

struct __________;

struct FEMContext { // OK

	static const FEMContext EMPTY;

	struct OBJECT: public RCObject<OBJECT> {
		~OBJECT(); // critSec,prev/ nextFunctionFRAME, bereinigen
	};

	FEMContext();
	FEMFrame newFrame();

	FEMArray valueToArray(FEMValue const& _value) const;
	FEMString valueToString(FEMValue const& _value) const;
	FEMBinary valueToBinary(FEMValue const& _value) const;
	FEMObject valueToObject(FEMValue const& _value) const;
	FEMHandler valueToHandler(FEMValue const& _value) const;
	FEMInteger valueToInteger(FEMValue const& _value) const;
	FEMDecimal valueToDecimal(FEMValue const& _value) const;
	FEMBoolean valueToBoolean(FEMValue const& _value) const;
	FEMDuration valueToDuration(FEMValue const& _value) const;
	FEMDatetime valueToDatetime(FEMValue const& _value) const;

	protected:
	RCPointer<OBJECT> _object_;
};

struct __________;

struct FEMValue: public FEMFunction {

	enum TYPE {
		VALUE_TYPE_VOID,
		VALUE_TYPE_ARRAY,
		VALUE_TYPE_STRING,
		VALUE_TYPE_BINARY,
		VALUE_TYPE_OBJECT,
		VALUE_TYPE_HANDLER,
		VALUE_TYPE_INTEGER,
		VALUE_TYPE_DECIMAL,
		VALUE_TYPE_BOOLEAN,
		VALUE_TYPE_DURATION,
		VALUE_TYPE_DATETIME,
		VALUE_TYPE_OTHER
	};

	/** Diese Klasse definiert die @c SUCPolicy von Werten. */
	struct POLICY: public SUCPolicy_STRUCT<FEMValue, POLICY> {
	};

	typedef SUCArray<FEMValue, POLICY> ARRAY;

	FEMValue(); // void

	// Typprüfung
	TYPE valueType() const;
	bool valueIsVoid() const;
	bool valueIsArray() const;
	bool valueIsString() const;
	bool valueIsBinary() const;
	bool valueIsObject() const;
	bool valueIsHandler() const;
	bool valueIsInteger() const;
	bool valueIsDecimal() const;
	bool valueIsBoolean() const;
	bool valueIsDuration() const;
	bool valueIsDatetime() const;
	bool valueIsOther() const;

	// cast ohne prüfung
	FEMVoid const& valueAsVoid() const;
	FEMArray const& valueAsArray() const;
	FEMString const& valueAsString() const;
	FEMBinary const& valueAsBinary() const;
	FEMObject const& valueAsObject() const;
	FEMHandler const& valueAsHandler() const;
	FEMInteger const& valueAsInteger() const;
	FEMDecimal const& valueAsDecimal() const;
	FEMBoolean const& valueAsBoolean() const;
	FEMDuration const& valueAsDuration() const;
	FEMDatetime const& valueAsDatetime() const;

	FEMValue clone() const;

};

struct __________;

struct FEMFrame {
	public:
	struct OBJECT: public RCObject<OBJECT> { // FEMFrame_BASE
		~OBJECT();
	};
	FEMFrame();
	FEMValue get(INT32 const _index) const;
	INT32 size() const;
	FEMArray params() const; // FEMArray_FRAME

	/** Diese Methode gibt die übergeordneten Parameterdaten zurück.
	 * @return übergeordnete Parameterdaten oder {@code this}. */
	FEMFrame const& parent() const;

	/** Diese Methode gibt das Kontextobjekt zurück.<<br>
	 * Funktionen können aus diesem Objekt Informationen für ihre Berechnungen extrahieren oder auch den Zustand dieses Objekts modifizieren.<br>
	 * Das Kontextobjekt entspricht dem Kontext {@code this} in {@code Java}-Methoden.
	 * @return Kontextobjekt. */
	FEMContext const& context() const;

	FEMFrame newFrame(FEMArray const& _params) const; // FEMFrame_ARRAY
	FEMFrame newFrame(FEMValue::ARRAY const& _params) const; // FEMFrame_VALUE
	FEMFrame newFrame(FEMFunction::ARRAY const& _params) const; // FEMFrame_CACHE
	FEMFrame newFrame(FEMValue const* _paramArray, INT32 const _paramCount) const; // FEMFrame_VALUE
	FEMFrame newFrame(FEMFunction const* _paramArray, INT32 const _paramCount) const; // FEMFrame_CACHE

	/** Diese Methode gibt diesen Stapelrahmen mit den gegebenen zugesicherten Parameterwerten zurück.<br>
	 * Sie ist eine Abkürzung für <tt>parent().newFrame(params)</tt>.
	 * @see #newFrame(FEMArray)
	 * @param params zugesicherte Parameterwerte.
	 * @return neuer Stapelrahmen. */
	FEMFrame withParams(FEMArray const& _params) const;
	FEMFrame withParams(FEMValue::ARRAY const& _params) const;
	FEMFrame withParams(FEMFunction::ARRAY const& _params) const;
	FEMFrame withParams(FEMValue const* _paramArray, INT32 const _paramCount) const;
	FEMFrame withParams(FEMFunction const* _paramArray, INT32 const _paramCount) const;
	protected:
	RCPointer<OBJECT> _object_;
};

struct __________;

struct FEMVoid: public FEMValue {

	static FEMVoid const INSTANCE; // FEMVoid_BASE

	FEMVoid();

};

struct FEMArray: public FEMValue {

	typedef ARRAY VALUE;

	typedef bool (*COLLECTOR)(PVOID _context, FEMValue const& _value);

	typedef bool (*COMPARATOR)(PVOID _context, FEMValue const& _this, FEMValue const& _that);

	static FEMArray const EMPTY; // FEMArray_VALUE

	static FEMArray from(VALUE const& _array); // FEMArray_VALUE
	static FEMArray from(FEMValue const* _itemArray, INT32 const _itemCount); // FEMArray_VALUE
	static FEMArray from(FEMValue const& _item, INT32 const _itemCount); // FEMArray_UNIFORM

	FEMArray();
	VALUE value() const;
	FEMValue get(INT32 const _index) const;
	INT32 length() const;
	FEMArray concat(FEMArray const& _that) const; // FEMArray_CONCAT
	FEMArray section(INT32 const _offset, INT32 const _length) const; // FEMArray_SECTION
	FEMArray reverse() const; // FEMArray_REVERSE
	FEMArray compact() const; // FEMArray_VALUE
	INT32 find(FEMValue const& _that, INT32 const _offset) const;
	INT32 find(FEMArray const& _that, INT32 const _offset) const;
	bool extract(PVOID _context, COLLECTOR _collector) const;
	INT32 compare(FEMArray const& _that, PVOID _context, COMPARATOR _comparator) const;
};

struct FEMString: public FEMValue {

	typedef SUCArray<UINT8> BYTES;
	typedef SUCArray<UINT16> CHARS;
	typedef SUCArray<UINT32> VALUE;

	typedef bool (*COLLECTOR)(PVOID _context, UINT32 const _value);

	static FEMString const EMPTY;

	static FEMString from(BYTES const& _array); // FEMStringBYTES
	static FEMString from(CHARS const& _array); // FEMStringCHARS
	static FEMString from(VALUE const& _array); // FEMStringVALUE
	static FEMString from(UINT32 const _item, INT32 const _itemCount); // FEMStringUNIFORM
	static FEMString from(CHAR const* _string);
	static FEMString from(UINT8 const* _itemArray, INT32 const _itemCount);
	static FEMString from(UINT16 const* _itemArray, INT32 const _itemCount);
	static FEMString from(UINT32 const* _itemArray, INT32 const _itemCount);
	static FEMString from(FEMString const& _script); // parsen

	FEMString();
	VALUE value() const;
	UINT32 get(INT32 const _index) const;
	INT32 length() const;
	FEMString concat(FEMString const& _that) const; // FEMStringCONCAT
	FEMString section(INT32 const _offset, INT32 const _length) const; // FEMStringSECTION
	FEMString reverse() const; // FEMStringREVERSE
	FEMString compact() const;
	INT32 find(UINT32 const _that, INT32 const _offset) const;
	INT32 find(FEMString const& _that, INT32 const _offset) const;
	bool extract(PVOID _context, COLLECTOR _collector) const;
	INT32 compare(FEMString const& _that) const;
	BYTES toBytes() const;
	CHARS toChars() const;

};

struct FEMBinary: public FEMValue {

	typedef SUCArray<UINT8> VALUE;

	typedef bool (*COLLECTOR)(PVOID _target, UINT8 const _value);

	static FEMBinary const EMPTY;

	static FEMBinary from(VALUE const& _array);
	static FEMBinary from(INT8 const _item, INT32 const _itemCount);
	static FEMBinary from(INT8 const* _itemArray, INT32 const _itemCount);
	static FEMBinary from(FEMString const& _script);

	FEMBinary() = delete;
	VALUE value() const;
	UINT8 get(INT32 const _index) const;
	INT32 length() const;
	FEMBinary concat(FEMBinary const& _that) const;
	FEMBinary section(INT32 const _offset, INT32 const _length) const;
	FEMBinary reverse() const;
	FEMBinary compact() const;
	INT32 find(INT8 const _that, INT32 const _offset) const;
	INT32 find(FEMBinary const& _that, INT32 const _offset) const;
	bool extract(PVOID _target, COLLECTOR _collector) const;

	bool equals(FEMBinary const& _that) const;
	INT32 compare(FEMBinary const& _that) const;

};

struct FEMObject: public FEMValue {

	static FEMObject const EMPTY;

	static FEMObject from(INT64 const _value);
	static FEMObject from(INT32 const _valueL, INT32 const _valueH);
	static FEMObject from(INT32 const _ref, INT32 const _type, INT32 const _owner);

	FEMObject();
	INT64 value() const;
	INT32 refValue() const;
	INT32 typeValue() const;
	INT32 ownerValue() const;
	FEMObject withRef(INT32 const _ref) const;
	FEMObject withType(INT32 const _type) const;
	FEMObject withOwner(INT32 const _owner) const;
	INT32 compare(FEMObject const& _that) const;

};

struct FEMHandler: public FEMValue {

	static FEMHandler const EMPTY;

	static FEMHandler from(FEMFunction const& _value);

	FEMHandler();
	FEMFunction value() const;

};

struct FEMInteger: public FEMValue {

	static FEMInteger const EMPTY; // FEMInteger_BASE

	static FEMInteger from(INT64 const& _value);
	static FEMInteger from(FEMString const& _script);

	FEMInteger();
	INT64 value() const;
	INT32 compare(FEMInteger const& _that) const;

};

struct FEMDecimal: public FEMValue {

	static FEMDecimal const EMPTY;

	static FEMDecimal from(double const& _value);
	static FEMDecimal from(FEMString const& _script);

	FEMDecimal();
	double value() const;
	INT32 compare(FEMDecimal const& _that) const;

};

struct FEMBoolean: public FEMValue {

	static FEMBoolean const TRUE;
	static FEMBoolean const FALSE;

	static FEMBoolean from(bool const _value);
	static FEMBoolean from(FEMString const& _script);

	FEMBoolean() = delete;
	bool value() const;

	INT32 hash() const;
	bool equals(FEMBoolean const& _that) const;
	INT32 compare(FEMBoolean const& _that) const;

};

struct FEMDuration: public FEMValue {

};

struct FEMDatetime: public FEMValue {

};

struct FEMException {

	static void checkState(bool _valid) {
		if (!_valid) throw FEMException();
	}

	static void checkNull(PCVOID _array) {
		if (!_array) throw FEMException();
	}

	static void checkCount(INT32 const _count) {
		if (_count < 0) throw FEMException();
	}
	static void checkIndex(INT32 const _index, INT32 const _count) {
		if (_index < 0 || _index >= _count) throw FEMException();
	}

};

}

}

}

#endif
