/* [cc-by] 2013 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#ifndef BEE_CREATIVE_IAMp_HPP

#define BEE_CREATIVE_IAMp_HPP

#include "bee_creative_iam.hpp"
#include "bee_creative_suc.hpp"
#include <boost/functional/hash.hpp>
#include <boost/unordered/unordered_map.hpp>

namespace bee {

namespace creative {

namespace iam {

using namespace suc;

class IAMMapBuilder: public SUCTable<IAMArray, IAMArray, SUC_HASHER_STRUCT<IAMArray>, SUC_POLICY_STRUCT<IAMArray>, SUC_POLICY_STRUCT<IAMArray>> {

	public:

	IAMArray build() const;

};

class IAMListBuilder: public SUCVector<IAMArray, SUC_POLICY_STRUCT<IAMArray>> {

	public:

	IAMArray build() const;

};

class IAMArrayBuilder: public SUCVector<INT32> {

	public:

	IAMArray build() const;

};

class IAMIndexBuilder {

	public:

	typedef SUCVector<IAMMapBuilder, SUC_POLICY_STRUCT<IAMMapBuilder>> MAP_VECTOR;

	typedef SUCVector<IAMListBuilder, SUC_POLICY_STRUCT<IAMListBuilder>> LIST_VECTOR;

	MAP_VECTOR& maps() {
		return __maps;
	}

	LIST_VECTOR& lists() {
		return __lists;
	}

	IAMArray build() const;

	private:

	MAP_VECTOR __maps;

	LIST_VECTOR __lists;

};

}

}

}

#endif
