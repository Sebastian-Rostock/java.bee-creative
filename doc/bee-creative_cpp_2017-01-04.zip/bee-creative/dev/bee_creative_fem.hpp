/* [cc-by] 2013..2016 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#ifndef BEE_CREATIVE_FEM_HPP
#define BEE_CREATIVE_FEM_HPP

#include "bee_creative.hpp"
#include "bee_creative_suc.hpp"
#include "bee_creative_iam.hpp"

#undef TRUE
#undef FALSE

#define NOT_IN_CPP

namespace bee {

namespace creative {

namespace fem {

using namespace bee::creative;
using namespace bee::creative::suc;
using namespace bee::creative::iam;

void fem_main();

struct FEMVoid;
struct FEMArray;
struct FEMValue;
struct FEMProxy;
struct FEMParam;
struct FEMString;
struct FEMBinary;
struct FEMObject;
struct FEMHandler;
struct FEMInteger;
struct FEMDecimal;
struct FEMBoolean;
struct FEMDuration;
struct FEMDatetime;
struct FEMFrame;
struct FEMContext;
struct FEMFunction;
struct FEMException;

struct __________;

struct FEMFunction {

	/** Dieser Typ definiert die Aufzählung aller Datentypkennungen. */
	enum TYPE {
		FUNCTION_TYPE_VALUE, FUNCTION_TYPE_PROXY, FUNCTION_TYPE_PARAM, FUNCTION_TYPE_METHOD, FUNCTION_TYPE_OTHER
	};

	struct OBJECT: public RCObject<OBJECT> {
		~OBJECT();
	};

	/** Diese Klasse definiert die @c SUCPolicy von Funktionen. */
	struct POLICY: public SUCPolicy_STRUCT<FEMFunction, POLICY> {
	};

	/** Diese Klasse definiert ein @c SUCArray von Funktionen. */
	typedef SUCArray<FEMFunction, POLICY> ARRAY;

	typedef SUCListing<FEMFunction, POLICY> LISTING;

	typedef FEMValue (*METHOD)(FEMFrame const& _frame);

	static FEMFunction from(METHOD _method);

	FEMFunction();

	/** Diese Methode gibt die Typkennung dieser Funktion zurück.
	 * @return Typkennung. */
	TYPE functionType() const;
	bool functionIsValue() const;
	bool functionIsProxy() const;
	bool functionIsParam() const;
	bool functionIsOther() const;
	FEMValue const& functionAsValue() const;
	FEMProxy const& functionAsProxy() const;
	FEMParam const& functionAsParam() const;

	/** FEMValue toValue() */
	FEMValue functionToValue() const; // FEMHandler_BASE

	/** FEMValue invoke(FEMFrame frame) */
	FEMValue functionInvoke(FEMFrame const& _frame) const;

	/** FEMFunction concat(final FEMFunction... params) */
	FEMFunction functionConcat(ARRAY const& _paramArray) const;
	FEMFunction functionConcat(FEMFunction const* _paramArray, INT32 _paramCount) const;

	/** FEMFunction compose(final FEMFunction... params) */
	FEMFunction functionCompose(ARRAY const& _paramArray) const;
	FEMFunction functionCompose(FEMFunction const* _paramArray, INT32 _paramCount) const;

	INT32 hash() const;
	FEMFunction clone() const;
	bool equals(FEMFunction const& _that) const;
	FEMString toScript() const;

	protected:
	RCPointer<OBJECT> _object_;

};

struct FEMProxy: public FEMFunction {

	/** Diese Methode gibt eine neue @c FEMProxyFunction mit dem gegebenen Namen zurück.
	 * @param _name Name.
	 * @return @c FEMProxyFunction. */
	static FEMProxy from(FEMString const& _name); // FEMFunction_PROXY

	FEMProxy() = delete;

	/** Diese Methode gibt den Namen zurück, der in @c from(FEMString const&) initialisiert wurde.
	 * @return Name. */
	FEMString proxyName() const;

	FEMFunction proxyTarget() const;

	void proxyTarget(FEMFunction const& _target);

};

struct FEMParam: public FEMFunction {

	static FEMFunction const FRAME; // FEMFunction_FRAME

	static FEMParam from(INT32 const _index); // FEMFunction_PARAM

	FEMParam() = delete;
	INT32 index() const;

};

struct __________;

struct FEMContext { // OK

	static const FEMContext EMPTY;

	struct OBJECT: public RCObject<OBJECT> {
		~OBJECT();
	};

	FEMContext();
	FEMFrame newFrame();

	FEMArray valueToArray(FEMValue const& _value) const;
	FEMString valueToString(FEMValue const& _value) const;
	FEMBinary valueToBinary(FEMValue const& _value) const;
	FEMObject valueToObject(FEMValue const& _value) const;
	FEMHandler valueToHandler(FEMValue const& _value) const;
	FEMInteger valueToInteger(FEMValue const& _value) const;
	FEMDecimal valueToDecimal(FEMValue const& _value) const;
	FEMBoolean valueToBoolean(FEMValue const& _value) const;
	FEMDuration valueToDuration(FEMValue const& _value) const;
	FEMDatetime valueToDatetime(FEMValue const& _value) const;

	protected:

	RCPointer<OBJECT> _object_;

};

struct __________;

struct FEMValue: public FEMFunction {

	/** Dieser Typ definiert die Aufzählung aller Datentypkennungen. */
	enum TYPE {
		VALUE_TYPE_VOID, VALUE_TYPE_ARRAY, VALUE_TYPE_STRING, VALUE_TYPE_BINARY, VALUE_TYPE_OBJECT, VALUE_TYPE_HANDLER, VALUE_TYPE_INTEGER, VALUE_TYPE_DECIMAL, VALUE_TYPE_BOOLEAN, VALUE_TYPE_DURATION,
		VALUE_TYPE_DATETIME, VALUE_TYPE_OTHER
	};

	/** Diese Klasse implementiert die @c SUCPolicy von Werten. */
	struct POLICY: public SUCPolicy_STRUCT<FEMValue, POLICY> {
	};

	/** Diese Klasse implementiert das @c SUCArray für Werte. */
	struct ARRAY: public SUCArray<FEMValue, POLICY> {

		ARRAY(INT32 _length = 0);

	};

	/** Diese Klasse implementiert das @c SUCListing für Werte. */
	struct LISTING: public SUCListing<FEMValue, POLICY> {

		LISTING(INT32 _capacity = 16);

	};

	FEMValue();

	/* instanceOf */
	TYPE valueType() const;
	bool valueIsVoid() const;
	bool valueIsArray() const;
	bool valueIsString() const;
	bool valueIsBinary() const;
	bool valueIsObject() const;
	bool valueIsHandler() const;
	bool valueIsInteger() const;
	bool valueIsDecimal() const;
	bool valueIsBoolean() const;
	bool valueIsDuration() const;
	bool valueIsDatetime() const;
	bool valueIsOther() const;

	/* cast */
	FEMVoid const& valueAsVoid() const;
	FEMArray const& valueAsArray() const;
	FEMString const& valueAsString() const;
	FEMBinary const& valueAsBinary() const;
	FEMObject const& valueAsObject() const;
	FEMHandler const& valueAsHandler() const;
	FEMInteger const& valueAsInteger() const;
	FEMDecimal const& valueAsDecimal() const;
	FEMBoolean const& valueAsBoolean() const;
	FEMDuration const& valueAsDuration() const;
	FEMDatetime const& valueAsDatetime() const;

	FEMValue clone() const;

};

struct __________;

struct FEMFrame {
	public:
	struct OBJECT: public RCObject<OBJECT> { // FEMFrame_BASE
		~OBJECT();
	};
	FEMFrame();
	FEMValue get(INT32 const _index) const;
	INT32 size() const;
	FEMArray params() const; // FEMArray_FRAME

	/** Diese Methode gibt die übergeordneten Parameterdaten zurück.
	 * @return übergeordnete Parameterdaten oder {@code this}. */
	FEMFrame const& parent() const;

	/** Diese Methode gibt das Kontextobjekt zurück.<<br>
	 * Funktionen können aus diesem Objekt Informationen für ihre Berechnungen extrahieren oder auch den Zustand dieses Objekts modifizieren.<br>
	 * Das Kontextobjekt entspricht dem Kontext {@code this} in {@code Java}-Methoden.
	 * @return Kontextobjekt. */
	FEMContext const& context() const;

	FEMFrame newFrame(FEMArray const& _params) const; // FEMFrame_ARRAY
	FEMFrame newFrame(FEMValue::ARRAY const& _params) const; // FEMFrame_VALUE
	FEMFrame newFrame(FEMFunction::ARRAY const& _params) const; // FEMFrame_CACHE
	FEMFrame newFrame(FEMValue const* _paramArray, INT32 const _paramCount) const; // FEMFrame_VALUE
	FEMFrame newFrame(FEMFunction const* _paramArray, INT32 const _paramCount) const; // FEMFrame_CACHE

	/** Diese Methode gibt diesen Stapelrahmen mit den gegebenen zugesicherten Parameterwerten zurück.<br>
	 * Sie ist eine Abkürzung für <tt>parent().newFrame(params)</tt>.
	 * @see #newFrame(FEMArray)
	 * @param params zugesicherte Parameterwerte.
	 * @return neuer Stapelrahmen. */
	FEMFrame withParams(FEMArray const& _params) const;
	FEMFrame withParams(FEMValue::ARRAY const& _params) const;
	FEMFrame withParams(FEMFunction::ARRAY const& _params) const;
	FEMFrame withParams(FEMValue const* _paramArray, INT32 const _paramCount) const;
	FEMFrame withParams(FEMFunction const* _paramArray, INT32 const _paramCount) const;
	protected:
	RCPointer<OBJECT> _object_;
};

struct __________;

/** Diese Klasse implementiert den unveränderlichen Leerwert. */
struct FEMVoid: public FEMValue {

	/** Dieses Feld speichert den Leerwert. */
	static FEMVoid const INSTANCE;

	/** Dieser Konstruktor initialisiert den Leerwert. */
	FEMVoid();

};

/** Diese Klasse implementiert eine unveränderliche Liste von Werten sowie Methoden zur Erzeugung solcher Wertlisten aus nativen und SUC-Arrays. */
struct FEMArray: public FEMValue {

	/** Dieser Datentyp definiert die Nutzdaten einer Wertliste als */
	typedef ARRAY VALUE;

	/** Diese Funktion dient dem geordneten Sammeln von Werten einer Wertliste. */
	typedef bool (*COLLECTOR)(PVOID _context, FEMValue const& _value);

	/** Diese Funktion dient dem vergleichen von Werten einer Wertliste. */
	typedef bool (*COMPARATOR)(PVOID _context, FEMValue const& _this, FEMValue const& _that);

	/** Dieses Feld speichert die leere Wertliste. */
	static FEMArray const EMPTY;

	/** Diese Methode konvertiert die gegebenen Werte in eine Wertliste und gibt diese zurück.
	 * Das gegebene Array wird Kopiert, sodass spätere Anderungen am gegebenen Array nicht auf die erzeugte Wertliste übertragen werden. */
	static FEMArray from(VALUE const& _array);

	/** Diese Methode konvertiert die gegebenen Werte in eine Wertliste und gibt diese zurück.
	 * Das gegebene Array wird Kopiert, sodass spätere Anderungen am gegebenen Array nicht auf die erzeugte Wertliste übertragen werden. */
	static FEMArray from(FEMValue const* _itemArray, INT32 const _itemCount);

	/** Diese Methode gibt eine uniforme Wertliste mit der gegebenen Länge zurück, deren Werte alle gleich dem gegebenen sind. */
	static FEMArray from(FEMValue const& _item, INT32 const _itemCount);

	/** Dieser Konstruktor initialisiert die leere Wertliste. */
	FEMArray();

	/** Diese Methode konvertiert diese Wertliste in ein @c ARRAY und gibt dieses zurück. */
	VALUE value() const;

	/** Diese Methode gibt den index-ten Wert zurück. */
	FEMValue get(INT32 const _index) const;

	/** Diese Methode gibt die Länge, d.h. die Anzahl der Werte in der Wertliste zurück. */
	INT32 length() const;

	/** Diese Methode gibt eine Sicht auf die Verkettung dieser Wertliste mit der gegebenen Wertliste zurück. */
	FEMArray concat(FEMArray const& _that) const;

	/** Diese Methode gibt eine Sicht auf einen Abschnitt dieser Wertliste zurück. */
	FEMArray section(INT32 const _offset, INT32 const _length) const;

	/** Diese Methode gibt eine rückwärts geordnete Sicht auf diese Wertliste zurück. */
	FEMArray reverse() const;

	/** Diese Methode gibt die Werte dieser Wertliste in einer performanteren oder zumindest gleichwertigen Wertliste zurück. */
	FEMArray compact() const;

	/** Diese Methode gibt die Position des ersten Vorkommens des gegebenen Werts innerhalb dieser Wertliste zurück.
	 * Die Suche beginnt an der gegebenen Position. Bei einer erfolglosen Suche wird -1 geliefert. */
	INT32 find(FEMValue const& _that, INT32 const _offset) const;

	/** Diese Methode gibt die Position des ersten Vorkommens der gegebenen Wertliste innerhalb dieser Wertliste zurück.
	 * Die Suche beginnt an der gegebenen Position. Bei einer erfolglosen Suche wird -1 geliefert. */
	INT32 find(FEMArray const& _that, INT32 const _offset) const;

	/** Diese Methode fügt alle Werte dieser Wertliste vom ersten zum letzten geordnet an den gegebenen @c COLLECTOR an.
	 * Das Anfügen wird vorzeitig abgebrochen, wenn der @c COLLECTOR @c false liefert. */
	bool extract(PVOID _context, COLLECTOR _collector) const;

	/** Diese Methode gibt -1, 0 bzw. +1 zurück, wenn die lexikographische Ordnung dieser Wertliste kleiner, gleich oder größer als die der gegebenen Wertliste ist.
	 * Die Werte werden über den gegebenen @c COMPARATOR verglichen. */
	INT32 compare(FEMArray const& _that, PVOID _context, COMPARATOR _comparator) const;

};

/** Diese Klasse implementiert eine Zeichenkette, deren Verkettungen, Anschnitte und Umkehrungen als Sichten auf die grundlegenden Zeichenketten realisiert sind. */
struct FEMString: public FEMValue {

	/** Dieser Datentyp definiert die UTF8-kodierten Nutzdaten einer Zeichenketet. */
	typedef SUCArray<UINT8> BYTES;

	/** Dieser Datentyp definiert die UTF16-kodierten Nutzdaten einer Zeichenketet. */
	typedef SUCArray<UINT16> CHARS;

	/** Dieser Datentyp definiert die UTF32-kodierten Nutzdaten einer Zeichenketet. */
	typedef SUCArray<UINT32> VALUE;

	/** Diese Funktion dient dem geordneten Sammeln von Codepoints einer Zeichenketet. */
	typedef bool (*COLLECTOR)(PVOID _context, UINT32 const _value);

	/** Dieses Feld speichert die leere Zeichenkette. */
	static FEMString const EMPTY;

	/** Diese Methode eine Zeichenkette mit den gegebenen UTF8-kodierten und nullterminierten Codepoints zurück. */
	static FEMString from(CHAR const* _string);

	/** Diese Methode eine Zeichenkette mit den gegebenen UTF8-kodierten Codepoints zurück. */
	static FEMString from(UINT8 const* _itemArray, INT32 const _itemCount);

	/** Diese Methode eine Zeichenkette mit den gegebenen UTF16-kodierten Codepoints zurück. */
	static FEMString from(UINT16 const* _itemArray, INT32 const _itemCount);

	/** Diese Methode eine Zeichenkette mit den gegebenen UTF32-kodierten Codepoints zurück. */
	static FEMString from(UINT32 const* _itemArray, INT32 const _itemCount);

	/** Diese Methode gibt eine uniforme Zeichenkette mit der gegebenen Länge zurück, deren Codepoints alle gleich dem gegebenen sind. */
	static FEMString from(UINT32 const _item, INT32 const _itemCount);

	static FEMString from(IAMArray const& _array, bool const _srtuctured = false);

	static FEMString from(FEMString const& _script); // parsen

	/** Dieser Konstruktor initialisiert die leere Zeichenkette. */
	FEMString();

	/** Diese Methode gibt die Codepoints in UTF32-Kodierung und nullterminiert zurück. */
	VALUE value() const;

	/** Diese Methode gibt das index-te Zeichen als Codepoint zurück. */
	UINT32 get(INT32 const _index) const;

	/** Diese Methode gibt die Länge, d.h. die Anzahl der Zeichen in der Zeichenkette zurück. */
	INT32 length() const;

	/** Diese Methode gibt eine Sicht auf die Verkettung dieser Zeichenkette mit der gegebenen Zeichenkette zurück. */
	FEMString concat(FEMString const& _that) const;

	/** Diese Methode gibt eine Sicht auf einen Abschnitt dieser Zeichenkette zurück. */
	FEMString section(INT32 const _offset, INT32 const _length) const;

	/** Diese Methode gibt eine rückwärts geordnete Sicht auf diese Zeichenkette zurück. */
	FEMString reverse() const;

	/** Diese Methode gibt die Codepoints dieser Zeichenkette in einer performanteren oder zumindest gleichwertigen Zeichenkette zurück. */
	FEMString compact() const;

	/** Diese Methode gibt die Position des ersten Vorkommens des gegebenen Zeichens innerhalb dieser Zeichenkette zurück.
	 * Die Suche beginnt an der gegebenen Position. Bei einer erfolglosen Suche wird -1 geliefert.*/
	INT32 find(UINT32 const _that, INT32 const _offset) const;

	/** Diese Methode gibt die Position des ersten Vorkommens der gegebenen Zeichenkette innerhalb dieser Zeichenkette zurück.
	 * Die Suche beginnt an der gegebenen Position. Bei einer erfolglosen Suche wird -1 geliefert. */
	INT32 find(FEMString const& _that, INT32 const _offset) const;

	/** Diese Methode fügt alle Codepoints dieser Zeichenkette vom ersten zum letzten geordnet an den gegebenen @c COLLECTOR an.
	 * Das Anfügen wird vorzeitig abgebrochen, wenn der @c COLLECTOR @c false liefert. */
	bool extract(PVOID _context, COLLECTOR _collector) const;

	/** Diese Methode gibt -1, 0 bzw. +1 zurück, wenn die lexikographische Ordnung dieser Zeichenkette kleiner, gleich oder größer als die der gegebenen Zeichenkette ist. */
	INT32 compare(FEMString const& _that) const;

	/** Diese Methode gibt die Codepoints in UTF8-Kodierung und nullterminiert zurück. */
	BYTES toBytes() const;

	/** Diese Methode gibt die Codepoints in UTF16-Kodierung und nullterminiert zurück. */
	CHARS toChars() const;

	IAMArray toArray(UINT8 const _mode, bool const _srtuctured = false) const;

};

struct FEMBinary: public FEMValue {

	typedef SUCArray<UINT8> VALUE;

	typedef bool (*COLLECTOR)(PVOID _target, UINT8 const _value);

	static FEMBinary const EMPTY;

	static FEMBinary from(VALUE const& _array);
	static FEMBinary from(INT8 const _item, INT32 const _itemCount);
	static FEMBinary from(INT8 const* _itemArray, INT32 const _itemCount);
	static FEMBinary from(FEMString const& _script);

	FEMBinary();
	VALUE value() const;
	UINT8 get(INT32 const _index) const;
	INT32 length() const;
	FEMBinary concat(FEMBinary const& _that) const;
	FEMBinary section(INT32 const _offset, INT32 const _length) const;
	FEMBinary reverse() const;
	FEMBinary compact() const;
	INT32 find(INT8 const _that, INT32 const _offset) const;
	INT32 find(FEMBinary const& _that, INT32 const _offset) const;
	bool extract(PVOID _target, COLLECTOR _collector) const;
	INT32 compare(FEMBinary const& _that) const;

};

struct FEMObject: public FEMValue {

	static FEMObject const EMPTY;

	static FEMObject from(INT64S const& _value);
	static FEMObject from(INT32 const _ref, INT32 const _type, INT32 const _owner);

	FEMObject();
	INT64 value() const;
	INT32 refValue() const;
	INT32 typeValue() const;
	INT32 ownerValue() const;
	FEMObject withRef(INT32 const _ref) const;
	FEMObject withType(INT32 const _type) const;
	FEMObject withOwner(INT32 const _owner) const;
	INT32 compare(FEMObject const& _that) const;

};

struct FEMHandler: public FEMValue {

	static FEMHandler const EMPTY;

	static FEMHandler from(FEMFunction const& _value);

	FEMHandler();
	FEMFunction value() const;

};

struct FEMInteger: public FEMValue {

	static FEMInteger const EMPTY; // FEMInteger_BASE

	static FEMInteger from(INT64 const& _value);
	static FEMInteger from(INT64S const& _value);
	static FEMInteger from(FEMString const& _script);

	FEMInteger();
	INT64 value() const;
	INT32 compare(FEMInteger const& _that) const;

};

struct FEMDecimal: public FEMValue {

	static FEMDecimal const EMPTY;

	static FEMDecimal from(double const& _value);
	static FEMDecimal from(INT64S const& _value);
	static FEMDecimal from(FEMString const& _script);

	FEMDecimal();
	double value() const;
	INT32 compare(FEMDecimal const& _that) const;

};

struct FEMBoolean: public FEMValue {

	static FEMBoolean const TRUE;
	static FEMBoolean const FALSE;

	static FEMBoolean from(bool const _value);
	static FEMBoolean from(FEMString const& _script);

	/** Dieser Konstruktor initialisiert @c FALSE. */
	FEMBoolean();

	/** Diese Methode gibt die Nutzdaten des Waheheitswerts zurück. */
	bool value() const;

	/** Dieser Operator delegiert an @c value(). */
	operator bool() const;

	INT32 compare(FEMBoolean const& _that) const;

};

struct FEMDuration: public FEMValue {

	static FEMDuration const EMPTY;

	static FEMDuration const MINIMUM;

	static FEMDuration const MAXIMUM;

	static FEMDuration from(INT64S const& _value);

	static FEMDuration from(INT32 _durationmonths, INT64 _durationmillis);

	static FEMDuration from(INT32 const _years, INT32 const _months, INT32 const _days, INT32 const _hours, INT64 const _minutes, INT64 const _seconds, INT64 const _milliseconds);

	static FEMDuration from(FEMString const& _script);

	static FEMDuration between(FEMDatetime const& _datetime1, FEMDatetime const& _datetime2);

	static INT32 minLengthOf(INT32 const _months);

	static INT32 maxLengthOf(INT32 const _months);

	static INT64 durationmillisOf(INT32 const _days, INT32 const _hours, INT64 const _minutes, INT64 const _seconds, INT64 const _milliseconds);

	static INT32 durationmonthsOf(INT32 const _years, INT32 const _months);

	FEMDuration();

	INT64 value() const;

	INT32 signValue() const;

	INT32 yearsValue() const;

	INT32 monthsValue() const;

	INT32 daysValue() const;

	INT32 hoursValue() const;

	INT32 minutesValue() const;

	INT32 secondsValue() const;

	INT32 millisecondsValue() const;

	INT64 durationmillisValue() const;

	INT32 durationmonthsValue() const;

	FEMDuration negate() const;

	FEMDuration move(INT32 const _durationmonths, INT64 const _durationmillis) const;

	FEMDuration move(INT32 const _years, INT32 const _months, INT32 const _days, INT32 const _hours, INT64 const _minutes, INT64 const _seconds, INT64 const _milliseconds) const;

	FEMDuration move(FEMDuration const& duration) const;

	INT32 compare(FEMDuration const& _that, INT32 const _undefined = 0) const;

};

struct FEMDatetime: public FEMValue {

	static FEMDatetime const EMPTY;
	static FEMDatetime const MINIMUM;
	static FEMDatetime const MAXIMUM;

	static FEMDatetime now();
	static FEMDatetime from(INT64S const& value);
	static FEMDatetime from(INT64 const& _millis);
	static FEMDatetime from(FEMString const& _script);
	static FEMDatetime fromDate(INT32 const _calendarday);
	static FEMDatetime fromDate(INT32 const _year, INT32 const _month, INT32 const _date);
	static FEMDatetime fromTime(INT32 const _daymillis);
	static FEMDatetime fromTime(INT32 const _hour, INT32 const _minute, INT32 const _second, INT32 const _millisecond);
	static FEMDatetime fromZone(INT32 const _zone);
	static FEMDatetime fromZone(INT32 const _zoneHour, INT32 const _zoneMinute);
	static bool leapOf(INT32 const _year);
	static INT32 lengthOf(INT32 const _month, INT32 const _year);
	static INT32 lengthOf(INT32 const _month, bool _leap);
	static INT32 yeardayOf(INT32 const _calendarday);
	static INT32 weekdayOf(INT32 const _calendarday);
	static INT32 daymillisOf(INT32 const _hour, INT32 const _minute, INT32 const _second, INT32 const _millisecond);
	static INT32 calendardayOf(INT32 const _year, INT32 const _month, INT32 const _date);

	FEMDatetime();
	INT64 value() const;
	INT32 yearValue() const;
	INT32 dateValue() const;
	INT32 monthValue() const;
	INT32 hourValue() const;
	INT32 minuteValue() const;
	INT32 secondValue() const;
	INT32 millisecondValue() const;
	INT32 zoneValue() const;
	bool hasDate() const;
	bool hasTime() const;
	bool hasZone() const;
	INT32 yeardayValue() const;
	INT32 weekdayValue() const;
	INT32 daymillisValue() const;
	INT32 calendardayValue() const;
	FEMDatetime withDate(INT32 const _calendarday) const;
	FEMDatetime withDate(INT32 const _year, INT32 const _month, INT32 const _date) const;
	FEMDatetime withDate(FEMDatetime const& _datetime) const;
	FEMDatetime withTime(INT32 const _daymillis) const;
	FEMDatetime withTime(INT32 const _hour, INT32 const _minute, INT32 const _second, INT32 const _millisecond) const;
	FEMDatetime withTime(FEMDatetime const& _datetime) const;
	FEMDatetime withZone(INT32 const _zone) const;
	FEMDatetime withZone(INT32 const _zoneHour, INT32 const _zoneMinute) const;
	FEMDatetime withZone(FEMDatetime const& _datetime) const;
	FEMDatetime withoutDate() const;
	FEMDatetime withoutTime() const;
	FEMDatetime withoutZone() const;
	FEMDatetime move(FEMDatetime const& _duration) const;
	FEMDatetime moveDate(INT32 const _years, INT32 const _months, INT32 const _days) const;
	FEMDatetime moveDate(FEMDatetime const& _duration) const;
	FEMDatetime moveTime(INT32 const _hours, INT32 const _minutes, INT32 const _seconds, INT32 const _milliseconds) const;
	FEMDatetime moveTime(INT32 const _hours, INT64 const& _minutes, INT64 const& _seconds, INT64 const& _milliseconds) const;
	FEMDatetime moveTime(FEMDatetime const& _duration) const;
	FEMDatetime moveZone(INT32 const _hours, INT32 const _minutes) const;
	FEMDatetime normalize() const;
	INT32 compare(FEMDatetime const& _that, INT32 const _undefined) const;

};

struct FEMException {

	struct OBJECT: public RCObject<OBJECT> {
		~OBJECT();
	};

	typedef FEMValue::LISTING MESSAGES;

	static void checkState(bool _valid) {
		if (!_valid) throw FEMException();
	}

	static void checkNull(PCVOID _array) {
		if (!_array) throw FEMException();
	}

	static void checkCount(INT32 const _count) {
		if (_count < 0) throw FEMException();
	}
	static void checkIndex(INT32 const _index, INT32 const _count) {
		if (_index < 0 || _index >= _count) throw FEMException();
	}

	FEMException();

	FEMValue& value();

	FEMContext& context();

	MESSAGES& messages();

	FEMException& putValue(FEMValue const& _value);

	FEMException& putContext(FEMContext const& _context);

	FEMException& putMessage(FEMString const& _message);

	protected:

	RCPointer<OBJECT> _object_;

};

}

}

}

#endif
