/* [cc-by] 2013..2016 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#include "bee_creative_fem.hpp"
#include <string.h>
#include <iostream>

namespace bee {

namespace creative {

namespace fem {

typedef FEMFrame::OBJECT FEMFrameOBJ;
typedef RCPointer<FEMFrameOBJ> FEMFramePTR;
typedef FEMContext::OBJECT FEMContextOBJ;
typedef RCPointer<FEMContextOBJ> FEMContextPTR;
typedef FEMFunction::OBJECT FEMFunctionOBJ;
typedef RCPointer<FEMFunctionOBJ> FEMFunctionPTR;
typedef FEMException::OBJECT FEMExceptionOBJ;
typedef RCPointer<FEMExceptionOBJ> FEMExceptionPTR;
struct FEMArrayCYCLIC;
struct FEMContextBASE;

struct __________;

/** Diese Klasse definiert die abstrakte Grundlage der Nutzdaten von Stapelrahmen, Funktionen und Werten. */
struct FEMFrameBASE: public RCObject<FEMFrameBASE> { // DONE

	/** Dieser Datentyp definiert die Auflistung der Typkennungen. */
	enum FRAME_TYPE {
		FRAME_ARRAY, // konst value
		FRAME_CYCLIC, //
		FRAME_INVOKE, // funkt
		FRAME_CONTEXT, // leer mit ctxt
		FRAME_CUSTOM1, // ? iam paams
		FRAME_CUSTOM2, // ?
		FRAME_CUSTOM3
	};

	static FEMFramePTR EMPTY;

	/** Dieses Feld speichert die Typkennung, mit der Fallunterscheidungen erfolgen. */
	FRAME_TYPE const dataType;

	/** Dieses Feld speichert die Anzahl der Parameter. */
	INT32 frameSize;

	/** Dieses Feld speichert den Verweis auf den übergeordneten Stapelrahmen. */
	FEMFramePTR parentFrame;

	/** Dieses Feld speichert den Verweis auf den Kontext. */
	FEMContextBASE const* ownerContext;

	FEMFrameBASE(FRAME_TYPE _dataType, INT32 const _frameSize, FEMFramePTR const& _parentFrame);

	FEMFrameBASE(FRAME_TYPE _dataType, INT32 const _frameSize, FEMContextBASE const& _ownerContext);

	FEMValue frameGetBASE(INT32 const _index) const;

	FEMArray frameParamsBASE() const;

};

struct FEMFrameARRAY: public FEMFrameBASE { // DONE

	/** Dieses Feld speichert die Parameterwerte. */
	FEMArray paramArray;

	FEMFrameARRAY(FEMFramePTR const& _parentFrame, FEMArray const& _paramArray);

	FEMValue frameGetARRAY(INT32 const _index) const;

	FEMArray frameParamsARRAY() const;

};

/** Diese Klasse implementiert die Nutzdaten eines Parameterwerts, der über eine Parameterfunktion berechnet werden kann. */
struct FEMFramePARAM { // DONE

	/** Dieses Feld speichert den Parameterwert zur Wiederverwendung. */
	FEMFunctionPTR paramValue;

	/** Dieses Feld speichert die Funktion zur Berechnung des Parameterwerts. */
	FEMFunction paramFunction;

	FEMFramePARAM(FEMFunction const& _paramFunction);

};

/** Diese Klasse implementiert die Nutzdaten eines Stapelrahmen, desses Parameterwerte über Parameterfunktionen bereitgestellt werden. */

struct FEMFrameCYCLIC: public FEMFrameBASE { // DONE

	/** Dieses Feld speichert die Wertliste als Sicht auf die Parameterwert. */
	FEMArrayCYCLIC* cyclicArray;

	FEMFrameCYCLIC(FEMContextBASE const& _ownerContext);

	FEMFrameCYCLIC(FRAME_TYPE const _dataType, INT32 const _frameSize, FEMFramePTR const& _parentFrame);

	FEMArray frameParamsCYCLIC() const;

};

/** Diese Klasse implementiert die Nutzdaten eines Stapelrahmen, desses Parameterwerte über Parameterfunktionen bereitgestellt werden. */
struct FEMFrameINVOKE: public FEMFrameCYCLIC { // DONE

	/** Dieses Feld speichert Paare aus Parameterwert und Parameterfunktion. */
	FEMFramePARAM paramArray[0];

	FEMFrameINVOKE(FEMFramePTR const& _parentFrame, FEMFunction const* _paramArray, INT32 const _paramCount);

	~FEMFrameINVOKE();

	FEMValue frameGetINVOKE(INT32 const _index) const;

};

struct FEMFrameCONTEXT: public FEMFrameBASE { // DONE

	FEMContext parentContext;

	FEMFrameCONTEXT(FEMContext const& _parentContext);

	FEMValue frameGetCONTEXT(INT32 const _index) const;

	FEMArray frameParamsCONTEXT() const;

};

struct FEMFrameCUSTOM1: public FEMFrameCYCLIC { // DONE

	FEMFrameCUSTOM1();

	~FEMFrameCUSTOM1();

	FEMValue frameGetCUSTOM1(INT32 const _index) const;

};

struct FEMFrameCUSTOM2: public FEMFrameCYCLIC { // DONE

	FEMFrameCUSTOM2();
	~FEMFrameCUSTOM2();
	FEMValue frameGetCUSTOM2(INT32 const _index) const;

};

struct FEMFrameCUSTOM3: public FEMFrameCYCLIC { // DONE

	FEMFrameCUSTOM3();

	~FEMFrameCUSTOM3();

	FEMValue frameGetCUSTOM3(INT32 const _index) const;

};

struct __________;

struct FEMFunctionBASE: public RCObject<FEMFunctionBASE> { // DONE

	enum DATA_TYPE {
		FUNCTION_PROXY, //
		FUNCTION_PARAM, //
		FUNCTION_FRAME, //
		FUNCTION_METHOD, //
		FUNCTION_CONCAT, //
		FUNCTION_COMPOSE, //
		FUNCTION_CUSTOM1, // systemfun
		FUNCTION_CUSTOM2, // ?
		FUNCTION_CUSTOM3, // ?
		VALUE_VOID, VALUE_TRUE, VALUE_FALSE, //
		ARRAY_VALUE, //
		ARRAY_CYCLIC, //
		ARRAY_CONCAT, //
		ARRAY_SECTION, //
		ARRAY_REVERSE, //
		ARRAY_UNIFORM, //
		ARRAY_CUSTOM1, // binary as array of boolean
		ARRAY_CUSTOM2, // iam-array as array of value-ref
		ARRAY_CUSTOM3, // iam_array as array of object-ref
		STRING_BYTES, STRING_CHARS, STRING_VALUE, STRING_CONCAT, STRING_SECTION, STRING_REVERSE, STRING_UNIFORM, STRING_CUSTOM1, // iam_array as utf16 mit länge im ersten element
		STRING_CUSTOM2, //
		STRING_CUSTOM3, //
		BINARY_VALUE, BINARY_CONCAT, BINARY_SECTION, BINARY_REVERSE, BINARY_UNIFORM, BINARY_CUSTOM1, // array as binary view
		BINARY_CUSTOM2, // iam_array als uint8 ohne kopie
		BINARY_CUSTOM3, // integer als binary[8]
		OBJECT_BASE, HANDLER_BASE, INTEGER_BASE, DECIMAL_BASE, DURATION_BASE, DATETIME_BASE
	};

	/** Dieses Feld speichert die Typkennung. */
	DATA_TYPE const dataType;

	FEMFunctionBASE(DATA_TYPE const _dataType);
	FEMFunction::TYPE functionType() const;
	INT32 functionHashBASE() const;
	FEMString functionScriptBASE() const;
	bool functionEqualsBASE(FEMFunctionBASE const& _that) const;
	FEMValue functionInvokeBASE(FEMFrame const& _frame) const;

};

/** Diese Klasse definiert die Nutzdaten eines FEMProxy. */
struct FEMFunctionPROXY: public FEMFunctionBASE { // DONE

	/** Dieses Feld speichert den Namen des Platzhalters. */
	FEMString proxyName;

	/** Dieses Feld speichert die Funktion, die der Platzhalter aufruft. */
	FEMFunction proxyTarget;

	FEMFunctionPROXY(FEMString const& _proxyName);
	INT32 functionHashPROXY() const;
	FEMString functionScriptPROXY() const;
	bool functionEqualsPROXY(FEMFunctionPROXY const& _that) const;
	FEMValue functionInvokePROXY(FEMFrame const& _frame) const;

};

/** Diese Klasse definiert die Nutzdaten eines FEMParam. */
struct FEMFunctionPARAM: public FEMFunctionBASE { // DONE

	static FEMString const SCRIPT;

	/** Dieses Feld speichert den Parameterindex. */
	INT32 paramIndex;

	FEMFunctionPARAM(UINT32 const& _paramIndex);
	INT32 functionHashPARAM() const;
	FEMString functionScriptPARAM() const;
	bool functionEqualsPARAM(FEMFunctionPARAM const& _that) const;
	FEMValue functionInvokePARAM(FEMFrame const& _frame) const;

};

/** Diese Klasse implementiert einen Puffer zur Wiederverwendung von FEMParam-Instanzen. */
struct FEMFunctionCACHE { // DONE

	static FEMFunctionCACHE INSTANCE;

	/** Dieses Feld speichert die Anzahl der FEMParam-Instanzen. */
	static UINT8 const functionCount = 16;

	/** Dieses Feld speichert die FEMParam-Instanzen. */
	FEMFunctionPTR functionArray[functionCount];

	/** Dieser Konstruktor initialisiert die FEMParam-Instanzen. */
	FEMFunctionCACHE();

};

struct FEMFunctionFRAME: public FEMFunctionBASE { // DONE

	static FEMString const SCRIPT;
	static FEMFunctionFRAME const* INSTANCE;

	FEMFunctionFRAME();
	INT32 functionHashFRAME() const;
	FEMString functionScriptFRAME() const;
	bool functionEqualsFRAME(FEMFunctionFRAME const& _that) const;
	FEMValue functionInvokeFRAME(FEMFrame const& _frame) const;

};

struct FEMFunctionMETHOD: public FEMFunctionBASE { // DONE

	FEMFunction::METHOD invokeMethod;

	FEMFunctionMETHOD(FEMFunction::METHOD _invokeMethod);
	INT32 functionHashMETHOD() const;
	FEMString functionScriptMETHOD() const;
	bool functionEqualsMETHOD(FEMFunctionMETHOD const& _that) const;
	FEMValue functionInvokeMETHOD(FEMFrame const& _frame) const;

};

struct FEMFunctionINVOKE: public FEMFunctionBASE { // DONE

	static FEMString const SCRIPT_OPEN;

	static FEMString const SCRIPT_CLOSE;

	static FEMString const SCRIPT_COMMA;

	static FEMString const SCRIPT_EMPTY;

	FEMFunction invokeMethod;

	INT32 paramCount;

	FEMFunction paramArray[0];

	FEMFunctionINVOKE(DATA_TYPE _dataType, FEMFunction const& _invokeMethod, FEMFunction const* _paramArray, INT32 _paramCount);
	~FEMFunctionINVOKE();
	INT32 functionHashINVOKE() const;
	FEMString functionScriptINVOKE() const;
	bool functionEqualsINVOKE(FEMFunctionINVOKE const& _that) const;

};

struct FEMFunctionCONCAT: public FEMFunctionINVOKE { // DONE

	FEMFunctionCONCAT(FEMFunction const& _invokeMethod, FEMFunction const* _paramArray, INT32 _paramCount);

	FEMValue functionInvokeCONCAT(FEMFrame const& _frame) const;

};

struct FEMFunctionCOMPOSE: public FEMFunctionINVOKE { // DONE

	FEMFunctionCOMPOSE(FEMFunction const& _invokeMethod, FEMFunction const* _paramArray, INT32 _paramCount);

	FEMValue functionInvokeCOMPOSE(FEMFrame const& _frame) const;

};

struct FEMFunctionCUSTOM1: public FEMFunctionBASE { // DONE

	FEMFunctionCUSTOM1();
	~FEMFunctionCUSTOM1();
	INT32 functionHashCUSTOM1() const;
	FEMString functionScriptCUSTOM1() const;
	bool functionEqualsCUSTOM1(FEMFunctionCUSTOM1 const& _that) const;
	FEMValue functionInvokeCUSTOM1(FEMFrame const& _frame) const;

};

struct FEMFunctionCUSTOM2: public FEMFunctionBASE { // DONE

	FEMFunctionCUSTOM2();
	~FEMFunctionCUSTOM2();
	INT32 functionHashCUSTOM2() const;
	FEMString functionScriptCUSTOM2() const;
	bool functionEqualsCUSTOM2(FEMFunctionCUSTOM2 const& _that) const;
	FEMValue functionInvokeCUSTOM2(FEMFrame const& _frame) const;

};

struct FEMFunctionCUSTOM3: public FEMFunctionBASE { // DONE

	FEMFunctionCUSTOM3();
	~FEMFunctionCUSTOM3();
	INT32 functionHashCUSTOM3() const;
	FEMString functionScriptCUSTOM3() const;
	bool functionEqualsCUSTOM3(FEMFunctionCUSTOM3 const& _that) const;
	FEMValue functionInvokeCUSTOM3(FEMFrame const& _frame) const;

};

struct __________;

struct FEMValueBASE: public FEMFunctionBASE { // DONE

	FEMValueBASE(DATA_TYPE const _dataType);
	FEMValue::TYPE valueType() const;
	FEMValue functionInvokeVALUE() const;

};

struct __________;

struct FEMValueVOID: public FEMValueBASE { // DONE

	static FEMString const SCRIPT;
	static FEMValueVOID const* INSTANCE;

	FEMValueVOID();
	FEMString functionScriptVOID() const;

};

struct FEMValueTRUE: public FEMValueBASE { // DONE

	static FEMString const SCRIPT;
	static FEMValueTRUE const* INSTANCE;

	FEMValueTRUE();
	FEMString functionScriptTRUE() const;

};

struct FEMValueFALSE: public FEMValueBASE { // DONE

	static FEMString const SCRIPT;
	static FEMValueFALSE const* INSTANCE;

	FEMValueFALSE();
	FEMString functionScriptFALSE() const;

};

struct __________;

struct FEMArrayBASE: public FEMValueBASE { // DONE

	static FEMArrayBASE const* EMPTY;

	static FEMString const SCRIPT_OPEN;

	static FEMString const SCRIPT_CLOSE;

	static FEMString const SCRIPT_COMMA;

	static bool hashEncoder(PVOID _context, FEMValue const& _value);
	static bool scriptEncoder(PVOID _context, FEMValue const& _value);

	INT32 arrayLength;

	FEMArrayBASE(DATA_TYPE const _dataType, INT32 const _arrayLength);
	FEMValue arrayGetBASE(INT32 const _index) const;
	bool arrayExtractBASE(PVOID _context, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMArray arraySectionBASE(INT32 const _offset, INT32 const _length) const;
	FEMArray arrayCompactBASE() const;
	FEMArray arrayReverseBASE() const;
	INT32 functionHashARRAY() const;
	FEMString functionScriptARRAY() const;
	bool functionEqualsARRAY(FEMArrayBASE const& _that) const;
	bool arrayExtractDEFAULT(PVOID _target, FEMArray::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;
	FEMArray arraySectionDEFAULT(INT32 const _offset, INT32 const _length) const;
	FEMArray arrayCompactDEFAULT() const;
	FEMArray arrayReverseDEFAULT() const;

};

struct FEMArrayVALUE: public FEMArrayBASE { // DONE

	FEMValue valueArray[0];

	FEMArrayVALUE(INT32 const _arrayLength);
	FEMArrayVALUE(FEMValue const* _valueArray, INT32 const _valueCount);
	~FEMArrayVALUE();
	FEMValue arrayGetVALUE(INT32 const _index) const;
	bool arrayExtractVALUE(PVOID _target, FEMArray::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;
	FEMArray arrayCompactVALUE() const;

};

/** Diese Klasse implementiert die Nutzdaten einer Wertliste, deren Elemente den zugesicherten Parameterwerten eines Stapelraumen entsprechen. */
struct FEMArrayCYCLIC: public FEMArrayBASE { // DONE

	/** Dieses Feld verweist auf die Nutzdaten des Stapelrahmen, dessen Parameterwerte als Elemente der Wertliste mit diesen Nutzdaten genutzt werden.
	 *  Dieser Verweis ist niemals @c null. */
	FEMFramePTR cyclicFrame;

	/** Dieses Feld verweist auf die vorherigen Nutzdaten in der doppelt verketteten und im Kontextobjekt verwalteten Liste.
	 *  Dieser Verweis ist niemals @c null. */
	FEMArrayCYCLIC* cyclicPrev;

	/** Dieses Feld verweist auf die nächsten Nutzdaten in der doppelt verketteten und im Kontextobjekt verwalteten Liste.
	 *  Dieser Verweis ist niemals @c null. */
	FEMArrayCYCLIC* cyclicNext;

	/** Dieses Feld verweist auf die Nutzdaten des Kontextobjekts, in welchem der Lebenslauf dieser Nutzdaten verwaltet wird.
	 *  Dieser Verweis ist niemals @c null. */
	FEMContextBASE const* cyclicContext;

	/** Dieser Kontruktor initialisiert den gezählten Verweis auf den Stapelrahmen.
	 * Als Kontextobjekt wird das des Stapelrahmen verwendet.
	 * Die Länge der Wertliste entspricht der Anzahl der zugesicherten Parameter des Stapelrahmen.
	 * Diese Nutzdaten werden in die doppelt verketteten Liste im Kontextobjekt eingefügt.
	 * Der Aufruf darf nur im Rahmen des kritischen Abschnitts des Kontextobjekts erfolgen. */
	FEMArrayCYCLIC(FEMFrameCYCLIC const& _cyclicFrame);

	/** Dieser Kontruktor initialisiert den gezählten Verweis auf das Kontextobjekt.
	 *  Die Länge der Wertliste ist @c 0.
	 *  Diese Nutzdaten werden als Wurzel de doppelt verketteten Liste im Kontextobjekt initialisiert und nutzen daher nicht den kritischen Abschnitt im Kontextobjekt. */
	FEMArrayCYCLIC(FEMContextBASE const& _ownerContext);

	/** Dieser Destruktor löst via @c deleteCYCLIC() die Verbindung zum Stapelrahmen sowie zum Kontextobjekt. */
	~FEMArrayCYCLIC();

	FEMValue arrayGetCYCLIC(INT32 const _index) const;

	/** Diese Methode löst die Verbindung zum Stapelrahmen sowie zur doppelt verketteten Liste im Kontextobjekt.
	 *  Der Aufruf darf zwar beliebig oft jedoch nur im Rahmen des kritischen Abschnitts des Kontextobjekts erfolgen. */
	void cyclicDelete();

};

struct FEMArrayCONCAT: public FEMArrayBASE { // DONE

	FEMArray array1;

	FEMArray array2;

	FEMArrayCONCAT(INT32 const _arrayLength, FEMArray const& _array1, FEMArray const& _array2);
	FEMValue arrayGetCONCAT(INT32 const _index) const;
	bool arrayExtractCONCAT(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMArray arraySectionCONCAT(INT32 _offset, INT32 _length) const;

};

struct FEMArraySECTION: public FEMArrayBASE { // DONE

	FEMArray array;

	INT32 offset;

	FEMArraySECTION(FEMArray const& _array, INT32 const _offset, INT32 const _length);
	FEMValue arrayGetSECTION(INT32 const _index) const;
	bool arrayExtractSECTION(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMArray arraySectionSECTION(INT32 _offset, INT32 _length) const;

};

struct FEMArrayREVERSE: public FEMArrayBASE { // DONE

	FEMArray array;

	FEMArrayREVERSE(FEMArray const& _array);
	FEMValue arrayGetREVERSE(INT32 const _index) const;
	bool arrayExtractREVERSE(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMArray arraySectionREVERSE(INT32 _offset, INT32 _length) const;
	FEMArray arrayReverseREVERSE() const;

};

struct FEMArrayUNIFORM: public FEMArrayBASE { // DONE

	FEMValue value;

	FEMArrayUNIFORM(FEMValue const& _value, INT32 const _length);
	FEMValue arrayGetUNIFORM(INT32 const _index) const;
	bool arrayExtractUNIFORM(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMArray arraySectionUNIFORM(INT32 _offset, INT32 _length) const;
	FEMArray arrayCompactUNIFORM() const;
	FEMArray arrayReverseUNIFORM() const;

};

struct FEMArrayCUSTOM1: public FEMArrayBASE { // DONE

	FEMArrayCUSTOM1();
	~FEMArrayCUSTOM1();
	FEMValue arrayGetCUSTOM1(INT32 const _index) const;

};

struct FEMArrayCUSTOM2: public FEMArrayBASE { // DONE

	FEMArrayCUSTOM2();
	~FEMArrayCUSTOM2();
	FEMValue arrayGetCUSTOM2(INT32 const _index) const;

};

struct FEMArrayCUSTOM3: public FEMArrayBASE { // DONE

	FEMArrayCUSTOM3();
	~FEMArrayCUSTOM3();
	FEMValue arrayGetCUSTOM3(INT32 const _index) const;

};

struct __________;

struct FEMStringBASE: public FEMValueBASE { // DONE

	static FEMStringBASE const* EMPTY;

	static bool functionHashEncoder(PVOID _context, UINT32 const _value);
	static bool functionScriptCounter(PVOID _context, UINT32 const _value);
	static bool functionScriptEncoder(PVOID _context, UINT32 const _value);

	INT32 stringLength;

	FEMStringBASE(DATA_TYPE const _dataType, INT32 const _stringLength);
	UINT32 stringGetBASE(INT32 const _index) const;
	bool stringExtractBASE(PVOID _context, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMString stringSectionBASE(INT32 const _offset, INT32 const _length) const;
	FEMString stringReverseBASE() const;
	FEMString stringCompactBASE() const;
	FEMString functionScriptSTRING() const;
	INT32 functionHashSTRING() const;
	bool functionEqualsSTRING(FEMStringBASE const& _that) const;
	bool stringExtractDEFAULT(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;
	FEMString stringSectionDEFAULT(INT32 const _offset, INT32 const _length) const;
	FEMString stringReverseDEFAULT() const;
	FEMString stringCompactDEFAULT() const;

};

struct FEMStringBYTES: public FEMStringBASE { // DONE

	static bool stringUTF8Header(UINT8 const _item);
	static UINT8 stringUTF8Size(UINT8 const _item);
	static INT32 stringUTF8Length(UINT8 const* _itemArray, INT32 const _itemCount);
	static UINT32 stringUTF8Codepoint(UINT8 const* _itemArray);
	static bool stringUTF8Counter(PVOID _context, UINT32 const _value);
	static bool stringUTF8Encoder(PVOID _context, UINT32 const _value);

	UINT8 itemArray[0];

	FEMStringBYTES(INT32 const _stringLength);
	FEMStringBYTES(INT32 const _stringLength, UINT8 const* _itemArray, INT32 const _itemCount);
	UINT32 stringGetBYTES(INT32 _index) const;
	bool stringExtractBYTES(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;

};

struct FEMStringCHARS: public FEMStringBASE { // DONE

	static INT32 stringUTF16Size(UINT16 const _item);
	static bool stringUTF16Header(UINT16 const _item);
	static INT32 stringUTF16Length(UINT16 const* _itemArray, INT32 const _itemCount);
	static UINT32 stringUTF16Codepoint(UINT16 const* _itemArray);
	static bool stringUTF16Counter(PVOID _context, UINT32 const _value);
	static bool stringUTF16Encoder(PVOID _context, UINT32 const _value);

	UINT16 itemArray[0];

	FEMStringCHARS(INT32 const _stringLength, UINT16 const* _itemArray, INT32 const _itemCount);
	UINT32 stringGetCHARS(INT32 _index) const;
	bool stringExtractCHARS(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;

};

struct FEMStringVALUE: public FEMStringBASE { // DONE

	static bool stringUTF32Encoder(PVOID _context, UINT32 const _value);

	UINT32 itemArray[0];

	FEMStringVALUE(INT32 const _length);
	FEMStringVALUE(UINT32 const* _itemArray, INT32 const _itemCount);
	UINT32 stringGetVALUE(INT32 const _index) const;
	bool stringExtractVALUE(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;
	FEMString stringCompactVALUE() const;

};

struct FEMStringCONCAT: public FEMStringBASE { // DONE

	FEMString string1;

	FEMString string2;

	FEMStringCONCAT(INT32 const _stringLength, FEMString const& _string1, FEMString const& _string2);
	UINT32 stringGetCONCAT(INT32 const _index) const;
	bool stringExtractCONCAT(PVOID _context, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMString stringSectionCONCAT(INT32 const _offset, INT32 const _length) const;

};

struct FEMStringSECTION: public FEMStringBASE { // DONE

	FEMString string;

	UINT32 offset;

	FEMStringSECTION(FEMString const& _string, INT32 const _offset, INT32 const _length);
	UINT32 stringGetSECTION(INT32 const _index) const;
	bool stringExtractSECTION(PVOID _context, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMString stringSectionSECTION(INT32 const _offset, INT32 const _length) const;

};

struct FEMStringREVERSE: public FEMStringBASE { // DONE

	FEMString string;

	FEMStringREVERSE(FEMString const& _string);
	UINT32 stringGetREVERSE(INT32 const _index) const;
	bool stringExtractREVERSE(PVOID _context, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMString stringSectionREVERSE(INT32 const _offset, INT32 const _length) const;
	FEMString stringReverseREVERSE() const;

};

struct FEMStringUNIFORM: public FEMStringBASE { // DONE

	UINT32 value;

	FEMStringUNIFORM(UINT32 const& _value, INT32 const _stringLength);
	UINT32 stringGetUNIFORM(INT32 const _index) const;
	bool stringExtractUNIFORM(PVOID _context, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMString stringSectionUNIFORM(INT32 const _offset, INT32 const _length) const;
	FEMString stringReverseUNIFORM() const;
	FEMString stringCompactUNIFORM() const;

};

struct FEMStringCUSTOM1: public FEMStringBASE { // DONE

	FEMStringCUSTOM1();
	UINT32 stringGetCUSTOM1(INT32 const _index) const;

};

struct FEMStringCUSTOM2: public FEMStringBASE { // DONE

	FEMStringCUSTOM2();
	UINT32 stringGetCUSTOM2(INT32 const _index) const;

};

struct FEMStringCUSTOM3: public FEMStringBASE { // DONE

	FEMStringCUSTOM3();
	UINT32 stringGetCUSTOM3(INT32 const _index) const;

};

struct __________;

struct FEMBinaryBASE: public FEMValueBASE { // DONE

	static FEMBinaryBASE const* EMPTY;

	static bool functionHashEncoder(PVOID _context, UINT8 const _value);
	static UINT8 functionScriptItem(UINT8 const _value);
	static bool functionScriptEncoder(PVOID _context, UINT8 const _value);

	INT32 binaryLength;

	FEMBinaryBASE(DATA_TYPE const _dataType, INT32 const _binaryLength);
	UINT32 binaryGetBASE(INT32 const _index) const;
	bool binaryExtractBASE(PVOID _target, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMBinary binarySectionBASE(INT32 const _offset, INT32 const _length) const;
	FEMBinary binaryCompactBASE() const;
	FEMBinary binaryReverseBASE() const;

	INT32 functionHashBINARY() const;
	FEMString functionScriptBINARY() const;
	bool functionEqualsBINARY(FEMBinaryBASE const& _that) const;
	bool binaryExtractDEFAULT(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;
	FEMBinary binarySectionDEFAULT(INT32 const _offset, INT32 const _length) const;

	FEMBinary binaryCompactDEFAULT() const;
	FEMBinary binaryReverseDEFAULT() const;

};

struct FEMBinaryVALUE: public FEMBinaryBASE { // DONE

	UINT32 itemArray[0];

	FEMBinaryVALUE(INT32 const _length);
	FEMBinaryVALUE(UINT32 const* _itemArray, INT32 const _itemCount);
	UINT32 binaryGetVALUE(INT32 const _index) const;
	bool binaryExtractVALUE(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const;
	FEMBinary binaryCompactVALUE() const;

};

struct FEMBinaryCONCAT: public FEMBinaryBASE { // DONE

	FEMBinary binary1;

	FEMBinary binary2;

	FEMBinaryCONCAT(INT32 const _binaryLength, FEMBinary const& _binary1, FEMBinary const& _binary2);
	UINT32 binaryGetCONCAT(INT32 const _index) const;
	bool binaryExtractCONCAT(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMBinary binarySectionCONCAT(INT32 const _offset, INT32 const _length) const;

};

struct FEMBinarySECTION: public FEMBinaryBASE { // DONE

	FEMBinary binary;

	UINT32 offset;

	FEMBinarySECTION(FEMBinary const& _binary, INT32 const _offset, INT32 const _length);
	UINT32 binaryGetSECTION(INT32 const _index) const;
	bool binaryExtractSECTION(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMBinary binarySectionSECTION(INT32 const _offset, INT32 const _length) const;

};

struct FEMBinaryREVERSE: public FEMBinaryBASE { // DONE

	FEMBinary binary;

	FEMBinaryREVERSE(FEMBinary const& _binary);
	UINT32 binaryGetREVERSE(INT32 const _index) const;
	bool binaryExtractREVERSE(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMBinary binarySectionREVERSE(INT32 const _offset, INT32 const _length) const;
	FEMBinary binaryReverseREVERSE() const;

};

struct FEMBinaryUNIFORM: public FEMBinaryBASE { // DONE

	UINT8 value;

	FEMBinaryUNIFORM(UINT8 const _value, INT32 const _binaryLength);
	UINT32 binaryGetUNIFORM(INT32 const _index) const;
	bool binaryExtractUNIFORM(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const;
	FEMBinary binarySectionUNIFORM(INT32 const _offset, INT32 const _length) const;
	FEMBinary binaryReverseUNIFORM() const;
	FEMBinary binaryCompactUNIFORM() const;

};

struct FEMBinaryCUSTOM1: public FEMBinaryBASE { // DONE

	FEMBinaryCUSTOM1();
	UINT32 binaryGetCUSTOM1(INT32 const _index) const;

};

struct FEMBinaryCUSTOM2: public FEMBinaryBASE { // DONE

	FEMBinaryCUSTOM2();
	UINT32 binaryGetCUSTOM2(INT32 const _index) const;

};

struct FEMBinaryCUSTOM3: public FEMBinaryBASE { // DONE

	FEMBinaryCUSTOM3();
	UINT32 binaryGetCUSTOM3(INT32 const _index) const;

};

struct __________;

struct FEMObjectBASE: public FEMValueBASE {

	INT32 refValue;

	UINT16 typeValue;

	UINT16 ownerValue;

	FEMObjectBASE(INT32 const _refValue, UINT16 const _typeValue, UINT16 const _ownerValue);
	INT32 functionHashOBJECT() const;
	FEMString functionScriptOBJECT() const;
	bool functionEqualsOBJECT(FEMObjectBASE const& _that) const;

};

struct __________;

struct FEMHandlerBASE: public FEMValueBASE {

	static FEMString const SCRIPT_OPEN;
	static FEMString const SCRIPT_CLOSE;

	FEMFunction handlerValue;

	FEMHandlerBASE(FEMFunction const& _handlerValue);
	INT32 functionHashHANDLER() const;
	FEMString functionScriptHANDLER() const;
	bool functionEqualsHANDLER(FEMHandlerBASE const& _that) const;

};

struct __________;

struct FEMIntegerBASE: public FEMValueBASE {

	INT64 value;

	FEMIntegerBASE(INT64 const& _value);
	INT32 functionHashINTEGER() const;
	FEMString functionScriptINTEGER() const;
	bool functionEqualsINTEGER(FEMIntegerBASE const& _that) const;

};

struct __________;

struct FEMDecimalBASE: public FEMValueBASE {

	double value;

	FEMDecimalBASE(double const& _value);
	INT32 functionHashDECIMAL() const;
	FEMString functionScriptDECIMAL() const;
	bool functionEqualsDECIMAL(FEMDecimalBASE const& _that) const;

};

struct __________;

struct FEMDatetimeBASE: public FEMValueBASE {

	static void _checkDate_(INT32 const calendarday) {
		if ((calendarday < 0) || (calendarday > 3074323)) throw FEMException();
	}

	static void _checkDate_(int year, int month, int date) {
		if (year != 1582) {
			_checkYear_(year);
			if ((month < 1) || (month > 12)) throw FEMException();
			if (date < 1) throw FEMException();
		} else if (month != 10) {
			if ((month < 10) || (month > 12)) throw FEMException();
			if (date < 1) throw FEMException();
		} else if (date < 15) throw FEMException();
		if (date > _lengthOf_(month, year)) throw FEMException();
	}

	static void _checkTime_(int hour, int minute, int second, int millisecond) {
		if (hour == 24) {
			if (minute != 0) throw FEMException();
			if (second != 0) throw FEMException();
			if (millisecond != 0) throw FEMException();
		} else {
			if ((hour < 0) || (hour > 23)) throw FEMException();
			if ((minute < 0) || (minute > 59)) throw FEMException();
			if ((second < 0) || (second > 59)) throw FEMException();
			if ((millisecond < 0) || (millisecond > 999)) throw FEMException();
		}
	}

	static bool _leapOf_(int year) {
		int div = year / 100, mod = year % 100;
		return ((mod != 0 ? mod : div) & 3) == 0;
	}

	static int _dateOf_(int calendarday) {
		int months = (int) (((calendarday + 139824) * 400 * 12L) / 146097);
		int div = months / 12, mod = months % 12;
		int year = div + 1200, month = mod + 1, date = (calendarday - _calendardayOf_(year, month, 1)) + 1;
		if (date <= 0) {
			if (month == 1) {
				year--;
				month = 12;
			} else {
				month--;
			}
			date += _lengthOf_(month, year);
		}
		return (year << 10) | (month << 5) | (date << 0);
	}

	static int _lengthOf_(int month, int year) {
		return _lengthOf_(month, _leapOf_(year));
	}

	static int _lengthOf_(int month, bool isLeap) {
		return 28 + (((isLeap ? 62648028 : 62648012) >> (month << 1)) & 3);
	}

	static int _yeardayOf_(int calendarday) {
		int year = (((calendarday + 139810) * 400) / 146097) + 1200;
		int result = (calendarday - _calendardayOf_(year, 1, 1)) + 1;
		if (result == 0) return _leapOf_(year - 1) ? 366 : 365;
		if (result == 366) return _leapOf_(year) ? 366 : 1;
		return result;
	}

	static int _daymillisOf_(int hour, int minute, int second, int millisecond) {
		return (hour * 3600000) + (minute * 60000) + (second * 1000) + millisecond;
	}

	static int _calendardayOf_(int year, int month, int date) {
		int year2 = (year - ((7 >> month) & 1)) >> 2, year3 = year2 / 25, month2 = month << 1;
		int month3 = (month * 29) + ((59630432 >> month2) & 3) + ((266948608 >> month2) & 12);
		return ((((year * 365) + year2) - year3) + (year3 >> 2) + month3 + date) - 578130;
	}

	static int _weekdayOf_(int calendarday) {
		return ((calendarday + 5) % 7) + 1;
	}

	static void _checkYear_(int year) {
		if ((year < 1582) || (year > 9999)) throw FEMException();
	}

	static void _checkZero_(int data, int ignore) {
		if ((data & ~ignore) != 0) throw FEMException();
	}

	static void _checkZone_(int zone) {
		if ((zone < -840) || (zone > 840)) throw FEMException();
	}

	INT64S value;

	FEMDatetimeBASE(INT64S const& _value);
	INT32 functionHashDATETIME() const;
	FEMString functionScriptDATETIME() const;
	bool functionEqualsDATETIME(FEMDatetimeBASE const& _that) const;

	int _yearValue_() const {
		return (value.asNE.getHI.asUINT32 >> 18) & 0x3FFF;
	}
	int _dateValue_() const {
		return (value.asNE.getLO.asUINT32 >> 15) & 0x1F;
	}
	int _monthValue_() const {
		return (value.asNE.getLO.asUINT32 >> 14) & 0x0F;
	}
	int _hourValue_() const {
		return (value.asNE.getLO.asUINT32 >> 10) & 0x1F;
	}
	int _minuteValue_() const {
		return (value.asNE.getHI.asUINT32 >> 8) & 0x3F;
	}
	int _secondValue_() const {
		return (value.asNE.getHI.asUINT32 >> 2) & 0x3F;
	}
	int _millisecondValue_() const {
		return (value.asNE.getLO.asUINT32 >> 0) & 0x03FF;
	}
	int _zoneValue_() const {
		return ((value.asNE.getLO.asUINT32 >> 20) & 0x07FF) - 1024;
	}

	bool hasDate() const {
		return (value.asNE.getHI.asUINT32 & 0x02) != 0;
	}
	bool hasTime() const {
		return (value.asNE.getHI.asUINT32 & 0x01) != 0;
	}
	bool hasZone() const {
		return (value.asNE.getLO.asUINT32 & 0x80000000) != 0;
	}
	int _calendardayValue_() const {
		return _calendardayOf_(_yearValue_(), _monthValue_(), _dateValue_());
	}
	int _daymillisValue_() const {
		return _daymillisOf_(_hourValue_(), _minuteValue_(), _secondValue_(), _millisecondValue_());
	}

	void _withDate_(INT32 const _calendarday) {
		INT32 date = _dateOf_(_calendarday);
		_withDate_((date >> 10) & 0x3FFF, (date >> 5) & 0x1F, (date >> 0) & 0x1F);
	}

	void _withDate_(INT32 const _year, INT32 const _month, INT32 const _date) {
		value = INT64S((value.asNE.getLO.asUINT32 & 0xFFF07FFF) | (_date << 15), (value.asNE.getHI.asUINT32 & 0x3FFD) | (_year << 18) | (_month << 14) | (1 << 1));
	}

	void _withTime_(INT32 const daymillis) {
		INT32 _hour = daymillis / 3600000, _hourmillis = daymillis % 3600000;
		INT32 _minute = _hourmillis / 60000, _minutemillis = _hourmillis % 60000;
		INT32 _second = _minutemillis / 1000, _millisecond = _minutemillis % 1000;
		_withTime_(_hour, _minute, _second, _millisecond);
	}

	void _withTime_(INT32 const _hour, INT32 const _minute, INT32 const _second, INT32 const _millisecond) {
		value = INT64S((value.asNE.getLO.asUINT32 & 0xFFFF8000) | (_hour << 10) | (_millisecond << 0), (value.asNE.getHI.asUINT32 & 0xFFFFC002) | (_minute << 8) | (_second << 2) | (1 << 0));
	}

	void _withZone_(int zone) {
		value = INT64S((value.asNE.getLO.asUINT32 & 0xFFFFF) | (1 << 31) | ((zone + 1024) << 20), value.asNE.getHI.asUINT32);
	}

	void withoutDate() {
		value = INT64S(value.asNE.getLO.asUINT32 & 0xFFF07FFF, value.asNE.getHI.asUINT32 & 0x3FFD);
	}

	void withoutTime() {
		value = INT64S(value.asNE.getLO.asUINT32 & 0xFFFF8000, value.asNE.getHI.asUINT32 & 0xFFFFC002);
	}

	void withoutZone() {
		value = INT64S((value.asNE.getLO.asUINT32 & 0xFFFFF) | (1024 << 20), value.asNE.getHI.asUINT32);
	}

	void _moveDate_(int monthsAdd, int daysAdd) {
		int value = ((12 * _yearValue_()) + _monthValue_() + monthsAdd) - 1;
		int year = value / 12, month = (value % 12) + 1;
		_checkYear_(year);
		value = _dateValue_();
		int length = FEMDatetime::lengthOf(month, year), date = value > length ? length : value;
		value = _calendardayOf_(year, month, date) + daysAdd;
		_withDate_(value);
	}

	void _moveTime_(INT64 const millisecondsAdd) {
		INT64 value = _daymillisValue_() + millisecondsAdd;
		int daysAdd = (int) (value / 86400000), daymillis = (int) (value % 86400000);
		if (daymillis < 0) {
			daysAdd--;
			daymillis += 86400000;
		}
		if ((daysAdd != 0) && hasDate()) _moveDate_(0, daysAdd);
		_withTime_(daymillis);
	}

	void _moveZone_(int zoneAdd) {
		if (zoneAdd == 0) return;
		int zoneNew = zoneAdd + _zoneValue_();
		_checkZone_(zoneNew);
		if (hasTime()) {
			_moveTime_(zoneAdd * 60000);
		} else if (hasDate()) {
			int daysAdd = (zoneAdd - 1439) / 1440;
			if (daysAdd != 0) {
				_moveDate_(0, daysAdd);
			}
		}
		_withZone_(zoneNew);
	}

	INT32 compare(FEMDatetimeBASE const& that, INT32 const undefined) const {
		INT32 result;
		if (hasDate()) {
			if (!that.hasDate()) return undefined;
			result = _calendardayValue_() - that._calendardayValue_();
			if ((result < -2) || (result > 2)) return compareValue<INT32>(result, 0);
			if (hasTime()) {
				if (that.hasTime()) {
					result *= 86400000;
					result += (_daymillisValue_() - that._daymillisValue_());
					result += (_zoneValue_() - that._zoneValue_()) * -60000;
					return compareValue<INT32>(result, 0);
				} else {
					if (that._zoneValue_() > 0) {
						result++;
					}
					result *= 86400000;
					result += _daymillisValue_();
					result += _zoneValue_() * -60000;
					if (result < 0) return -1;
					if (result >= 86400000) return +1;
					return undefined;
				}
			} else {
				if (that.hasTime()) {
					if (_zoneValue_() > 0) {
						result--;
					}
					result *= 86400000;
					result -= that._daymillisValue_();
					result -= that._zoneValue_() * -60000;
					if (result > 0) return +1;
					if (result <= -86400000) return -1;
					return undefined;
				} else {
					if (_zoneValue_() > 0) {
						result--;
					}
					if (that._zoneValue_() > 0) {
						result++;
					}
					return compareValue<INT32>(result, 0);
				}
			}
		} else {
			if (that.hasDate()) return undefined;
			if (hasTime()) {
				if (!that.hasTime()) return undefined;
				result = _daymillisValue_() - that._daymillisValue_();
				result += (_zoneValue_() - that._zoneValue_()) * -60000;
				return compareValue<INT32>(result, 0);
			} else {
				if (that.hasTime()) return undefined;
				if (hasZone()) {
					if (!that.hasZone()) return undefined;
					result = that._zoneValue_() - _zoneValue_();
					return compareValue<INT32>(result, 0);
				} else {
					if (that.hasZone()) return undefined;
					return 0;
				}
			}
		}
	}

};

struct __________;

struct FEMDurationBASE: public FEMValueBASE {

	static UINT8 const ranges[4800];

	INT64S value;

	static void checkDays(INT32 const _days);
	static void checkYears(INT32 const _years);
	static void checkMonths(INT32 const _months);
	static void checkHours(INT32 const _hours);
	static void checkMinutes(INT64 const& _minutes);
	static void checkSeconds(INT64 const& _seconds);
	static void checkMilliseconds(INT64 const& _milliseconds);
	static void checkPositive(INT32 const _value);
	static INT32 rangeOf(UINT32 const _months);
	static INT32 lengthOf(UINT32 const _months);
	static INT64 durationmillisOf(INT32 const _days, INT32 const _hours, INT64 const _minutes, INT64 const _seconds, INT64 const _milliseconds);
	static INT32 durationmonthsOf(INT32 const _years, INT32 const _months);
	static INT32 compare(FEMDuration const& _this, FEMDuration const& _that, INT32 const _undefined);

	FEMDurationBASE(INT64S const& _value);
	INT32 functionHashDURATION() const;
	FEMString functionScriptDURATION() const;
	bool functionEqualsDURATION(FEMDurationBASE const& _that) const;
	// TODO
	INT32 durationSignValue() const;

	INT32 durationYearsValue() const;

	INT32 durationMonthsValue() const;
	INT32 durationDaysValue() const;
	INT32 durationHoursValue() const;

	INT32 durationMinutesValue() const;
	INT32 durationSecondsValue() const;
	INT32 durationMillisecondsValue() const;

	INT64 durationTotalmillisValue() const;

	INT32 durationTotalmonthsValue() const;

};

struct I_____I;

struct FEMContextBASE: public RCObject<FEMContextBASE> { // DONE

	static FEMContextBASE const* EMPTY;

	CSObject cyclicSection;

	/** Dieses Feld speichert den Kopf der doppelt verketteten Liste, in welcher die zyklisch referenzierten Nutzdaten  von Wertlisten verwaltet werden. */
	FEMArrayCYCLIC cyclicList;

	FEMContextBASE();
	~FEMContextBASE();
	void cyclicDelete();

};

struct __________;

struct FEMExceptionBASE: public RCObject<FEMExceptionBASE> {

	FEMValue value;

	FEMContext context;

	FEMException::MESSAGES messages;

};

struct __________;

struct FEM_CAST {

	FEMValue toValue[0];
	FEMValueBASE toValueBASE[0];

	FEMProxy toProxy[0];

	FEMParam toParam[0];

	FEMFunction toFunction[0];
	FEMFunctionOBJ toFunctionOBJ[0];
	FEMFunctionPTR toFunctionPTR[0];
	FEMFunctionBASE toFunctionBASE[0];
	FEMFunctionPROXY toFunctionPROXY[0];
	FEMFunctionPARAM toFunctionPARAM[0];
	FEMFunctionFRAME toFunctionFRAME[0];
	FEMFunctionMETHOD toFunctionMETHOD[0];
	FEMFunctionCONCAT toFunctionCONCAT[0];
	FEMFunctionCOMPOSE toFunctionCOMPOSE[0];
	FEMFunctionCUSTOM1 toFunctionCUSTOM1[0];
	FEMFunctionCUSTOM2 toFunctionCUSTOM2[0];
	FEMFunctionCUSTOM3 toFunctionCUSTOM3[0];

	FEMVoid toVoid[0];
	FEMValueVOID toValueVOID[0];

	FEMArray toArray[0];
	FEMArrayBASE toArrayBASE[0];
	FEMArrayVALUE toArrayVALUE[0];
	FEMArrayCONCAT toArrayCONCAT[0];
	FEMArrayCYCLIC toArrayCYCLIC[0];
	FEMArraySECTION toArraySECTION[0];
	FEMArrayREVERSE toArrayREVERSE[0];
	FEMArrayUNIFORM toArrayUNIFORM[0];
	FEMArrayCUSTOM1 toArrayCUSTOM1[0];
	FEMArrayCUSTOM2 toArrayCUSTOM2[0];
	FEMArrayCUSTOM3 toArrayCUSTOM3[0];

	FEMString toString[0];
	FEMStringBASE toStringBASE[0];
	FEMStringBYTES toStringBYTES[0];
	FEMStringCHARS toStringCHARS[0];
	FEMStringVALUE toStringVALUE[0];
	FEMStringCONCAT toStringCONCAT[0];
	FEMStringSECTION toStringSECTION[0];
	FEMStringREVERSE toStringREVERSE[0];
	FEMStringUNIFORM toStringUNIFORM[0];
	FEMStringCUSTOM1 toStringCUSTOM1[0];
	FEMStringCUSTOM2 toStringCUSTOM2[0];
	FEMStringCUSTOM3 toStringCUSTOM3[0];

	FEMBinary toBinary[0];
	FEMBinaryBASE toBinaryBASE[0];
	FEMBinaryVALUE toBinaryVALUE[0];
	FEMBinaryCONCAT toBinaryCONCAT[0];
	FEMBinarySECTION toBinarySECTION[0];
	FEMBinaryREVERSE toBinaryREVERSE[0];
	FEMBinaryUNIFORM toBinaryUNIFORM[0];
	FEMBinaryCUSTOM1 toBinaryCUSTOM1[0];
	FEMBinaryCUSTOM2 toBinaryCUSTOM2[0];
	FEMBinaryCUSTOM3 toBinaryCUSTOM3[0];

	FEMObject toObject[0];
	FEMObjectBASE toObjectBASE[0];

	FEMHandler toHandler[0];
	FEMHandlerBASE toHandlerBASE[0];

	FEMInteger toInteger[0];
	FEMIntegerBASE toIntegerBASE[0];

	FEMDecimal toDecimal[0];
	FEMDecimalBASE toDecimalBASE[0];

	FEMBoolean toBoolean[0];
	FEMValueTRUE toValueTRUE[0];
	FEMValueFALSE toValueFALSE[0];

	FEMDatetime toDatetime[0];
	FEMDatetimeBASE toDatetimeBASE[0];

	FEMDuration toDuration[0];
	FEMDurationBASE toDurationBASE[0];

	FEMContext toContext[0];
	FEMContextOBJ toContextOBJ[0];
	FEMContextPTR toContextPTR[0];
	FEMContextBASE toContextBASE[0];

	FEMFrame toFrame[0];
	FEMFrameOBJ toFrameOBJ[0];
	FEMFramePTR toFramePTR[0];
	FEMFrameBASE toFrameBASE[0];
	FEMFrameARRAY toFrameARRAY[0];
	FEMFrameCYCLIC toFrameCYCLIC[0];
	FEMFrameINVOKE toFrameINVOKE[0];
	FEMFrameCUSTOM1 toFrameCUSTOM1[0];
	FEMFrameCUSTOM2 toFrameCUSTOM2[0];
	FEMFrameCUSTOM3 toFrameCUSTOM3[0];
	FEMFrameCONTEXT toFrameCONTEXT[0];
	FEMFramePARAM toFramePARAM[0];

	FEMException toException[0];
	FEMExceptionOBJ toExceptionOBJ[0];
	FEMExceptionPTR toExceptionPTR[0];
	FEMExceptionBASE toExceptionBASE[0];

	INT8S toINT8S[0];
	INT16S toINT16S[0];
	INT32S toINT32S[0];
	INT64S toINT64S[0];

	FEM_CAST* toPointerAndCastItsTarget;

	FEM_CAST();
	FEM_CAST(PVOID _this);

};

inline FEM_CAST* femCast(PCVOID _this) {
	return ((FEM_CAST*) _this);
}

inline FEM_CAST::FEM_CAST()
		: toPointerAndCastItsTarget(0) {
}

inline FEM_CAST::FEM_CAST(PVOID _this)
		: toPointerAndCastItsTarget((FEM_CAST*) _this) {
}

void fem_main() {
	using namespace std;
//
//	FEMContext con;
//	FEMFrame frm = con.newFrame();
//
//	cout << frm.size() << '\n';
//	cout << frm.withParams(&FEMVoid::INSTANCE, 1).params().get(0).hash() << '\n';

#define PRINTSIZE(X) cout << #X << "  " << sizeof(X) << '\n';

	PRINTSIZE(INT8S)
	PRINTSIZE(INT16S)
	PRINTSIZE(INT32S)
	PRINTSIZE(INT64S)
	PRINTSIZE(FEM_CAST)

	PRINTSIZE(FEMFrame)
	PRINTSIZE(FEMFrameOBJ)
	PRINTSIZE(FEMFramePTR)
	PRINTSIZE(FEMFrameBASE)
	PRINTSIZE(FEMFrameARRAY)
	PRINTSIZE(FEMFrameCYCLIC)
	PRINTSIZE(FEMFrameINVOKE)
	PRINTSIZE(FEMFrameCONTEXT)
	PRINTSIZE(FEMFrameCUSTOM1)
	PRINTSIZE(FEMFrameCUSTOM2)
	PRINTSIZE(FEMFrameCUSTOM3)

	PRINTSIZE(FEMFunction)
	PRINTSIZE(FEMFunctionOBJ)
	PRINTSIZE(FEMFunctionPTR)
	PRINTSIZE(FEMFunctionBASE)
	PRINTSIZE(FEMFunctionPROXY)
	PRINTSIZE(FEMFunctionPARAM)
	PRINTSIZE(FEMFunctionCACHE)
	PRINTSIZE(FEMFunctionFRAME)
	PRINTSIZE(FEMFunctionMETHOD)
	PRINTSIZE(FEMFunctionINVOKE)
	PRINTSIZE(FEMFunctionCONCAT)
	PRINTSIZE(FEMFunctionCOMPOSE)
	PRINTSIZE(FEMFunctionCUSTOM1)
	PRINTSIZE(FEMFunctionCUSTOM2)
	PRINTSIZE(FEMFunctionCUSTOM3)

	FEM_CAST test;

	cout << "cast test\n";
	cout << (INT32(&test.toPointerAndCastItsTarget[1]) - INT32(&test.toPointerAndCastItsTarget[0])) << '\n';
	cout << sizeof(FEM_CAST) << '\n';
	cout.flush();
}

struct __________;

FEMFrame::FEMFrame() // DONE
		: _object_(FEMFrameBASE::EMPTY) {
}

FEMValue FEMFrame::get(INT32 const _index) const { // DONE
	FEMFrameBASE* _this = femCast(this)->toPointerAndCastItsTarget->toFrameBASE;
	INT32 _thisIndex = _index;
	while (true) {
		INT32 _nextIndex = _thisIndex - _this->frameSize;
		if (_nextIndex < 0) return _this->frameGetBASE(_thisIndex);
		_this = femCast(&_this->parentFrame)->toPointerAndCastItsTarget->toFrameBASE;
		_thisIndex = _nextIndex;
		FEMException::checkState(_this);
	}
	return FEMVoid::INSTANCE;
}

INT32 FEMFrame::size() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFrameBASE->frameSize;
}

FEMArray FEMFrame::params() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFrameBASE->frameParamsBASE();
}

FEMFrame const& FEMFrame::parent() const { // DONE
	FEMFrameBASE* _data = femCast(this)->toPointerAndCastItsTarget->toFrameBASE;
	FEMFrame* _parentFrame = femCast(&_data->parentFrame)->toFrame;
	if (!femCast(_parentFrame)->toPointerAndCastItsTarget) return *this;
	return *_parentFrame;
}

FEMContext const& FEMFrame::context() const { // DONE
	FEMFrameBASE* _this = femCast(this)->toPointerAndCastItsTarget->toFrameBASE;
	return *femCast(&_this->ownerContext)->toContext;
}

FEMFrame FEMFrame::newFrame(FEMArray const& _paramArray) const { // DONE
	FEMFrameARRAY* _result = new FEMFrameARRAY(_object_, _paramArray);
	return FEMFrame(*femCast(&_result)->toFrame);
}

FEMFrame FEMFrame::newFrame(FEMValue::ARRAY const& _paramArray) const { // DONE
	return newFrame(_paramArray.data(), _paramArray.length());
}

FEMFrame FEMFrame::newFrame(FEMFunction::ARRAY const& _paramArray) const { // DONE
	return newFrame(_paramArray.data(), _paramArray.length());
}

FEMFrame FEMFrame::newFrame(FEMValue const* _paramArray, INT32 const _paramCount) const { // DONE
	return newFrame(FEMArray::from(_paramArray, _paramCount));
}

FEMFrame FEMFrame::newFrame(FEMFunction const* _paramArray, INT32 const _paramCount) const { // DONE
	FEMException::checkNull(_paramArray);
	FEMException::checkCount(_paramCount);
	FEMFrameINVOKE* _result = new (new INT8[sizeof(FEMFrameINVOKE) + _paramCount * sizeof(FEMFramePARAM)]) FEMFrameINVOKE(_object_, _paramArray, _paramCount);
	return FEMFrame(*femCast(&_result)->toFrame);
}

FEMFrame FEMFrame::withParams(FEMArray const& _params) const { // DONE
	return parent().newFrame(_params);
}

FEMFrame FEMFrame::withParams(FEMValue::ARRAY const& _params) const { // DONE
	return parent().newFrame(_params);
}

FEMFrame FEMFrame::withParams(FEMFunction::ARRAY const& _params) const { // DONE
	return parent().newFrame(_params);
}

FEMFrame FEMFrame::withParams(FEMValue const* _paramArray, INT32 const _paramCount) const { // DONE
	return parent().newFrame(_paramArray, _paramCount);
}

FEMFrame FEMFrame::withParams(FEMFunction const* _paramArray, INT32 const _paramCount) const { // DONE
	return parent().newFrame(_paramArray, _paramCount);
}

struct __________;

FEMFrameOBJ::~OBJECT() { // DONE
	switch (femCast(this)->toFrameBASE->dataType) {
		case FEMFrameBASE::FRAME_ARRAY:
			femCast(this)->toFrameARRAY->~FEMFrameARRAY();
			break;
		case FEMFrameBASE::FRAME_CYCLIC:
			femCast(this)->toFrameCYCLIC->~FEMFrameCYCLIC();
			break;
		case FEMFrameBASE::FRAME_INVOKE:
			femCast(this)->toFrameINVOKE->~FEMFrameINVOKE();
			break;
		case FEMFrameBASE::FRAME_CONTEXT:
			femCast(this)->toFrameCONTEXT->~FEMFrameCONTEXT();
			break;
		case FEMFrameBASE::FRAME_CUSTOM1:
			femCast(this)->toFrameCUSTOM1->~FEMFrameCUSTOM1();
			break;
		case FEMFrameBASE::FRAME_CUSTOM2:
			femCast(this)->toFrameCUSTOM2->~FEMFrameCUSTOM2();
			break;
		case FEMFrameBASE::FRAME_CUSTOM3:
			femCast(this)->toFrameCUSTOM3->~FEMFrameCUSTOM3();
			break;
	}
}

struct __________;

inline FEMFrameBASE::FEMFrameBASE(FRAME_TYPE const _dataType, INT32 const _frameSize, FEMFramePTR const& _parentFrame) // DONE
		: dataType(_dataType), frameSize(_frameSize), parentFrame(_parentFrame), ownerContext(femCast(&_parentFrame)->toPointerAndCastItsTarget->toFrameBASE->ownerContext) {
}

inline FEMFrameBASE::FEMFrameBASE(FRAME_TYPE const _dataType, INT32 const _frameSize, FEMContextBASE const& _ownerContext) // DONE
		: dataType(_dataType), frameSize(_frameSize), parentFrame(), ownerContext(&_ownerContext) {
}

inline FEMValue FEMFrameBASE::frameGetBASE(INT32 const _index) const { // DONE
	switch (dataType) {
		case FRAME_ARRAY:
			return femCast(this)->toFrameARRAY->frameGetARRAY(_index);
		case FRAME_INVOKE:
			return femCast(this)->toFrameINVOKE->frameGetINVOKE(_index);
		case FRAME_CONTEXT:
			return femCast(this)->toFrameCONTEXT->frameGetCONTEXT(_index);
		case FRAME_CUSTOM1:
			return femCast(this)->toFrameCUSTOM1->frameGetCUSTOM1(_index);
		case FRAME_CUSTOM2:
			return femCast(this)->toFrameCUSTOM2->frameGetCUSTOM2(_index);
		case FRAME_CUSTOM3:
			return femCast(this)->toFrameCUSTOM3->frameGetCUSTOM3(_index);
		case FRAME_CYCLIC:
			;
	}
	throw FEMException();
}

inline FEMArray FEMFrameBASE::frameParamsBASE() const { // DONE
	switch (dataType) {
		case FRAME_ARRAY:
			return femCast(this)->toFrameARRAY->frameParamsARRAY();
		case FRAME_CONTEXT:
			return femCast(this)->toFrameCONTEXT->frameParamsCONTEXT();
		case FRAME_CYCLIC:
		case FRAME_INVOKE:
		case FRAME_CUSTOM1:
		case FRAME_CUSTOM2:
		case FRAME_CUSTOM3:
			return femCast(this)->toFrameCYCLIC->frameParamsCYCLIC();
	}
	throw FEMException();
}

struct __________;

inline FEMFrameARRAY::FEMFrameARRAY(FEMFramePTR const& _parentFrame, FEMArray const& _paramArray) // DONE
		: FEMFrameBASE(FRAME_ARRAY, _paramArray.length(), _parentFrame), paramArray(_paramArray) {
}

inline FEMValue FEMFrameARRAY::frameGetARRAY(INT32 const _index) const { // DONE
	return paramArray.get(_index);
}

inline FEMArray FEMFrameARRAY::frameParamsARRAY() const { // DONE
	return paramArray;
}

struct __________;

inline FEMFramePARAM::FEMFramePARAM(FEMFunction const& _paramFunction) // DONE
		: paramValue(), paramFunction(_paramFunction) {
}

struct __________;

inline FEMFrameCYCLIC::FEMFrameCYCLIC(FEMContextBASE const& _ownerContext)
		: FEMFrameBASE(FRAME_CYCLIC, 0, _ownerContext), cyclicArray(0) {
}

inline FEMFrameCYCLIC::FEMFrameCYCLIC(FRAME_TYPE const _dataType, INT32 const _frameSize, FEMFramePTR const& _parentFrame) // DONE
		: FEMFrameBASE(_dataType, _frameSize, _parentFrame), cyclicArray(0) {
}

inline FEMArray FEMFrameCYCLIC::frameParamsCYCLIC() const { // DONE
	CSGuard _cleanupGuard(femCast(ownerContext)->toContextBASE->cyclicSection);
	if (!cyclicArray) new FEMArrayCYCLIC(*this);
	return *femCast(&cyclicArray)->toArray;
}

struct __________;

inline FEMFrameINVOKE::FEMFrameINVOKE(FEMFramePTR const& _parentFrame, FEMFunction const* _paramArray, INT32 const _paramCount) // DONE
		: FEMFrameCYCLIC(FRAME_INVOKE, _paramCount, _parentFrame) {
	setupArray<FEMFunction, FEMFramePARAM>(_paramArray, paramArray, _paramCount);
}

inline FEMFrameINVOKE::~FEMFrameINVOKE() { // DONE
	resetArray<FEMFramePARAM>(paramArray, frameSize);
}

FEMValue FEMFrameINVOKE::frameGetINVOKE(INT32 const _index) const { // DONE
	CSGuard _cleanupGuard(femCast(ownerContext)->toContextBASE->cyclicSection);
	FEM_CAST* _cacheItem = femCast(paramArray + _index);
	if (_cacheItem->toPointerAndCastItsTarget) return *_cacheItem->toValue;
	FEMValue _cacheValue = _cacheItem->toFramePARAM->paramFunction.functionInvoke(*femCast(&parentFrame)->toFrame);
	*_cacheItem->toValue = _cacheValue;
	return _cacheValue;
}

struct __________;

inline FEMFrameCUSTOM1::FEMFrameCUSTOM1()
		: FEMFrameCYCLIC(FRAME_CUSTOM1, 0, EMPTY) {
}

inline FEMFrameCUSTOM1::~FEMFrameCUSTOM1() {
}

inline FEMValue FEMFrameCUSTOM1::frameGetCUSTOM1(INT32 const _index) const {
	throw FEMException();
}

struct __________;

inline FEMFrameCUSTOM2::FEMFrameCUSTOM2() //
		: FEMFrameCYCLIC(FRAME_CUSTOM2, 0, EMPTY) {
}

inline FEMFrameCUSTOM2::~FEMFrameCUSTOM2() { //
}

inline FEMValue FEMFrameCUSTOM2::frameGetCUSTOM2(INT32 const _index) const { //
	throw FEMException();
}

struct __________;

inline FEMFrameCUSTOM3::FEMFrameCUSTOM3() //
		: FEMFrameCYCLIC(FRAME_CUSTOM3, 0, EMPTY) {
}

inline FEMFrameCUSTOM3::~FEMFrameCUSTOM3() { //
}

inline FEMValue FEMFrameCUSTOM3::frameGetCUSTOM3(INT32 const _index) const { //
	throw FEMException();
}

struct __________;

inline FEMFrameCONTEXT::FEMFrameCONTEXT(FEMContext const& _parentContext) // DONE
		: FEMFrameBASE(FRAME_CONTEXT, 0, *femCast(&_parentContext)->toPointerAndCastItsTarget->toContextBASE), parentContext(_parentContext) {
}

inline FEMValue FEMFrameCONTEXT::frameGetCONTEXT(INT32 const _index) const { // DONE
	throw FEMException();
}

inline FEMArray FEMFrameCONTEXT::frameParamsCONTEXT() const { // DONE
	return FEMArray::EMPTY;
}

struct __________;

FEMFunction FEMFunction::from(METHOD _method) { // DONE
	FEMFunctionMETHOD* _result = new FEMFunctionMETHOD(_method);
	return FEMFunction(*femCast(&_result)->toFunction);
}

FEMFunction::FEMFunction()
		: FEMFunction(FEMVoid::INSTANCE) {
}

FEMFunction::TYPE FEMFunction::functionType() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFunctionBASE->functionType();
}

bool FEMFunction::functionIsValue() const { // DONE
	return functionType() == FUNCTION_TYPE_VALUE;
}

bool FEMFunction::functionIsProxy() const { // DONE
	return functionType() == FUNCTION_TYPE_PROXY;
}

bool FEMFunction::functionIsParam() const { // DONE
	return functionType() == FUNCTION_TYPE_PARAM;
}

bool FEMFunction::functionIsOther() const { // DONE
	return functionType() == FUNCTION_TYPE_OTHER;
}

FEMValue const& FEMFunction::functionAsValue() const { // DONE
	return *femCast(this)->toValue;
}

FEMProxy const& FEMFunction::functionAsProxy() const { // DONE
	return *femCast(this)->toProxy;
}

FEMParam const& FEMFunction::functionAsParam() const { // DONE
	return *femCast(this)->toParam;
}

FEMValue FEMFunction::functionToValue() const { // DONE
	return FEMHandler::from(*this);
}

FEMValue FEMFunction::functionInvoke(FEMFrame const& _frame) const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFunctionBASE->functionInvokeBASE(_frame);
}

FEMFunction FEMFunction::functionConcat(ARRAY const& _paramArray) const { // DONE
	return functionConcat(_paramArray.data(), _paramArray.length());
}

FEMFunction FEMFunction::functionConcat(FEMFunction const* _paramArray, INT32 _paramCount) const { // DONE
	FEMException::checkNull(_paramArray);
	FEMException::checkCount(_paramCount);
	FEMFunctionCONCAT* _result = new (new UINT8[sizeof(FEMFunctionCONCAT) + _paramCount * sizeof(FEMFunction)]) FEMFunctionCONCAT(*this, _paramArray, _paramCount);
	return FEMFunction(*femCast(&_result)->toFunction);
}

FEMFunction FEMFunction::functionCompose(ARRAY const& _paramArray) const { // DONE
	return functionCompose(_paramArray.data(), _paramArray.length());
}

FEMFunction FEMFunction::functionCompose(FEMFunction const* _paramArray, INT32 _paramCount) const { // DONE
	FEMException::checkNull(_paramArray);
	FEMException::checkCount(_paramCount);
	FEMFunctionCOMPOSE* _result = new (new UINT8[sizeof(FEMFunctionCOMPOSE) + _paramCount * sizeof(FEMFunction)]) FEMFunctionCOMPOSE(*this, _paramArray, _paramCount);
	return FEMFunction(*femCast(&_result)->toFunction);
}

INT32 FEMFunction::hash() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFunctionBASE->functionHashBASE();
}

FEMFunction FEMFunction::clone() const { // DONE
	return *this;
}

bool FEMFunction::equals(FEMFunction const& _that) const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFunctionBASE->functionEqualsBASE(*femCast(&_that)->toPointerAndCastItsTarget->toFunctionBASE);
}

FEMString FEMFunction::toScript() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toFunctionBASE->functionScriptBASE();
}

struct __________;

FEMFunctionOBJ::~OBJECT() { // DONE
	switch (femCast(this)->toFunctionBASE->dataType) {
		case FEMFunctionBASE::FUNCTION_PROXY:
			femCast(this)->toFunctionPROXY->~FEMFunctionPROXY();
			break;
		case FEMFunctionBASE::FUNCTION_PARAM:
			femCast(this)->toFunctionPARAM->~FEMFunctionPARAM();
			break;
		case FEMFunctionBASE::FUNCTION_FRAME:
			femCast(this)->toFunctionFRAME->~FEMFunctionFRAME();
			break;
		case FEMFunctionBASE::FUNCTION_METHOD:
			femCast(this)->toFunctionMETHOD->~FEMFunctionMETHOD();
			break;
		case FEMFunctionBASE::FUNCTION_CONCAT:
			femCast(this)->toFunctionCONCAT->~FEMFunctionCONCAT();
			break;
		case FEMFunctionBASE::FUNCTION_COMPOSE:
			femCast(this)->toFunctionCOMPOSE->~FEMFunctionCOMPOSE();
			break;
		case FEMFunctionBASE::FUNCTION_CUSTOM1:
			femCast(this)->toFunctionCUSTOM1->~FEMFunctionCUSTOM1();
			break;
		case FEMFunctionBASE::FUNCTION_CUSTOM2:
			femCast(this)->toFunctionCUSTOM2->~FEMFunctionCUSTOM2();
			break;
		case FEMFunctionBASE::FUNCTION_CUSTOM3:
			femCast(this)->toFunctionCUSTOM3->~FEMFunctionCUSTOM3();
			break;
		case FEMFunctionBASE::VALUE_VOID:
			femCast(this)->toValueVOID->~FEMValueVOID();
			break;
		case FEMFunctionBASE::VALUE_TRUE:
			femCast(this)->toValueTRUE->~FEMValueTRUE();
			break;
		case FEMFunctionBASE::VALUE_FALSE:
			femCast(this)->toValueFALSE->~FEMValueFALSE();
			break;
		case FEMFunctionBASE::ARRAY_VALUE:
			femCast(this)->toArrayVALUE->~FEMArrayVALUE();
			break;
		case FEMFunctionBASE::ARRAY_CYCLIC:
			femCast(this)->toArrayCYCLIC->~FEMArrayCYCLIC();
			break;
		case FEMFunctionBASE::ARRAY_CONCAT:
			femCast(this)->toArrayCONCAT->~FEMArrayCONCAT();
			break;
		case FEMFunctionBASE::ARRAY_SECTION:
			femCast(this)->toArraySECTION->~FEMArraySECTION();
			break;
		case FEMFunctionBASE::ARRAY_REVERSE:
			femCast(this)->toArrayREVERSE->~FEMArrayREVERSE();
			break;
		case FEMFunctionBASE::ARRAY_UNIFORM:
			femCast(this)->toArrayUNIFORM->~FEMArrayUNIFORM();
			break;
		case FEMFunctionBASE::ARRAY_CUSTOM1:
			femCast(this)->toArrayCUSTOM1->~FEMArrayCUSTOM1();
			break;
		case FEMFunctionBASE::ARRAY_CUSTOM2:
			femCast(this)->toArrayCUSTOM2->~FEMArrayCUSTOM2();
			break;
		case FEMFunctionBASE::ARRAY_CUSTOM3:
			femCast(this)->toArrayCUSTOM3->~FEMArrayCUSTOM3();
			break;
		case FEMFunctionBASE::STRING_BYTES:
			femCast(this)->toStringBYTES->~FEMStringBYTES();
			break;
		case FEMFunctionBASE::STRING_CHARS:
			femCast(this)->toStringCHARS->~FEMStringCHARS();
			break;
		case FEMFunctionBASE::STRING_VALUE:
			femCast(this)->toStringVALUE->~FEMStringVALUE();
			break;
		case FEMFunctionBASE::STRING_CONCAT:
			femCast(this)->toStringCONCAT->~FEMStringCONCAT();
			break;
		case FEMFunctionBASE::STRING_SECTION:
			femCast(this)->toStringSECTION->~FEMStringSECTION();
			break;
		case FEMFunctionBASE::STRING_REVERSE:
			femCast(this)->toStringREVERSE->~FEMStringREVERSE();
			break;
		case FEMFunctionBASE::STRING_UNIFORM:
			femCast(this)->toStringUNIFORM->~FEMStringUNIFORM();
			break;
		case FEMFunctionBASE::STRING_CUSTOM1:
			femCast(this)->toStringCUSTOM1->~FEMStringCUSTOM1();
			break;
		case FEMFunctionBASE::STRING_CUSTOM2:
			femCast(this)->toStringCUSTOM2->~FEMStringCUSTOM2();
			break;
		case FEMFunctionBASE::STRING_CUSTOM3:
			femCast(this)->toStringCUSTOM3->~FEMStringCUSTOM3();
			break;
		case FEMFunctionBASE::BINARY_VALUE:
			femCast(this)->toBinaryVALUE->~FEMBinaryVALUE();
			break;
		case FEMFunctionBASE::BINARY_CONCAT:
			femCast(this)->toBinaryCONCAT->~FEMBinaryCONCAT();
			break;
		case FEMFunctionBASE::BINARY_SECTION:
			femCast(this)->toBinarySECTION->~FEMBinarySECTION();
			break;
		case FEMFunctionBASE::BINARY_REVERSE:
			femCast(this)->toBinaryREVERSE->~FEMBinaryREVERSE();
			break;
		case FEMFunctionBASE::BINARY_UNIFORM:
			femCast(this)->toBinaryUNIFORM->~FEMBinaryUNIFORM();
			break;
		case FEMFunctionBASE::BINARY_CUSTOM1:
			femCast(this)->toBinaryCUSTOM1->~FEMBinaryCUSTOM1();
			break;
		case FEMFunctionBASE::BINARY_CUSTOM2:
			femCast(this)->toBinaryCUSTOM2->~FEMBinaryCUSTOM2();
			break;
		case FEMFunctionBASE::BINARY_CUSTOM3:
			femCast(this)->toBinaryCUSTOM3->~FEMBinaryCUSTOM3();
			break;
		case FEMFunctionBASE::OBJECT_BASE:
			femCast(this)->toObjectBASE->~FEMObjectBASE();
			break;
		case FEMFunctionBASE::HANDLER_BASE:
			femCast(this)->toHandlerBASE->~FEMHandlerBASE();
			break;
		case FEMFunctionBASE::INTEGER_BASE:
			femCast(this)->toIntegerBASE->~FEMIntegerBASE();
			break;
		case FEMFunctionBASE::DECIMAL_BASE:
			femCast(this)->toDecimalBASE->~FEMDecimalBASE();
			break;
		case FEMFunctionBASE::DURATION_BASE:
			femCast(this)->toDurationBASE->~FEMDurationBASE();
			break;
		case FEMFunctionBASE::DATETIME_BASE:
			femCast(this)->toDatetimeBASE->~FEMDatetimeBASE();
			break;
	}
}

struct __________;

inline FEMFunctionBASE::FEMFunctionBASE(DATA_TYPE const _dataType) // DONE
		: dataType(_dataType) {
}

inline FEMFunction::TYPE FEMFunctionBASE::functionType() const { // DONE
	switch (dataType) {
		case FUNCTION_PROXY:
			return FEMFunction::FUNCTION_TYPE_PROXY;
		case FUNCTION_PARAM:
			return FEMFunction::FUNCTION_TYPE_PARAM;
		case FUNCTION_FRAME:
		case FUNCTION_METHOD:
		case FUNCTION_CONCAT:
		case FUNCTION_COMPOSE:
		case FUNCTION_CUSTOM1:
		case FUNCTION_CUSTOM2:
		case FUNCTION_CUSTOM3:
			return FEMFunction::FUNCTION_TYPE_OTHER;
		default:
			return FEMFunction::FUNCTION_TYPE_VALUE;
	}
}

inline INT32 FEMFunctionBASE::functionHashBASE() const {
	switch (dataType) {
		case FUNCTION_PROXY:
			return femCast(this)->toFunctionPROXY->functionHashPROXY();
		case FUNCTION_PARAM:
			return femCast(this)->toFunctionPARAM->functionHashPARAM();
		case FUNCTION_FRAME:
			return femCast(this)->toFunctionFRAME->functionHashFRAME();
		case FUNCTION_METHOD:
			return femCast(this)->toFunctionMETHOD->functionHashMETHOD();
		case FUNCTION_CONCAT:
			return femCast(this)->toFunctionCOMPOSE->functionHashINVOKE();
		case FUNCTION_COMPOSE:
			return femCast(this)->toFunctionCOMPOSE->functionHashINVOKE();
		case FUNCTION_CUSTOM1:
			return femCast(this)->toFunctionCUSTOM1->functionHashCUSTOM1();
		case FUNCTION_CUSTOM2:
			return femCast(this)->toFunctionCUSTOM2->functionHashCUSTOM2();
		case FUNCTION_CUSTOM3:
			return femCast(this)->toFunctionCUSTOM3->functionHashCUSTOM3();
		case VALUE_VOID:
			return VALUE_VOID;
		case VALUE_TRUE:
			return VALUE_TRUE;
		case VALUE_FALSE:
			return VALUE_FALSE;
		case ARRAY_VALUE:
		case ARRAY_CYCLIC:
		case ARRAY_CONCAT:
		case ARRAY_SECTION:
		case ARRAY_REVERSE:
		case ARRAY_UNIFORM:
		case ARRAY_CUSTOM1:
		case ARRAY_CUSTOM2:
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayBASE->functionHashARRAY();
		case STRING_BYTES:
		case STRING_CHARS:
		case STRING_VALUE:
		case STRING_CONCAT:
		case STRING_SECTION:
		case STRING_REVERSE:
		case STRING_UNIFORM:
		case STRING_CUSTOM1:
		case STRING_CUSTOM2:
		case STRING_CUSTOM3:
			return femCast(this)->toStringBASE->functionHashSTRING();
		case BINARY_VALUE:
		case BINARY_CONCAT:
		case BINARY_SECTION:
		case BINARY_REVERSE:
		case BINARY_UNIFORM:
		case BINARY_CUSTOM1:
		case BINARY_CUSTOM2:
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryBASE->functionHashBINARY();
		case OBJECT_BASE:
			return femCast(this)->toObjectBASE->functionHashOBJECT();
		case HANDLER_BASE:
			return femCast(this)->toHandlerBASE->functionHashHANDLER();
		case INTEGER_BASE:
			return femCast(this)->toIntegerBASE->functionHashINTEGER();
		case DECIMAL_BASE:
			return femCast(this)->toDecimalBASE->functionHashDECIMAL();
		case DURATION_BASE:
			return femCast(this)->toDurationBASE->functionHashDURATION();
		case DATETIME_BASE:
			return femCast(this)->toDatetimeBASE->functionHashDATETIME();
	}
	throw FEMException();
}

inline FEMString FEMFunctionBASE::functionScriptBASE() const { // DONE
	switch (dataType) {
		case FUNCTION_PROXY:
			return femCast(this)->toFunctionPROXY->functionScriptPROXY();
		case FUNCTION_PARAM:
			return femCast(this)->toFunctionPARAM->functionScriptPARAM();
		case FUNCTION_FRAME:
			return femCast(this)->toFunctionFRAME->functionScriptFRAME();
		case FUNCTION_METHOD:
			return femCast(this)->toFunctionMETHOD->functionScriptMETHOD();
		case FUNCTION_CONCAT:
			return femCast(this)->toFunctionCOMPOSE->functionScriptINVOKE();
		case FUNCTION_COMPOSE:
			return femCast(this)->toFunctionCOMPOSE->functionScriptINVOKE();
		case FUNCTION_CUSTOM1:
			return femCast(this)->toFunctionCUSTOM1->functionScriptCUSTOM1();
		case FUNCTION_CUSTOM2:
			return femCast(this)->toFunctionCUSTOM2->functionScriptCUSTOM2();
		case FUNCTION_CUSTOM3:
			return femCast(this)->toFunctionCUSTOM3->functionScriptCUSTOM3();
		case VALUE_VOID:
			return femCast(this)->toValueVOID->functionScriptVOID();
		case VALUE_TRUE:
			return femCast(this)->toValueTRUE->functionScriptTRUE();
		case VALUE_FALSE:
			return femCast(this)->toValueFALSE->functionScriptFALSE();
		case ARRAY_VALUE:
		case ARRAY_CYCLIC:
		case ARRAY_CONCAT:
		case ARRAY_SECTION:
		case ARRAY_REVERSE:
		case ARRAY_UNIFORM:
		case ARRAY_CUSTOM1:
		case ARRAY_CUSTOM2:
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayBASE->functionScriptARRAY();
		case STRING_BYTES:
		case STRING_CHARS:
		case STRING_VALUE:
		case STRING_CONCAT:
		case STRING_SECTION:
		case STRING_REVERSE:
		case STRING_UNIFORM:
		case STRING_CUSTOM1:
		case STRING_CUSTOM2:
		case STRING_CUSTOM3:
			return femCast(this)->toStringBASE->functionScriptSTRING();
		case BINARY_VALUE:
		case BINARY_CONCAT:
		case BINARY_SECTION:
		case BINARY_REVERSE:
		case BINARY_UNIFORM:
		case BINARY_CUSTOM1:
		case BINARY_CUSTOM2:
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryBASE->functionScriptBINARY();
		case OBJECT_BASE:
			return femCast(this)->toObjectBASE->functionScriptOBJECT();
		case HANDLER_BASE:
			return femCast(this)->toHandlerBASE->functionScriptHANDLER();
		case INTEGER_BASE:
			return femCast(this)->toIntegerBASE->functionScriptINTEGER();
		case DECIMAL_BASE:
			return femCast(this)->toDecimalBASE->functionScriptDECIMAL();
		case DURATION_BASE:
			return femCast(this)->toDurationBASE->functionScriptDURATION();
		case DATETIME_BASE:
			return femCast(this)->toDatetimeBASE->functionScriptDATETIME();
	}
	throw FEMException();
}

inline bool FEMFunctionBASE::functionEqualsBASE(FEMFunctionBASE const& _that) const {
	if (this == &_that) return true;
	switch (dataType) {
		case FUNCTION_PROXY:
			if (_that.dataType != FUNCTION_PROXY) return false;
			return femCast(this)->toFunctionPROXY->functionEqualsPROXY(*femCast(&_that)->toFunctionPROXY);
		case FUNCTION_PARAM:
			if (_that.dataType != FUNCTION_PARAM) return false;
			return femCast(this)->toFunctionPARAM->functionEqualsPARAM(*femCast(&_that)->toFunctionPARAM);
		case FUNCTION_FRAME:
			if (_that.dataType != FUNCTION_FRAME) return false;
			return femCast(this)->toFunctionFRAME->functionEqualsFRAME(*femCast(&_that)->toFunctionFRAME);
		case FUNCTION_METHOD:
			if (_that.dataType != FUNCTION_METHOD) return false;
			return femCast(this)->toFunctionMETHOD->functionEqualsMETHOD(*femCast(&_that)->toFunctionMETHOD);
		case FUNCTION_CONCAT:
			if (_that.dataType != FUNCTION_CONCAT) return false;
			return femCast(this)->toFunctionCONCAT->functionEqualsINVOKE(*femCast(&_that)->toFunctionCONCAT);
		case FUNCTION_COMPOSE:
			if (_that.dataType != FUNCTION_COMPOSE) return false;
			return femCast(this)->toFunctionCOMPOSE->functionEqualsINVOKE(*femCast(&_that)->toFunctionCOMPOSE);
		case FUNCTION_CUSTOM1:
			if (_that.dataType != FUNCTION_CUSTOM1) return false;
			return femCast(this)->toFunctionCUSTOM1->functionEqualsCUSTOM1(*femCast(&_that)->toFunctionCUSTOM1);
		case FUNCTION_CUSTOM2:
			if (_that.dataType != FUNCTION_CUSTOM2) return false;
			return femCast(this)->toFunctionCUSTOM2->functionEqualsCUSTOM2(*femCast(&_that)->toFunctionCUSTOM2);
		case FUNCTION_CUSTOM3:
			if (_that.dataType != FUNCTION_CUSTOM3) return false;
			return femCast(this)->toFunctionCUSTOM3->functionEqualsCUSTOM3(*femCast(&_that)->toFunctionCUSTOM3);
		case VALUE_VOID:
			return _that.dataType == VALUE_VOID;
		case VALUE_TRUE:
			return _that.dataType == VALUE_TRUE;
		case VALUE_FALSE:
			return _that.dataType == VALUE_FALSE;
		case ARRAY_VALUE:
		case ARRAY_CYCLIC:
		case ARRAY_CONCAT:
		case ARRAY_SECTION:
		case ARRAY_REVERSE:
		case ARRAY_UNIFORM:
		case ARRAY_CUSTOM1:
		case ARRAY_CUSTOM2:
		case ARRAY_CUSTOM3:
			if ((_that.dataType < ARRAY_VALUE) || (_that.dataType > ARRAY_CUSTOM3)) return false;
			return femCast(this)->toArrayBASE->functionEqualsARRAY(*femCast(&_that)->toArrayBASE);
		case STRING_BYTES:
		case STRING_CHARS:
		case STRING_VALUE:
		case STRING_CONCAT:
		case STRING_SECTION:
		case STRING_REVERSE:
		case STRING_UNIFORM:
		case STRING_CUSTOM1:
		case STRING_CUSTOM2:
		case STRING_CUSTOM3:
			if ((_that.dataType < STRING_BYTES) || (_that.dataType > STRING_CUSTOM3)) return false;
			return femCast(this)->toStringBASE->functionEqualsSTRING(*femCast(&_that)->toStringBASE);
		case BINARY_VALUE:
		case BINARY_CONCAT:
		case BINARY_SECTION:
		case BINARY_REVERSE:
		case BINARY_UNIFORM:
		case BINARY_CUSTOM1:
		case BINARY_CUSTOM2:
		case BINARY_CUSTOM3:
			if ((_that.dataType < BINARY_VALUE) || (_that.dataType > BINARY_CUSTOM3)) return false;
			return femCast(this)->toBinaryBASE->functionEqualsBINARY(*femCast(&_that)->toBinaryBASE);
		case OBJECT_BASE:
			if (_that.dataType != OBJECT_BASE) return false;
			return femCast(this)->toObjectBASE->functionEqualsOBJECT(*femCast(&_that)->toObjectBASE);
		case HANDLER_BASE:
			if (_that.dataType != HANDLER_BASE) return false;
			return femCast(this)->toHandlerBASE->functionEqualsHANDLER(*femCast(&_that)->toHandlerBASE);
		case INTEGER_BASE:
			if (_that.dataType != INTEGER_BASE) return false;
			return femCast(this)->toIntegerBASE->functionEqualsINTEGER(*femCast(&_that)->toIntegerBASE);
		case DECIMAL_BASE:
			if (_that.dataType != DECIMAL_BASE) return false;
			return femCast(this)->toDecimalBASE->functionEqualsDECIMAL(*femCast(&_that)->toDecimalBASE);
		case DURATION_BASE:
			if (_that.dataType != DURATION_BASE) return false;
			return femCast(this)->toDurationBASE->functionEqualsDURATION(*femCast(&_that)->toDurationBASE);
		case DATETIME_BASE:
			if (_that.dataType != DATETIME_BASE) return false;
			return femCast(this)->toDatetimeBASE->functionEqualsDATETIME(*femCast(&_that)->toDatetimeBASE);
	}
	throw FEMException();
}

inline FEMValue FEMFunctionBASE::functionInvokeBASE(FEMFrame const& _frame) const { // DONE
	switch (dataType) {
		case FUNCTION_PROXY:
			return femCast(this)->toFunctionPROXY->functionInvokePROXY(_frame);
		case FUNCTION_PARAM:
			return femCast(this)->toFunctionPARAM->functionInvokePARAM(_frame);
		case FUNCTION_FRAME:
			return femCast(this)->toFunctionFRAME->functionInvokeFRAME(_frame);
		case FUNCTION_METHOD:
			return femCast(this)->toFunctionMETHOD->functionInvokeMETHOD(_frame);
		case FUNCTION_CONCAT:
			return femCast(this)->toFunctionCONCAT->functionInvokeCONCAT(_frame);
		case FUNCTION_COMPOSE:
			return femCast(this)->toFunctionCOMPOSE->functionInvokeCOMPOSE(_frame);
		case FUNCTION_CUSTOM1:
			return femCast(this)->toFunctionCUSTOM1->functionInvokeCUSTOM1(_frame);
		case FUNCTION_CUSTOM2:
			return femCast(this)->toFunctionCUSTOM2->functionInvokeCUSTOM2(_frame);
		case FUNCTION_CUSTOM3:
			return femCast(this)->toFunctionCUSTOM3->functionInvokeCUSTOM3(_frame);
		case VALUE_VOID:
		case VALUE_TRUE:
		case VALUE_FALSE:
		case ARRAY_VALUE:
		case ARRAY_CYCLIC:
		case ARRAY_CONCAT:
		case ARRAY_SECTION:
		case ARRAY_REVERSE:
		case ARRAY_UNIFORM:
		case ARRAY_CUSTOM1:
		case ARRAY_CUSTOM2:
		case ARRAY_CUSTOM3:
		case STRING_BYTES:
		case STRING_CHARS:
		case STRING_VALUE:
		case STRING_CONCAT:
		case STRING_SECTION:
		case STRING_REVERSE:
		case STRING_UNIFORM:
		case STRING_CUSTOM1:
		case STRING_CUSTOM2:
		case STRING_CUSTOM3:
		case BINARY_VALUE:
		case BINARY_CONCAT:
		case BINARY_SECTION:
		case BINARY_REVERSE:
		case BINARY_UNIFORM:
		case BINARY_CUSTOM1:
		case BINARY_CUSTOM2:
		case BINARY_CUSTOM3:
		case OBJECT_BASE:
		case HANDLER_BASE:
		case INTEGER_BASE:
		case DECIMAL_BASE:
		case DURATION_BASE:
		case DATETIME_BASE:
			return femCast(this)->toValueBASE->functionInvokeVALUE();
	}
	throw FEMException();
}

struct __________;

inline FEMFunctionPROXY::FEMFunctionPROXY(FEMString const& _proxyName) // DONE
		: FEMFunctionBASE(FUNCTION_PROXY), proxyName(_proxyName), proxyTarget(FEMVoid::INSTANCE) {
}

inline INT32 FEMFunctionPROXY::functionHashPROXY() const { // DONE
	return proxyName.hash();
}

inline FEMString FEMFunctionPROXY::functionScriptPROXY() const { // DONE
	return proxyName;
}

bool FEMFunctionPROXY::functionEqualsPROXY(FEMFunctionPROXY const& _that) const { // DONE
	return proxyName.equals(_that.proxyName);
}

inline FEMValue FEMFunctionPROXY::functionInvokePROXY(FEMFrame const& _frame) const { // DONE
	return proxyTarget.functionInvoke(_frame);
}

struct __________;

inline FEMFunctionPARAM::FEMFunctionPARAM(UINT32 const& _paramIndex) // DONE
		: FEMFunctionBASE(FUNCTION_PARAM), paramIndex(_paramIndex) {
}

inline INT32 FEMFunctionPARAM::functionHashPARAM() const { // DONE
	return paramIndex;
}

inline FEMString FEMFunctionPARAM::functionScriptPARAM() const { // DONE
	return SCRIPT.concat(FEMInteger::from(paramIndex + 1).toScript());
}

inline bool FEMFunctionPARAM::functionEqualsPARAM(FEMFunctionPARAM const& _that) const { // DONE
	return paramIndex == _that.paramIndex;
}

inline FEMValue FEMFunctionPARAM::functionInvokePARAM(FEMFrame const& _frame) const { // DONE
	return _frame.get(paramIndex);
}

struct __________;

inline FEMFunctionCACHE::FEMFunctionCACHE() { // DONE
	for (INT32 i = 0; i < functionCount; ++i) {
		functionArray[i].set(femCast(new FEMFunctionPARAM(i))->toFunctionOBJ);
	}
}

struct __________;

inline FEMFunctionFRAME::FEMFunctionFRAME() // DONE
		: FEMFunctionBASE(FUNCTION_FRAME) {
}

inline INT32 FEMFunctionFRAME::functionHashFRAME() const { // DONE
	return FUNCTION_FRAME;
}

inline FEMString FEMFunctionFRAME::functionScriptFRAME() const { // DONE
	return SCRIPT;
}

inline bool FEMFunctionFRAME::functionEqualsFRAME(FEMFunctionFRAME const& _that) const { // DONE
	return true;
}

inline FEMValue FEMFunctionFRAME::functionInvokeFRAME(FEMFrame const& _frame) const { // DONE
	return _frame.params();
}

struct __________;

inline FEMFunctionMETHOD::FEMFunctionMETHOD(FEMFunction::METHOD _invokeMethod) // DONE
		: FEMFunctionBASE(FUNCTION_METHOD), invokeMethod(_invokeMethod) {
}

inline INT32 FEMFunctionMETHOD::functionHashMETHOD() const { // DONE
	return (INT32) invokeMethod;
}

inline FEMString FEMFunctionMETHOD::functionScriptMETHOD() const { // TODO
	return FEMString::EMPTY;
}

inline bool FEMFunctionMETHOD::functionEqualsMETHOD(FEMFunctionMETHOD const& _that) const { // DONE
	return invokeMethod == _that.invokeMethod;
}

inline FEMValue FEMFunctionMETHOD::functionInvokeMETHOD(FEMFrame const& _frame) const { // DONE
	return (*invokeMethod)(_frame);
}

struct __________;

inline FEMFunctionINVOKE::FEMFunctionINVOKE(DATA_TYPE _dataType, FEMFunction const& _invokeMethod, FEMFunction const* _paramArray, INT32 _paramCount) // DONE
		: FEMFunctionBASE(_dataType), invokeMethod(_invokeMethod), paramCount(_paramCount) {
	setupArray<FEMFunction, FEMFunction>(_paramArray, paramArray, _paramCount);
}

inline FEMFunctionINVOKE::~FEMFunctionINVOKE() { // DONE
	resetArray<FEMFunction>(paramArray, paramCount);
}

inline INT32 FEMFunctionINVOKE::functionHashINVOKE() const { // DONE
	return invokeMethod.hash() ^ FEMFunction::POLICY::hashArray(paramArray, paramCount);
}

inline FEMString FEMFunctionINVOKE::functionScriptINVOKE() const { // DONE
	FEMString _result = invokeMethod.toScript();
	FEMFunction const* _array = paramArray;
	FEMFunction const* _cancel = _array + paramCount;
	_result = _result.concat(SCRIPT_OPEN);
	if (_array != _cancel) {
		_result = _result.concat(_array->toScript());
		_array++;
		while (_array != _cancel) {
			_result = _result.concat(SCRIPT_COMMA).concat(_array->toScript());
			++_array;
		}
	}
	return _result.concat(SCRIPT_CLOSE);
}

inline bool FEMFunctionINVOKE::functionEqualsINVOKE(FEMFunctionINVOKE const& _that) const { // DONE
	if (!invokeMethod.equals(_that.invokeMethod)) return false;
	return FEMFunction::POLICY::equalsArray(paramArray, _that.paramArray, paramCount, _that.paramCount);
}

struct __________;

inline FEMFunctionCONCAT::FEMFunctionCONCAT(FEMFunction const& _invokeMethod, FEMFunction const* _paramArray, INT32 _paramCount) // DONE
		: FEMFunctionINVOKE(FUNCTION_CONCAT, _invokeMethod, _paramArray, _paramCount) {
}

inline FEMValue FEMFunctionCONCAT::functionInvokeCONCAT(FEMFrame const& _frame) const { // DONE
	return invokeMethod.functionInvoke(_frame).valueAsHandler().value().functionInvoke(_frame.newFrame(paramArray, paramCount));
}

struct __________;

inline FEMFunctionCOMPOSE::FEMFunctionCOMPOSE(FEMFunction const& _invokeMethod, FEMFunction const* _paramArray, INT32 _paramCount) // DONE
		: FEMFunctionINVOKE(FUNCTION_COMPOSE, _invokeMethod, _paramArray, _paramCount) {
}

inline FEMValue FEMFunctionCOMPOSE::functionInvokeCOMPOSE(FEMFrame const& _frame) const { // DONE
	return invokeMethod.functionInvoke(_frame.newFrame(paramArray, paramCount));
}

struct __________;

inline FEMFunctionCUSTOM1::FEMFunctionCUSTOM1()
		: FEMFunctionBASE(FUNCTION_CUSTOM1) {
}

inline FEMFunctionCUSTOM1::~FEMFunctionCUSTOM1() {
}

inline INT32 FEMFunctionCUSTOM1::functionHashCUSTOM1() const {
	return 0;
}

inline FEMString FEMFunctionCUSTOM1::functionScriptCUSTOM1() const {
	return FEMString::EMPTY;
}

inline bool FEMFunctionCUSTOM1::functionEqualsCUSTOM1(FEMFunctionCUSTOM1 const& _that) const {
	return false;
}

inline FEMValue FEMFunctionCUSTOM1::functionInvokeCUSTOM1(FEMFrame const& _frame) const {
	return FEMVoid::INSTANCE;
}

struct __________;

inline FEMFunctionCUSTOM2::FEMFunctionCUSTOM2()
		: FEMFunctionBASE(FUNCTION_CUSTOM2) {
}

inline FEMFunctionCUSTOM2::~FEMFunctionCUSTOM2() {
}

inline INT32 FEMFunctionCUSTOM2::functionHashCUSTOM2() const {
	return 0;
}

inline FEMString FEMFunctionCUSTOM2::functionScriptCUSTOM2() const {
	return FEMString::EMPTY;
}

inline bool FEMFunctionCUSTOM2::functionEqualsCUSTOM2(FEMFunctionCUSTOM2 const& _that) const {
	return false;
}

inline FEMValue FEMFunctionCUSTOM2::functionInvokeCUSTOM2(FEMFrame const& _frame) const {
	return FEMVoid::INSTANCE;
}

struct __________;

inline FEMFunctionCUSTOM3::FEMFunctionCUSTOM3()
		: FEMFunctionBASE(FUNCTION_CUSTOM3) {
}

inline FEMFunctionCUSTOM3::~FEMFunctionCUSTOM3() {
}

inline INT32 FEMFunctionCUSTOM3::functionHashCUSTOM3() const {
	return 0;
}

inline FEMString FEMFunctionCUSTOM3::functionScriptCUSTOM3() const {
	return FEMString::EMPTY;
}

inline bool FEMFunctionCUSTOM3::functionEqualsCUSTOM3(FEMFunctionCUSTOM3 const& _that) const {
	return false;
}

inline FEMValue FEMFunctionCUSTOM3::functionInvokeCUSTOM3(FEMFrame const& _frame) const {
	return FEMVoid::INSTANCE;
}

struct __________;

FEMValue::FEMValue() {
}

FEMValue::TYPE FEMValue::valueType() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toValueBASE->valueType();
}

bool FEMValue::valueIsVoid() const { // DONE
	return valueType() == VALUE_TYPE_VOID;
}

bool FEMValue::valueIsArray() const { // DONE
	return valueType() == VALUE_TYPE_ARRAY;
}

bool FEMValue::valueIsString() const { // DONE
	return valueType() == VALUE_TYPE_STRING;
}

bool FEMValue::valueIsBinary() const { // DONE
	return valueType() == VALUE_TYPE_BINARY;
}

bool FEMValue::valueIsObject() const { // DONE
	return valueType() == VALUE_TYPE_OBJECT;
}

bool FEMValue::valueIsHandler() const { // DONE
	return valueType() == VALUE_TYPE_HANDLER;
}

bool FEMValue::valueIsInteger() const { // DONE
	return valueType() == VALUE_TYPE_INTEGER;
}

bool FEMValue::valueIsDecimal() const { // DONE
	return valueType() == VALUE_TYPE_DECIMAL;
}

bool FEMValue::valueIsBoolean() const { // DONE
	return valueType() == VALUE_TYPE_BOOLEAN;
}

bool FEMValue::valueIsDuration() const { // DONE
	return valueType() == VALUE_TYPE_DURATION;
}

bool FEMValue::valueIsDatetime() const { // DONE
	return valueType() == VALUE_TYPE_DATETIME;
}

bool FEMValue::valueIsOther() const { // DONE
	return valueType() == VALUE_TYPE_OTHER;
}

FEMVoid const& FEMValue::valueAsVoid() const { // DONE
	FEMException::checkState(valueIsVoid());
	return *femCast(this)->toVoid;
}

FEMArray const& FEMValue::valueAsArray() const { // DONE
	FEMException::checkState(valueIsArray());
	return *femCast(this)->toArray;
}

FEMString const& FEMValue::valueAsString() const { // DONE
	FEMException::checkState(valueIsString());
	return *femCast(this)->toString;
}

FEMBinary const& FEMValue::valueAsBinary() const { // DONE
	FEMException::checkState(valueIsBinary());
	return *femCast(this)->toBinary;
}

FEMObject const& FEMValue::valueAsObject() const { // DONE
	FEMException::checkState(valueIsObject());
	return *femCast(this)->toObject;
}

FEMHandler const& FEMValue::valueAsHandler() const { // DONE
	FEMException::checkState(valueIsHandler());
	return *femCast(this)->toHandler;
}

FEMInteger const& FEMValue::valueAsInteger() const { // DONE
	FEMException::checkState(valueIsInteger());
	return *femCast(this)->toInteger;
}

FEMDecimal const& FEMValue::valueAsDecimal() const { // DONE
	FEMException::checkState(valueIsDecimal());
	return *femCast(this)->toDecimal;
}

FEMBoolean const& FEMValue::valueAsBoolean() const { // DONE
	FEMException::checkState(valueIsBoolean());
	return *femCast(this)->toBoolean;
}

FEMDuration const& FEMValue::valueAsDuration() const { // DONE
	FEMException::checkState(valueIsDuration());
	return *femCast(this)->toDuration;
}

FEMDatetime const& FEMValue::valueAsDatetime() const { // DONE
	FEMException::checkState(valueIsDatetime());
	return *femCast(this)->toDatetime;
}

FEMValue FEMValue::clone() const { // DONE
	return *this;
}

struct __________;

FEMValue::ARRAY::ARRAY(INT32 _length) // DONE
		: SUCArray<FEMValue, POLICY>(_length) {
}

struct __________;

FEMValue::LISTING::LISTING(INT32 _capacity) // DONE
		: SUCListing<FEMValue, POLICY>(_capacity) {
}

struct __________;

inline FEMValueBASE::FEMValueBASE(DATA_TYPE const _dataType)
		: FEMFunctionBASE(_dataType) {
}

inline FEMValue::TYPE FEMValueBASE::valueType() const { // DONE
	switch (dataType) {
		case VALUE_VOID:
			return FEMValue::VALUE_TYPE_VOID;
		case VALUE_TRUE:
		case VALUE_FALSE:
			return FEMValue::VALUE_TYPE_BOOLEAN;
		case ARRAY_VALUE:
		case ARRAY_CYCLIC:
		case ARRAY_CONCAT:
		case ARRAY_SECTION:
		case ARRAY_REVERSE:
		case ARRAY_UNIFORM:
		case ARRAY_CUSTOM1:
		case ARRAY_CUSTOM2:
		case ARRAY_CUSTOM3:
			return FEMValue::VALUE_TYPE_ARRAY;
		case STRING_BYTES:
		case STRING_CHARS:
		case STRING_VALUE:
		case STRING_CONCAT:
		case STRING_SECTION:
		case STRING_REVERSE:
		case STRING_UNIFORM:
		case STRING_CUSTOM1:
		case STRING_CUSTOM2:
		case STRING_CUSTOM3:
			return FEMValue::VALUE_TYPE_STRING;
		case BINARY_VALUE:
		case BINARY_CONCAT:
		case BINARY_SECTION:
		case BINARY_REVERSE:
		case BINARY_UNIFORM:
		case BINARY_CUSTOM1:
		case BINARY_CUSTOM2:
		case BINARY_CUSTOM3:
			return FEMValue::VALUE_TYPE_BINARY;
		case OBJECT_BASE:
			return FEMValue::VALUE_TYPE_OBJECT;
		case HANDLER_BASE:
			return FEMValue::VALUE_TYPE_HANDLER;
		case INTEGER_BASE:
			return FEMValue::VALUE_TYPE_INTEGER;
		case DECIMAL_BASE:
			return FEMValue::VALUE_TYPE_DECIMAL;
		case DURATION_BASE:
			return FEMValue::VALUE_TYPE_DURATION;
		case DATETIME_BASE:
			return FEMValue::VALUE_TYPE_DATETIME;
		default:
			return FEMValue::VALUE_TYPE_OTHER;
	}
}

FEMValue FEMValueBASE::functionInvokeVALUE() const {
	FEMValueBASE const* _result = this;
	return FEMValue(*femCast(&_result)->toValue);
}

struct __________;

FEMVoid::FEMVoid() // DONE
		: FEMVoid(INSTANCE) {
}

struct __________;

inline FEMValueVOID::FEMValueVOID() // DONE
		: FEMValueBASE(VALUE_VOID) {
}

inline FEMString FEMValueVOID::functionScriptVOID() const { // DONE
	return SCRIPT;
}

struct __________;

inline FEMValueTRUE::FEMValueTRUE() // DONE
		: FEMValueBASE(VALUE_TRUE) {
}

inline FEMString FEMValueTRUE::functionScriptTRUE() const { // DONE
	return SCRIPT;
}

struct __________;

inline FEMValueFALSE::FEMValueFALSE() // DONE
		: FEMValueBASE(VALUE_FALSE) {
}

inline FEMString FEMValueFALSE::functionScriptFALSE() const { // DONE
	return SCRIPT;
}

struct __________;

FEMArray FEMArray::from(VALUE const& _array) { // DONE
	return from(_array.data(), _array.length());
}

FEMArray FEMArray::from(FEMValue const* _itemArray, INT32 const _itemCount) { // DONE
	FEMException::checkNull(_itemArray);
	if (!_itemCount) return EMPTY;
	if (_itemCount == 1) return from(*_itemArray, 1);
	FEMException::checkCount(_itemCount);
	DELETE_ARRAY<INT8> _resultGuard(new INT8[sizeof(FEMArrayVALUE) + _itemCount * sizeof(FEMValue)]);
	FEMArrayVALUE* _result = new (_resultGuard.array()) FEMArrayVALUE(_itemArray, _itemCount);
	_resultGuard.cancel();
	return FEMArray(*femCast(&_result)->toArray);
}

FEMArray FEMArray::from(FEMValue const& _item, INT32 const _itemCount) { // DONE
	if (!_itemCount) return EMPTY;
	FEMException::checkCount(_itemCount);
	FEMArrayUNIFORM* _result = new FEMArrayUNIFORM(_item, _itemCount);
	return FEMArray(*femCast(&_result)->toArray);
}

FEMArray::FEMArray() // DONE
		: FEMArray(EMPTY) {
}

bool FEMArray_value(PVOID _target, FEMValue const& _value) { // DONE
	FEMValue** _cursor = (FEMValue**) _target;
	**_cursor = _value;
	*_cursor += 1;
	return true;
}

FEMArray::VALUE FEMArray::value() const { // DONE
	VALUE _result(length());
	FEMValue* _context = _result.data();
	extract(&_context, FEMArray_value);
	return _result;
}

FEMValue FEMArray::get(INT32 const _index) const { // DONE
	FEMArrayBASE* _thisArray = femCast(this)->toPointerAndCastItsTarget->toArrayBASE;
	FEMException::checkIndex(_index, _thisArray->arrayLength);
	return _thisArray->arrayGetBASE(_index);
}

INT32 FEMArray::length() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toArrayBASE->arrayLength;
}

FEMArray FEMArray::concat(FEMArray const& _that) const { // DONE
	INT32 _thisLength = length();
	if (!_thisLength) return _that;
	INT32 _thatLength = _that.length();
	if (!_thatLength) return *this;
	FEMArrayCONCAT* _result = new FEMArrayCONCAT(_thisLength + _thatLength, *this, _that);
	return FEMArray(*femCast(&_result)->toArray);
}

FEMArray FEMArray::section(INT32 const _offset, INT32 const _length) const { // DONE
	FEMArrayBASE* _thisArray = femCast(this)->toPointerAndCastItsTarget->toArrayBASE;
	INT32 _thisLength = _thisArray->arrayLength;
	if ((_offset == 0) && (_length == _thisLength)) return *this;
	if ((_offset < 0) || (_length < 0) || ((_offset + _length) > _thisLength)) throw FEMException();
	if (_length == 0) return EMPTY;
	return _thisArray->arraySectionBASE(_offset, _length);
}

FEMArray FEMArray::reverse() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toArrayBASE->arrayReverseBASE();
}

FEMArray FEMArray::compact() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toArrayBASE->arrayCompactBASE();
}

INT32 FEMArray::find(FEMValue const& _that, INT32 const _offset) const { // DONE
	struct FEMArray_findValue {

		FEMValue const& value;

		INT32 index;

		FEMArray_findValue(FEMValue const& _value)
				: value(_value), index(0) {
		}

		static bool collector(PVOID _context, FEMValue const& _value) {
			FEMArray_findValue* _result = (FEMArray_findValue*) _context;
			if (_result->value.equals(_value)) return false;
			_result->index++;
			return true;
		}

	};
	FEMArrayBASE* _thisArray = femCast(this)->toPointerAndCastItsTarget->toArrayBASE;
	INT32 _length = _thisArray->arrayLength - _offset;
	if ((_offset < 0) || (_length < 0)) throw FEMException();
	FEMArray_findValue _context(_that);
	if (_thisArray->arrayExtractBASE(&_context, FEMArray_findValue::collector, _offset, _length, true)) return -1;
	return _context.index + _offset;
}

INT32 FEMArray::find(FEMArray const& _that, INT32 const _offset) const {
	FEMArrayBASE* _thisArray = femCast(this)->toPointerAndCastItsTarget->toArrayBASE;
	FEMArrayBASE* _thatArray = femCast(&_that)->toPointerAndCastItsTarget->toArrayBASE;
	if ((_offset < 0) || (_offset > _thisArray->arrayLength)) throw FEMException();
	INT32 _thatLength = _thatArray->arrayLength;
	if (_thatLength == 0) return _offset;
	INT32 _thisLength = _thisArray->arrayLength - _thatLength;
	FEMValue _thatValue = _thatArray->arrayGetBASE(0);
	for (int _thisIndex = _offset; _thisIndex < _thisLength; _thisIndex++) {
		if (_thatValue.equals(_thisArray->arrayGetBASE(_thisIndex))) {
			for (int _thatIndex = 1; _thatIndex < _thatLength; _thatIndex++) {
				if (!_thisArray->arrayGetBASE(_thisIndex + _thatIndex).equals(_thatArray->arrayGetBASE(_thatIndex))) {
					goto FIND;
				}
			}
			return _thisIndex;
		}
		FIND: ;
	}
	return -1;

}

bool FEMArray::extract(PVOID _target, COLLECTOR _collector) const { // DONE
	FEMArrayBASE* _thisArray = femCast(this)->toPointerAndCastItsTarget->toArrayBASE;
	return _thisArray->arrayExtractBASE(_target, _collector, 0, _thisArray->arrayLength, true);
}

INT32 FEMArray::compare(FEMArray const& _that, PVOID _context, COMPARATOR _comparator) const {
	FEMArrayBASE* _thisArray = femCast(this)->toPointerAndCastItsTarget->toArrayBASE;
	FEMArrayBASE* _thatArray = femCast(&_that)->toPointerAndCastItsTarget->toArrayBASE;
	INT32 _thisLength = _thisArray->arrayLength;
	INT32 _thatLength = _thatArray->arrayLength;
	INT32 _length = _thisLength < _thatLength ? _thisLength : _thatLength;
	for (INT32 _index = 0; _index < _length; _index++) {
		FEMValue _thisValue = _thisArray->arrayGetBASE(_index);
		FEMValue _thatValue = _thatArray->arrayGetBASE(_index);
		INT32 _result = _comparator(_context, _thisValue, _thatValue);
		if (_result < 0) return -1;
		if (_result > 0) return +1;
	}
	INT32 _result = _thisLength - _thatLength;
	if (_result < 0) return -1;
	if (_result > 0) return +1;
	return 0;
}

struct __________;

inline bool FEMArrayBASE::hashEncoder(PVOID _target, FEMValue const& _value) { // DONE
	SUCHash* _result = (SUCHash*) _target;
	_result->pushHash(_value.hash());
	return true;
}

inline bool FEMArrayBASE::scriptEncoder(PVOID _context, FEMValue const& _value) { // DONE
	FEMString* _result = (FEMString*) _context;
	*_result = _result->concat(_value.toScript()).concat(SCRIPT_COMMA);
	return true;
}

inline FEMArrayBASE::FEMArrayBASE(DATA_TYPE const _dataType, INT32 const _arrayLength) // DONE
		: FEMValueBASE(_dataType), arrayLength(_arrayLength) {
}

inline FEMValue FEMArrayBASE::arrayGetBASE(INT32 const _index) const { // DONE
	switch (dataType) {
		case ARRAY_VALUE:
			return femCast(this)->toArrayVALUE->arrayGetVALUE(_index);
		case ARRAY_CYCLIC:
			return femCast(this)->toArrayCYCLIC->arrayGetCYCLIC(_index);
		case ARRAY_CONCAT:
			return femCast(this)->toArrayCONCAT->arrayGetCONCAT(_index);
		case ARRAY_SECTION:
			return femCast(this)->toArraySECTION->arrayGetSECTION(_index);
		case ARRAY_REVERSE:
			return femCast(this)->toArrayREVERSE->arrayGetREVERSE(_index);
		case ARRAY_UNIFORM:
			return femCast(this)->toArrayUNIFORM->arrayGetUNIFORM(_index);
		case ARRAY_CUSTOM1:
			return femCast(this)->toArrayCUSTOM1->arrayGetCUSTOM1(_index);
		case ARRAY_CUSTOM2:
			return femCast(this)->toArrayCUSTOM2->arrayGetCUSTOM2(_index);
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayCUSTOM3->arrayGetCUSTOM3(_index);
		default:
			throw FEMException();
	}
}

inline bool FEMArrayBASE::arrayExtractBASE(PVOID _context, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	switch (dataType) {
		case ARRAY_VALUE:
			return femCast(this)->toArrayVALUE->arrayExtractVALUE(_context, _collector, _offset, _length, _foreward);
		case ARRAY_CYCLIC:
			return femCast(this)->toArrayCYCLIC->arrayExtractDEFAULT(_context, _collector, _offset, _length, _foreward);
		case ARRAY_CONCAT:
			return femCast(this)->toArrayCONCAT->arrayExtractCONCAT(_context, _collector, _offset, _length, _foreward);
		case ARRAY_SECTION:
			return femCast(this)->toArraySECTION->arrayExtractSECTION(_context, _collector, _offset, _length, _foreward);
		case ARRAY_REVERSE:
			return femCast(this)->toArrayREVERSE->arrayExtractREVERSE(_context, _collector, _offset, _length, _foreward);
		case ARRAY_UNIFORM:
			return femCast(this)->toArrayUNIFORM->arrayExtractUNIFORM(_context, _collector, _offset, _length, _foreward);
		case ARRAY_CUSTOM1:
			return femCast(this)->toArrayCUSTOM1->arrayExtractDEFAULT(_context, _collector, _offset, _length, _foreward);
		case ARRAY_CUSTOM2:
			return femCast(this)->toArrayCUSTOM2->arrayExtractDEFAULT(_context, _collector, _offset, _length, _foreward);
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayCUSTOM3->arrayExtractDEFAULT(_context, _collector, _offset, _length, _foreward);
		default:
			throw FEMException();
	}
}

inline bool FEMArrayBASE::arrayExtractDEFAULT(PVOID _target, FEMArray::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const { // DONE
	if (_foreward) {
		for (_length += _offset; _offset < _length; _offset++) {
			if (!_collector(_target, arrayGetBASE(_offset))) return false;
		}
	} else {
		for (_length += _offset - 1; _offset <= _length; _length--) {
			if (!_collector(_target, arrayGetBASE(_length))) return false;
		}
	}
	return true;
}

inline FEMArray FEMArrayBASE::arraySectionBASE(INT32 const _offset, INT32 const _length) const { // DONE
	switch (dataType) {
		case ARRAY_VALUE:
			return femCast(this)->toArrayVALUE->arraySectionDEFAULT(_offset, _length);
		case ARRAY_CYCLIC:
			return femCast(this)->toArrayCYCLIC->arraySectionDEFAULT(_offset, _length);
		case ARRAY_CONCAT:
			return femCast(this)->toArrayCONCAT->arraySectionCONCAT(_offset, _length);
		case ARRAY_SECTION:
			return femCast(this)->toArraySECTION->arraySectionSECTION(_offset, _length);
		case ARRAY_REVERSE:
			return femCast(this)->toArrayREVERSE->arraySectionREVERSE(_offset, _length);
		case ARRAY_UNIFORM:
			return femCast(this)->toArrayUNIFORM->arraySectionUNIFORM(_offset, _length);
		case ARRAY_CUSTOM1:
			return femCast(this)->toArrayCUSTOM1->arraySectionDEFAULT(_offset, _length);
		case ARRAY_CUSTOM2:
			return femCast(this)->toArrayCUSTOM2->arraySectionDEFAULT(_offset, _length);
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayCUSTOM3->arraySectionDEFAULT(_offset, _length);
		default:
			throw FEMException();
	}
}

inline FEMArray FEMArrayBASE::arraySectionDEFAULT(INT32 const _offset, INT32 const _length) const { // DONE
	FEMArrayBASE const* _this = this;
	FEMArraySECTION* _result = new FEMArraySECTION(*femCast(&_this)->toArray, _offset, _length);
	return FEMArray(*femCast(&_result)->toArray);
}

inline FEMArray FEMArrayBASE::arrayCompactBASE() const { // DONE
	switch (dataType) {
		case ARRAY_VALUE:
			return femCast(this)->toArrayVALUE->arrayCompactVALUE();
		case ARRAY_CYCLIC:
			return femCast(this)->toArrayCYCLIC->arrayCompactDEFAULT();
		case ARRAY_CONCAT:
			return femCast(this)->toArrayCONCAT->arrayCompactDEFAULT();
		case ARRAY_SECTION:
			return femCast(this)->toArraySECTION->arrayCompactDEFAULT();
		case ARRAY_REVERSE:
			return femCast(this)->toArrayREVERSE->arrayCompactDEFAULT();
		case ARRAY_UNIFORM:
			return femCast(this)->toArrayUNIFORM->arrayCompactUNIFORM();
		case ARRAY_CUSTOM1:
			return femCast(this)->toArrayCUSTOM1->arrayCompactDEFAULT();
		case ARRAY_CUSTOM2:
			return femCast(this)->toArrayCUSTOM2->arrayCompactDEFAULT();
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayCUSTOM3->arrayCompactDEFAULT();
		default:
			throw FEMException();
	}
}

inline FEMArray FEMArrayBASE::arrayCompactDEFAULT() const { // DONE
	FEMArrayBASE const* _this = this; // TODO faster
	return FEMArray::from(femCast(&_this)->toArray->value());
}

inline FEMArray FEMArrayBASE::arrayReverseBASE() const { // DONE
	switch (dataType) {
		case ARRAY_VALUE:
			return femCast(this)->toArrayVALUE->arrayReverseDEFAULT();
		case ARRAY_CYCLIC:
			return femCast(this)->toArrayCYCLIC->arrayReverseDEFAULT();
		case ARRAY_CONCAT:
			return femCast(this)->toArrayCONCAT->arrayReverseDEFAULT();
		case ARRAY_SECTION:
			return femCast(this)->toArraySECTION->arrayReverseDEFAULT();
		case ARRAY_REVERSE:
			return femCast(this)->toArrayREVERSE->arrayReverseREVERSE();
		case ARRAY_UNIFORM:
			return femCast(this)->toArrayUNIFORM->arrayReverseUNIFORM();
		case ARRAY_CUSTOM1:
			return femCast(this)->toArrayCUSTOM1->arrayReverseDEFAULT();
		case ARRAY_CUSTOM2:
			return femCast(this)->toArrayCUSTOM2->arrayReverseDEFAULT();
		case ARRAY_CUSTOM3:
			return femCast(this)->toArrayCUSTOM3->arrayReverseDEFAULT();
		default:
			throw FEMException();
	}
}

inline FEMArray FEMArrayBASE::arrayReverseDEFAULT() const { // DONE
	FEMArrayBASE const* _this = this;
	FEMArrayREVERSE* _result = new FEMArrayREVERSE(*femCast(&_this)->toArray);
	return FEMArray(*femCast(&_result)->toArray);
}

inline INT32 FEMArrayBASE::functionHashARRAY() const { // DONE
	SUCHash _result;
	arrayExtractBASE(&_result, hashEncoder, 0, arrayLength, true);
	return _result;
}

inline FEMString FEMArrayBASE::functionScriptARRAY() const { // DONE
	FEMString _result = SCRIPT_OPEN;
	arrayExtractBASE(&_result, scriptEncoder, 0, arrayLength, true);
	return _result.section(0, _result.length() - SCRIPT_COMMA.length()).concat(SCRIPT_CLOSE);
}

inline bool FEMArrayBASE::functionEqualsARRAY(FEMArrayBASE const& _that) const { // DONE
	INT32 _length = arrayLength;
	if (_that.arrayLength != _length) return false;
	for (INT32 _index = 0; _index < _length; _index++) {
		FEMValue _thisValue = arrayGetBASE(_index);
		FEMValue _thatValue = _that.arrayGetBASE(_index);
		if (!_thisValue.equals(_thatValue)) return false;
	}
	return true;
}

struct __________;

inline FEMArrayVALUE::FEMArrayVALUE(INT32 const _arrayLength) // DONE
		: FEMArrayBASE(ARRAY_VALUE, _arrayLength) {
	setupArray<FEMValue>(valueArray, _arrayLength);
}

inline FEMArrayVALUE::FEMArrayVALUE(FEMValue const* _valueArray, INT32 const _valueCount) // DONE
		: FEMArrayBASE(ARRAY_VALUE, _valueCount) {
	setupArray<FEMValue, FEMValue>(_valueArray, valueArray, _valueCount);
}

inline FEMArrayVALUE::~FEMArrayVALUE() { // DONE
	resetArray<FEMValue>(valueArray, arrayLength);
}

inline FEMValue FEMArrayVALUE::arrayGetVALUE(INT32 const _index) const { // DONE
	return valueArray[_index];
}

inline bool FEMArrayVALUE::arrayExtractVALUE(PVOID _target, FEMArray::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const { // DONE
	if (_foreward) { // TODO faster
		for (_length += _offset; _offset < _length; _offset++) {
			if (!_collector(_target, valueArray[_offset])) return false;
		}
	} else {
		for (_length += _offset - 1; _offset <= _length; _length--) {
			if (!_collector(_target, valueArray[_length])) return false;
		}
	}
	return true;
}

inline FEMArray FEMArrayVALUE::arrayCompactVALUE() const { // DONE
	FEMArrayVALUE const* _result = this;
	return FEMArray(*femCast(&_result)->toArray);
}

struct __________;

inline FEMArrayCYCLIC::FEMArrayCYCLIC(FEMFrameCYCLIC const& _cyclicFrame) // DONE
		: FEMArrayBASE(ARRAY_CYCLIC, _cyclicFrame.frameSize), cyclicFrame(femCast(&_cyclicFrame)->toFrameOBJ), cyclicPrev(this), cyclicNext(this), cyclicContext(_cyclicFrame.ownerContext) {
	FEMArrayCYCLIC* _cyclicList = &femCast(cyclicContext)->toContextBASE->cyclicList;
	_cyclicList->cyclicNext = ((cyclicNext = (cyclicPrev = _cyclicList)->cyclicNext)->cyclicPrev = this);
	femCast(&_cyclicFrame)->toFrameCYCLIC->cyclicArray = this;
}

inline FEMArrayCYCLIC::FEMArrayCYCLIC(FEMContextBASE const& _ownerContext)
		: FEMArrayBASE(ARRAY_CYCLIC, 0), cyclicFrame(femCast(new FEMFrameCYCLIC(_ownerContext))->toFrameOBJ), cyclicPrev(this), cyclicNext(this), cyclicContext(&_ownerContext) {
}

inline FEMArrayCYCLIC::~FEMArrayCYCLIC() { // DONE
	CSGuard _cyclicGuard = CSGuard(femCast(cyclicContext)->toContextBASE->cyclicSection);
	cyclicDelete();
}

inline FEMValue FEMArrayCYCLIC::arrayGetCYCLIC(INT32 const _index) const { // DONE
	return femCast(&cyclicFrame)->toPointerAndCastItsTarget->toFrameCYCLIC->frameGetBASE(_index);
}

void FEMArrayCYCLIC::cyclicDelete() { // DONE
	(cyclicPrev->cyclicNext = cyclicNext)->cyclicPrev = cyclicPrev;
	cyclicPrev = (cyclicNext = this);
	femCast(&cyclicFrame)->toPointerAndCastItsTarget->toFrameCYCLIC->cyclicArray = 0;
	cyclicFrame = FEMFrameBASE::EMPTY;
}

struct __________;

inline FEMArrayCONCAT::FEMArrayCONCAT(INT32 const _arrayLength, FEMArray const& _array1, FEMArray const& _array2) // DONE
		: FEMArrayBASE(ARRAY_CONCAT, _arrayLength), array1(_array1), array2(_array2) {
}

inline FEMValue FEMArrayCONCAT::arrayGetCONCAT(INT32 const _index) const { // DONE
	FEMArrayBASE* _array1 = femCast(&array1)->toPointerAndCastItsTarget->toArrayBASE;
	INT32 _index2 = _index - _array1->arrayLength;
	if (_index2 < 0) return _array1->arrayGetBASE(_index);
	FEMArrayBASE* _array2 = femCast(&array2)->toPointerAndCastItsTarget->toArrayBASE;
	return _array2->arrayGetBASE(_index2);
}

inline bool FEMArrayCONCAT::arrayExtractCONCAT(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	FEMArrayBASE* _array1 = femCast(&array1)->toPointerAndCastItsTarget->toArrayBASE;
	FEMArrayBASE* _array2 = femCast(&array2)->toPointerAndCastItsTarget->toArrayBASE;
	INT32 _offset2 = _offset - _array1->arrayLength, _length2 = _offset2 + _length;
	if (_offset2 >= 0) return _array2->arrayExtractBASE(_target, _collector, _offset2, _length, _foreward);
	if (_length2 <= 0) return _array1->arrayExtractBASE(_target, _collector, _offset, _length, _foreward);
	if (_foreward) {
		if (!_array1->arrayExtractBASE(_target, _collector, _offset, -_offset2, true)) return false;
		return _array2->arrayExtractBASE(_target, _collector, 0, _length2, true);
	} else {
		if (!_array2->arrayExtractBASE(_target, _collector, 0, _length2, false)) return false;
		return _array1->arrayExtractBASE(_target, _collector, _offset, -_offset2, false);
	}
}

inline FEMArray FEMArrayCONCAT::arraySectionCONCAT(INT32 _offset, INT32 _length) const { // DONE
	FEMArrayBASE* _array1 = femCast(&array1)->toPointerAndCastItsTarget->toArrayBASE;
	FEMArrayBASE* _array2 = femCast(&array2)->toPointerAndCastItsTarget->toArrayBASE;
	INT32 _offset2 = _offset - _array1->arrayLength, _length2 = _offset2 + _length;
	if (_offset2 >= 0) return _array2->arraySectionBASE(_offset2, _length);
	if (_length2 <= 0) return _array1->arraySectionBASE(_offset, _length);
	return _array1->arraySectionBASE(_offset, -_offset2).concat(_array2->arraySectionBASE(0, _length2));
}

struct __________;

inline FEMArraySECTION::FEMArraySECTION(FEMArray const& _array, INT32 const _offset, INT32 const _length) // DONE
		: FEMArrayBASE(ARRAY_SECTION, _length), array(_array), offset(_offset) {
}

inline FEMValue FEMArraySECTION::arrayGetSECTION(INT32 const _index) const { // DONE
	return femCast(&array)->toPointerAndCastItsTarget->toArrayBASE->arrayGetBASE(_index + offset);
}

inline bool FEMArraySECTION::arrayExtractSECTION(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	return femCast(&array)->toPointerAndCastItsTarget->toArrayBASE->arrayExtractBASE(_target, _collector, offset + _offset, _length, _foreward);
}

inline FEMArray FEMArraySECTION::arraySectionSECTION(INT32 _offset, INT32 _length) const { // DONE
	return femCast(&array)->toPointerAndCastItsTarget->toArrayBASE->arraySectionBASE(offset + _offset, _length);
}

struct __________;

inline FEMArrayREVERSE::FEMArrayREVERSE(FEMArray const& _array) // DONE
		: FEMArrayBASE(ARRAY_REVERSE, _array.length()), array(_array) {
}

inline FEMValue FEMArrayREVERSE::arrayGetREVERSE(INT32 const _index) const { // DONE
	return femCast(&array)->toPointerAndCastItsTarget->toArrayBASE->arrayGetBASE(arrayLength - _index - 1);
}

inline bool FEMArrayREVERSE::arrayExtractREVERSE(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	return femCast(&array)->toPointerAndCastItsTarget->toArrayBASE->arrayExtractBASE(_target, _collector, arrayLength - _offset - _length, _length, !_foreward);
}

inline FEMArray FEMArrayREVERSE::arraySectionREVERSE(INT32 _offset, INT32 _length) const { // DONE
	return femCast(&array)->toPointerAndCastItsTarget->toArrayBASE->arraySectionBASE(arrayLength - _offset - _length, _length).reverse();
}

inline FEMArray FEMArrayREVERSE::arrayReverseREVERSE() const { // DONE
	return array;
}

struct __________;

inline FEMArrayUNIFORM::FEMArrayUNIFORM(FEMValue const& _value, INT32 const _length) // DONE
		: FEMArrayBASE(ARRAY_UNIFORM, _length), value(_value) {
}

inline FEMValue FEMArrayUNIFORM::arrayGetUNIFORM(INT32 const _index) const { // DONE
	return value;
}

inline bool FEMArrayUNIFORM::arrayExtractUNIFORM(PVOID _target, FEMArray::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	for (INT32 i = _length; i > 0; --i) {
		if (!(*_collector)(_target, value)) return false;
	}
	return true;
}

inline FEMArray FEMArrayUNIFORM::arraySectionUNIFORM(INT32 _offset, INT32 _length) const { // DONE
	FEMArrayUNIFORM* _result = new FEMArrayUNIFORM(value, _length);
	return FEMArray(*femCast(&_result)->toArray);
}

inline FEMArray FEMArrayUNIFORM::arrayCompactUNIFORM() const { // DONE
	FEMArrayUNIFORM const* _result = this;
	return FEMArray(*femCast(&_result)->toArray);
}

inline FEMArray FEMArrayUNIFORM::arrayReverseUNIFORM() const { // DONE
	FEMArrayUNIFORM const* _result = this;
	return FEMArray(*femCast(&_result)->toArray);
}

struct __________;

inline FEMArrayCUSTOM1::FEMArrayCUSTOM1() // DONE
		: FEMArrayBASE(ARRAY_CUSTOM1, 0) {
}

inline FEMArrayCUSTOM1::~FEMArrayCUSTOM1() { // DONE
}

inline FEMValue FEMArrayCUSTOM1::arrayGetCUSTOM1(INT32 const _index) const { // DONE
	throw FEMException();
}

struct __________;

inline FEMArrayCUSTOM2::FEMArrayCUSTOM2() // DONE
		: FEMArrayBASE(ARRAY_CUSTOM2, 0) {
}

inline FEMArrayCUSTOM2::~FEMArrayCUSTOM2() { // DONE
}

inline FEMValue FEMArrayCUSTOM2::arrayGetCUSTOM2(INT32 const _index) const { // DONE
	throw FEMException();
}

struct __________;

inline FEMArrayCUSTOM3::FEMArrayCUSTOM3() // DONE
		: FEMArrayBASE(ARRAY_CUSTOM3, 0) {
}

inline FEMArrayCUSTOM3::~FEMArrayCUSTOM3() { // DONE
}

inline FEMValue FEMArrayCUSTOM3::arrayGetCUSTOM3(INT32 const _index) const { // DONE
	throw FEMException();
}

struct __________;

FEMString FEMString::from(UINT32 const _item, INT32 const _itemCount) {
	if (!_itemCount) return EMPTY;
	FEMException::checkCount(_itemCount);
	FEMStringUNIFORM* _result = new FEMStringUNIFORM(_item, _itemCount);
	return FEMString(*femCast(&_result)->toString);
}

FEMString FEMString::from(CHAR const* _string) { // DONE
	FEMException::checkNull(_string);
	return from((UINT8 const*) _string, strlen(_string));
}

FEMString FEMString::from(UINT8 const* _itemArray, INT32 const _itemCount) { // DONE
	FEMException::checkNull(_itemArray);
	FEMException::checkCount(_itemCount);
	INT32 _stringLength = FEMStringBYTES::stringUTF8Length(_itemArray, _itemCount);
	if (!_stringLength) return EMPTY;
	if (_stringLength == 1) return from(FEMStringBYTES::stringUTF8Codepoint(_itemArray), 1);
	DELETE_ARRAY<UINT8> _deleteGuard(new UINT8[sizeof(FEMStringBYTES) + _stringLength + 1]);
	FEMStringBYTES* _result = new (_deleteGuard.array()) FEMStringBYTES(_stringLength, _itemArray, _itemCount);
	_deleteGuard.cancel();
	return FEMString(*femCast(&_result)->toString);
}

FEMString FEMString::from(UINT16 const* _itemArray, INT32 const _itemCount) { // DONE
	FEMException::checkNull(_itemArray);
	FEMException::checkCount(_itemCount);
	INT32 _stringLength = FEMStringCHARS::stringUTF16Length(_itemArray, _itemCount);
	if (!_stringLength) return EMPTY;
	if (_stringLength == 1) return from(FEMStringCHARS::stringUTF16Codepoint(_itemArray), 1);
	DELETE_ARRAY<UINT8> _deleteGuard(new UINT8[sizeof(FEMStringCHARS) + (_stringLength << 1) + 2]);
	FEMStringCHARS* _result = new (_deleteGuard.array()) FEMStringCHARS(_stringLength, _itemArray, _itemCount);
	_deleteGuard.cancel();
	return FEMString(*femCast(&_result)->toString);
}

FEMString FEMString::from(UINT32 const* _itemArray, INT32 const _itemCount) { // DONE
	FEMException::checkNull(_itemArray);
	FEMException::checkCount(_itemCount);
	if (!_itemCount) return EMPTY;
	if (_itemCount == 1) return from(_itemArray[0], 1);
	DELETE_ARRAY<UINT8> _deleteGuard(new UINT8[sizeof(FEMStringVALUE) + (_itemCount << 2) + 4]);
	FEMStringVALUE* _result = new (_deleteGuard.array()) FEMStringVALUE(_itemArray, _itemCount);
	_deleteGuard.cancel();
	return FEMString(*femCast(&_result)->toString);
}

FEMString FEMString::from(FEMString const& _script) { // TODO
	return EMPTY;
}

FEMString::FEMString() // DONE
		: FEMString(EMPTY) {
}

FEMString::VALUE FEMString::value() const { // DONE
	VALUE _result(length() + 1);
	UINT32* _cursor = _result.data();
	extract(&_cursor, FEMStringVALUE::stringUTF32Encoder);
	_cursor[0] = 0;
	return _result;
}

UINT32 FEMString::get(INT32 const _index) const {
	FEMStringBASE* _this = femCast(this)->toPointerAndCastItsTarget->toStringBASE;
	FEMException::checkIndex(_index, _this->stringLength);
	return _this->stringGetBASE(_index);
}

INT32 FEMString::length() const {
	return femCast(this)->toPointerAndCastItsTarget->toStringBASE->stringLength;
}

FEMString FEMString::concat(FEMString const& _that) const { // DONE
	INT32 _thisLength = length();
	if (!_thisLength) return _that;
	INT32 _thatLength = _that.length();
	if (!_thatLength) return *this;
	PCVOID _this = new FEMStringCONCAT(_thisLength + _thatLength, *this, _that);
	return FEMString(*femCast(&_this)->toString);
}

FEMString FEMString::section(INT32 const _offset, INT32 const _length) const { // DONE
	FEMStringBASE* _thisString = femCast(this)->toPointerAndCastItsTarget->toStringBASE;
	INT32 _thisLength = _thisString->stringLength;
	if ((_offset == 0) && (_length == _thisLength)) return *this;
	if ((_offset < 0) || (_length < 0) || ((_offset + _length) > _thisLength)) throw FEMException();
	if (_length == 0) return EMPTY;
	return _thisString->stringSectionBASE(_offset, _length);
}

FEMString FEMString::reverse() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toStringBASE->stringReverseBASE();
}

FEMString FEMString::compact() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toStringBASE->stringCompactBASE();
}

INT32 FEMString::find(UINT32 const _that, INT32 const _offset) const { // DONE
	struct FEMString_findValue {

		UINT32 value;

		INT32 index;

		FEMString_findValue(UINT32 _value)
				: value(_value), index(0) {
		}

		static bool collector(PVOID _context, UINT32 const _value) {
			FEMString_findValue* _result = (FEMString_findValue*) _context;
			if (_result->value == _value) return false;
			_result->index++;
			return true;
		}

	};
	FEMStringBASE* _thisString = femCast(this)->toPointerAndCastItsTarget->toStringBASE;
	INT32 _length = _thisString->stringLength - _offset;
	if ((_offset < 0) || (_length < 0)) throw FEMException();
	FEMString_findValue _context(_that);
	if (_thisString->stringExtractBASE(&_context, FEMString_findValue::collector, _offset, _length, true)) return -1;
	return _context.index + _offset;
}

INT32 FEMString::find(FEMString const& _that, INT32 const _offset) const {
	FEMStringBASE* _thisString = femCast(this)->toPointerAndCastItsTarget->toStringBASE;
	FEMStringBASE* _thatString = femCast(&_that)->toPointerAndCastItsTarget->toStringBASE;
	if ((_offset < 0) || (_offset > _thisString->stringLength)) throw FEMException();
	INT32 _thatLength = _thatString->stringLength;
	if (_thatLength == 0) return _offset;
	INT32 _thisLength = _thisString->stringLength - _thatLength;
	UINT32 _thatValue = _thatString->stringGetBASE(0);
	for (int _thisIndex = _offset; _thisIndex < _thisLength; _thisIndex++) {
		if (_thatValue == _thisString->stringGetBASE(_thisIndex)) {
			for (int _thatIndex = 1; _thatIndex < _thatLength; _thatIndex++) {
				if (!_thisString->stringGetBASE(_thisIndex + _thatIndex) == _thatString->stringGetBASE(_thatIndex)) {
					goto FIND;
				}
			}
			return _thisIndex;
		}
		FIND: ;
	}
	return -1;

}

bool FEMString::extract(PVOID _target, COLLECTOR _collector) const { // DONE
	FEMStringBASE* _thisString = femCast(this)->toPointerAndCastItsTarget->toStringBASE;
	return _thisString->stringExtractBASE(_target, _collector, 0, _thisString->stringLength, true);
}

INT32 FEMString::compare(FEMString const& _that) const { // DONE
	FEMStringBASE* _thisString = femCast(this)->toPointerAndCastItsTarget->toStringBASE;
	FEMStringBASE* _thatString = femCast(&_that)->toPointerAndCastItsTarget->toStringBASE;
	INT32 _thisLength = _thisString->stringLength;
	INT32 _thatLength = _thatString->stringLength;
	INT32 _length = _thisLength < _thatLength ? _thisLength : _thatLength;
	for (INT32 _index = 0; _index < _length; _index++) {
		UINT32 _thisValue = _thisString->stringGetBASE(_index);
		UINT32 _thatValue = _thatString->stringGetBASE(_index);
		INT32 _result = _thisValue - _thatValue;
		if (_result < 0) return -1;
		if (_result > 0) return +1;
	}
	INT32 _result = _thisLength - _thatLength;
	if (_result < 0) return -1;
	if (_result > 0) return +1;
	return 0;
}

FEMString::BYTES FEMString::toBytes() const { // DONE
	INT32 _length = 1;
	extract(&_length, FEMStringBYTES::stringUTF8Counter);
	BYTES _result(_length);
	UINT8* _cursor = _result.data();
	extract(&_cursor, FEMStringBYTES::stringUTF8Encoder);
	_cursor[0] = 0;
	return _result;
}

FEMString::CHARS FEMString::toChars() const { // DONE
	INT32 _length = 1;
	extract(&_length, FEMStringCHARS::stringUTF16Counter);
	CHARS _result(_length);
	UINT16* _cursor = _result.data();
	extract(&_cursor, FEMStringCHARS::stringUTF16Encoder);
	_cursor[0] = 0;
	return _result;
}

struct __________;

inline bool FEMStringBASE::functionHashEncoder(PVOID _context, UINT32 const _value) { // DONE
	SUCHash* _result = (SUCHash*) _context;
	_result->pushHash(_value);
	return true;
}

inline bool FEMStringBASE::functionScriptCounter(PVOID _context, UINT32 const _value) {
	INT32* _length = (INT32*) _context;
	switch (_value) {
		case '\"':
		case '\\':
		case '\r':
		case '\n':
		case '\t':
			_length[0] += 1;
	}
	return true;
}

inline bool FEMStringBASE::functionScriptEncoder(PVOID _context, UINT32 const _value) {
	UINT32** _cursor = (UINT32**) _context;
	UINT32* _buffer = _cursor[0];
	switch (_value) {
		case '\"':
			_buffer[0] = '\\';
			_buffer[1] = '\"';
			_cursor[0] = _buffer + 2;
			return true;
		case '\\':
			_buffer[0] = '\\';
			_buffer[1] = '\\';
			_cursor[0] = _buffer + 2;
			return true;
		case '\r':
			_buffer[0] = '\\';
			_buffer[1] = 'r';
			_cursor[0] = _buffer + 2;
			return true;
		case '\n':
			_buffer[0] = '\\';
			_buffer[1] = 'n';
			_cursor[0] = _buffer + 2;
			return true;
		case '\t':
			_buffer[0] = '\\';
			_buffer[1] = 't';
			_cursor[0] = _buffer + 2;
			return true;
		default:
			_buffer[0] = _value;
			_cursor[0] = _buffer + 1;
			return true;
	}
}

inline FEMStringBASE::FEMStringBASE(DATA_TYPE const _dataType, INT32 const _stringLength) // DONE
		: FEMValueBASE(_dataType), stringLength(_stringLength) {
}

inline UINT32 FEMStringBASE::stringGetBASE(INT32 const _index) const { // DONE
	switch (dataType) {
		case STRING_BYTES:
			return femCast(this)->toStringBYTES->stringGetBYTES(_index);
		case STRING_CHARS:
			return femCast(this)->toStringCHARS->stringGetCHARS(_index);
		case STRING_VALUE:
			return femCast(this)->toStringVALUE->stringGetVALUE(_index);
		case STRING_CONCAT:
			return femCast(this)->toStringCONCAT->stringGetCONCAT(_index);
		case STRING_SECTION:
			return femCast(this)->toStringSECTION->stringGetSECTION(_index);
		case STRING_REVERSE:
			return femCast(this)->toStringREVERSE->stringGetREVERSE(_index);
		case STRING_UNIFORM:
			return femCast(this)->toStringUNIFORM->stringGetUNIFORM(_index);
		case STRING_CUSTOM1:
			return femCast(this)->toStringCUSTOM1->stringGetCUSTOM1(_index);
		case STRING_CUSTOM2:
			return femCast(this)->toStringCUSTOM2->stringGetCUSTOM2(_index);
		case STRING_CUSTOM3:
			return femCast(this)->toStringCUSTOM3->stringGetCUSTOM3(_index);
		default:
			throw FEMException();
	}
}

inline bool FEMStringBASE::stringExtractBASE(PVOID _target, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	switch (dataType) {
		case STRING_BYTES:
			return femCast(this)->toStringBYTES->stringExtractBYTES(_target, _collector, _offset, _length, _foreward);
		case STRING_CHARS:
			return femCast(this)->toStringCHARS->stringExtractCHARS(_target, _collector, _offset, _length, _foreward);
		case STRING_VALUE:
			return femCast(this)->toStringVALUE->stringExtractVALUE(_target, _collector, _offset, _length, _foreward);
		case STRING_CONCAT:
			return femCast(this)->toStringCONCAT->stringExtractCONCAT(_target, _collector, _offset, _length, _foreward);
		case STRING_SECTION:
			return femCast(this)->toStringSECTION->stringExtractSECTION(_target, _collector, _offset, _length, _foreward);
		case STRING_REVERSE:
			return femCast(this)->toStringREVERSE->stringExtractREVERSE(_target, _collector, _offset, _length, _foreward);
		case STRING_UNIFORM:
			return femCast(this)->toStringUNIFORM->stringExtractUNIFORM(_target, _collector, _offset, _length, _foreward);
		case STRING_CUSTOM1:
			return femCast(this)->toStringCUSTOM1->stringExtractDEFAULT(_target, _collector, _offset, _length, _foreward);
		case STRING_CUSTOM2:
			return femCast(this)->toStringCUSTOM2->stringExtractDEFAULT(_target, _collector, _offset, _length, _foreward);
		case STRING_CUSTOM3:
			return femCast(this)->toStringCUSTOM3->stringExtractDEFAULT(_target, _collector, _offset, _length, _foreward);
		default:
			throw FEMException();
	}
}

inline bool FEMStringBASE::stringExtractDEFAULT(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const { // DONE
	if (_foreward) {
		for (_length += _offset; _offset < _length; _offset++) {
			if (!_collector(_context, stringGetBASE(_offset))) return false;
		}
	} else {
		for (_length += _offset - 1; _offset <= _length; _length--) {
			if (!_collector(_context, stringGetBASE(_length))) return false;
		}
	}
	return true;
}

inline FEMString FEMStringBASE::stringSectionBASE(INT32 const _offset, INT32 const _length) const { // DONE
	switch (dataType) {
		case STRING_BYTES:
			return femCast(this)->toStringBYTES->stringSectionDEFAULT(_offset, _length);
		case STRING_CHARS:
			return femCast(this)->toStringCHARS->stringSectionDEFAULT(_offset, _length);
		case STRING_VALUE:
			return femCast(this)->toStringVALUE->stringSectionDEFAULT(_offset, _length);
		case STRING_CONCAT:
			return femCast(this)->toStringCONCAT->stringSectionCONCAT(_offset, _length);
		case STRING_SECTION:
			return femCast(this)->toStringSECTION->stringSectionSECTION(_offset, _length);
		case STRING_REVERSE:
			return femCast(this)->toStringREVERSE->stringSectionREVERSE(_offset, _length);
		case STRING_UNIFORM:
			return femCast(this)->toStringUNIFORM->stringSectionUNIFORM(_offset, _length);
		case STRING_CUSTOM1:
			return femCast(this)->toStringCUSTOM1->stringSectionDEFAULT(_offset, _length);
		case STRING_CUSTOM2:
			return femCast(this)->toStringCUSTOM2->stringSectionDEFAULT(_offset, _length);
		case STRING_CUSTOM3:
			return femCast(this)->toStringCUSTOM3->stringSectionDEFAULT(_offset, _length);
		default:
			throw FEMException();
	}
}

inline FEMString FEMStringBASE::stringSectionDEFAULT(INT32 const _offset, INT32 const _length) const { // DONE
	FEMStringBASE const* _this = this;
	FEMStringSECTION* _result = new FEMStringSECTION(*femCast(&_this)->toString, _offset, _length);
	return FEMString(*femCast(&_result)->toString);
}

inline FEMString FEMStringBASE::stringCompactBASE() const { // DONE
	switch (dataType) {
		case STRING_BYTES:
			return femCast(this)->toStringBYTES->stringCompactDEFAULT();
		case STRING_CHARS:
			return femCast(this)->toStringCHARS->stringCompactDEFAULT();
		case STRING_VALUE:
			return femCast(this)->toStringVALUE->stringCompactVALUE();
		case STRING_CONCAT:
			return femCast(this)->toStringCONCAT->stringCompactDEFAULT();
		case STRING_SECTION:
			return femCast(this)->toStringSECTION->stringCompactDEFAULT();
		case STRING_REVERSE:
			return femCast(this)->toStringREVERSE->stringCompactDEFAULT();
		case STRING_UNIFORM:
			return femCast(this)->toStringUNIFORM->stringCompactUNIFORM();
		case STRING_CUSTOM1:
			return femCast(this)->toStringCUSTOM1->stringCompactDEFAULT();
		case STRING_CUSTOM2:
			return femCast(this)->toStringCUSTOM2->stringCompactDEFAULT();
		case STRING_CUSTOM3:
			return femCast(this)->toStringCUSTOM3->stringCompactDEFAULT();
		default:
			throw FEMException();
	}
}

inline FEMString FEMStringBASE::stringCompactDEFAULT() const { // DONE
	INT32 _itemCount = stringLength;
	if (!_itemCount) return FEMString::EMPTY;
	if (_itemCount == 1) return FEMString::from(stringGetBASE(0), 1);
	DELETE_ARRAY<UINT8> _deleteGuard(new UINT8[sizeof(FEMStringVALUE) + (_itemCount << 2) + 4]);
	FEMStringVALUE* _result = new (_deleteGuard.array()) FEMStringVALUE(_itemCount);
	UINT32* _cusror = _result->itemArray;
	stringExtractBASE(_cusror, FEMStringVALUE::stringUTF32Encoder, 0, _itemCount, true);
	_deleteGuard.cancel();
	return FEMString(*femCast(&_result)->toString);
}

inline FEMString FEMStringBASE::stringReverseBASE() const { // DONE
	switch (dataType) {
		case STRING_BYTES:
			return femCast(this)->toStringBYTES->stringReverseDEFAULT();
		case STRING_CHARS:
			return femCast(this)->toStringCHARS->stringReverseDEFAULT();
		case STRING_VALUE:
			return femCast(this)->toStringVALUE->stringReverseDEFAULT();
		case STRING_CONCAT:
			return femCast(this)->toStringCONCAT->stringReverseDEFAULT();
		case STRING_SECTION:
			return femCast(this)->toStringSECTION->stringReverseDEFAULT();
		case STRING_REVERSE:
			return femCast(this)->toStringREVERSE->stringReverseREVERSE();
		case STRING_UNIFORM:
			return femCast(this)->toStringUNIFORM->stringReverseUNIFORM();
		case STRING_CUSTOM1:
			return femCast(this)->toStringCUSTOM1->stringReverseDEFAULT();
		case STRING_CUSTOM2:
			return femCast(this)->toStringCUSTOM2->stringReverseDEFAULT();
		case STRING_CUSTOM3:
			return femCast(this)->toStringCUSTOM3->stringReverseDEFAULT();
		default:
			throw FEMException();
	}
}

inline FEMString FEMStringBASE::stringReverseDEFAULT() const { // DONE
	FEMStringBASE const* _this = this;
	FEMStringREVERSE* _result = new FEMStringREVERSE(*femCast(&_this)->toString);
	return FEMString(*femCast(&_result)->toString);
}

inline INT32 FEMStringBASE::functionHashSTRING() const { // DONE
	SUCHash _result;
	stringExtractBASE(&_result, functionHashEncoder, 0, stringLength, true);
	return _result;
}

inline FEMString FEMStringBASE::functionScriptSTRING() const { // DONE
	INT32 _thisLength = stringLength, _thatLength = _thisLength + 2;
	stringExtractBASE(&_thatLength, functionScriptCounter, 0, _thisLength, true);
	FEMStringVALUE* _result = new FEMStringVALUE(_thatLength);
	_result->itemArray[0] = '\"';
	_result->itemArray[_thatLength - 1] = '\"';
	stringExtractBASE(_result->itemArray + 1, functionScriptEncoder, 0, _thisLength, true);
	return FEMString(*femCast(&_result)->toString);
}

inline bool FEMStringBASE::functionEqualsSTRING(FEMStringBASE const& _that) const { // DONE
	INT32 _length = stringLength;
	if (_that.stringLength != _length) return false;
	for (INT32 _index = 0; _index < _length; _index++) {
		UINT32 _thisValue = stringGetBASE(_index);
		UINT32 _thatValue = _that.stringGetBASE(_index);
		if (_thisValue != _thatValue) return false;
	}
	return true;
}

struct __________;

inline UINT8 FEMStringBYTES::stringUTF8Size(UINT8 const _item) {
	switch ((_item >> 4) & 15) {
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
			return 1;
		case 12:
		case 13:
			return 2;
		case 14:
			return 3;
		case 15:
			return 4;
	}
	throw FEMException();
}

inline bool FEMStringBYTES::stringUTF8Header(UINT8 const _item) {
	return (_item & 192) != 128;
}

inline INT32 FEMStringBYTES::stringUTF8Length(UINT8 const* _itemArray, INT32 const _itemCount) {
	INT32 _result = 0;
	UINT8 const* _itemLimit = _itemArray + _itemCount;
	while (_itemArray < _itemLimit) {
		_result++;
		_itemArray += stringUTF8Size(_itemArray[0]);
	}
	if (_itemArray != _itemLimit) throw FEMException();
	return _result;
}

inline UINT32 FEMStringBYTES::stringUTF8Codepoint(UINT8 const* _itemArray) {
	switch ((_itemArray[0] >> 4) & 15) {
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
			return _itemArray[0] & 127;
		case 12:
		case 13:
			return ((_itemArray[0] & 31) << 6) | (_itemArray[1] & 63);
		case 14:
			return ((_itemArray[0] & 15) << 12) | ((_itemArray[1] & 63) << 6) | (_itemArray[2] & 63);
		case 15:
			return ((_itemArray[0] & 7) << 18) | ((_itemArray[1] & 63) << 12) | ((_itemArray[2] & 63) << 6) | (_itemArray[3] & 63);
	}
	throw FEMException();
}

inline bool FEMStringBYTES::stringUTF8Counter(PVOID _context, UINT32 const _value) { // DONE
	INT32* _length = (INT32*) _context;
	if (_value < 128) {
		_length[0] += 1;
	} else if (_value < 2048) {
		_length[0] += 2;
	} else if (_value < 65536) {
		_length[0] += 3;
	} else {
		_length[0] += 4;
	}
	return true;
}

inline bool FEMStringBYTES::stringUTF8Encoder(PVOID _context, UINT32 const _value) { // DONE
	UINT8** _cursor = (UINT8**) _context;
	UINT8* _buffer = _cursor[0];
	if (_value < 128) {
		_buffer[0] = (UINT8) _value;
		_cursor[0] = _buffer + 1;
	} else if (_value < 2048) {
		_buffer[0] = (UINT8) (192 | (_value >> 6));
		_buffer[1] = (UINT8) (128 | (_value & 63));
		_cursor[0] = _buffer + 2;
	} else if (_value < 65536) {
		_buffer[0] = (UINT8) (224 | (_value >> 12));
		_buffer[1] = (UINT8) (128 | ((_value >> 6) & 63));
		_buffer[2] = (UINT8) (128 | (_value & 63));
		_cursor[0] = _buffer + 3;
	} else {
		_buffer[0] = (UINT8) (240 | (_value >> 18));
		_buffer[1] = (UINT8) (128 | ((_value >> 12) & 63));
		_buffer[2] = (UINT8) (128 | ((_value >> 6) & 63));
		_buffer[3] = (UINT8) (128 | (_value & 63));
		_cursor[0] = _buffer + 4;
	}
	return true;
}

FEMStringBYTES::FEMStringBYTES(INT32 const _stringLength)
		: FEMStringBASE(STRING_BYTES, _stringLength) {
}

FEMStringBYTES::FEMStringBYTES(INT32 const _stringLength, UINT8 const* _itemArray, INT32 const _itemCount)
		: FEMStringBASE(STRING_BYTES, _stringLength) {
	memcpy(itemArray, _itemArray, _itemCount);
	itemArray[_itemCount] = 0;
}

UINT32 FEMStringBYTES::stringGetBYTES(INT32 _index) const {
	UINT8 const* _itemArray = itemArray;
	while (_index > 0) {
		_index--;
		_itemArray += stringUTF8Size(_itemArray[0]);
	}
	return stringUTF8Codepoint(_itemArray);
}

bool FEMStringBYTES::stringExtractBYTES(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const {
	UINT8 const* _itemArray = itemArray;
	if (_foreward) {
		while (_offset > 0) {
			_offset--;
			_itemArray += stringUTF8Size(_itemArray[0]);
		}
		while (_length > 0) {
			if (!_collector(_context, stringUTF8Codepoint(_itemArray))) return false;
			_length--;
			_itemArray += stringUTF8Size(_itemArray[0]);
		}
	} else {
		_offset += _length;
		while (_offset > 0) {
			_offset--;
			_itemArray += stringUTF8Size(_itemArray[0]);
		}
		while (_length > 0) {
			while (!stringUTF8Header(0[--_itemArray])) {
			}
			if (!_collector(_context, stringUTF8Codepoint(_itemArray))) return false;
			_length--;
		}
	}
	return true;
}

struct __________;

inline INT32 FEMStringCHARS::stringUTF16Size(UINT16 const _item) {
	UINT16 const _header = _item & 64512;
	if (_header == 55296) return 2;
	if (_header != 56320) return 1;
	throw FEMException();
}

inline bool FEMStringCHARS::stringUTF16Header(UINT16 const _item) {
	return (_item & 64512) != 56320;
}

inline INT32 FEMStringCHARS::stringUTF16Length(UINT16 const* _itemArray, INT32 const _itemCount) {
	INT32 _result = 0;
	UINT16 const* _itemLimit = _itemArray + _itemCount;
	while (_itemArray < _itemLimit) {
		_result++;
		_itemArray += stringUTF16Size(_itemArray[0]);
	}
	if (_itemArray != _itemLimit) throw FEMException();
	return _result;
}

inline UINT32 FEMStringCHARS::stringUTF16Codepoint(UINT16 const* _itemArray) {
	UINT16 const _item = _itemArray[0];
	UINT16 const _header = _item & 64512;
	if (_header == 55296) return (((_item & 1023) << 10) | (_itemArray[1] & 1023)) + 65536;
	if (_header != 56320) return _item;
	throw FEMException();
}

inline bool FEMStringCHARS::stringUTF16Counter(PVOID _context, UINT32 const _value) { // DONE
	INT32* _length = (INT32*) _context;
	if (_value < 65536) {
		_length[0] += 1;
	} else {
		_length[0] += 2;
	}
	return true;
}

inline bool FEMStringCHARS::stringUTF16Encoder(PVOID _context, UINT32 const _value) { // DONE
	UINT16** _cursor = (UINT16**) _context;
	UINT16* _buffer = _cursor[0];
	int _value2 = _value - 65536;
	if (_value2 < 0) {
		_buffer[0] = (UINT16) _value;
		_cursor[0] = _buffer + 1;
	} else {
		_buffer[0] = (UINT16) (55296 | (_value2 >> 10));
		_buffer[1] = (UINT16) (56320 | (_value2 & 1023));
		_cursor[0] = _buffer + 2;
	}
	return true;
}

FEMStringCHARS::FEMStringCHARS(INT32 const _stringLength, UINT16 const* _itemArray, INT32 const _itemCount)
		: FEMStringBASE(STRING_CHARS, _stringLength) {
	memcpy(itemArray, _itemArray, _itemCount << 1);
	itemArray[_itemCount] = 0;
}

UINT32 FEMStringCHARS::stringGetCHARS(INT32 _index) const {
	UINT16 const* _itemArray = itemArray;
	while (_index > 0) {
		_index--;
		_itemArray += stringUTF16Size(_itemArray[0]);
	}
	return stringUTF16Codepoint(_itemArray);
}

bool FEMStringCHARS::stringExtractCHARS(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const {
	UINT16 const* _itemArray = itemArray;
	if (_foreward) {
		while (_offset > 0) {
			_offset--;
			_itemArray += stringUTF16Size(_itemArray[0]);
		}
		while (_length > 0) {
			if (!_collector(_context, stringUTF16Codepoint(_itemArray))) return false;
			_length--;
			_itemArray += stringUTF16Size(_itemArray[0]);
		}
	} else {
		_offset += _length;
		while (_offset > 0) {
			_offset--;
			_itemArray += stringUTF16Size(_itemArray[0]);
		}
		while (_length > 0) {
			while (!stringUTF16Header(0[--_itemArray])) {
			}
			if (!_collector(_context, stringUTF16Codepoint(_itemArray))) return false;
			_length--;
		}
	}
	return true;
}

struct __________;

inline bool FEMStringVALUE::stringUTF32Encoder(PVOID _context, UINT32 const _value) { // DONE
	UINT32** _cursor = (UINT32**) _context;
	UINT32* _buffer = _cursor[0];
	_buffer[0] = _value;
	_cursor[0] = _buffer + 1;
	return true;
}

inline FEMStringVALUE::FEMStringVALUE(INT32 const _length)
		: FEMStringBASE(STRING_VALUE, _length) {
	itemArray[_length] = 0;
}

inline FEMStringVALUE::FEMStringVALUE(UINT32 const* _itemArray, INT32 const _itemCount)
		: FEMStringVALUE(_itemCount) {
	memcpy(itemArray, _itemArray, _itemCount << 2);
}

inline UINT32 FEMStringVALUE::stringGetVALUE(INT32 const _index) const {
	return itemArray[_index];
}

inline bool FEMStringVALUE::stringExtractVALUE(PVOID _context, FEMString::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const {
	if (_foreward) { // TODO faster
		for (_length += _offset; _offset < _length; _offset++) {
			if (!_collector(_context, itemArray[_offset])) return false;
		}
	} else {
		for (_length += _offset - 1; _offset <= _length; _length--) {
			if (!_collector(_context, itemArray[_length])) return false;
		}
	}
	return true;
}

inline FEMString FEMStringVALUE::stringCompactVALUE() const {
	FEMStringVALUE const* _result = this;
	return FEMString(*femCast(&_result)->toString);
}

struct __________;

inline FEMStringCONCAT::FEMStringCONCAT(INT32 const _stringLength, FEMString const& _string1, FEMString const& _string2)
		: FEMStringBASE(STRING_CONCAT, _stringLength), string1(_string1), string2(_string2) {
}

inline UINT32 FEMStringCONCAT::stringGetCONCAT(INT32 const _index) const {
	FEMStringBASE* _string1 = femCast(&string1)->toPointerAndCastItsTarget->toStringBASE;
	INT32 _index2 = _index - _string1->stringLength;
	if (_index2 < 0) return _string1->stringGetBASE(_index);
	FEMStringBASE* _string2 = femCast(&string2)->toPointerAndCastItsTarget->toStringBASE;
	return _string2->stringGetBASE(_index2);
}

inline bool FEMStringCONCAT::stringExtractCONCAT(PVOID _context, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const {
	FEMStringBASE* _string1 = femCast(&string1)->toPointerAndCastItsTarget->toStringBASE;
	FEMStringBASE* _string2 = femCast(&string2)->toPointerAndCastItsTarget->toStringBASE;
	INT32 _offset2 = _offset - _string1->stringLength, _length2 = _offset2 + _length;
	if (_offset2 >= 0) return _string2->stringExtractBASE(_context, _collector, _offset2, _length, _foreward);
	if (_length2 <= 0) return _string1->stringExtractBASE(_context, _collector, _offset, _length, _foreward);
	if (_foreward) {
		if (!_string1->stringExtractBASE(_context, _collector, _offset, -_offset2, true)) return false;
		return _string2->stringExtractBASE(_context, _collector, 0, _length2, true);
	} else {
		if (!_string2->stringExtractBASE(_context, _collector, 0, _length2, false)) return false;
		return _string1->stringExtractBASE(_context, _collector, _offset, -_offset2, false);
	}
}

inline FEMString FEMStringCONCAT::stringSectionCONCAT(INT32 const _offset, INT32 const _length) const {
	FEMStringBASE* _string1 = femCast(&string1)->toPointerAndCastItsTarget->toStringBASE;
	FEMStringBASE* _string2 = femCast(&string2)->toPointerAndCastItsTarget->toStringBASE;
	INT32 _offset2 = _offset - _string1->stringLength, _length2 = _offset2 + _length;
	if (_offset2 >= 0) return _string2->stringSectionBASE(_offset2, _length);
	if (_length2 <= 0) return _string1->stringSectionBASE(_offset, _length);
	return _string1->stringSectionBASE(_offset, -_offset2).concat(_string2->stringSectionBASE(0, _length2));
}

struct __________;

inline FEMStringSECTION::FEMStringSECTION(FEMString const& _string, INT32 const _offset, INT32 const _length)
		: FEMStringBASE(STRING_SECTION, _length), string(_string), offset(_offset) {
}

inline UINT32 FEMStringSECTION::stringGetSECTION(INT32 const _index) const { // DONE
	return femCast(&string)->toPointerAndCastItsTarget->toStringBASE->stringGetBASE(_index + offset);
}

inline bool FEMStringSECTION::stringExtractSECTION(PVOID _target, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	return femCast(&string)->toPointerAndCastItsTarget->toStringBASE->stringExtractBASE(_target, _collector, offset + _offset, _length, _foreward);
}

inline FEMString FEMStringSECTION::stringSectionSECTION(INT32 _offset, INT32 _length) const { // DONE
	return femCast(&string)->toPointerAndCastItsTarget->toStringBASE->stringSectionBASE(offset + _offset, _length);
}

struct __________;

inline FEMStringREVERSE::FEMStringREVERSE(FEMString const& _string)
		: FEMStringBASE(STRING_REVERSE, _string.length()), string(_string) {
}

inline UINT32 FEMStringREVERSE::stringGetREVERSE(INT32 const _index) const { // DONE
	return femCast(&string)->toPointerAndCastItsTarget->toStringBASE->stringGetBASE(stringLength - _index - 1);
}

inline bool FEMStringREVERSE::stringExtractREVERSE(PVOID _target, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	return femCast(&string)->toPointerAndCastItsTarget->toStringBASE->stringExtractBASE(_target, _collector, stringLength - _offset - _length, _length, !_foreward);
}

inline FEMString FEMStringREVERSE::stringSectionREVERSE(INT32 _offset, INT32 _length) const { // DONE
	return femCast(&string)->toPointerAndCastItsTarget->toStringBASE->stringSectionBASE(stringLength - _offset - _length, _length).reverse();
}

inline FEMString FEMStringREVERSE::stringReverseREVERSE() const { // DONE
	return string;
}

struct __________;

inline FEMStringUNIFORM::FEMStringUNIFORM(UINT32 const& _value, INT32 const _stringLength)
		: FEMStringBASE(STRING_UNIFORM, _stringLength), value(_value) {
}

inline UINT32 FEMStringUNIFORM::stringGetUNIFORM(INT32 const _index) const { // DONE
	return value;
}

inline bool FEMStringUNIFORM::stringExtractUNIFORM(PVOID _target, FEMString::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	for (INT32 i = _length; i > 0; --i) {
		if (!(*_collector)(_target, value)) return false;
	}
	return true;
}

inline FEMString FEMStringUNIFORM::stringSectionUNIFORM(INT32 const _offset, INT32 const _length) const { // DONE
	FEMStringUNIFORM* _result = new FEMStringUNIFORM(value, _length);
	return FEMString(*femCast(&_result)->toString);
}

inline FEMString FEMStringUNIFORM::stringCompactUNIFORM() const { // DONE
	FEMStringUNIFORM const* _result = this;
	return FEMString(*femCast(&_result)->toString);
}

inline FEMString FEMStringUNIFORM::stringReverseUNIFORM() const { // DONE
	FEMStringUNIFORM const* _result = this;
	return FEMString(*femCast(&_result)->toString);
}

struct __________;

inline FEMStringCUSTOM1::FEMStringCUSTOM1()
		: FEMStringBASE(STRING_CUSTOM1, 0) {
}

inline UINT32 FEMStringCUSTOM1::stringGetCUSTOM1(INT32 const _index) const {
	return 0;
}

struct __________;

inline FEMStringCUSTOM2::FEMStringCUSTOM2()
		: FEMStringBASE(STRING_CUSTOM2, 0) {
}

inline UINT32 FEMStringCUSTOM2::stringGetCUSTOM2(INT32 const _index) const {
	return 0;
}

struct __________;

inline FEMStringCUSTOM3::FEMStringCUSTOM3()
		: FEMStringBASE(STRING_CUSTOM3, 0) {
}

inline UINT32 FEMStringCUSTOM3::stringGetCUSTOM3(INT32 const _index) const {
	return 0;
}

struct __________;

inline bool FEMBinaryBASE::functionHashEncoder(PVOID _context, UINT8 const _value) { // DONE
	SUCHash* _result = (SUCHash*) _context;
	_result->pushHash(_value);
	return true;
}

inline UINT8 FEMBinaryBASE::functionScriptItem(UINT8 const _value) {
	return _value < 10 ? ('0' + _value) : ('A' - 10 + _value);
}

inline bool FEMBinaryBASE::functionScriptEncoder(PVOID _context, UINT8 const _value) {
	UINT8** _cursor = (UINT8**) _context;
	**_cursor = functionScriptItem((_value >> 4) & 15);
	++*_cursor;
	**_cursor = functionScriptItem((_value >> 0) & 15);
	++*_cursor;
	return true;
}

inline FEMBinaryBASE::FEMBinaryBASE(DATA_TYPE const _dataType, INT32 const _binaryLength) // DONE
		: FEMValueBASE(_dataType), binaryLength(_binaryLength) {
}

inline UINT32 FEMBinaryBASE::binaryGetBASE(INT32 const _index) const { // DONE
	switch (dataType) {
		case BINARY_VALUE:
			return femCast(this)->toBinaryVALUE->binaryGetVALUE(_index);
		case BINARY_CONCAT:
			return femCast(this)->toBinaryCONCAT->binaryGetCONCAT(_index);
		case BINARY_SECTION:
			return femCast(this)->toBinarySECTION->binaryGetSECTION(_index);
		case BINARY_REVERSE:
			return femCast(this)->toBinaryREVERSE->binaryGetREVERSE(_index);
		case BINARY_UNIFORM:
			return femCast(this)->toBinaryUNIFORM->binaryGetUNIFORM(_index);
		case BINARY_CUSTOM1:
			return femCast(this)->toBinaryCUSTOM1->binaryGetCUSTOM1(_index);
		case BINARY_CUSTOM2:
			return femCast(this)->toBinaryCUSTOM2->binaryGetCUSTOM2(_index);
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryCUSTOM3->binaryGetCUSTOM3(_index);
		default:
			throw FEMException();
	}
}

inline bool FEMBinaryBASE::binaryExtractBASE(PVOID _target, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	switch (dataType) {
		case BINARY_VALUE:
			return femCast(this)->toBinaryVALUE->binaryExtractVALUE(_target, _collector, _offset, _length, _foreward);
		case BINARY_CONCAT:
			return femCast(this)->toBinaryCONCAT->binaryExtractCONCAT(_target, _collector, _offset, _length, _foreward);
		case BINARY_SECTION:
			return femCast(this)->toBinarySECTION->binaryExtractSECTION(_target, _collector, _offset, _length, _foreward);
		case BINARY_REVERSE:
			return femCast(this)->toBinaryREVERSE->binaryExtractREVERSE(_target, _collector, _offset, _length, _foreward);
		case BINARY_UNIFORM:
			return femCast(this)->toBinaryUNIFORM->binaryExtractUNIFORM(_target, _collector, _offset, _length, _foreward);
		case BINARY_CUSTOM1:
			return femCast(this)->toBinaryCUSTOM1->binaryExtractDEFAULT(_target, _collector, _offset, _length, _foreward);
		case BINARY_CUSTOM2:
			return femCast(this)->toBinaryCUSTOM2->binaryExtractDEFAULT(_target, _collector, _offset, _length, _foreward);
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryCUSTOM3->binaryExtractDEFAULT(_target, _collector, _offset, _length, _foreward);
		default:
			throw FEMException();
	}
}

inline bool FEMBinaryBASE::binaryExtractDEFAULT(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const { // DONE
	if (_foreward) {
		for (_length += _offset; _offset < _length; _offset++) {
			if (!_collector(_context, binaryGetBASE(_offset))) return false;
		}
	} else {
		for (_length += _offset - 1; _offset <= _length; _length--) {
			if (!_collector(_context, binaryGetBASE(_length))) return false;
		}
	}
	return true;
}

inline FEMBinary FEMBinaryBASE::binarySectionBASE(INT32 const _offset, INT32 const _length) const { // DONE
	switch (dataType) {
		case BINARY_VALUE:
			return femCast(this)->toBinaryVALUE->binarySectionDEFAULT(_offset, _length);
		case BINARY_CONCAT:
			return femCast(this)->toBinaryCONCAT->binarySectionCONCAT(_offset, _length);
		case BINARY_SECTION:
			return femCast(this)->toBinarySECTION->binarySectionSECTION(_offset, _length);
		case BINARY_REVERSE:
			return femCast(this)->toBinaryREVERSE->binarySectionREVERSE(_offset, _length);
		case BINARY_UNIFORM:
			return femCast(this)->toBinaryUNIFORM->binarySectionUNIFORM(_offset, _length);
		case BINARY_CUSTOM1:
			return femCast(this)->toBinaryCUSTOM1->binarySectionDEFAULT(_offset, _length);
		case BINARY_CUSTOM2:
			return femCast(this)->toBinaryCUSTOM2->binarySectionDEFAULT(_offset, _length);
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryCUSTOM3->binarySectionDEFAULT(_offset, _length);
		default:
			throw FEMException();
	}
}

inline FEMBinary FEMBinaryBASE::binarySectionDEFAULT(INT32 const _offset, INT32 const _length) const { // DONE
	FEMBinaryBASE const* _this = this;
	FEMBinarySECTION* _result = new FEMBinarySECTION(*femCast(&_this)->toBinary, _offset, _length);
	return FEMBinary(*femCast(&_result)->toBinary);
}

inline FEMBinary FEMBinaryBASE::binaryCompactBASE() const { // DONE
	switch (dataType) {
		case BINARY_VALUE:
			return femCast(this)->toBinaryVALUE->binaryCompactVALUE();
		case BINARY_CONCAT:
			return femCast(this)->toBinaryCONCAT->binaryCompactDEFAULT();
		case BINARY_SECTION:
			return femCast(this)->toBinarySECTION->binaryCompactDEFAULT();
		case BINARY_REVERSE:
			return femCast(this)->toBinaryREVERSE->binaryCompactDEFAULT();
		case BINARY_UNIFORM:
			return femCast(this)->toBinaryUNIFORM->binaryCompactUNIFORM();
		case BINARY_CUSTOM1:
			return femCast(this)->toBinaryCUSTOM1->binaryCompactDEFAULT();
		case BINARY_CUSTOM2:
			return femCast(this)->toBinaryCUSTOM2->binaryCompactDEFAULT();
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryCUSTOM3->binaryCompactDEFAULT();
		default:
			throw FEMException();
	}
}

inline FEMBinary FEMBinaryBASE::binaryCompactDEFAULT() const { // DONE
	FEMBinaryBASE const* _this = this;
	return FEMBinary::from(femCast(&_this)->toBinary->value()); // TODO faster
}

inline FEMBinary FEMBinaryBASE::binaryReverseBASE() const { // DONE
	switch (dataType) {
		case BINARY_VALUE:
			return femCast(this)->toBinaryVALUE->binaryReverseDEFAULT();
		case BINARY_CONCAT:
			return femCast(this)->toBinaryCONCAT->binaryReverseDEFAULT();
		case BINARY_SECTION:
			return femCast(this)->toBinarySECTION->binaryReverseDEFAULT();
		case BINARY_REVERSE:
			return femCast(this)->toBinaryREVERSE->binaryReverseREVERSE();
		case BINARY_UNIFORM:
			return femCast(this)->toBinaryUNIFORM->binaryReverseUNIFORM();
		case BINARY_CUSTOM1:
			return femCast(this)->toBinaryCUSTOM1->binaryReverseDEFAULT();
		case BINARY_CUSTOM2:
			return femCast(this)->toBinaryCUSTOM2->binaryReverseDEFAULT();
		case BINARY_CUSTOM3:
			return femCast(this)->toBinaryCUSTOM3->binaryReverseDEFAULT();
		default:
			throw FEMException();
	}
}

inline FEMBinary FEMBinaryBASE::binaryReverseDEFAULT() const { // DONE
	FEMBinaryBASE const* _this = this;
	FEMBinaryREVERSE* _result = new FEMBinaryREVERSE(*femCast(&_this)->toBinary);
	return FEMBinary(*femCast(&_result)->toBinary);
}

inline INT32 FEMBinaryBASE::functionHashBINARY() const { // DONE
	SUCHash _result;
	binaryExtractBASE(&_result, functionHashEncoder, 0, binaryLength, true);
	return _result;
}

inline FEMString FEMBinaryBASE::functionScriptBINARY() const { // DONE
	INT32 _length = binaryLength;
	DELETE_ARRAY<UINT8> _deleteGuard(new UINT8[sizeof(FEMStringBYTES) + _length + 3]);
	FEMStringBYTES* _result = new (_deleteGuard.array()) FEMStringBYTES(_length);
	UINT8* _cursor = _result->itemArray;
	_cursor[0] = '0';
	_cursor[1] = 'x';
	_cursor += 2;
	binaryExtractBASE(&_cursor, functionScriptEncoder, 0, _length, true);
	_cursor[0] = 0;
	_deleteGuard.cancel();
	return FEMString(*femCast(&_result)->toString);
}

inline bool FEMBinaryBASE::functionEqualsBINARY(FEMBinaryBASE const& _that) const { // DONE
	INT32 _length = binaryLength;
	if (_that.binaryLength != _length) return false;
	for (INT32 _index = 0; _index < _length; _index++) {
		UINT32 _thisValue = binaryGetBASE(_index);
		UINT32 _thatValue = _that.binaryGetBASE(_index);
		if (_thisValue != _thatValue) return false;
	}
	return true;
}

struct __________;

inline FEMBinaryVALUE::FEMBinaryVALUE(INT32 const _length)
		: FEMBinaryBASE(BINARY_VALUE, _length) {
}

inline FEMBinaryVALUE::FEMBinaryVALUE(UINT32 const* _itemArray, INT32 const _itemCount)
		: FEMBinaryBASE(BINARY_VALUE, _itemCount) {
	memcpy(itemArray, _itemArray, _itemCount * sizeof(UINT32));
}

inline UINT32 FEMBinaryVALUE::binaryGetVALUE(INT32 const _index) const {
	return itemArray[_index];
}

inline bool FEMBinaryVALUE::binaryExtractVALUE(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 _offset, INT32 _length, bool const _foreward) const {
	if (_foreward) { // TODO faster
		for (_length += _offset; _offset < _length; _offset++) {
			if (!_collector(_context, itemArray[_offset])) return false;
		}
	} else {
		for (_length += _offset - 1; _offset <= _length; _length--) {
			if (!_collector(_context, itemArray[_length])) return false;
		}
	}
	return true;
}

inline FEMBinary FEMBinaryVALUE::binaryCompactVALUE() const {
	FEMBinaryVALUE const* _result = this;
	return FEMBinary(*femCast(&_result)->toBinary);
}

struct __________;

inline FEMBinaryCONCAT::FEMBinaryCONCAT(INT32 const _binaryLength, FEMBinary const& _binary1, FEMBinary const& _binary2)
		: FEMBinaryBASE(BINARY_CONCAT, _binaryLength), binary1(_binary1), binary2(_binary2) {
}

inline UINT32 FEMBinaryCONCAT::binaryGetCONCAT(INT32 const _index) const {
	FEMBinaryBASE* _binary1 = femCast(&binary1)->toPointerAndCastItsTarget->toBinaryBASE;
	INT32 _index2 = _index - _binary1->binaryLength;
	if (_index2 < 0) return _binary1->binaryGetBASE(_index);
	FEMBinaryBASE* _binary2 = femCast(&binary2)->toPointerAndCastItsTarget->toBinaryBASE;
	return _binary2->binaryGetBASE(_index2);
}

inline bool FEMBinaryCONCAT::binaryExtractCONCAT(PVOID _context, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const {
	FEMBinaryBASE* _binary1 = femCast(&binary1)->toPointerAndCastItsTarget->toBinaryBASE;
	FEMBinaryBASE* _binary2 = femCast(&binary2)->toPointerAndCastItsTarget->toBinaryBASE;
	INT32 _offset2 = _offset - _binary1->binaryLength, _length2 = _offset2 + _length;
	if (_offset2 >= 0) return _binary2->binaryExtractBASE(_context, _collector, _offset2, _length, _foreward);
	if (_length2 <= 0) return _binary1->binaryExtractBASE(_context, _collector, _offset, _length, _foreward);
	if (_foreward) {
		if (!_binary1->binaryExtractBASE(_context, _collector, _offset, -_offset2, true)) return false;
		return _binary2->binaryExtractBASE(_context, _collector, 0, _length2, true);
	} else {
		if (!_binary2->binaryExtractBASE(_context, _collector, 0, _length2, false)) return false;
		return _binary1->binaryExtractBASE(_context, _collector, _offset, -_offset2, false);
	}
}

inline FEMBinary FEMBinaryCONCAT::binarySectionCONCAT(INT32 const _offset, INT32 const _length) const {
	FEMBinaryBASE* _binary1 = femCast(&binary1)->toPointerAndCastItsTarget->toBinaryBASE;
	FEMBinaryBASE* _binary2 = femCast(&binary2)->toPointerAndCastItsTarget->toBinaryBASE;
	INT32 _offset2 = _offset - _binary1->binaryLength, _length2 = _offset2 + _length;
	if (_offset2 >= 0) return _binary2->binarySectionBASE(_offset2, _length);
	if (_length2 <= 0) return _binary1->binarySectionBASE(_offset, _length);
	return _binary1->binarySectionBASE(_offset, -_offset2).concat(_binary2->binarySectionBASE(0, _length2));
}

struct __________;

inline FEMBinarySECTION::FEMBinarySECTION(FEMBinary const& _binary, INT32 const _offset, INT32 const _length)
		: FEMBinaryBASE(BINARY_SECTION, _length), binary(_binary), offset(_offset) {
}

inline UINT32 FEMBinarySECTION::binaryGetSECTION(INT32 const _index) const { // DONE
	return femCast(&binary)->toPointerAndCastItsTarget->toBinaryBASE->binaryGetBASE(_index + offset);
}

inline bool FEMBinarySECTION::binaryExtractSECTION(PVOID _target, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	return femCast(&binary)->toPointerAndCastItsTarget->toBinaryBASE->binaryExtractBASE(_target, _collector, offset + _offset, _length, _foreward);
}

inline FEMBinary FEMBinarySECTION::binarySectionSECTION(INT32 _offset, INT32 _length) const { // DONE
	return femCast(&binary)->toPointerAndCastItsTarget->toBinaryBASE->binarySectionBASE(offset + _offset, _length);
}

struct __________;

inline FEMBinaryREVERSE::FEMBinaryREVERSE(FEMBinary const& _binary)
		: FEMBinaryBASE(BINARY_REVERSE, _binary.length()), binary(_binary) {
}

inline UINT32 FEMBinaryREVERSE::binaryGetREVERSE(INT32 const _index) const { // DONE
	return femCast(&binary)->toPointerAndCastItsTarget->toBinaryBASE->binaryGetBASE(binaryLength - _index - 1);
}

inline bool FEMBinaryREVERSE::binaryExtractREVERSE(PVOID _target, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	return femCast(&binary)->toPointerAndCastItsTarget->toBinaryBASE->binaryExtractBASE(_target, _collector, binaryLength - _offset - _length, _length, !_foreward);
}

inline FEMBinary FEMBinaryREVERSE::binarySectionREVERSE(INT32 _offset, INT32 _length) const { // DONE
	return femCast(&binary)->toPointerAndCastItsTarget->toBinaryBASE->binarySectionBASE(binaryLength - _offset - _length, _length).reverse();
}

inline FEMBinary FEMBinaryREVERSE::binaryReverseREVERSE() const { // DONE
	return binary;
}

struct __________;

inline FEMBinaryUNIFORM::FEMBinaryUNIFORM(UINT8 const _value, INT32 const _binaryLength)
		: FEMBinaryBASE(BINARY_UNIFORM, _binaryLength), value(_value) {
}

inline UINT32 FEMBinaryUNIFORM::binaryGetUNIFORM(INT32 const _index) const { // DONE
	return value;
}

inline bool FEMBinaryUNIFORM::binaryExtractUNIFORM(PVOID _target, FEMBinary::COLLECTOR _collector, INT32 const _offset, INT32 const _length, bool const _foreward) const { // DONE
	for (INT32 i = _length; i > 0; --i) {
		if (!(*_collector)(_target, value)) return false;
	}
	return true;
}

inline FEMBinary FEMBinaryUNIFORM::binarySectionUNIFORM(INT32 const _offset, INT32 const _length) const { // DONE
	FEMBinaryUNIFORM* _result = new FEMBinaryUNIFORM(value, _length);
	return FEMBinary(*femCast(&_result)->toBinary);
}

inline FEMBinary FEMBinaryUNIFORM::binaryCompactUNIFORM() const { // DONE
	FEMBinaryUNIFORM const* _result = this;
	return FEMBinary(*femCast(&_result)->toBinary);
}

inline FEMBinary FEMBinaryUNIFORM::binaryReverseUNIFORM() const { // DONE
	FEMBinaryUNIFORM const* _result = this;
	return FEMBinary(*femCast(&_result)->toBinary);
}

struct __________;

inline FEMBinaryCUSTOM1::FEMBinaryCUSTOM1()
		: FEMBinaryBASE(BINARY_CUSTOM1, 0) {
}

inline UINT32 FEMBinaryCUSTOM1::binaryGetCUSTOM1(INT32 const _index) const {
	return 0;
}

struct __________;

inline FEMBinaryCUSTOM2::FEMBinaryCUSTOM2()
		: FEMBinaryBASE(BINARY_CUSTOM2, 0) {
}

inline UINT32 FEMBinaryCUSTOM2::binaryGetCUSTOM2(INT32 const _index) const {
	return 0;
}

struct __________;

inline FEMBinaryCUSTOM3::FEMBinaryCUSTOM3()
		: FEMBinaryBASE(BINARY_CUSTOM3, 0) {
}

inline UINT32 FEMBinaryCUSTOM3::binaryGetCUSTOM3(INT32 const _index) const {
	return 0;
}

struct __________;

FEMObject FEMObject::from(INT64S const& _value) { // DONE
	return from(_value.asNE.getHI.asINT32, _value.asNE.getLO.asNE.getLO.asUINT16, _value.asNE.getLO.asNE.getHI.asUINT16);
}

FEMObject FEMObject::from(INT32 const _ref, INT32 const _type, INT32 const _owner) { // DONE
	FEMException::checkCount(_ref);
	FEMException::checkIndex(_type, 65536);
	FEMException::checkIndex(_owner, 65536);
	FEMObjectBASE* _result = new FEMObjectBASE(_ref, _type, _owner);
	return FEMObject(*femCast(&_result)->toObject);
}

FEMObject::FEMObject() // DONE
		: FEMObject(EMPTY) {
}

INT64 FEMObject::value() const { // DONE
	FEMObjectBASE const* _object = femCast(this)->toPointerAndCastItsTarget->toObjectBASE;
	return INT64S(INT32S(_object->typeValue, _object->ownerValue), _object->refValue).asINT64;
}

INT32 FEMObject::refValue() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toObjectBASE->refValue;
}

INT32 FEMObject::typeValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toObjectBASE->typeValue;
}

INT32 FEMObject::ownerValue() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toObjectBASE->ownerValue;
}

FEMObject FEMObject::withRef(INT32 const _ref) const { // DONE
	FEMObjectBASE const* _thisObject = femCast(this)->toPointerAndCastItsTarget->toObjectBASE;
	return from(_ref, _thisObject->typeValue, _thisObject->ownerValue);
}

FEMObject FEMObject::withType(INT32 const _type) const { // DONE
	FEMObjectBASE const* _thisObject = femCast(this)->toPointerAndCastItsTarget->toObjectBASE;
	return from(_thisObject->refValue, _type, _thisObject->ownerValue);
}

FEMObject FEMObject::withOwner(INT32 const _owner) const { // DONE
	FEMObjectBASE const* _thisObject = femCast(this)->toPointerAndCastItsTarget->toObjectBASE;
	return from(_thisObject->refValue, _thisObject->typeValue, _owner);
}

INT32 FEMObject::compare(FEMObject const& _that) const { // DONE
	FEMObjectBASE const* _thisObject = femCast(this)->toPointerAndCastItsTarget->toObjectBASE;
	FEMObjectBASE const* _thatObject = femCast(&_that)->toPointerAndCastItsTarget->toObjectBASE;
	INT32 _result = compareValue<INT32>(_thisObject->refValue, _thatObject->refValue);
	if (_result) return _result;
	_result = compareValue<UINT16>(_thisObject->ownerValue, _thatObject->ownerValue);
	if (_result) return _result;
	_result = compareValue<UINT16>(_thisObject->typeValue, _thatObject->typeValue);
	return _result;
}

struct __________;

inline FEMObjectBASE::FEMObjectBASE(INT32 const _refValue, UINT16 const _typeValue, UINT16 const _ownerValue) // DONE
		: FEMValueBASE(OBJECT_BASE), refValue(_refValue), typeValue(_typeValue), ownerValue(_ownerValue) {
}

inline INT32 FEMObjectBASE::functionHashOBJECT() const { // DONE
	return refValue ^ typeValue ^ ownerValue;
}

inline FEMString FEMObjectBASE::functionScriptOBJECT() const { // TODO
	return FEMString();
}

inline bool FEMObjectBASE::functionEqualsOBJECT(FEMObjectBASE const& _that) const { // DONE
	return (refValue == _that.refValue) && (typeValue == _that.typeValue) && (ownerValue == _that.ownerValue);
}

struct __________;

FEMHandler FEMHandler::from(FEMFunction const& _value) { // DONE
	PCVOID _this = new FEMHandlerBASE(_value);
	return FEMHandler(*femCast(&_this)->toPointerAndCastItsTarget->toHandler);
}

FEMHandler::FEMHandler() // DONE
		: FEMHandler(EMPTY) {
}
FEMFunction FEMHandler::value() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toHandlerBASE->handlerValue;
}

struct __________;

inline FEMHandlerBASE::FEMHandlerBASE(FEMFunction const& _handlerValue) // DONE
		: FEMValueBASE(HANDLER_BASE), handlerValue(_handlerValue) {
}

inline INT32 FEMHandlerBASE::functionHashHANDLER() const { // DONE
	return handlerValue.hash();
}

inline FEMString FEMHandlerBASE::functionScriptHANDLER() const { // DONE
	return SCRIPT_OPEN.concat(handlerValue.toScript()).concat(SCRIPT_CLOSE);
}

inline bool FEMHandlerBASE::functionEqualsHANDLER(FEMHandlerBASE const& _that) const { // DONE
	return handlerValue.equals(_that.handlerValue);
}

struct __________;

FEMInteger FEMInteger::from(INT64 const& _value) { // DONE
	return from(*femCast(&_value)->toINT64S);
}

FEMInteger FEMInteger::from(INT64S const& _value) { // DONE
	FEMIntegerBASE* _result = new FEMIntegerBASE(_value.asINT64);
	return FEMInteger(*femCast(&_result)->toInteger);
}

FEMInteger FEMInteger::from(FEMString const& _script) { // TODO
	return FEMInteger::EMPTY;
}

FEMInteger::FEMInteger() // DONE
		: FEMInteger(EMPTY) {
}

INT64 FEMInteger::value() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toIntegerBASE->value;
}

INT32 FEMInteger::compare(FEMInteger const& _that) const { // DONE
	INT64 _thisValue = value();
	INT64 _thatValue = _that.value();
	return _thisValue < _thatValue ? -1 : _thisValue > _thatValue ? +1 : 0;
}

struct __________;

inline FEMIntegerBASE::FEMIntegerBASE(INT64 const& _value) // DONE
		: FEMValueBASE(INTEGER_BASE), value(_value) {
}

inline INT32 FEMIntegerBASE::functionHashINTEGER() const { // DONE
	INT64S const* _value = femCast(&value)->toINT64S;
	return _value->asNE.getLO.asINT32 ^ _value->asNE.getHI.asINT32;
}

inline FEMString FEMIntegerBASE::functionScriptINTEGER() const { // TODO
	return FEMString::EMPTY;
}

inline bool FEMIntegerBASE::functionEqualsINTEGER(FEMIntegerBASE const& _that) const { // DONE
	return value == _that.value;
}

struct __________;

FEMDecimal FEMDecimal::from(double const& _value) { // DONE
	FEMDecimalBASE* _result = new FEMDecimalBASE(_value);
	return FEMDecimal(*femCast(&_result)->toDecimal);
}

FEMDecimal FEMDecimal::from(FEMString const& _script) { // TODO
	return EMPTY;
}

FEMDecimal::FEMDecimal() // DONE
		: FEMDecimal(EMPTY) {
}

double FEMDecimal::value() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toDecimalBASE->value;
}

INT32 FEMDecimal::compare(FEMDecimal const& _that) const { // DONE
	double _thisValue = value();
	double _thatValue = _that.value();
	return _thisValue < _thatValue ? -1 : _thisValue > _thatValue ? +1 : 0;
}

struct __________;

FEMDecimalBASE::FEMDecimalBASE(double const& _value) // DONE
		: FEMValueBASE(DECIMAL_BASE), value(_value) {
}

INT32 FEMDecimalBASE::functionHashDECIMAL() const { // DONE
	INT64S const* _value = femCast(&value)->toINT64S;
	return _value->asNE.getLO.asINT32 ^ _value->asNE.getHI.asINT32;
}

FEMString FEMDecimalBASE::functionScriptDECIMAL() const { // TODO
	return FEMString::EMPTY;
}

bool FEMDecimalBASE::functionEqualsDECIMAL(FEMDecimalBASE const& _that) const { // DONE
	return value == _that.value || ((value != value) && (_that.value != _that.value));
}

struct __________;

FEMBoolean FEMBoolean::from(bool const _value) { // DONE
	return _value ? TRUE : FALSE;
}

FEMBoolean FEMBoolean::from(FEMString const& _script) { // TODO
	return TRUE;
}

FEMBoolean::FEMBoolean() // DONE
		: FEMBoolean(FALSE) {
}

bool FEMBoolean::value() const { // DONE
	return femCast(this)->toPointerAndCastItsTarget->toValueBASE->dataType == FEMValueBASE::VALUE_TRUE;
}

FEMBoolean::operator bool() const {
	return value();
}

INT32 FEMBoolean::compare(FEMBoolean const& _that) const { // DONE
	bool _thisValue = value();
	bool _thatValue = _that.value();
	return _thisValue ? (_thatValue ? 0 : +1) : (_thatValue ? -1 : 0);
}

struct __________;

//
//static FEMDatetime now();
FEMDatetime FEMDatetime::from(INT64S const& _value) { // DONE
	FEMDatetimeBASE* _result = new FEMDatetimeBASE(_value);
	return FEMDatetime(*femCast(&_result)->toDatetime);
}

//static FEMDatetime from(INT64 const& _millis);
//static FEMDatetime from(FEMString const& _script);

FEMDatetime FEMDatetime::fromDate(INT32 const _calendarday) { // DÓNE
	return EMPTY.withDate(_calendarday);
}

FEMDatetime FEMDatetime::fromDate(INT32 const _year, INT32 const _month, INT32 const _date) { // DONE
	return EMPTY.withDate(_year, _month, _date);
}

FEMDatetime FEMDatetime::fromTime(INT32 const _daymillis) { // DONE
	return EMPTY.withTime(_daymillis);
}

FEMDatetime FEMDatetime::fromTime(INT32 const _hour, INT32 const _minute, INT32 const _second, INT32 const _millisecond) { // DONE
	return EMPTY.withTime(_hour, _minute, _second, _millisecond);
}

FEMDatetime FEMDatetime::fromZone(INT32 const _zone) { // DONE
	return EMPTY.withZone(_zone);
}

FEMDatetime FEMDatetime::fromZone(INT32 const _zoneHour, INT32 const _zoneMinute) { // DONE
	return EMPTY.withZone(_zoneHour, _zoneMinute);
}

bool FEMDatetime::leapOf(INT32 const _year) { // DONE
	FEMDatetimeBASE::_checkYear_(_year);
	return FEMDatetimeBASE::_leapOf_(_year);
}

INT32 FEMDatetime::lengthOf(INT32 const _month, INT32 const _year) { // DONE
	if (_year != 1582) return lengthOf(_month, leapOf(_year));
	if ((_month < 10) || (_month > 12)) throw FEMException();
	return FEMDatetimeBASE::_lengthOf_(_month, leapOf(_year));
}

INT32 FEMDatetime::lengthOf(INT32 const _month, bool _leap) { // DONE
	if ((_month < 1) || (_month > 12)) throw FEMException();
	return FEMDatetimeBASE::_lengthOf_(_month, _leap);
}

INT32 FEMDatetime::yeardayOf(INT32 const _calendarday) { // DONE
	FEMDatetimeBASE::_checkDate_(_calendarday);
	return FEMDatetimeBASE::_yeardayOf_(_calendarday);
}

INT32 FEMDatetime::weekdayOf(INT32 const _calendarday) { // DONE
	FEMDatetimeBASE::_checkDate_(_calendarday);
	return FEMDatetimeBASE::_weekdayOf_(_calendarday);
}

INT32 FEMDatetime::daymillisOf(INT32 const _hour, INT32 const _minute, INT32 const _second, INT32 const _millisecond) { // DONE
	FEMDatetimeBASE::_checkTime_(_hour, _minute, _second, _millisecond);
	return FEMDatetimeBASE::_daymillisOf_(_hour, _minute, _second, _millisecond);
}

INT32 FEMDatetime::calendardayOf(INT32 const _year, INT32 const _month, INT32 const _date) { // DONE
	FEMDatetimeBASE::_checkDate_(_year, _month, _date);
	return FEMDatetimeBASE::_calendardayOf_(_year, _month, _date);
}

FEMDatetime::FEMDatetime()
		: FEMDatetime(EMPTY) {
}

INT64 FEMDatetime::value() const {
	return femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE->value.asINT64;
}

INT32 FEMDatetime::yearValue() const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasDate()) throw FEMException();
	return _thisBase->_yearValue_();
}

INT32 FEMDatetime::dateValue() const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasDate()) throw FEMException();
	return _thisBase->_dateValue_();
}

INT32 FEMDatetime::monthValue() const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasDate()) throw FEMException();
	return _thisBase->_monthValue_();
}

INT32 FEMDatetime::hourValue() const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasTime()) throw FEMException();
	return _thisBase->_hourValue_();
}

INT32 FEMDatetime::minuteValue() const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasTime()) throw FEMException();
	return _thisBase->_minuteValue_();
}

INT32 FEMDatetime::secondValue() const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasTime()) throw FEMException();
	return _thisBase->_secondValue_();
}

INT32 FEMDatetime::millisecondValue() const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasTime()) throw FEMException();
	return _thisBase->_millisecondValue_();
}

INT32 FEMDatetime::zoneValue() const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasZone()) throw FEMException();
	return _thisBase->_zoneValue_();
}

bool FEMDatetime::hasDate() const {
	return femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE->hasDate();
}

bool FEMDatetime::hasTime() const {
	return femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE->hasTime();
}

bool FEMDatetime::hasZone() const {
	return femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE->hasZone();
}

INT32 FEMDatetime::yeardayValue() const {
	return yeardayOf(calendardayValue());
}

INT32 FEMDatetime::weekdayValue() const {
	return weekdayOf(calendardayValue());
}

INT32 FEMDatetime::daymillisValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE->_daymillisValue_();
}

INT32 FEMDatetime::calendardayValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE->_calendardayValue_();
}

FEMDatetime FEMDatetime::withDate(INT32 const _calendarday) const {
	FEMDatetimeBASE::_checkDate_(_calendarday);
	FEMDatetimeBASE* _result = new FEMDatetimeBASE(femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE->value);
	DELETE_VALUE<FEMDatetimeBASE> _delete(_result);
	_result->_withDate_(_calendarday);
	_delete.cancel();
	return FEMDatetime(*femCast(&_result)->toDatetime);
}

FEMDatetime FEMDatetime::withDate(INT32 const _year, INT32 const _month, INT32 const _date) const {
	FEMDatetimeBASE::_checkDate_(_year, _month, _date);
	FEMDatetimeBASE* _result = new FEMDatetimeBASE(femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE->value);
	DELETE_VALUE<FEMDatetimeBASE> _delete(_result);
	_result->_withDate_(_year, _month, _date);
	_delete.cancel();
	return FEMDatetime(*femCast(&_result)->toDatetime);
}

FEMDatetime FEMDatetime::withDate(FEMDatetime const& _datetime) const {
	FEMDatetimeBASE const* _thatBase = femCast(&_datetime)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thatBase->hasDate()) return withoutDate();
	return withDate(_thatBase->_yearValue_(), _thatBase->_monthValue_(), _thatBase->_dateValue_());
}

FEMDatetime FEMDatetime::withTime(INT32 const _daymillis) const {
	if ((_daymillis < 0) || (_daymillis > 86400000)) throw FEMException();
	FEMDatetimeBASE* _result = new FEMDatetimeBASE(femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE->value);
	DELETE_VALUE<FEMDatetimeBASE> _delete(_result);
	_result->_withTime_(_daymillis);
	_delete.cancel();
	return FEMDatetime(*femCast(&_result)->toDatetime);
}

FEMDatetime FEMDatetime::withTime(INT32 const _hour, INT32 const _minute, INT32 const _second, INT32 const _millisecond) const {
	FEMDatetimeBASE::_checkTime_(_hour, _minute, _second, _millisecond);
	FEMDatetimeBASE* _result = new FEMDatetimeBASE(femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE->value);
	DELETE_VALUE<FEMDatetimeBASE> _delete(_result);
	_result->_withTime_(_hour, _minute, _second, _millisecond);
	_delete.cancel();
	return FEMDatetime(*femCast(&_result)->toDatetime);
}

FEMDatetime FEMDatetime::withTime(FEMDatetime const& _datetime) const {
	FEMDatetimeBASE const* _that = femCast(&_datetime)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_that->hasTime()) return withoutTime();
	return withTime(_that->_hourValue_(), _that->_minuteValue_(), _that->_secondValue_(), _that->_millisecondValue_());
}

FEMDatetime FEMDatetime::withZone(INT32 const _zone) const {
	FEMDatetimeBASE::_checkZone_(_zone);
	FEMDatetimeBASE const* _this = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (_this->hasZone()) return moveZone(0, _zone - _this->_zoneValue_());
	FEMDatetimeBASE* _result = new FEMDatetimeBASE(_this->value);
	_result->_withZone_(_zone);
	return FEMDatetime(*femCast(&_result)->toDatetime);
}

FEMDatetime FEMDatetime::withZone(INT32 const _zoneHour, INT32 const _zoneMinute) const {
	if ((_zoneHour == -14) || (_zoneHour == 14)) {
		if (_zoneMinute != 0) throw FEMException();
	} else {
		if ((_zoneHour < -14) || (_zoneHour > 14)) throw FEMException();
		if ((_zoneMinute < 0) || (_zoneMinute > 59)) throw FEMException();
	}
	return withZone((_zoneHour * 60) + (_zoneHour < 0 ? -_zoneMinute : _zoneMinute));
}

FEMDatetime FEMDatetime::withZone(FEMDatetime const& _datetime) const {
	FEMDatetimeBASE const* _that = femCast(&_datetime)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_that->hasZone()) return withoutZone();
	return withZone(_that->_zoneValue_());
}

FEMDatetime FEMDatetime::withoutDate() const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasDate()) return *this;
	FEMDatetimeBASE* _result = new FEMDatetimeBASE(_thisBase->value);
	DELETE_VALUE<FEMDatetimeBASE> _delete(_result);
	_result->withoutDate();
	_delete.cancel();
	return FEMDatetime(*femCast(&_result)->toDatetime);
}

FEMDatetime FEMDatetime::withoutTime() const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasTime()) return *this;
	FEMDatetimeBASE* _result = new FEMDatetimeBASE(_thisBase->value);
	DELETE_VALUE<FEMDatetimeBASE> _delete(_result);
	_result->withoutTime();
	_delete.cancel();
	return FEMDatetime(*femCast(&_result)->toDatetime);
}

FEMDatetime FEMDatetime::withoutZone() const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasZone()) return *this;
	FEMDatetimeBASE* _result = new FEMDatetimeBASE(_thisBase->value);
	DELETE_VALUE<FEMDatetimeBASE> _delete(_result);
	_result->withoutZone();
	_delete.cancel();
	return FEMDatetime(*femCast(&_result)->toDatetime);
}

//FEMDatetimeFEMDatetime:: move(FEMDatetime const& _duration) const;
//FEMDatetime FEMDatetime::moveDate(INT32 const _years, INT32 const _months, INT32 const _days) const;
//FEMDatetime FEMDatetime::moveDate(FEMDatetime const& _duration) const;
//FEMDatetime FEMDatetime::moveTime(INT32 const _hours, INT32 const _minutes, INT32 const _seconds, INT32 const _milliseconds) const;
//FEMDatetime FEMDatetime::moveTime(INT32 const _hours, INT64 const& _minutes, INT64 const& _seconds, INT64 const& _milliseconds) const;
//FEMDatetime FEMDatetime::moveTime(FEMDatetime const& _duration) const;
FEMDatetime FEMDatetime::moveZone(INT32 const _hours, INT32 const _minutes) const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasZone()) throw FEMException();
	if ((_hours == 0) && (_minutes == 0)) return *this;
	if ((_hours < -28) || (_hours > 28)) throw FEMException();
	if ((_minutes < -1680) || (_minutes > 1680)) throw FEMException();
	FEMDatetimeBASE* _result = new FEMDatetimeBASE(_thisBase->value);
	DELETE_VALUE<FEMDatetimeBASE> _delete(_result);
	_result->_moveZone_((_hours * 60) + _minutes);
	_delete.cancel();
	return FEMDatetime(*femCast(&_result)->toDatetime);
}

FEMDatetime FEMDatetime::normalize() const {
	FEMDatetimeBASE const* _thisBase = femCast(this)->toPointerAndCastItsTarget->toDatetimeBASE;
	if (!_thisBase->hasDate() || !_thisBase->hasTime()) return *this;
	if ((_thisBase->_hourValue_() == 24) && (_thisBase->_yearValue_() == 9999) && (_thisBase->_monthValue_() == 12) && (_thisBase->_dateValue_() == 31)) return *this;
	FEMDatetimeBASE* _result = new FEMDatetimeBASE(_thisBase->value);
	DELETE_VALUE<FEMDatetimeBASE> _delete(_result);
	_result->_moveDate_(0, 1);
	_result->_withTime_(0, 0, 0, 0);
	_delete.cancel();
	return FEMDatetime(*femCast(&_result)->toDatetime);
}

//INT32 FEMDatetime::compare(FEMDatetime const& _that, INT32 const _undefined) const;

struct __________;

FEMDatetimeBASE::FEMDatetimeBASE(INT64S const& _value) // DONE
		: FEMValueBASE(DATETIME_BASE), value(_value) {
}

INT32 FEMDatetimeBASE::functionHashDATETIME() const { // DONE
	return value.asNE.getLO.asINT32 ^ value.asNE.getHI.asINT32;
}

FEMString FEMDatetimeBASE::functionScriptDATETIME() const { // TODO
	return FEMString();
}

bool FEMDatetimeBASE::functionEqualsDATETIME(FEMDatetimeBASE const& _that) const { // DONE
	if (value.asUINT64 == _that.value.asUINT64) return true;
	return compare(_that, 1) == 0;
}

struct __________;

FEMDuration FEMDuration::from(INT64S const& _value) {
	FEMDurationBASE* _result = new FEMDurationBASE(_value);
	return FEMDuration(*femCast(&_result)->toDuration);
}

FEMDuration FEMDuration::from(INT32 durationmonths, INT64 durationmillis) {
	FEMDurationBASE::checkMonths(+durationmonths);
	FEMDurationBASE::checkMonths(-durationmonths);
	FEMDurationBASE::checkMilliseconds(+durationmillis);
	FEMDurationBASE::checkMilliseconds(-durationmillis);
	INT32 negate = 0, years, months, days, hours, minutes, seconds, milliseconds;
	if (durationmillis < 0) {
		durationmonths = -durationmonths;
		durationmillis = -durationmillis;
		negate = 1;
	}
	// "durationmillis" auf "durationmonths" übertragen
	durationmonths += (INT32) (durationmillis / 12622780800000L) * 4800;
	durationmillis = durationmillis % 12622780800000L;
	// Vorzeichen prüfen
	if (durationmillis > 0) {
		FEMDurationBASE::checkPositive(durationmonths);
	} else if (durationmonths < 0) {
		negate ^= 1;
		durationmonths = -durationmonths;
	} else if (durationmonths == 0) return EMPTY;
	days = (int) (durationmillis / 86400000);
	milliseconds = (int) (durationmillis % 86400000);
	hours = milliseconds / 3600000;
	milliseconds = milliseconds % 3600000;
	minutes = milliseconds / 60000;
	milliseconds = milliseconds % 60000;
	seconds = milliseconds / 1000;
	milliseconds = milliseconds % 1000;
	months = durationmonths % 12;
	years = durationmonths / 12;
	FEMDurationBASE::checkYears(years);
	return from(INT64S( //
	        (years << 18) | (negate << 17) | (hours << 12) | (minutes << 6) | (seconds << 0), //
	        (days << 14) | (months << 10) | (milliseconds << 0)));
}

FEMDuration FEMDuration::from(INT32 const _years, INT32 const _months, INT32 const _days, INT32 const _hours, INT64 const _minutes, INT64 const _seconds, INT64 const _milliseconds) {
	return EMPTY.move(_years, _months, _days, _hours, _minutes, _seconds, _milliseconds);
}

FEMDuration FEMDuration::from(FEMString const& _script) {
	// TODO
	return EMPTY;
}

FEMDuration FEMDuration::between(FEMDatetime const& _datetime1, FEMDatetime const& _datetime2) {
	if (_datetime1.hasDate()) {
		if (!_datetime2.hasDate()) throw FEMException();
		if (_datetime1.hasTime()) {
			if (!_datetime2.hasTime()) throw FEMException();
			return from(0, 0, _datetime1.calendardayValue() - _datetime2.calendardayValue(), //
			0, _datetime2.zoneValue() - _datetime1.zoneValue(), 0, _datetime1.daymillisValue() - _datetime2.daymillisValue());
		} else {
			if (_datetime2.hasTime()) throw FEMException();
			return from(0, 0, _datetime1.calendardayValue() - _datetime2.calendardayValue(), //
			0, _datetime2.zoneValue() - _datetime1.zoneValue(), 0, 0);
		}
	} else {
		if (_datetime2.hasDate()) throw FEMException();
		if (_datetime1.hasTime()) {
			if (!_datetime2.hasTime()) throw FEMException();
			return from(0, 0, 0, 0, _datetime2.zoneValue() - _datetime1.zoneValue(), 0, _datetime1.daymillisValue() - _datetime2.daymillisValue());
		} else {
			if (_datetime2.hasTime()) throw FEMException();
			return from(0, 0, 0, 0, _datetime2.zoneValue() - _datetime1.zoneValue(), 0, 0);
		}
	}
}

INT32 FEMDuration::minLengthOf(INT32 const _months) {
	FEMDurationBASE::checkMonths(_months);
	FEMDurationBASE::checkPositive(_months);
	return FEMDurationBASE::lengthOf(_months) - ((FEMDurationBASE::rangeOf(_months) >> 0) & 0x0F);
}

INT32 FEMDuration::maxLengthOf(INT32 const _months) {
	FEMDurationBASE::checkMonths(_months);
	FEMDurationBASE::checkPositive(_months);
	return FEMDurationBASE::lengthOf(_months) + ((FEMDurationBASE::rangeOf(_months) >> 4) & 0x0F);
}

INT64 FEMDuration::durationmillisOf(INT32 const _days, INT32 const _hours, INT64 const _minutes, INT64 const _seconds, INT64 const _milliseconds) {
	FEMDurationBASE::checkDays(-_days);
	FEMDurationBASE::checkDays(+_days);
	FEMDurationBASE::checkHours(+_hours);
	FEMDurationBASE::checkHours(-_hours);
	FEMDurationBASE::checkMinutes(+_minutes);
	FEMDurationBASE::checkMinutes(-_minutes);
	FEMDurationBASE::checkSeconds(+_seconds);
	FEMDurationBASE::checkSeconds(-_seconds);
	INT64 _result = FEMDurationBASE::durationmillisOf(_days, _hours, _minutes, _seconds, _milliseconds);
	FEMDurationBASE::checkMilliseconds(+_result);
	FEMDurationBASE::checkMilliseconds(-_result);
	return _result;
}

INT32 FEMDuration::durationmonthsOf(INT32 const _years, INT32 const _months) {
	FEMDurationBASE::checkYears(+_years);
	FEMDurationBASE::checkYears(-_years);
	FEMDurationBASE::checkMonths(-_months);
	FEMDurationBASE::checkMonths(+_months);
	INT32 _result = FEMDurationBASE::durationmonthsOf(_years, _months);
	FEMDurationBASE::checkMonths(+_result);
	FEMDurationBASE::checkMonths(-_result);
	return _result;
}

FEMDuration::FEMDuration()
		: FEMDuration(EMPTY) {
}

INT64 FEMDuration::value() const {
	return femCast(this)->toPointerAndCastItsTarget->toDurationBASE->value.asINT64;
}

INT32 FEMDuration::signValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toDurationBASE->durationSignValue();
}

INT32 FEMDuration::yearsValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toDurationBASE->durationYearsValue();
}

INT32 FEMDuration::monthsValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toDurationBASE->durationMonthsValue();
}

INT32 FEMDuration::daysValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toDurationBASE->durationDaysValue();
}

INT32 FEMDuration::hoursValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toDurationBASE->durationHoursValue();
}

INT32 FEMDuration::minutesValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toDurationBASE->durationMinutesValue();
}

INT32 FEMDuration::secondsValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toDurationBASE->durationSecondsValue();
}

INT32 FEMDuration::millisecondsValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toDurationBASE->durationMillisecondsValue();
}

INT64 FEMDuration::durationmillisValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toDurationBASE->durationTotalmillisValue();
}

INT32 FEMDuration::durationmonthsValue() const {
	return femCast(this)->toPointerAndCastItsTarget->toDurationBASE->durationTotalmonthsValue();
}

FEMDuration FEMDuration::negate() const {
	if (signValue() == 0) return *this;
	INT64S const& _value = femCast(this)->toPointerAndCastItsTarget->toDurationBASE->value;
	return from(INT64S(_value.asNE.getLO.asUINT32, _value.asNE.getHI.asUINT32 ^ 0x020000));
}

FEMDuration FEMDuration::move(INT32 const _durationmonths, INT64 const _durationmillis) const {
	FEMDurationBASE::checkMonths(-_durationmonths);
	FEMDurationBASE::checkMonths(+_durationmonths);
	FEMDurationBASE::checkMilliseconds(+_durationmillis);
	FEMDurationBASE::checkMilliseconds(-_durationmillis);
	if (signValue() < 0) return from(_durationmonths - durationmonthsValue(), _durationmillis - durationmillisValue());
	return from(_durationmonths + durationmonthsValue(), _durationmillis + durationmillisValue());
}

FEMDuration FEMDuration::move(INT32 const _years, INT32 const _months, INT32 const _days, INT32 const _hours, INT64 const _minutes, INT64 const _seconds, INT64 const _milliseconds) const {
	return move(durationmonthsOf(_years, _months), durationmillisOf(_days, _hours, _minutes, _seconds, _milliseconds));
}

FEMDuration FEMDuration::move(FEMDuration const& _duration) const {
	if (_duration.signValue() < 0) return move(-_duration.durationmonthsValue(), -_duration.durationmillisValue());
	return move(_duration.durationmonthsValue(), _duration.durationmillisValue());
}

INT32 FEMDuration::compare(FEMDuration const& _that, INT32 const _undefined) const {
	int _thisSign = signValue(), _thatSign = _that.signValue();
	if (_thatSign > 0) return _thisSign > 0 ? FEMDurationBASE::compare(*this, _that, _undefined) : -1;
	if (_thatSign < 0) return _thisSign < 0 ? FEMDurationBASE::compare(_that, *this, _undefined) : +1;
	return _thisSign;
}

struct __________;

inline void FEMDurationBASE::checkDays(INT32 const _days) {
	if (_days > 3652424) throw FEMException();
}

inline void FEMDurationBASE::checkYears(INT32 const _years) {
	if (_years > 9999) throw FEMException();
}

inline void FEMDurationBASE::checkMonths(INT32 const _months) {
	if (_months > 119999) throw FEMException();
}

inline void FEMDurationBASE::checkHours(INT32 const _hours) {
	if (_hours > 87658199) throw FEMException();
}

inline void FEMDurationBASE::checkMinutes(INT64 const& _minutes) {
	if (_minutes > 5259491999L) throw FEMException();
}

inline void FEMDurationBASE::checkSeconds(INT64 const& _seconds) {
	if (_seconds > 315569519999L) throw FEMException();
}

inline void FEMDurationBASE::checkMilliseconds(INT64 const& _milliseconds) {
	if (_milliseconds > 315569519999999L) throw FEMException();
}

inline void FEMDurationBASE::checkPositive(INT32 const _value) {
	if (_value < 0) throw FEMException();
}

inline INT32 FEMDurationBASE::rangeOf(UINT32 const _months) {
	return ranges[_months % 4800];
}

inline INT32 FEMDurationBASE::lengthOf(UINT32 const _months) {
	return (_months * 146097) / 4800;
}

inline INT64 FEMDurationBASE::durationmillisOf(INT32 const _days, INT32 const _hours, INT64 const _minutes, INT64 const _seconds, INT64 const _milliseconds) {
	return (_days * 86400000L) + (_hours * 3600000L) + (_minutes * 60000L) + (_seconds * 1000L) + _milliseconds;
}

inline INT32 FEMDurationBASE::durationmonthsOf(INT32 const _years, INT32 const _months) {
	return (_years * 12) + _months;
}

inline INT32 FEMDurationBASE::compare(FEMDuration const& _this, FEMDuration const& _that, INT32 const _undefined) {
	INT32 thisMonths = _this.durationmonthsValue(), thatMonths = _that.durationmonthsValue();
	INT64 thisMillis = _this.durationmillisValue(), thatMillis = _that.durationmillisValue();
	if (thisMonths == thatMonths) return compareValue<INT64>(thisMillis, thatMillis);
	INT32 thisLength = FEMDurationBASE::lengthOf(thisMonths), thisRange = FEMDurationBASE::rangeOf(thisMonths);
	INT32 thatLength = FEMDurationBASE::lengthOf(thatMonths), thatRange = FEMDurationBASE::rangeOf(thatMonths);
	INT32 length = thisLength - thatLength;
	INT64 millis = thisMillis - thatMillis;
	INT64 _result;
	// 864e5 x thisMinLength + thisMillis > 864e5 x thatMaxLength + thatMillis => +1
	_result = millis + ((length - ((thisRange >> 0) & 0xF) - ((thatRange >> 4) & 0xF)) * 86400000L);
	if (_result > 0) return +1;
	// 864e5 x thisMaxLength + thisMillis < 864e5 x thatMinLength + thatMillis => -1
	_result = millis + ((length + ((thisRange >> 4) & 0xF) + ((thatRange >> 0) & 0xF)) * 86400000L);
	if (_result < 0) return -1;
	return _undefined;
}

inline FEMDurationBASE::FEMDurationBASE(INT64S const& _value) // DONE
		: FEMValueBASE(DURATION_BASE), value(_value) {
}

inline INT32 FEMDurationBASE::functionHashDURATION() const { // DONE
	return value.asNE.getLO.asUINT32 ^ value.asNE.getHI.asUINT32;
}

inline FEMString FEMDurationBASE::functionScriptDURATION() const { // TODO
	return FEMString();
}

inline bool FEMDurationBASE::functionEqualsDURATION(FEMDurationBASE const& _that) const { // DONE
	if (value.asUINT64 == _that.value.asUINT64) return true;
	FEMDurationBASE const* _thisBase = this;
	FEMDurationBASE const* _thatBase = &_that;
	return femCast(&_thisBase)->toDuration->compare(*femCast(&_thatBase)->toDuration, 1) == 0;
}

inline INT32 FEMDurationBASE::durationSignValue() const {
	if ((value.asNE.getLO.asUINT32 | value.asNE.getHI.asUINT32) == 0) return 0;
	return (value.asNE.getHI.asUINT32 & 0x020000) != 0 ? -1 : +1;
}

inline INT32 FEMDurationBASE::durationYearsValue() const {
	return (value.asNE.getHI.asUINT32 >> 18) & 0x3FFF;
}

inline INT32 FEMDurationBASE::durationMonthsValue() const {
	return (value.asNE.getLO.asUINT32 >> 10) & 0x0F;
}

inline INT32 FEMDurationBASE::durationDaysValue() const {
	return (value.asNE.getLO.asUINT32 >> 14) & 0x03FFFF;
}

inline INT32 FEMDurationBASE::durationHoursValue() const {
	return (value.asNE.getHI.asUINT32 >> 12) & 0x1F;
}

inline INT32 FEMDurationBASE::durationMinutesValue() const {
	return (value.asNE.getHI.asUINT32 >> 6) & 0x3F;
}

inline INT32 FEMDurationBASE::durationSecondsValue() const {
	return (value.asNE.getHI.asUINT32 >> 0) & 0x3F;
}

inline INT32 FEMDurationBASE::durationMillisecondsValue() const {
	return (value.asNE.getLO.asUINT32 >> 0) & 0x03FF;
}

inline INT64 FEMDurationBASE::durationTotalmillisValue() const {
	return durationmillisOf(durationDaysValue(), durationHoursValue(), durationMinutesValue(), durationSecondsValue(), durationMillisecondsValue());
}

inline INT32 FEMDurationBASE::durationTotalmonthsValue() const {
	return durationmonthsOf(durationYearsValue(), durationMonthsValue());
}

struct __________;

struct __________;

struct __________;

FEMProxy FEMProxy::from(FEMString const& _name) {
	PCVOID _this = new FEMFunctionPROXY(_name);
	return FEMProxy(*femCast(&_this)->toPointerAndCastItsTarget->toProxy);
}

struct I_____I;

FEMParam FEMParam::from(INT32 const _index) { // DONE
	SUCException::checkCount(_index);
	if (_index < FEMFunctionCACHE::INSTANCE.functionCount) return FEMParam(*femCast(FEMFunctionCACHE::INSTANCE.functionArray + _index)->toParam);
	FEMFunctionPARAM* _result = new FEMFunctionPARAM(_index);
	return FEMParam(*femCast(&_result)->toParam);
}

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct I_____I;

struct __________;

FEMContext::FEMContext()
		: _object_(femCast(new FEMContextBASE())->toContextOBJ) {
}

FEMFrame FEMContext::newFrame() { // DONE
	FEMFrameCONTEXT* _result = new FEMFrameCONTEXT(*this);
	return FEMFrame(*femCast(&_result)->toFrame);
}

FEMArray FEMContext::valueToArray(FEMValue const& _value) const { // TODO
	return FEMArray::EMPTY;
}

FEMString FEMContext::valueToString(FEMValue const& _value) const { // TODO
	return FEMString::EMPTY;
}

FEMBinary FEMContext::valueToBinary(FEMValue const& _value) const { // TODO
	return FEMBinary::EMPTY;
}

FEMObject FEMContext::valueToObject(FEMValue const& _value) const { // TODO
	return FEMObject::EMPTY;
}

FEMHandler FEMContext::valueToHandler(FEMValue const& _value) const { // TODO
	return FEMHandler::EMPTY;
}

FEMInteger FEMContext::valueToInteger(FEMValue const& _value) const { // TODO
	return FEMInteger::EMPTY;
}

FEMDecimal FEMContext::valueToDecimal(FEMValue const& _value) const { // TODO
	return FEMDecimal::EMPTY;
}

FEMBoolean FEMContext::valueToBoolean(FEMValue const& _value) const { // TODO
	return FEMBoolean::FALSE;
}

FEMDuration FEMContext::valueToDuration(FEMValue const& _value) const { // TODO
	return FEMDuration::EMPTY;
}

FEMDatetime FEMContext::valueToDatetime(FEMValue const& _value) const { // TODO
	return FEMDatetime::EMPTY;
}

struct __________;

FEMContextOBJ::~OBJECT() {
	femCast(this)->toContextBASE->~FEMContextBASE();
}

struct __________;

inline FEMContextBASE::FEMContextBASE() // DONE
		: cyclicSection(), cyclicList(*this) {
}

inline FEMContextBASE::~FEMContextBASE() { // DONE
	cyclicDelete();
}

inline void FEMContextBASE::cyclicDelete() { // DONE
	CSGuard _cyclicGuard = CSGuard(cyclicSection);
	FEMArrayCYCLIC* _list = &cyclicList;
	while (true) {
		FEMArrayCYCLIC* _next = _list->cyclicNext;
		if (_next == _list) return;
		_next->cyclicDelete();
	}
}

struct __________;

FEMException::FEMException()
		: _object_(femCast(new FEMExceptionBASE())->toExceptionOBJ) {
}

FEMValue& FEMException::value() {
	return femCast(this)->toPointerAndCastItsTarget->toExceptionBASE->value;
}

FEMContext& FEMException::context() {
	return femCast(this)->toPointerAndCastItsTarget->toExceptionBASE->context;
}

FEMValue::LISTING& FEMException::messages() {
	return femCast(this)->toPointerAndCastItsTarget->toExceptionBASE->messages;
}

FEMException& FEMException::putValue(FEMValue const& _value) {
	value() = _value;
	return *this;
}

FEMException& FEMException::putContext(FEMContext const& _context) {
	context() = _context;
	return *this;
}

FEMException& FEMException::putMessage(FEMString const& _message) {
	messages().add(_message);
	return *this;
}

struct __________;

FEMExceptionOBJ::~OBJECT() {
	femCast(this)->toExceptionBASE->~FEMExceptionBASE();
}

struct __________;

FEMFunctionCACHE FEMFunctionCACHE::INSTANCE = FEMFunctionCACHE();

FEMString const FEMFunctionPARAM::SCRIPT = FEMString::from("$");
FEMString const FEMFunctionFRAME::SCRIPT = FEMString::from("$");
FEMString const FEMFunctionINVOKE::SCRIPT_OPEN = FEMString::from("(");
FEMString const FEMFunctionINVOKE::SCRIPT_CLOSE = FEMString::from(")");
FEMString const FEMFunctionINVOKE::SCRIPT_COMMA = FEMString::from("; ");

FEMString const FEMValueVOID::SCRIPT = FEMString::from("undefined");
FEMString const FEMValueTRUE::SCRIPT = FEMString::from("true");
FEMString const FEMValueFALSE::SCRIPT = FEMString::from("false");

FEMString const FEMArrayBASE::SCRIPT_OPEN = FEMString::from("[");
FEMString const FEMArrayBASE::SCRIPT_CLOSE = FEMString::from("]");
FEMString const FEMArrayBASE::SCRIPT_COMMA = FEMString::from("; ");

FEMString const FEMHandlerBASE::SCRIPT_OPEN = FEMString::from("{:");
FEMString const FEMHandlerBASE::SCRIPT_CLOSE = FEMString::from("}");

FEMValueVOID const* FEMValueVOID::INSTANCE = new FEMValueVOID();
FEMVoid const FEMVoid::INSTANCE = FEMVoid(*femCast(&FEMValueVOID::INSTANCE)->toVoid);

FEMArrayBASE const* FEMArrayBASE::EMPTY = new FEMArrayUNIFORM(FEMVoid::INSTANCE, 0);
FEMArray const FEMArray::EMPTY = FEMArray(*femCast(&FEMArrayBASE::EMPTY)->toArray);

FEMStringBASE const* FEMStringBASE::EMPTY = new FEMStringUNIFORM(0, 0);
FEMString const FEMString::EMPTY = FEMString(*femCast(&FEMStringBASE::EMPTY)->toString);

FEMBinaryBASE const* FEMBinaryBASE::EMPTY = new FEMBinaryUNIFORM(0, 0);
FEMBinary const FEMBinary::EMPTY = FEMBinary(*femCast(&FEMBinaryBASE::EMPTY)->toBinary);

FEMObject const FEMObject::EMPTY = FEMObject::from(0, 0, 0);

FEMHandler const FEMHandler::EMPTY = FEMHandler::from(FEMVoid::INSTANCE);

FEMInteger const FEMInteger::EMPTY = FEMInteger::from(0);

FEMDecimal const FEMDecimal::EMPTY = FEMDecimal::from(0);

FEMValueTRUE const* FEMValueTRUE::INSTANCE = new FEMValueTRUE();
FEMValueFALSE const* FEMValueFALSE::INSTANCE = new FEMValueFALSE();
FEMBoolean const FEMBoolean::TRUE = FEMBoolean(*femCast(&FEMValueTRUE::INSTANCE)->toBoolean);
FEMBoolean const FEMBoolean::FALSE = FEMBoolean(*femCast(&FEMValueFALSE::INSTANCE)->toBoolean);

FEMDatetime const FEMDatetime::EMPTY = FEMDatetime::from(INT64S(0x40000000, 0x00));
FEMDatetime const FEMDatetime::MINIMUM = FEMDatetime::fromDate(1582, 10, 15).withTime(0, 0, 0, 0).withZone(14, 0);
FEMDatetime const FEMDatetime::MAXIMUM = FEMDatetime::fromDate(9999, 12, 31).withTime(24, 0, 0, 0).withZone(-14, 0);

FEMDuration const FEMDuration::EMPTY = FEMDuration::from(INT64S(0, 0));
FEMDuration const FEMDuration::MINIMUM = FEMDuration::from(-119999, -12622780799999L);
FEMDuration const FEMDuration::MAXIMUM = FEMDuration::from(119999, 12622780799999L);

FEMFunctionFRAME const* FEMFunctionFRAME::INSTANCE = new FEMFunctionFRAME();

FEMFunction const FEMParam::FRAME = FEMFunction(*femCast(&FEMFunctionFRAME::INSTANCE)->toFunction);

FEMContextBASE const* FEMContextBASE::EMPTY = new FEMContextBASE();
FEMFramePTR FEMFrameBASE::EMPTY = FEMFramePTR(femCast(new FEMFrameCYCLIC(*FEMContextBASE::EMPTY))->toFrameOBJ);

FEMContext const FEMContext::EMPTY = FEMContext(*femCast(&FEMContextBASE::EMPTY)->toContext);

UINT8 const FEMDurationBASE::ranges[4800] = { 0, 18, 33, 18, 33, 18, 33, 33, 33, 48, 33, 48, 16, 34, 34, 34, 49, 34, 49, 49, 49, 49, 49, 49, 16, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 16, 19, 34, 19, 34, 34, 34, 49,
        34, 49, 34, 49, 16, 19, 34, 19, 34, 19, 34, 34, 34, 49, 34, 49, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 50, 17, 35, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 17, 19, 34, 19, 34, 34, 34, 49, 34, 49, 34, 49, 16,
        19, 34, 19, 34, 19, 34, 49, 34, 49, 34, 49, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 35, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 17, 19, 34, 34, 34, 34, 34, 49, 34, 49, 34, 49, 16, 19, 34, 19, 34, 19,
        34, 49, 34, 49, 34, 49, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 35, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 17, 19, 34, 34, 34, 34, 34, 49, 34, 49, 34, 49, 16, 19, 34, 19, 34, 19, 34, 49, 34, 49, 34,
        49, 17, 35, 50, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 50, 17, 19, 34, 34, 34, 34, 34, 49, 34, 49, 49, 49, 16, 19, 34, 19, 34, 19, 34, 49, 34, 49, 34, 49, 17, 35, 50, 35,
        50, 35, 50, 50, 50, 50, 50, 65, 17, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 50, 17, 19, 34, 34, 34, 34, 34, 49, 34, 49, 49, 49, 16, 19, 34, 19, 34, 19, 34, 49, 34, 49, 34, 49, 17, 35, 50, 35, 50, 35, 50, 50, 50,
        65, 50, 65, 17, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 50, 17, 34, 34, 34, 34, 34, 34, 49, 34, 49, 49, 49, 16, 19, 34, 19, 34, 34, 34, 49, 34, 49, 34, 49, 17, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35,
        35, 35, 35, 35, 50, 50, 50, 50, 50, 50, 17, 34, 34, 34, 34, 34, 34, 49, 34, 49, 49, 49, 16, 19, 34, 19, 34, 34, 34, 49, 34, 49, 34, 49, 17, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50,
        50, 50, 50, 50, 50, 17, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 16, 19, 34, 19, 34, 34, 34, 49, 34, 49, 34, 49, 32, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 50,
        17, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 16, 19, 34, 19, 34, 34, 34, 49, 34, 49, 34, 49, 32, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 34, 34, 34, 34,
        34, 34, 49, 49, 49, 49, 49, 16, 19, 34, 34, 34, 34, 34, 49, 34, 49, 34, 49, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 34, 34, 34, 34, 34, 34, 49, 49, 49,
        49, 49, 16, 19, 34, 34, 34, 34, 34, 49, 34, 49, 34, 49, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 16, 19, 34,
        34, 34, 34, 34, 49, 34, 49, 49, 49, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 16, 19, 34, 34, 34, 34, 34, 49,
        34, 49, 49, 49, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 16, 34, 34, 34, 34, 34, 34, 49, 34, 49, 49, 49, 32,
        35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 16, 34, 34, 34, 34, 34, 34, 49, 34, 49, 49, 49, 32, 35, 50, 35, 50, 50,
        50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 34, 34, 34, 49, 34, 49, 49, 49, 49, 49, 49, 16, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50,
        65, 32, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 34, 34, 34, 49, 34, 49, 49, 49, 49, 49, 49, 16, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35,
        50, 35, 50, 50, 50, 65, 50, 65, 17, 34, 34, 34, 49, 34, 49, 49, 49, 49, 49, 64, 16, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50,
        65, 50, 65, 17, 34, 34, 34, 49, 34, 49, 49, 49, 49, 49, 64, 16, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 34,
        34, 34, 49, 34, 49, 49, 49, 49, 49, 64, 16, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 34, 49, 34, 49, 34, 49,
        49, 49, 49, 49, 64, 16, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 34, 49, 34, 49, 34, 49, 49, 49, 64, 49, 64,
        16, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 32, 50, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 17, 34, 49, 34, 49, 34, 49, 49, 49, 64, 49, 64, 16, 34, 34, 34, 34,
        34, 49, 49, 49, 49, 49, 49, 32, 50, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 17, 34, 49, 34, 49, 34, 49, 49, 49, 64, 49, 64, 16, 34, 34, 34, 49, 34, 49, 49, 49, 49,
        49, 49, 32, 50, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 50, 33, 51, 51,
        51, 51, 51, 51, 66, 66, 66, 66, 66, 33, 36, 51, 36, 51, 51, 51, 66, 51, 66, 51, 66, 33, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 65, 33, 51, 51, 51, 51, 51, 51, 66,
        66, 66, 66, 66, 33, 36, 51, 51, 51, 51, 51, 66, 51, 66, 51, 66, 33, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 65, 33, 51, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 33,
        36, 51, 51, 51, 51, 51, 66, 51, 66, 51, 66, 33, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 65, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 36, 51, 51, 51, 51,
        51, 66, 51, 66, 66, 66, 33, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 50, 50, 65, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 36, 51, 51, 51, 51, 51, 66, 51, 66, 66,
        66, 33, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 50, 50, 65, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 51, 51, 51, 51, 51, 51, 66, 51, 66, 66, 66, 33, 35, 50, 35,
        50, 50, 50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 51, 51, 51, 51, 51, 51, 66, 51, 66, 66, 66, 33, 35, 50, 35, 50, 50, 50, 65, 50,
        65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 51, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 33, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35,
        50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 33, 51, 51, 51, 66, 51, 66, 66, 66, 66, 66, 66, 33, 51, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 33, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50,
        50, 50, 65, 50, 65, 33, 51, 51, 51, 66, 51, 66, 66, 66, 66, 66, 81, 33, 51, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 33, 35, 50, 50, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65,
        33, 51, 51, 51, 66, 51, 66, 66, 66, 66, 66, 81, 33, 51, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 33, 35, 50, 50, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 33, 51, 51, 51, 66,
        51, 66, 66, 66, 66, 66, 81, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 35, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 33, 51, 66, 51, 66, 51, 66, 66, 66, 66,
        66, 81, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 35, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 33, 51, 66, 51, 66, 51, 66, 66, 66, 66, 66, 81, 33, 51, 51,
        51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 50, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 33, 51, 66, 51, 66, 51, 66, 66, 66, 81, 66, 81, 33, 51, 51, 51, 51, 51, 66, 66,
        66, 66, 66, 66, 33, 50, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 33, 51, 66, 51, 66, 51, 66, 66, 66, 81, 66, 81, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33,
        50, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 48, 51, 66, 51, 66, 51, 66, 66, 66, 81, 66, 81, 33, 51, 51, 51, 66, 51, 66, 66, 66, 66, 66, 66, 33, 50, 50, 50, 50, 50,
        50, 65, 65, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 48, 51, 66, 51, 66, 51, 66, 66, 66, 81, 66, 81, 33, 51, 51, 51, 66, 51, 66, 66, 66, 66, 66, 66, 33, 50, 50, 50, 50, 50, 50, 65, 65, 65, 65,
        65, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 50, 65, 48, 51, 66, 51, 66, 51, 66, 81, 66, 81, 66, 81, 33, 51, 51, 51, 66, 51, 66, 66, 66, 66, 66, 81, 33, 50, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 32, 35, 50, 50,
        50, 50, 50, 65, 50, 65, 50, 65, 48, 51, 66, 51, 66, 51, 66, 81, 66, 81, 66, 81, 33, 51, 51, 51, 66, 51, 66, 66, 66, 66, 66, 81, 33, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 65, 32, 35, 50, 50, 50, 50, 50, 65, 50,
        65, 65, 65, 48, 51, 66, 51, 66, 51, 66, 81, 66, 81, 66, 81, 33, 51, 66, 51, 66, 51, 66, 66, 66, 66, 66, 81, 33, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 65, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 48, 51,
        66, 51, 66, 51, 66, 81, 66, 81, 66, 81, 33, 51, 66, 51, 66, 51, 66, 66, 66, 66, 66, 81, 33, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 65, 32, 50, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 48, 51, 66, 51, 66, 66, 66,
        81, 66, 81, 66, 81, 33, 51, 66, 51, 66, 51, 66, 66, 66, 81, 66, 81, 33, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 65, 32, 50, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65,
        17, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 16, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50,
        35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 50, 17, 35, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 33, 36, 51, 36, 51, 51, 51, 66, 51, 66, 51, 66, 33, 36, 51, 36, 51, 36, 51, 51, 51, 66,
        51, 66, 18, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 50, 17, 35, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 33, 36, 51, 51, 51, 51, 51, 66, 51, 66, 51, 66, 33, 36, 51, 36, 51, 36, 51, 66, 51, 66, 51, 66, 18, 35, 35,
        35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 35, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 33, 36, 51, 51, 51, 51, 51, 66, 51, 66, 51, 66, 33, 36, 51, 36, 51, 36, 51, 66, 51, 66, 51, 66, 18, 35, 35, 35, 50, 35, 50, 50,
        50, 50, 50, 65, 17, 35, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 33, 36, 51, 51, 51, 51, 51, 66, 51, 66, 66, 66, 33, 36, 51, 36, 51, 36, 51, 66, 51, 66, 51, 66, 18, 35, 50, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17,
        35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 50, 33, 36, 51, 51, 51, 51, 51, 66, 51, 66, 66, 66, 33, 36, 51, 36, 51, 36, 51, 66, 51, 66, 51, 66, 18, 35, 50, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 35, 35, 35, 35, 35,
        50, 50, 50, 50, 50, 50, 33, 51, 51, 51, 51, 51, 51, 66, 51, 66, 66, 66, 33, 36, 51, 36, 51, 51, 51, 66, 51, 66, 51, 66, 18, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50,
        50, 33, 51, 51, 51, 51, 51, 51, 66, 51, 66, 66, 66, 33, 36, 51, 36, 51, 51, 51, 66, 51, 66, 51, 66, 18, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 50, 33, 51, 51, 51,
        51, 51, 51, 66, 66, 66, 66, 66, 33, 36, 51, 36, 51, 51, 51, 66, 51, 66, 51, 66, 33, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 50, 33, 51, 51, 51, 51, 51, 51, 66, 66,
        66, 66, 66, 33, 36, 51, 36, 51, 51, 51, 66, 51, 66, 51, 66, 33, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 50, 33, 51, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 33, 36,
        51, 51, 51, 51, 51, 66, 51, 66, 51, 66, 33, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 65, 33, 51, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 33, 36, 51, 51, 51, 51, 51,
        66, 51, 66, 51, 66, 33, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 65, 33, 51, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 33, 36, 51, 51, 51, 51, 51, 66, 51, 66, 66, 66,
        33, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 50, 50, 65, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 36, 51, 51, 51, 51, 51, 66, 51, 66, 66, 66, 33, 35, 50, 35, 50,
        35, 50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 50, 50, 65, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 36, 51, 51, 51, 51, 51, 66, 51, 66, 66, 66, 33, 35, 50, 35, 50, 50, 50, 65, 50, 65,
        50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 51, 51, 51, 51, 51, 51, 66, 51, 66, 66, 66, 33, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 17, 35, 50,
        35, 50, 35, 50, 50, 50, 65, 50, 65, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 51, 51, 51, 51, 51, 51, 66, 51, 66, 66, 66, 33, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 50,
        50, 65, 50, 65, 33, 51, 51, 51, 66, 51, 66, 66, 66, 66, 66, 66, 33, 51, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 33, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 33,
        51, 51, 51, 66, 51, 66, 66, 66, 66, 66, 66, 33, 51, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 33, 35, 50, 50, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 33, 51, 51, 51, 66, 51,
        66, 66, 66, 66, 66, 81, 33, 51, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 33, 35, 50, 50, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 33, 51, 51, 51, 66, 51, 66, 66, 66, 66, 66,
        81, 33, 51, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 33, 35, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 33, 51, 66, 51, 66, 51, 66, 66, 66, 66, 66, 81, 33, 51, 51, 51,
        51, 51, 66, 66, 66, 66, 66, 66, 33, 35, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 33, 51, 66, 51, 66, 51, 66, 66, 66, 66, 66, 81, 33, 51, 51, 51, 51, 51, 66, 66, 66,
        66, 66, 66, 33, 35, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 33, 51, 66, 51, 66, 51, 66, 66, 66, 81, 66, 81, 33, 51, 51, 51, 51, 51, 66, 66, 66, 66, 66, 66, 33, 50,
        50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 35, 35, 50, 50, 50, 50, 50, 50, 17, 34, 34, 34, 34, 34, 34,
        49, 34, 49, 49, 49, 16, 19, 34, 19, 34, 34, 34, 49, 34, 49, 34, 49, 32, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 50, 17, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49,
        16, 19, 34, 19, 34, 34, 34, 49, 34, 49, 34, 49, 32, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 50, 17, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 16, 19, 34, 19, 34,
        34, 34, 49, 34, 49, 34, 49, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 16, 19, 34, 34, 34, 34, 34, 49, 34, 49,
        34, 49, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 35, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 16, 19, 34, 34, 34, 34, 34, 49, 34, 49, 49, 49, 32, 35, 50,
        35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 16, 19, 34, 34, 34, 34, 34, 49, 34, 49, 49, 49, 32, 35, 50, 35, 50, 35, 50, 65,
        50, 65, 50, 65, 17, 35, 50, 35, 50, 35, 50, 50, 50, 50, 50, 65, 17, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 16, 19, 34, 34, 34, 34, 34, 49, 34, 49, 49, 49, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 17,
        35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 16, 34, 34, 34, 34, 34, 34, 49, 34, 49, 49, 49, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 17, 35, 50, 35, 50, 35,
        50, 50, 50, 65, 50, 65, 17, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 16, 34, 34, 34, 34, 34, 34, 49, 34, 49, 49, 49, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50,
        65, 17, 34, 34, 34, 49, 34, 49, 49, 49, 49, 49, 49, 16, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 50, 50, 65, 50, 65, 17, 34, 34, 34,
        49, 34, 49, 49, 49, 49, 49, 49, 16, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 34, 34, 34, 49, 34, 49, 49, 49,
        49, 49, 64, 16, 34, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 34, 34, 34, 49, 34, 49, 49, 49, 49, 49, 64, 16, 34,
        34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 50, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 34, 49, 34, 49, 34, 49, 49, 49, 49, 49, 64, 16, 34, 34, 34, 34, 34, 49,
        49, 49, 49, 49, 49, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 35, 50, 65, 50, 65, 50, 65, 17, 34, 49, 34, 49, 34, 49, 49, 49, 49, 49, 64, 16, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49,
        32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 17, 34, 49, 34, 49, 34, 49, 49, 49, 64, 49, 64, 16, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 32, 50, 50, 50, 50,
        50, 50, 65, 50, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 17, 34, 49, 34, 49, 34, 49, 49, 49, 64, 49, 64, 16, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 32, 50, 50, 50, 50, 50, 50, 65, 50, 65,
        65, 65, 32, 35, 50, 35, 50, 50, 50, 65, 50, 65, 50, 65, 32, 34, 49, 34, 49, 34, 49, 49, 49, 64, 49, 64, 16, 34, 34, 34, 49, 34, 49, 49, 49, 49, 49, 49, 32, 50, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 32, 35, 50,
        35, 50, 50, 50, 65, 50, 65, 50, 65, 32, 34, 49, 34, 49, 34, 49, 49, 49, 64, 49, 64, 16, 34, 34, 34, 49, 34, 49, 49, 49, 49, 49, 49, 32, 50, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 32, 35, 50, 35, 50, 50, 50, 65,
        50, 65, 50, 65, 32, 34, 49, 34, 49, 34, 49, 64, 49, 64, 49, 64, 16, 34, 34, 34, 49, 34, 49, 49, 49, 49, 49, 64, 32, 50, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 50, 65, 32,
        34, 49, 34, 49, 34, 49, 64, 49, 64, 49, 64, 16, 34, 34, 34, 49, 34, 49, 49, 49, 49, 49, 64, 32, 50, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 50, 65, 32, 34, 49, 34, 49, 34,
        49, 64, 49, 64, 49, 64, 16, 34, 49, 34, 49, 34, 49, 49, 49, 49, 49, 64, 32, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 65, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 34, 49, 34, 49, 34, 49, 64, 49, 64, 49,
        64, 16, 34, 49, 34, 49, 34, 49, 49, 49, 49, 49, 64, 32, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 65, 32, 35, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 34, 49, 34, 49, 34, 49, 64, 49, 64, 49, 64, 16, 34, 49, 34,
        49, 34, 49, 49, 49, 64, 49, 64, 32, 50, 50, 50, 50, 50, 65, 65, 65, 65, 65, 65, 32, 50, 50, 50, 50, 50, 50, 65, 50, 65, 65, 65, 32, 34, 49, 34, 49, 49, 49, 64, 49, 64, 49, 64, 16, 34, 49, 34, 49, 34, 49, 49, 49,
        64, 49, 64, 16, 34, 34, 34, 34, 34, 49, 49, 49, 49, 49, 49, 16, 34, 34, 34, 34, 34, 34, 49, 34, 49, 49, 49, 16, 18, 33, 18, 33, 33, 33, 48, 33, 48, 33, 48 };

}

}

}

