/* [cc-by] 2013 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#include "bee_creative_iam2.hpp"

namespace bee {

namespace creative {

namespace iam {

void __addAll(IAMArrayBuilder& _target, IAMArray const& _source) {
	if (_source.type() != 4) {
		INT32 _index = _target.length(), _length = _source.length();
		_target.insert(_index, _length);
		INT32* _value = &_target.get(_index);
		for (INT32 i; i < _length; i++) {
			_value[i] = _source.get(i);
		}
	} else {
		_target.addAll((INT32*) _source.data(), _source.length());
	}
}

void __addData(IAMArrayBuilder& _target, IAMListBuilder const& _source) {
	for (IAMListBuilder::CURSOR_CONST cur = _source.cursor(); cur; ++cur) {
		__addAll(_target, *cur);
	}
}

INT32 __addOffset(IAMArrayBuilder& _target, IAMListBuilder const& _source) {
	INT32 _result = 0;
	_target.add(_result);
	for (IAMListBuilder::CURSOR_CONST cur = _source.cursor(); cur; ++cur) {
		_result += cur->length();
		_target.add(_result);
	}
	return _result;
}

INT32 __rangeMask(INT32 const _entryCount) {
	INT32 _result = 2;
	while (_result < _entryCount) {
		_result = _result << 1;
	}
	return (_result - 1) & 536870911;
}

IAMArray IAMMapBuilder::build() const {
	IAMArrayBuilder _result;
	INT32 _entryCount = length(), _rangeMask = __rangeMask(_entryCount);
	SUCArray<INT32> _countArray(_rangeMask + 2);
	SUCVector<INT32> _indexArray(_entryCount);
	SUCVector<ENTRY_CONST*> _entryArray(_entryCount);
	IAMListBuilder _keyData, _valueData;
	_keyData.insert(0, _entryCount);
	_valueData.insert(0, _entryCount);
	for (SUCArray<INT32>::CURSOR cur = _countArray.cursor(); cur; ++cur) {
		*cur = 0;
	}
	for (CURSOR_CONST cur = cursor(); cur; ++cur) {
		ENTRY_CONST* _entry = &*cur;
		INT32 _index = _entry->key().hash() & _rangeMask;
		_entryArray.add(_entry);
		_indexArray.add(_index);
		++_countArray[_index];
	}
	{
		INT32 _count = 0;
		for (SUCArray<INT32>::CURSOR cur = _countArray.cursor(); cur; ++cur) {
			INT32 _value = *cur;
			*cur = _count;
			_count += _value;
		}
	}
	_result.allocate(3 + _countArray.length() + (_entryCount << 1));
	_result.add((INT32) 0xF00D13FF);
	_result.add(_entryCount);
	_result.add(_rangeMask);
	_result.addAll(_countArray);
	{
		INT32* _countCur = _countArray.data();
		SUCVector<INT32>::CURSOR _indexCur = _indexArray.cursor();
		SUCVector<ENTRY_CONST*>::CURSOR _entryCur = _entryArray.cursor();
		while (_entryCur) {
			INT32* _count = _countCur + *_indexCur;
			INT32 _offset = *_count;
			ENTRY_CONST* _entry = *_entryCur;
			_keyData[_offset] = _entry->key();
			_valueData[_offset] = _entry->value();
			*_count = _offset + 1;
			++_indexCur;
			++_entryCur;
		}
	}
	INT32 _keyOfset = __addOffset(_result, _keyData);
	_result.allocate(_result.capacity() + _keyOfset);
	__addData(_result, _keyData);
	INT32 _valueOfset = __addOffset(_result, _valueData);
	_result.allocate(_result.capacity() + _valueOfset);
	__addData(_result, _valueData);
	return _result.build();
}

IAMArray IAMListBuilder::build() const {
	IAMArrayBuilder _result;
	INT32 _itemCount = length();
	_result.allocate(_itemCount + 3);
	_result.add((INT32) 0xF00D200F);
	_result.add((INT32) _itemCount);
	INT32 _itemOffset = __addOffset(_result, *this);
	_result.allocate(_result.capacity() + _itemOffset);
	__addData(_result, *this);
	return _result.build();
}

IAMArray IAMArrayBuilder::build() const {
	IAMArray _result(data(), length(), true);
	return _result;
}

IAMArray IAMIndexBuilder::build() const {
	INT32 _mapCount = __maps.length();
	IAMListBuilder _mapData;
	_mapData.allocate(_mapCount);
	for (MAP_VECTOR::CURSOR_CONST cur = __maps.cursor(); cur; ++cur) {
		_mapData.add(cur->build());
	}
	INT32 _listCount = __lists.length();
	IAMListBuilder _listData;
	_listData.allocate(_listCount);
	for (LIST_VECTOR::CURSOR_CONST cur = __lists.cursor(); cur; ++cur) {
		_listData.add(cur->build());
	}
	IAMArrayBuilder _result;
	_result.allocate(5 + _mapCount + _listCount);
	_result.add((INT32) 0xF00DBA5E);
	_result.add(_mapCount);
	_result.add(_listCount);
	INT32 _mapOffset = __addOffset(_result, _mapData);
	INT32 _listOffset = __addOffset(_result, _listData);
	_result.allocate(_result.capacity() + _mapOffset + _listOffset);
	__addData(_result, _mapData);
	__addData(_result, _listData);
	return _result.build();
}

}

}

}
