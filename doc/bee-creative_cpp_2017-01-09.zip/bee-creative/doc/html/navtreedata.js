var NAVTREE =
[
  [ "bee-creative", "index.html", [
    [ "Namensbereiche", null, [
      [ "Liste aller Namensbereiche", "namespaces.html", "namespaces" ],
      [ "Elemente eines Namensbereiches", "namespacemembers.html", [
        [ "Alle", "namespacemembers.html", null ],
        [ "Funktionen", "namespacemembers_func.html", null ]
      ] ]
    ] ],
    [ "Klassen", null, [
      [ "Auflistung der Klassen", "annotated.html", "annotated" ],
      [ "Klassen-Verzeichnis", "classes.html", null ],
      [ "Klassenhierarchie", "hierarchy.html", "hierarchy" ],
      [ "Klassen-Elemente", "functions.html", [
        [ "Alle", "functions.html", "functions_dup" ],
        [ "Funktionen", "functions_func.html", "functions_func" ],
        [ "Variablen", "functions_vars.html", null ],
        [ "Typdefinitionen", "functions_type.html", null ],
        [ "Aufzählungen", "functions_enum.html", null ]
      ] ]
    ] ],
    [ "Dateien", null, [
      [ "Auflistung der Dateien", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"structbee_1_1creative_1_1fem_1_1_f_e_m_function_c_o_n_c_a_t.html#ab072f358dede6c3f4ddb86ab7172f188",
"structbee_1_1creative_1_1suc_1_1_s_u_c_iterator_1_1_i_t_e_r_a_t_o_r___r_e_v_e_r_s_e.html#a9abe3842a0b171007549e92c5917299b"
];

var SYNCONMSG = 'Klicken um Panelsynchronisation auszuschalten';
var SYNCOFFMSG = 'Klicken um Panelsynchronisation einzuschalten';