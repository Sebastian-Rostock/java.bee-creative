var structbee_1_1creative_1_1suc_1_1_s_u_c_exception =
[
    [ "SUCException", "structbee_1_1creative_1_1suc_1_1_s_u_c_exception.html#a3159f9e093f6472958850043b9781732", null ],
    [ "checkIndex", "structbee_1_1creative_1_1suc_1_1_s_u_c_exception.html#a64e813ed0c09206e6476c8ec10785a20", null ],
    [ "code", "structbee_1_1creative_1_1suc_1_1_s_u_c_exception.html#a6f895fdb1a2046ccd2f98fb9b65d868a", null ],
    [ "_code_", "structbee_1_1creative_1_1suc_1_1_s_u_c_exception.html#a6342d9639281ffb3289be73250bdc893", null ],
    [ "ILLEGAL_ALIGN", "structbee_1_1creative_1_1suc_1_1_s_u_c_exception.html#ab45f3b6eaf1a11fc0fa45b0d7f6aeea9", null ],
    [ "ILLEGAL_COUNT", "structbee_1_1creative_1_1suc_1_1_s_u_c_exception.html#ab4cc8cfe933f9fc8ceb1496e03ae8d49", null ],
    [ "ILLEGAL_INDEX", "structbee_1_1creative_1_1suc_1_1_s_u_c_exception.html#a5cf02c55e64734824cad23be3e0a1172", null ],
    [ "ILLEGAL_STATE", "structbee_1_1creative_1_1suc_1_1_s_u_c_exception.html#a937656eebc35a80fc54bb2533c61ff6f", null ]
];