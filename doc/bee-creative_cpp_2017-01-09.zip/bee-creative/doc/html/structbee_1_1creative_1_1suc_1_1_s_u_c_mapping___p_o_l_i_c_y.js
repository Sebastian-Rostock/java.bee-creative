var structbee_1_1creative_1_1suc_1_1_s_u_c_mapping___p_o_l_i_c_y =
[
    [ "INDEX_POLICY", "structbee_1_1creative_1_1suc_1_1_s_u_c_mapping___p_o_l_i_c_y.html#a47038bfb825464219b232cf47c8c1b10", null ],
    [ "LEVEL_POLICY", "structbee_1_1creative_1_1suc_1_1_s_u_c_mapping___p_o_l_i_c_y.html#a398a98502528e37271621ab7fbe28da1", null ],
    [ "CACHE_ENABLED", "structbee_1_1creative_1_1suc_1_1_s_u_c_mapping___p_o_l_i_c_y.html#a529be62a11d4788c15ae3b80b5b0d0f3", null ],
    [ "HASH_ENABLED", "structbee_1_1creative_1_1suc_1_1_s_u_c_mapping___p_o_l_i_c_y.html#aab34bc0a6b9a55e23aa9f0d0e6e1b715", null ],
    [ "TREE_ENABLED", "structbee_1_1creative_1_1suc_1_1_s_u_c_mapping___p_o_l_i_c_y.html#a2b3770efbd85d4aceb8d1e276e357c8f", null ]
];