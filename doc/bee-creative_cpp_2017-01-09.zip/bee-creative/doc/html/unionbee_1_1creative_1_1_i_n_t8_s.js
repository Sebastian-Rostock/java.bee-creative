var unionbee_1_1creative_1_1_i_n_t8_s =
[
    [ "INT8S", "unionbee_1_1creative_1_1_i_n_t8_s.html#a2a6fe214f70179eb8afcfe6aa43e3b86", null ],
    [ "asINT8", "unionbee_1_1creative_1_1_i_n_t8_s.html#a0475f1b7028213b7df2cb09477db1c96", null ],
    [ "asUINT8", "unionbee_1_1creative_1_1_i_n_t8_s.html#a25345f7f2fb5613ff22c1d7deeff082e", null ]
];