package bee.creative.app.ft;

import java.awt.Component;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class FTTextOption {

	public String val;

	public FTTextOption(final String val) {
		this.val = val;
	}

	@Override
	public String toString() {
		return String.valueOf(this.val);
	}

	Component toControl() {
		final JTextField res = new JTextField(this.val);
		res.getDocument().addDocumentListener(new DocumentListener() {

			@Override
			public void removeUpdate(final DocumentEvent event) {
				FTTextOption.this.val = res.getText();
			}

			@Override
			public void insertUpdate(final DocumentEvent event) {
				FTTextOption.this.val = res.getText();
			}

			@Override
			public void changedUpdate(final DocumentEvent event) {
			}

		});
		return res;
	}

}