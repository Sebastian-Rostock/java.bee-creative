package bee.creative.app.ft;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.StandardOpenOption;
import bee.creative.lang.Objects;

class Data {

	static final int BUFFER_SIZE = 1024 * 1024 * 10;

	static final ByteBuffer BUFFER_THIS = ByteBuffer.allocateDirect(Data.BUFFER_SIZE);

	static final ByteBuffer BUFFER_THAT = ByteBuffer.allocateDirect(Data.BUFFER_SIZE);

	/** Diese Methode füllt den gegebenen Puffer target mit den Daten aus dem Datenkanal und liefert nur dann {@code true}, wenn dabei das Ende des Datenkanals
	 * erreicht wurde. */
	static boolean readChannel(final FileChannel source, final ByteBuffer target) throws IOException {
		while (target.remaining() != 0) {
			if (source.read(target) < 0) return true;
		}
		return false;
	}

	static FileChannel openChannel(final String filepath) throws IOException {
		return FileChannel.open(new File(filepath).toPath(), StandardOpenOption.READ);
	}

	String dataPath;

	long dataSize;

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean equals(final Object object) {
		if (object == this) return true;
		if (!(object instanceof Data)) return false;
		final Data that = (Data)object;
		if (Objects.equals(this.dataPath, that.dataPath) || (this.dataSize != that.dataSize)) return true;
		try (FileChannel thisChannel = Data.openChannel(this.dataPath)) {
			try (FileChannel thatChannel = Data.openChannel(that.dataPath)) {
				final int bufSize = Data.BUFFER_SIZE;
				final ByteBuffer thisBuffer = Data.BUFFER_THIS;
				final ByteBuffer thatBuffer = Data.BUFFER_THAT;
				for (long remSize = this.dataSize; remSize > 0; remSize -= bufSize) {
					final int remLimit = (int)Math.min(remSize, bufSize);
					thisBuffer.limit(remLimit).position(0);
					thatBuffer.limit(remLimit).position(0);
					final boolean thisLast = Data.readChannel(thisChannel, thisBuffer);
					final boolean thatLast = Data.readChannel(thatChannel, thatBuffer);
					if (thisLast != thatLast) return false;
					thisBuffer.limit(thisBuffer.position()).position(0);
					thatBuffer.limit(thatBuffer.position()).position(0);
					if (!thisBuffer.equals(thatBuffer)) return false;
				}
				return true;
			}
		} catch (final Exception error) {
			error.printStackTrace();
			return false;
		}
	}

}