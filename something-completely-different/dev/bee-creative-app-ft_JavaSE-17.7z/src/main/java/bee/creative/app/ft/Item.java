package bee.creative.app.ft;

import java.io.File;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import bee.creative.fem.FEMBinary;

class Item {

	String sourcePath;

	Long sourceSize;

	Object sourceHash;

	Object sourceData;

	Item previousItem;

	Item(final String sourcePath) {
		this.sourcePath = sourcePath;
	}

	void computeSize() {
		try {
			this.sourceSize = new File(this.sourcePath).length();
		} catch (final Exception error) {
			error.printStackTrace();
			this.sourceSize = null;
		}
	}

	void computeHash(final long hashSize, final ByteBuffer hashBuffer, final MessageDigest hashBuilder) {
		try (var channel = Data.openChannel(this.sourcePath)) {
			hashBuilder.reset();
			final var bufSize = hashBuffer.capacity();
			for (var remSize = hashSize; remSize > 0; remSize -= bufSize) {
				final var remLimit = (int)Math.min(remSize, bufSize);
				hashBuffer.limit(remLimit).position(0);
				final var last = Data.readChannel(channel, hashBuffer);
				hashBuffer.limit(hashBuffer.position()).position(0);
				hashBuilder.update(hashBuffer);
				if (last) {
					break;
				}
			}
			this.sourceHash = FEMBinary.from(hashBuilder.digest()).toString(false);
		} catch (final Exception error) {
			error.printStackTrace();
			this.sourceHash = this;
		}
	}

	void computeData(final long dataSize) {
		try {
			final var fileData = new Data();
			fileData.dataPath = this.sourcePath;
			fileData.dataSize = dataSize;
			this.sourceData = fileData;
		} catch (final Exception error) {
			error.printStackTrace();
			this.sourceData = this;
		}
	}

	@Override
	public String toString() {
		return this.sourcePath;
	}

}