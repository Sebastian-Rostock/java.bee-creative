package bee.creative.app.ft;

import java.awt.Component;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

public class FTLongOption {

	public long val, min, max, inc;

	public FTLongOption(final long val, final Number min, final Number max, final long inc) {
		this.val = val;
		this.min = min != null ? min.longValue() : Long.MIN_VALUE;
		this.max = max != null ? max.longValue() : Long.MAX_VALUE;
		this.inc = inc;
	}

	@Override
	public String toString() {
		return Long.toString(this.val);
	}

	Component toControl() {
		final SpinnerNumberModel res = new SpinnerNumberModel(this.val, this.min, this.max, this.inc);
		res.addChangeListener(l -> this.val = res.getNumber().longValue());
		return new JSpinner(res);
	}

}
