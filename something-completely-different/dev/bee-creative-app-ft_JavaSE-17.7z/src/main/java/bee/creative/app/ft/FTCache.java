package bee.creative.app.ft;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import bee.creative.csv.CSVReader;
import bee.creative.csv.CSVWriter;
import bee.creative.fem.FEMBinary;
import bee.creative.util.HashMap;

class FTCache {

	public FTCache() throws NoSuchAlgorithmException {
		this.hasher = MessageDigest.getInstance("SHA-256");
	}

	public String getHash(final String filePath, final long hashSize) {
		final var file = new File(filePath);
		final var fileSize = file.length();
		final var fileTime = file.lastModified();
		Object[] entry = this.cache.get(filePath);
		if ((entry != null) && (this.getFileSize(entry).longValue() == fileSize) && (this.getFileTime(entry).longValue() == fileTime)) {
			final int count = this.getHashCount(entry);
			for (var index = 0; index < count; index++) {
				if (this.getHashSize(entry, index).longValue() == hashSize) return this.getHashCode(entry, index);
			}
			final var hashCode = this.computeHash(filePath, hashSize);
			entry = this.setHashCount(entry, count + 1);
			this.setHashSize(entry, count, hashSize);
			this.setHashCode(entry, count, hashCode);
			return hashCode;
		}
		final var hashCode = this.computeHash(filePath, hashSize);
		entry = this.setHashCount(FTCache.EMPTY, 1);
		this.setFileSize(entry, fileSize);
		this.setFileTime(entry, fileTime);
		this.setHashSize(entry, 0, hashSize);
		this.setHashCode(entry, 0, hashCode);
		this.cache.put(filePath, entry);
		return hashCode;
	}

	public String computeHash(final String filePath, final long hashSize) {
		final var hashBuffer = this.buffer;
		final var hashBuilder = this.hasher;
		try (var channel = Data.openChannel(filePath)) {
			hashBuilder.reset();
			final var bufSize = hashBuffer.capacity();
			for (var remSize = hashSize; remSize > 0; remSize -= bufSize) {
				final var remLimit = (int)Math.min(remSize, bufSize);
				hashBuffer.limit(remLimit).position(0);
				final var last = Data.readChannel(channel, hashBuffer);
				hashBuffer.limit(hashBuffer.position()).position(0);
				hashBuilder.update(hashBuffer);
				if (last) {
					break;
				}
			}
			return FEMBinary.from(hashBuilder.digest()).toString(false);
		} catch (final Exception error) {
			error.printStackTrace();
			return null;
		}
	}

	public void persist(final CSVWriter writer) throws NullPointerException, IOException {
		for (final var src: this.cache.entrySet()) {
			final Object[] entry = src.getValue();
			final var hashCount = this.getHashCount(entry);
			final var values = new Object[(hashCount * 2) + 3];
			values[0] = src.getKey();
			values[1] = this.getFileSize(entry);
			values[2] = this.getFileTime(entry);
			for (var i = 0; i < hashCount; i++) {
				values[(i * 2) + 3] = this.getHashSize(entry, i);
				values[(i * 2) + 4] = this.getHashCode(entry, i);
			}
			writer.writeEntry(values);
		}
	}

	public void restore(final CSVReader reader) throws NullPointerException, IllegalArgumentException, IOException {
		for (var src = reader.readEntry(); src != null; src = reader.readEntry()) {
			final var hashCount = (src.length - 3) / 2;
			final var entry = this.setHashCount(FTCache.EMPTY, hashCount);
			this.setFileSize(entry, Long.valueOf(src[1]));
			this.setFileTime(entry, Long.valueOf(src[2]));
			for (var i = 0; i < hashCount; i++) {
				this.setHashSize(entry, i, Long.valueOf(src[(i * 2) + 3]));
				this.setHashCode(entry, i, src[(i * 2) + 4]);
			}
			this.cache.put(src[0], entry);
		}
	}

	private static final Object[] EMPTY = new Object[0];

	/** Dieses Feld bildet von einem absoluten Dateipfad auf eine Liste der Form ({@link Long}, {@link String})+ besteht. */
	private final HashMap<String, Object[]> cache = new HashMap<>(1000);

	private final ByteBuffer buffer = ByteBuffer.allocateDirect(Data.BUFFER_SIZE);

	private final MessageDigest hasher;

	private Long getFileSize(final Object[] entry) {
		return (Long)entry[0];
	}

	private void setFileSize(final Object[] entry, final Long value) {
		entry[0] = value;
	}

	private Long getFileTime(final Object[] entry) {
		return (Long)entry[1];
	}

	private void setFileTime(final Object[] entry, final Long value) {
		entry[1] = value;
	}

	private Long getHashSize(final Object[] entry, final int index) {
		return (Long)entry[(index * 2) + 2];
	}

	private void setHashSize(final Object[] entry, final int index, final Long value) {
		entry[(index * 2) + 2] = value;
	}

	private String getHashCode(final Object[] entry, final int index) {
		return (String)entry[(index * 2) + 3];
	}

	private void setHashCode(final Object[] entry, final int index, final String value) {
		entry[(index * 2) + 3] = value;
	}

	private int getHashCount(final Object[] entry) {
		return (entry.length - 2) / 2;
	}

	private Object[] setHashCount(final Object[] entry, final int value) {
		return Arrays.copyOf(entry, 2 + (value * 2));
	}

}
