package bee.creative.app.ft;

import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.FileTime;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import bee.creative.fem.FEMBinary;
import bee.creative.lang.Objects;
import bee.creative.lang.Runnable2;
import bee.creative.lang.Strings;
import bee.creative.util.Consumer;
import bee.creative.util.HashMap;
import bee.creative.util.HashSet;

/** Diese Applikation ermittelt aus allen gewählten Dateien die jenigen, die in den ersten X Byte gleich sind und gruppiert diese. <pre> einstellbar sind -
 * größe des abzugleichenden dateikopfes -
 *
 * @author [cc-by] 2022 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */
@SuppressWarnings ("serial")
@Deprecated
public class FileToolMain extends FileToolWindow {

	static final File OPTION_FILE = new File(".options").getAbsoluteFile();

	public static void main(final String[] args) throws Exception {
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		new FileToolMain();
	}

	static DropTargetAdapter performDropWith(final Consumer<? super DropTargetDropEvent> performDrop) {
		return new DropTargetAdapter() {

			@Override
			public void drop(final DropTargetDropEvent event) {
				performDrop.set(event);
			}

		};
	}

	static AbstractAction performActionWith(final Consumer<? super ActionEvent> performAction) {
		return new AbstractAction() {

			@Override
			public void actionPerformed(final ActionEvent event) {
				performAction.set(event);
			}

		};
	}

//	@Override
	void initialize() {
//		super.initialize();
		new DropTarget(this.sourceList, FileToolMain.performDropWith(this::_performDropSourceAction));
		this.sourceList.getActionMap().put("paste-from-clipboard", FileToolMain.performActionWith(this::_performPasteSourceAction));
		new DropTarget(this.targetList, FileToolMain.performDropWith(this::_performDropTargetAction));
		this.targetList.getActionMap().put("paste-from-clipboard", FileToolMain.performActionWith(this::_performPasteTargetAction));
		this.scanButton.addActionListener(this::_performScanSourceAction);
		this.copyButton.addActionListener(this::performCopySourceAction);
		this.findButton.addActionListener(this::performFindSourceAction);
		this.viewButton.addActionListener(this::_performPreviewTargetsAction);
		this.moveButton.addActionListener(this::_performRecycleTargetsAction);
		this.stopButton.addActionListener(this::_performCancelProcessAction);
		this.frame.setSize(800, 600);
		this.frame.setLocationRelativeTo(null);
		this.frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		this.frame.setVisible(true);
		this.updateButtons(false, false);
		new Timer(500, this::_performUpdateProcessAction).start();
		this._performRestoreOptionsAction();
	}

	String taskTitle;

	Object taskEntry;

	int taskCount;

	boolean isTaskRunning;

	boolean isTaskCanceled;

	/** Diese Methode führt die gegebene Berechnung {@code task} mit dem gegebenen Titel {@code title} in einem neuen {@link Thread} aus, sofern derzeit keine
	 * anderer derartige Berechnung {@link #isTaskRunning läuft}. Der Titel wird im Fehlerdialog sowie als {@link #taskTitle} verwendet. */
	void runTask(final String title, final Runnable2 task) {
		final var thread = new Thread(() -> {
			synchronized (this) {
				if (this.isTaskRunning) return;
				this.taskTitle = title;
				this.taskEntry = null;
				this.taskCount = 0;
				this.isTaskRunning = true;
				this.isTaskCanceled = false;
				this.runLater(() -> {
					this.updateButtons(true, false);
					this._performPersistOptionsAction();
				});
			}
			try {
				task.run();
			} catch (final CancellationException ignore) {

			} catch (final Throwable error) {
				this.runLater(() -> this.showException(title, "<html>" + "Unerwarteter Fehler<br>" + this.escapeHtml(error.toString()) + "</html>"));
			} finally {
				synchronized (this) {
					this.taskTitle = null;
					this.taskEntry = null;
					this.taskCount = 0;
					this.isTaskRunning = false;
					this.isTaskCanceled = false;
					EventQueue.invokeLater(() -> this.updateButtons(false, false));
				}
			}
		});
		thread.setDaemon(true);
		thread.start();
	}

	synchronized void checkTask() throws CancellationException {
		if (this.isTaskCanceled) throw new CancellationException();
	}

	synchronized void cancelTask() {
		if (this.isTaskCanceled || !this.isTaskRunning) return;
		this.isTaskCanceled = true;
		this.runLater(() -> this.updateButtons(true, true));
	}

	void runLater(final Runnable runnable) {
		EventQueue.invokeLater(runnable);
	}

	void showException(final String title, final String message) {
		JOptionPane.showMessageDialog(this.frame, message, title, JOptionPane.ERROR_MESSAGE);
	}

	void showInformation(final String title, final String message) {
		JOptionPane.showMessageDialog(this.frame, message, title, JOptionPane.INFORMATION_MESSAGE);
	}

	void showConfirmation(final String title, final String message, final Runnable task) {
		if (JOptionPane.showConfirmDialog(this.frame, message, title, JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
		task.run();
	}

	void updateButtons(final boolean isEntered, final boolean isCanceled) {
		for (final var item: Arrays.asList(this.sourceList, this.targetList, this.hashSize, this.testSize, this.scanButton, this.copyButton, this.findButton,
			this.moveButton, this.viewButton)) {
			item.setEnabled(!isEntered);
		}
		this.stopButton.setEnabled(isEntered && !isCanceled);
	}

	/** Diese Methode ergänzt den Text in {@code transList} um die im gegebenen {@link Transferable} enthaltenen {@link DataFlavor#javaFileListFlavor Dateipfade}
	 * und liefert im Erfolgsfall {@code true}. */
	boolean performAdd(final JTextArea target, final Transferable source, final boolean acceptOnlyFiles) throws UnsupportedFlavorException, IOException {
		if (source == null) return false;
		if (!target.isEnabled()) return true;
		if (!source.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) return false;
		@SuppressWarnings ("unchecked")
		final var fileList = (List<File>)source.getTransferData(DataFlavor.javaFileListFlavor);
		final var pathList = new ArrayList<>();
		final var text = target.getText();
		if (!text.isEmpty()) {
			pathList.add(text);
		}
		for (final File file: fileList) {
			if (!acceptOnlyFiles || file.isFile()) {
				pathList.add(file.getPath());
			}
		}
		target.setText(Strings.join("\n", pathList));
		return true;
	}

	void performDrop(final JTextArea target, final DropTargetDropEvent source, final boolean acceptOnlyFiles) {
		try {
			source.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);
			this.performAdd(target, source.getTransferable(), acceptOnlyFiles);
		} catch (final Exception error) {
			error.printStackTrace();
		}
	}

	void performPaste(final JTextArea target, final boolean acceptOnlyFiles) {
		try {
			if (this.performAdd(target, Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null), acceptOnlyFiles)) return;
			target.paste();
		} catch (final Exception error) {
			error.printStackTrace();
		}
	}

	void _performDropSourceAction(final DropTargetDropEvent event) {
		this.performDrop(this.sourceList, event, false);
	}

	void _performDropTargetAction(final DropTargetDropEvent event) {
		this.performDrop(this.targetList, event, true);
	}

	void _performPasteSourceAction(final ActionEvent event) {
		this.performPaste(this.sourceList, false);
	}

	void _performPasteTargetAction(final ActionEvent event) {
		this.performPaste(this.targetList, true);
	}

	void _performScanSourceAction(final ActionEvent event) {
		this.runLater(() -> this.showConfirmation("Aufbereiten beginnen", "<html>" + //
			"Sollen die eingegebenen Datei- und Verzeichnispfade wirklich aufbereitet werden?<br>" + //
			"Beim <b>Aufbereiten</b> der Verzeichnisse werden diese durch alle darin enthatenen Dateien ersetzt.<br>" + //
			"Die abschließende Bestückung der Anzeige kann bei vielen Dateien mehrere Minuten dauern und nicht abgebrochen werden." + //
			"</html>", () -> {
				final var stringListValue = this.sourceList.getText();
				this.runTask("Aufbereiten", () -> {
					final var stringList = Strings.split(Item.LINE_BREAK, stringListValue);
					this.taskCount = stringList.size();
					final var sourceStack = new LinkedList<File>();
					for (final var string: stringList) {
						this.checkTask();
						this.taskEntry = string;
						final var file = new File(string.trim());
						if (file.isAbsolute()) {
							sourceStack.add(file.getAbsoluteFile());
						} else {
							this.taskCount--;
						}
					}
					final var resultSet = new HashSet<String>();
					final var resultList = new ArrayList<String>();
					while (!sourceStack.isEmpty()) {
						this.checkTask();
						final var source = sourceStack.remove(0);
						this.taskEntry = source;
						if (source.isDirectory()) {
							final var fileArray = source.listFiles();
							if (fileArray != null) {
								sourceStack.addAll(0, Arrays.asList(fileArray));
								this.taskCount += fileArray.length;
							}
						} else if (source.isFile()) {
							final var result = source.getAbsolutePath();
							if (resultSet.add(result)) {
								resultList.add(result);
							}
						}
						this.taskCount--;
					}
					final var sourceListValue2 = Strings.join("\n", resultList);
					final var todoCount = stringList.size();
					final var doneCount = resultList.size();
					this.runLater(() -> {
						this.sourceList.setText(sourceListValue2);
						this.showInformation("Aufbereiten abgeschlossen", "<html>" + //
							"<b>" + todoCount + "</b> Datei- und Verzeichnispfade zu <b>" + doneCount + "</b> Dateispfaden aufbereitet." + //
							"</html>");
					});
				});
			}));
	}

	{}
	{}

	private String escapeHtml(final String string) {
		return string.replaceAll("&", "&amp;").replaceAll("<", "&lt;");
	}

	void performCopySourceAction(final ActionEvent event) {

		final String stringListValue = this.sourceList.getText();
		final long copyTimeValue = (Long)this.copyTime.getValue();
		this.runTask("Erneuern", () -> {

			FileTime.fromMillis(System.currentTimeMillis() - (copyTimeValue * 24 * 60 * 60 * 1000));
			// TODO zeitfilter berechnen

			final List<String> stringList = Strings.split(Item.LINE_BREAK, stringListValue);
			this.taskCount = stringList.size();

			final List<File> sourceStack = new LinkedList<>();
			for (final String string: stringList) {
				this.checkTask();
				this.taskEntry = string;
				final File file = new File(string.trim());
				if (file.isAbsolute()) {

					sourceStack.add(file.getAbsoluteFile());
					// TODO zeitfilter anwenden
				} else {
					this.taskCount--;
				}
			}

			while (!sourceStack.isEmpty()) {
				this.checkTask();
				final File source = sourceStack.remove(0);
				this.taskEntry = source;

				// TODO datei verarbeiten

				this.taskCount--;
			}

		});
	}

	void performFindSourceAction(final ActionEvent event) {
		final String stringListValue = this.sourceList.getText();
		final long hashSizeValue = (Long)this.hashSize.getValue();
		final long testSizeValue = (Long)this.testSize.getValue();

		this.runTask("Suchen", () -> {

			final List<String> stringList = Strings.split(Item.LINE_BREAK, stringListValue);
			this.taskCount = stringList.size() + 1;

			final Set<String> pathSet = new HashSet<>(this.taskCount);
			final List<Item> itemList = new LinkedList<>();
			for (final String string: stringList) {
				this.checkTask();
				this.taskEntry = string;
				this.taskCount--;
				final File file = new File(string).getAbsoluteFile();
				if (file.isFile()) {
					final String path = file.getPath();
					if (pathSet.add(path)) {
						itemList.add(0, new Item(path));
						this.taskCount++;
					}
				}
			}
			pathSet.clear();

			final HashMap<Object, Item> sizeListMap = new HashMap<>();
			for (final Item item1: itemList) { // rückwärts
				this.checkTask();
				this.taskEntry = item1;
				this.taskCount--;

				item1.computeSize();

				item1.previousItem = sizeListMap.put(item1.sourceSize, item1);
				if (item1.previousItem != null) {
					this.taskCount++;
				}
			}
			sizeListMap.remove(null);
			itemList.clear();

			final HashMap<Object, Item> hashListMap = new HashMap<>();
			final HashMap<Object, Item> itemDataListMap = new HashMap<>();
			final LinkedList<Item> targetList = new LinkedList<>();
			final ByteBuffer hashBuffer = Data.BUFFER_THIS;
			final MessageDigest hashBuilder = MessageDigest.getInstance("SHA-256");

			for (final Item sizeList: sizeListMap.values()) {
				this.checkTask();
				if (sizeList.previousItem != null) {
					this.taskCount++;
					hashListMap.clear();
					final long testSize = Math.min(sizeList.sourceSize.longValue(), testSizeValue);
					for (Item item2 = sizeList, next; item2 != null; item2 = next) { // vorwärts
						this.taskEntry = item2;
						this.taskCount--;
						next = item2.previousItem;

						item2.computeHash(hashSizeValue, hashBuffer, hashBuilder);

						item2.previousItem = hashListMap.put(item2.sourceHash, item2);
						if (item2.previousItem != null) {
							this.taskCount++;
						}
					}

					for (final Item hashList: hashListMap.values()) {
						this.checkTask();
						if (hashList.previousItem != null) {
							this.taskCount++;

							itemDataListMap.clear();
							for (Item item3 = hashList, prev; item3 != null; item3 = prev) { // rückwärts
								this.checkTask();
								prev = item3.previousItem;

								item3.computeData(testSize);

								item3.previousItem = itemDataListMap.put(item3.sourceData, item3);
								if (item3.previousItem != null) {
									this.taskCount++;
								}
							}
							for (final Item dataList1: itemDataListMap.values()) {
								if (dataList1.previousItem != null) {
									targetList.add(dataList1);
								}
							}

						}
					}

				}
			}

			final StringBuilder targetBuilder = new StringBuilder();
			for (final Item dataList2: targetList) {
				this.taskEntry = dataList2;
				this.taskCount--;
				for (Item item4 = dataList2.previousItem; item4 != null; item4 = item4.previousItem) { // vorwärts
					this.checkTask();
					targetBuilder //
						.append(item4.sourcePath).append("\t") //
						.append(dataList2.sourcePath).append("\t") //
						.append(dataList2.sourceHash).append("\t") //
						.append(dataList2.sourceSize).append("\n");
				}
			}

			final String targetTextValue = targetBuilder.toString();
			SwingUtilities.invokeLater(() -> {
				this.targetList.setText(targetTextValue);
			});

		});
	}

	{}

	/** Diese Methode erzeugt ein temporäres Verzeichnis, legt in diesem die vergleichsdateien als symlink an und öffnet es anschließend im Dateiexplorer. */
	void _performPreviewTargetsAction(final ActionEvent event) {
		this.runLater(() -> this.showConfirmation("Anzeigen beginnen", "<html>" + //
			"Sollen die aufgelisteten Dateien wirklich <b>angezeigt</b> werden?<br>" + //
			"Die Dateien werden dabei als Symlinks in ein temporäres Verzeichnis eingefügt.<br>" + //
			"Das temporäre Verzeichnis wird abschließend angezeigt." + //
			"</html>", () -> {
				final String sourceListValue = this.targetList.getText();
				this.runTask("Anzeigen", () -> {
					var entryCount = 0;
					var failCount = 0;
					final var parentFile = Files.createTempDirectory("file-clone-finder-").toFile();
					final var stringList = Strings.split(Item.LINE_BREAK, sourceListValue);
					this.taskCount = stringList.size();
					for (final String string: stringList) {
						this.checkTask();
						this.taskEntry = string;
						this.taskCount--;
						final var pathList = Strings.split(Item.PAIR_BREAK, string.trim());
						if (pathList.size() >= 2) {
							final var duplikatPath = pathList.get(0).trim();
							final var originalPath = pathList.get(1).trim();
							if (!duplikatPath.isEmpty() && !originalPath.isEmpty()) {
								final var duplikatFile = new File(duplikatPath);
								final var originalFile = new File(originalPath);
								if (duplikatFile.isFile() && originalFile.isFile()) {
									entryCount++;
									final var duplikatLink = new File(parentFile, entryCount + "-DUPLIKAT-" + duplikatFile.getName());
									final var originalLink = new File(parentFile, entryCount + "-ORIGINAL-" + originalFile.getName());
									try {
										Files.createSymbolicLink(duplikatLink.toPath(), duplikatFile.toPath());
									} catch (final Exception e) {
										failCount++;
									}
									try {
										Files.createSymbolicLink(originalLink.toPath(), originalFile.toPath());
									} catch (final Exception e) {
										failCount++;
									}
								}
							}
						}
					}
					Desktop.getDesktop().open(parentFile);
					final var todoCount = entryCount * 2;
					final var doneCount = todoCount - failCount;
					this.runLater(() -> this.showInformation("Anzeigen abgeschlossen", "<html>" + //
						"<b>" + doneCount + "</b> von <b>" + todoCount + "</b> Symlinks wurden in das temporäre Verzeichnis eingefügt.<br>" + //
						"<b>" + parentFile + "</b>" + //
						"</html>"));
				});
			}));
	}

	/** Diese Methode verschiebt die in {@link #targetList} angegebenen Dateien in den Papierkorb. */
	void _performRecycleTargetsAction(final ActionEvent event) {
		this.runLater(() -> this.showConfirmation("Recyclen beginnen", "<html>" + //
			"Sollen die aufgelisteten Dateien wirklich <b>recyclet</b> werden?<br>" + //
			"Die Dateien werden dabei in den Papierkorb verschoben." + //
			"</html>", () -> {
				final String entryListValue = this.targetList.getText();
				this.runTask("Recyclen", () -> {
					var failCount = 0;
					final Desktop desktop = Desktop.getDesktop();
					final var entryList = Strings.split(Item.LINE_BREAK, entryListValue);
					this.taskCount = entryList.size();
					final var filePathSet = new HashSet<String>(this.taskCount);
					for (final var entry: entryList) {
						this.checkTask();
						this.taskEntry = entry;
						this.taskCount--;
						final var splitList = Strings.split(Item.PAIR_BREAK, entry.trim());
						if (splitList.size() >= 1) {
							final String filePath = splitList.get(0).trim();
							if (!filePath.isEmpty() && filePathSet.add(filePath)) {
								if (!desktop.moveToTrash(new File(filePath))) {
									failCount++;
								}
							}
						}
					}
					final var todoCount = filePathSet.size();
					final var doneCount = todoCount - failCount;
					this.runLater(() -> this.showInformation("Recyclen abgeschlossen", "<html>" + //
						"<b>" + doneCount + "</b> von <b>" + todoCount + "</b> Dateien wurden in den Papierkorb verschoben." + //
						"</html>"));
				});
			}));
	}

	void _performCancelProcessAction(final ActionEvent event) {
		this.runLater(() -> this.showConfirmation( //
			Objects.notNull(this.taskTitle, "Abbrechen"), //
			"<html>Sollen der Vorgang wirklich abgebrochen werden?</html>", //
			this::cancelTask));
	}

	synchronized void _performUpdateProcessAction(final ActionEvent event) {
		if (this.isTaskRunning) {
			final String title = Objects.notNull(this.taskTitle, "?"), entry = String.valueOf(this.taskEntry);
			this.progressInfo.setText("<html>" + title + " - " + this.taskCount + " - " + entry.replaceAll("\\\\", "\\<wbr>") + "</html>");
		} else {
			this.progressInfo.setText(" ");
		}
	}

	void _performPersistOptionsAction() {
		try {
			final var store = new Properties();
			store.setProperty("hashSize", String.valueOf(this.hashSize.getValue()));
			store.setProperty("testSize", String.valueOf(this.testSize.getValue()));
			store.setProperty("copyTime", String.valueOf(this.copyTime.getValue()));
			try (var file = new FileWriter(FileToolMain.OPTION_FILE, StandardCharsets.UTF_8)) {
				store.store(file, "file-tool-options");
			}
		} catch (final Exception error) {
			error.printStackTrace();
		}
	}

	void _performRestoreOptionsAction() {
		try {
			final var store = new Properties();
			try (var file = new FileReader(FileToolMain.OPTION_FILE, StandardCharsets.UTF_8)) {
				store.load(file);
			}
			this.hashSize.setValue(Long.valueOf(store.getProperty("hashSize")));
			this.testSize.setValue(Long.valueOf(store.getProperty("testSize")));
			this.copyTime.setValue(Long.valueOf(store.getProperty("copyTime")));
		} catch (final Exception error) {
			error.printStackTrace();
		}
	}

	static class Item {

		static final Pattern LINE_BREAK = Pattern.compile("[\r\n]+");

		static final Pattern PAIR_BREAK = Pattern.compile(">|\t");

		String sourcePath;

		Long sourceSize;

		Object sourceHash;

		Object sourceData;

		Item previousItem;

		Item(final String sourcePath) {
			this.sourcePath = sourcePath;
		}

		void computeSize() {
			try {
				this.sourceSize = new File(this.sourcePath).length();
			} catch (final Exception error) {
				error.printStackTrace();
				this.sourceSize = null;
			}
		}

		void computeHash(final long hashSize, final ByteBuffer hashBuffer, final MessageDigest hashBuilder) {
			try (var channel = Data.openChannel(this.sourcePath)) {
				hashBuilder.reset();
				final var bufSize = hashBuffer.capacity();
				for (var remSize = hashSize; remSize > 0; remSize -= bufSize) {
					final var remLimit = (int)Math.min(remSize, bufSize);
					hashBuffer.limit(remLimit).position(0);
					final var last = Data.readChannel(channel, hashBuffer);
					hashBuffer.limit(hashBuffer.position()).position(0);
					hashBuilder.update(hashBuffer);
					if (last) {
						break;
					}
				}
				this.sourceHash = FEMBinary.from(hashBuilder.digest()).toString(false);
			} catch (final Exception error) {
				error.printStackTrace();
				this.sourceHash = this;
			}
		}

		void computeData(final long dataSize) {
			try {
				final var fileData = new Data();
				fileData.dataPath = this.sourcePath;
				fileData.dataSize = dataSize;
				this.sourceData = fileData;
			} catch (final Exception error) {
				error.printStackTrace();
				this.sourceData = this;
			}
		}

		@Override
		public String toString() {
			return this.sourcePath;
		}

	}

	static class Data {

		static final int BUFFER_SIZE = 1024 * 1024 * 10;

		static final ByteBuffer BUFFER_THIS = ByteBuffer.allocateDirect(Data.BUFFER_SIZE);

		static final ByteBuffer BUFFER_THAT = ByteBuffer.allocateDirect(Data.BUFFER_SIZE);

		/** Diese Methode füllt den gegebenen Puffer target mit den Daten aus dem Datenkanal und liefert nutr dann true, wenn dabei das Ende des Datenkanals
		 * erreicht wurde. */
		static boolean readChannel(final FileChannel source, final ByteBuffer target) throws IOException {
			while (target.remaining() != 0) {
				if (source.read(target) < 0) return true;
			}
			return false;
		}

		static FileChannel openChannel(final String filepath) throws IOException {
			return FileChannel.open(new File(filepath).toPath(), StandardOpenOption.READ);
		}

		String dataPath;

		long dataSize;

		@Override
		public int hashCode() {
			return 0;
		}

		@Override
		public boolean equals(final Object object) {
			if (object == this) return true;
			if (!(object instanceof Data)) return false;
			final Data that = (Data)object;
			if (Objects.equals(this.dataPath, that.dataPath) || (this.dataSize != that.dataSize)) return true;
			try (FileChannel thisChannel = Data.openChannel(this.dataPath)) {
				try (FileChannel thatChannel = Data.openChannel(that.dataPath)) {
					final int bufSize = Data.BUFFER_SIZE;
					final ByteBuffer thisBuffer = Data.BUFFER_THIS;
					final ByteBuffer thatBuffer = Data.BUFFER_THAT;
					for (long remSize = this.dataSize; remSize > 0; remSize -= bufSize) {
						final int remLimit = (int)Math.min(remSize, bufSize);
						thisBuffer.limit(remLimit).position(0);
						thatBuffer.limit(remLimit).position(0);
						final boolean thisLast = Data.readChannel(thisChannel, thisBuffer);
						final boolean thatLast = Data.readChannel(thatChannel, thatBuffer);
						if (thisLast != thatLast) return false;
						thisBuffer.limit(thisBuffer.position()).position(0);
						thatBuffer.limit(thatBuffer.position()).position(0);
						if (!thisBuffer.equals(thatBuffer)) return false;
					}
					return true;
				}
			} catch (final Exception error) {
				error.printStackTrace();
				return false;
			}
		}

	}

}
