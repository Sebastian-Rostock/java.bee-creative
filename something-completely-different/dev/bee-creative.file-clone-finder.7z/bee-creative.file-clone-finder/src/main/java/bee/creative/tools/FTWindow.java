package bee.creative.tools;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CancellationException;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import bee.creative.lang.Objects;
import bee.creative.lang.Strings;
import bee.creative.util.Iterables;
import bee.creative.util.Iterators;

class FTWindow extends JFrame {

	public static void main(final String[] args) throws Exception {
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		new FTWindow().setVisible(true);
	}

	FTWindow() {
		this.setTitle("File-Tool");
		this.setMinimumSize(new Dimension(400, 200));
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		this.setSize(new Dimension(600, 400));
		final JTabbedPane pagePanel = new JTabbedPane(SwingConstants.TOP);
		{
			final JPanel inputPage = new JPanel();
			inputPage.setBackground(UIManager.getColor("TabbedPane.highlight"));
			inputPage.setLayout(new GridBagLayout());
			pagePanel.addTab("Pfadliste (Eingabepfade)", null, inputPage, null);
			{
				this.inputMenu = this.createInputMenu();
				this.inputArea = this.createInputArea();
			}
			{
				final JScrollPane inputPanel = new JScrollPane(this.inputArea);
				inputPanel.setColumnHeaderView(this.inputMenu);
				inputPage.add(inputPanel, new GridBagConstraints(0, 0, 1, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(3, 3, 3, 3), 0, 0));
			}
			{
				final JLabel inputLabel = this.createInputLabel();
				inputPage.add(inputLabel, new GridBagConstraints(0, 1, 1, 1, 1, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 3, 3, 3), 0, 0));
			}
		}
		{
			final JPanel tablePage = new JPanel();
			tablePage.setBackground(UIManager.getColor("TabbedPane.highlight"));
			tablePage.setLayout(new GridBagLayout());
			pagePanel.addTab("Pfadtabelle (Quell- und Zielpfade)", null, tablePage, null);
			{
				this.tableMenu = this.createTableMenu();
				this.tableArea = this.createTableArea();
			}
			{
				final JScrollPane targetPanel = new JScrollPane(this.tableArea);
				targetPanel.setColumnHeaderView(this.tableMenu);
				tablePage.add(targetPanel, new GridBagConstraints(0, 0, 1, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(3, 3, 3, 3), 0, 0));
			}
			{
				final JLabel inputLabel = this.createTableLabel();
				tablePage.add(inputLabel, new GridBagConstraints(0, 1, 1, 1, 1, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 3, 3, 3), 0, 0));
			}
		}
		{
			this.taskInfo = new JLabel();
			this.taskStop = new JButton("abbrechen");
			this.taskStop.addActionListener(this::_8_1_setupCancelProcess);
		}
		final Container contentPane = this.getContentPane();
		contentPane.setLayout(new GridBagLayout());
		contentPane.add(pagePanel, new GridBagConstraints(0, 0, 2, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(3, 3, 3, 3), 0, 0));
		contentPane.add(this.taskInfo,
			new GridBagConstraints(0, 1, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 3, 3, 3), 0, 0));
		contentPane.add(this.taskStop,
			new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 3, 3), 0, 0));
		this.execUpdateEnabled();
		this.setLocationRelativeTo(null);
		new Timer(500, this::updateTask).start();
	}

	private JTextArea inputArea;

	private JMenuBar inputMenu;

	private String getInputText() {
		return this.inputArea.getText();
	}

	private void setInputText(final String inputText) {
		this.runLater(() -> this.inputArea.setText(inputText));
	}

	@SuppressWarnings ("serial")
	private JTextArea createInputArea() {
		final JTextArea res = new JTextArea();
		new DropTarget(res, new DropTargetAdapter() {

			@Override
			public void drop(final DropTargetDropEvent event) {
				FTWindow.this.setupImportInputs(event);
			}

		});
		res.getActionMap().put("paste-from-clipboard", new AbstractAction() {

			@Override
			public void actionPerformed(final ActionEvent event) {
				FTWindow.this.setupImportInputs();
			}

		});
		return res;
	}

	private JLabel createInputLabel() {
		return new JLabel("" + //
			"<html>" + //
			"Dateien und Verzeichnisse können hier aus der Zwischenablage eingefügt bzw. aus dem Dateiexplorer fallengelassen werden." + //
			"</html>" //
		);
	}

	private JMenuBar createInputMenu() {
		return this.createMenuBar( //
			this.createMenu( //
				"Eingabepfade", //
				this.createMenuItem("" + //
					"<html>" + //
					"Fehlerpfade erhalten...<br>" + //
					"<i>&nbsp;&nbsp;Alle Eingabepfade zu existierenden Dateien bzw. Verzeichnissen werden verworfen.</i>" + //
					"</html>", //
					this::setupCleanupExistingInputs //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Fehlerpfade entfernen...<br>" + //
					"<i>&nbsp;&nbsp;Alle Eingabepfade zu nicht existierenden Dateien bzw. Verzeichnissen werden verworfen.</i>" + //
					"</html>", //
					this::setupCleanupMissingInputs //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Dateien auflösen...<br>" + //
					"<i>&nbsp;&nbsp;Alle Verzeichnispfade werden durch alle rekursiv darin enthaltenen Dateipfade ersetzt.</i>" + //
					"</html>", //
					this::_1_4_setupResolveInputsToFiles //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Verzeichnisse auflösen...<br>" + //
					"<i>&nbsp;&nbsp;Alle Verzeichnispfade werden um alle rekursiv darin enthaltenen Verzeichnispfade ergänzt.</i>" + //
					"</html>", //
					this::_1_5_setupResolveInputsToFolders //
				), //
				this.createMenuBreak(), //
				this.createMenuItem("" + //
					"<html>" + //
					"Eingabepfade übertragen...<br>" + //
					"<i>&nbsp;&nbsp;Alle Eingabepfade werden in die Pfadtabelle übertragen.</i>" + //
					"</html>", //
					this::_2_1_setupReplaceTableWithInputs //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Eingabepfade exportieren<br>" + //
					"<i>&nbsp;&nbsp;Alle Eingabepfade werden in die Zwischenablage kopiert.</i>" + //
					"</html>", //
					this::_1_3_setupExportInputsToClipboard //
				) //
			), //
			this.createMenu( //
				"Dateien", //
				this.createMenuItem("" + //
					"<html>" + //
					"Dateien löschen...<br>" + //
					"<i>&nbsp;&nbsp;Alle Dateien werden endgültig gelöscht.</i>" + //
					"</html>", //
					this::_3_1_setupDeleteInputFiles //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Dateien recyceln...<br>" + //
					"<i>&nbsp;&nbsp;Alle Dateien werden in den Papierkorb verschoben.</i>" + //
					"</html>", //
					this::_3_2_setupRecycleInputFiles //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Dateien erneuern...<br>" + //
					"<i>&nbsp;&nbsp;Alle alten Dateien werden kopiert und durch ihre Kopien ersetzt." + //
					"</html>", //
					this::setupRefreshInputFiles //
				), //
				this.createMenuBreak(), //
				this.createMenuItem("" + //
					"<html>" + //
					"Dateiduplikate übertragen...<br>" + //
					"<i>&nbsp;&nbsp;Alle Datenpfade zu inhaltlich gleichen Dateien werden in die Pfadtabelle übertragen." + //
					"</html>", //
					this::_2_2_setupCreateTableWithClones //
				) //
			), //
			this.createMenu( //
				"Verzeichnisse", //
				this.createMenuItem("" + //
					"<html>" + //
					"Verzeichnisse löschen...<br>" + //
					"<i>&nbsp;&nbsp;Alle leeren Verzeichnisse werden endgültig gelöscht.</i>" + //
					"</html>", //
					this::_4_1_setupDeleteInputFolders //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Verzeichnisse recyceln...<br>" + //
					"<i>&nbsp;&nbsp;Alle leeren Verzeichnisse werden in den Papierkorb verschoben.</i>" + //
					"</html>", //
					this::_4_2_setupRecycleInputFolders //
				) //
			) //
		);
	}

	private JTextArea tableArea;

	private JMenuBar tableMenu;

	private String getTableText() {
		return this.inputArea.getText();
	}

	private void setTableText(final String tableText) {
		this.runLater(() -> this.tableArea.setText(tableText));
	}

	private JTextArea createTableArea() {
		return new JTextArea();
	}

	private JLabel createTableLabel() {
		return new JLabel("" + //
			"<html>" + //
			"Jede Zeile besteht mindestens aus einem Quell- und einen Zieldatenpfad. Alle Werte einer Zeile werden mit Tabulatoren getrennt." + //
			"</html>" //
		);
	}

	private JMenuBar createTableMenu() {
		return this.createMenuBar( //
			this.createMenu( //
				"Quellpfade", //
				this.createMenuItem("" + //
					"<html>" + //
					"Fehlerpfade erhalten...<br>" + //
					"<i>&nbsp;&nbsp;Alle Quellpfade zu existierenden Dateien bzw. Verzeichnissen werden verworfen.</i>" + //
					"</html>", //
					this::_5_5_setupCleanupExistingSources //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Fehlerpfade entfernen...<br>" + //
					"<i>&nbsp;&nbsp;Alle Quellpfade zu nicht existierenden Dateien bzw. Verzeichnissen werden verworfen.</i>" + //
					"</html>", //
					this::_5_6_setupCleanupMissingSources //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Quellpfade ersetzen...<br>" + //
					"<i>&nbsp; Alle Quellpfade werden durch deren Zielpfaden ersetzt.<i>" + //
					"</html>", //
					this::_5_1_setupReplaceSourcesWithTargets //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Quellpfade tauschen...<br>" + //
					"<i>&nbsp; Alle Quell- und Zielpfade werden miteinander getauscht.<i>" + //
					"</html>", //
					this::_5_2_setupExchangeSourcesWithTargets //
				), //
				this.createMenuBreak(), //
				this.createMenuItem("" + //
					"<html>" + //
					"Quellpfade übertragen...<br>" + //
					"<i>&nbsp; Alle Eingabepfade werden mit allen Quellpfaden ersetzt.<i>" + //
					"</html>", //
					this::_5_3_setupReplaceInputsWithSources //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Quellpfade exportieren<br>" + //
					"<i>&nbsp;&nbsp;Alle Quellpfade werden in die Zwischenablage kopiert.</i>" + //
					"</html>", //
					this::_5_4_setupExportSourcesToClipboard //
				)//
			), //

			this.createMenu( //
				"Zielpfade", //
				this.createMenuItem("" + //
					"<html>" + //
					"Fehlerpfade erhalten...<br>" + //
					"<i>&nbsp;&nbsp;Alle Zielpfade zu existierenden Dateien bzw. Verzeichnissen werden verworfen.</i>" + //
					"</html>", //
					this::_6_7_setupCleanupExistingTargets //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Fehlerpfade entfernen...<br>" + //
					"<i>&nbsp;&nbsp;Alle Zielpfade zu nicht existierenden Dateien bzw. Verzeichnissen werden verworfen.</i>" + //
					"</html>", //
					this::_6_8_setupCleanupMissingTargets //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Zielpfade ersetzen...<br>" + //
					"<i>&nbsp; Alle Zielpfade werden durch deren Quellpfaden ersetzt.<i>" + //
					"</html>", //
					this::_6_1_setupReplaceTargetsWithSources //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Zielpfade tauschen...<br>" + //
					"<i>&nbsp; Alle Ziel- und Quellpfade werden miteinander getauscht.<i>" + //
					"</html>", //
					this::_6_2_setupExchangeTargetsWithSources //
				), //
				this.createMenuBreak(), //
				this.createMenuItem("" + //
					"<html>" + //
					"Zielpfade übertragen...<br>" + //
					"<i>&nbsp; Alle Eingabepfade werden mit allen Zielpfaden ersetzt.<i>" + //
					"</html>", //
					this::_6_3_setupReplaceInputsWithTargets //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Zielpfade exportieren<br>" + //
					"<i>&nbsp;&nbsp;Alle Zielpfade werden in die Zwischenablage kopiert.</i>" + //
					"</html>", //
					this::_6_4_setupExportTargetsToClipboard //
				), //
				this.createMenuBreak(), //
				this.createMenuItem("" + //
					"<html>" + //
					"Zeitnamen ableiten...<br>" + //
					"<i>&nbsp;&nbsp;Alle Zieldateinamen werden aus dem Änderungszeitpunkt der Quelldatei abgeleitet.</i>" + //
					"</html>", //
					this::_6_5_setupCreateTargetsWithChangenames //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Zeitpfade ableiten...<br>" + //
					"<i>&nbsp;&nbsp;Alle Zieldateipfade werden aus dem Zeitpunkt im Quellnamen abgeleitet.</i>" + //
					"</html>", //
					this::_6_6_setupCreateTargetsWithChangepaths //
				) //
			), //
			this.createMenu(//
				"Dateien", //
				this.createMenuItem("" + //
					"<html>" + //
					"Quelldateien löschen...<br>" + //
					"<i>&nbsp;&nbsp;Alle Quelldateien werden endgültig gelöscht.</i>" + //
					"</html>", //
					this::_3_1_setupDeleteSourceFiles //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Quelldateien recyceln...<br>" + //
					"<i>&nbsp;&nbsp;Alle Quelldateien werden in den Papierkorb verschoben.</i>" + //
					"</html>", //
					this::_3_2_setupRecycleSourceFiles //
				), //
				this.createMenuBreak(), //
				this.createMenuItem("" + //
					"<html>" + //
					"Zieldateien löschen...<br>" + //
					"<i>&nbsp;&nbsp;Alle Zieldateien werden endgültig gelöscht.</i>" + //
					"</html>", //
					this::_3_1_setupDeleteTargetFiles //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Zieldateien recyceln...<br>" + //
					"<i>&nbsp;&nbsp;Alle Zieldateien werden in den Papierkorb verschoben.</i>" + //
					"</html>", //
					this::_3_2_setupRecycleTargetFiles //
				), //
				this.createMenuBreak(), //
				this.createMenuItem("" + //
					"<html>" + //
					"Dateien anzeigen...<br>" + //
					"<i>&nbsp;&nbsp;Alle Dateien werden zur Anzeige über Symlinks in ein temporäres Verteichnis eingefügt.</i>" + //
					"</html>", //
					this::_7_1_setupShowSourcesAndTarets //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Dateien kopieren...<br>" + //
					"<i>&nbsp;&nbsp;Alle in den Quellpfaden genannten Dateien werden in ihren Zielpfad kopiert.</i>" + //
					"</html>", //
					this::_7_2_setupCopySourcesToTargets //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Dateien verschieben...<br>" + //
					"<i>&nbsp;&nbsp;Alle in den Quellpfaden genannten Dateien werden in ihren Zielpfad verschoben.</i>" + //
					"</html>", //
					this::_7_3_setupMoveSourcesToTargets //
				) //
			), //
			this.createMenu(//
				"Verzeichnisse", //
				this.createMenuItem("" + //
					"<html>" + //
					"Quellverzeichnisse löschen...<br>" + //
					"<i>&nbsp;&nbsp;Alle leeren Quellverzeichnisse werden endgültig gelöscht.</i>" + //
					"</html>", //
					this::_4_1_setupDeleteSourceFolders //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Quellverzeichnisse recyceln...<br>" + //
					"<i>&nbsp;&nbsp;Alle leeren Quellverzeichnisse werden in den Papierkorb verschoben.</i>" + //
					"</html>", //
					this::_4_2_setupRecycleSourceFolders //
				), //
				this.createMenuBreak(), //
				this.createMenuItem("" + //
					"<html>" + //
					"Zielverzeichnisse löschen...<br>" + //
					"<i>&nbsp;&nbsp;Alle leeren Zielverzeichnisse werden endgültig gelöscht.</i>" + //
					"</html>", //
					this::_4_1_setupDeleteTargetFolders //
				), //
				this.createMenuItem("" + //
					"<html>" + //
					"Zielverzeichnisse recyceln...<br>" + //
					"<i>&nbsp;&nbsp;Alle leeren Zielverzeichnisse werden in den Papierkorb verschoben.</i>" + //
					"</html>", //
					this::_4_2_setupRecycleTargetFolders //
				) //
			) //
		);
	}

	private JMenu createMenu(final String text, final Component... items) {
		final JMenu result = new JMenu(text);
		Iterators.fromArray(items).collectAll(result::add);
		return result;
	}

	private JMenuBar createMenuBar(final JMenu... menus) {
		final JMenuBar result = new JMenuBar();
		Iterators.fromArray(menus).collectAll(result::add);
		return result;
	}

	private JMenuItem createMenuItem(final String text, final Runnable onClick) {
		final JMenuItem result = new JMenuItem(text);
		result.addActionListener(event -> onClick.run());
		return result;
	}

	private JSeparator createMenuBreak() {
		return new JSeparator();
	}

	public final SpinnerNumberModel testSizeModel = new SpinnerNumberModel(20971520L, 0L, null, 1048576L);

	public final SpinnerNumberModel hashSizeModel = new SpinnerNumberModel(1048576L, 0L, null, 1048576L);

	public final SpinnerNumberModel copyTimeModel = new SpinnerNumberModel(1800L, 100L, null, 100L);

	public final SpinnerNumberModel moveTimeModel = new SpinnerNumberModel(0L, null, null, 3600L);

	private FTDialog createDialog() {
		final FTDialog res = new FTDialog();
		this.runLater(res::open);
		return res;
	}

	JLabel taskInfo;

	JButton taskStop;

	String taskTitle;

	Object taskEntry;

	int taskCount;

	FTDialog taskCancel;

	boolean isTaskRunning;

	boolean isTaskCanceled;

	/** Diese Methode führt die gegebene Berechnung {@code task} mit dem gegebenen Titel {@code title} in einem neuen {@link Thread} aus, sofern derzeit keine
	 * anderer derartige Berechnung {@link #isTaskRunning läuft}. Der Titel wird im Fehlerdialog sowie als {@link #taskTitle} verwendet. */
	private void runTask(final String title, final FTTask task) {
		final var thread = new Thread(() -> {
			synchronized (this) {
				if (this.isTaskRunning) return;
				this.taskTitle = title;
				this.taskEntry = null;
				this.taskCount = 0;
				this.isTaskRunning = true;
				this.isTaskCanceled = false;
				EventQueue.invokeLater(this::execUpdateEnabled);
			}
			try {
				task.run();
			} catch (final CancellationException ignore) {

			} catch (final Throwable error) {
				EventQueue.invokeLater(() -> this.createDialog() //
					.withTitle(title) //
					.withMessage("<html><b>Unerwarteter Fehler</b><br>%s</html>", error.toString().replaceAll("&", "&amp;").replaceAll("<", "&lt;")) //
					.withButton("Okay"));
			} finally {
				synchronized (this) {
					this.taskTitle = null;
					this.taskEntry = null;
					this.taskCount = 0;
					this.isTaskRunning = false;
					this.isTaskCanceled = false;
					EventQueue.invokeLater(this::execUpdateEnabled);
					if (this.taskCancel == null) return;
					this.taskCancel.dispose();
					this.taskCancel = null;
				}
			}
		});
		thread.setDaemon(true);
		thread.start();
	}

	/** Diese Methode führt die gegebene Berechnung {@code task} später aus. */
	private void runLater(final Runnable task) {
		EventQueue.invokeLater(task);
	}

	private void runDemo(final Runnable task) {
		final int stop = 300;
		final int step = 100;
		for (int i = 0; (i < stop) && !this.isTaskCanceled; i += step) {
			this.taskCount = stop - i;
			try {
				Thread.sleep(step);
			} catch (final InterruptedException e) {}
		}
		task.run();
	}

	private void execUpdateEnabled() {
		final var enabled = !this.isTaskRunning;
		this.inputArea.setEnabled(enabled);
		this.execUpdateEnabled(enabled, this.inputArea, this.inputMenu, this.tableArea, this.tableMenu);
		this.taskStop.setEnabled(!enabled && !this.isTaskCanceled);
	}

	private void execUpdateEnabled(final boolean value, final Component... targets) {
		for (final var target: targets) {
			target.setEnabled(value);
			if (target instanceof Container) {
				this.execUpdateEnabled(value, ((Container)target).getComponents());
			}
		}
	}

	private void execExportToClipboard(final List<File> fileList) {
		this.runLater(() -> {
			final var clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			clipboard.setContents(new Transferable() {

				@Override
				public boolean isDataFlavorSupported(final DataFlavor flavor) {
					for (final var item: this.getTransferDataFlavors())
						if (item.equals(flavor)) return true;
					return false;
				}

				@Override
				public DataFlavor[] getTransferDataFlavors() {
					return new DataFlavor[]{DataFlavor.javaFileListFlavor, DataFlavor.stringFlavor};
				}

				@Override
				public Object getTransferData(final DataFlavor flavor) throws UnsupportedFlavorException, IOException {
					if (DataFlavor.javaFileListFlavor.equals(flavor)) return fileList;
					if (DataFlavor.stringFlavor.equals(flavor)) return Strings.join("\n", Iterables.translate(fileList, File::getPath));
					throw new UnsupportedFlavorException(flavor);
				}

			}, null);
		});
	}

	void updateTask(final ActionEvent event) {
		if (this.isTaskRunning) {
			final String title = Objects.notNull(this.taskTitle, "?"), entry = String.valueOf(Objects.notNull(this.taskEntry, ""));
			this.taskInfo.setText("<html>" + title + " - " + this.taskCount + " - " + entry.replaceAll("\\\\", "\\<wbr>") + "</html>");
		} else {
			this.taskInfo.setText(" ");
		}
	}

	void setupImportInputs(final DropTargetDropEvent event) {
		if (!this.inputArea.isEnabled()) return;
		final Transferable transData = event.getTransferable();
		if (transData == null) return;
		event.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);
		this.startImportInputs(transData);
	}

	void setupImportInputs() {
		if (!this.inputArea.isEnabled()) return;
		final Transferable transData = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);
		if ((transData == null) || this.startImportInputs(transData)) return;
		this.inputArea.paste();
	}

	boolean startImportInputs(final Transferable transData) {
		if (!transData.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) return false;
		try {
			final var inputText = this.getInputText();
			@SuppressWarnings ("unchecked")
			final var fileList = (List<File>)transData.getTransferData(DataFlavor.javaFileListFlavor);
			this.enterImportInputs(inputText, fileList);
			return true;
		} catch (final Exception ignore) {}
		return false;
	}

	public void enterImportInputs(final String inputText, final List<File> fileList) {
		this.runDemo(() -> this.leaveImportInputs(inputText));
	}

	public void leaveImportInputs(final String inputText) {
		this.setInputText(inputText);
	}

	void setupCleanupExistingInputs() {
		this.createDialog()//
			.withTitle("Fehlerpfade erhalten") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Datenpfade zu existierenden Dateien bzw. Verzeichnissen wirklich verworfen werden?</b><br> " + //
				"Duplikate sowie relative Datenpfade werden ebenfalls verworfen. " + //
				"</html>" //
			) //
			.withButton("Ja", this::startCleanupExistingInputs) //
			.withButton("Nein");
	}

	void startCleanupExistingInputs() {
		final var inputText = this.getInputText();
		this.runTask("Fehlerpfaderhaltung", () -> this.enterCleanupExistingInputs(inputText));
	}

	public void enterCleanupExistingInputs(final String inputText) {
		this.runDemo(() -> this.leaveCleanupExistingInputs(inputText, 1234567, 7890));
	}

	public void leaveCleanupExistingInputs(final String keepText, final int validCount, int errorCount) {
		this.setInputText(keepText);
		this.createDialog() //
			.withTitle("Fehlerpfade erhalten") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Zeilen bleiben erhalten.<br> " + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount//
			) //
			.withButton("Okay");
	}

	void setupCleanupMissingInputs() {
		this.createDialog()//
			.withTitle("Fehlerpfade entfernen") //
			.withMessage("<html>" + //
				"<b>Sollen alle Datenpfade zu nicht existierenden Dateien bzw. Verzeichnissen wirklich verworfen werden?</b><br> " + //
				"Duplikate sowie relative Datenpfade werden ebenfalls verworfen. " + //
				"</html>" //
			) //
			.withButton("Ja", this::startCleanupMissingInputs) //
			.withButton("Nein");
	}

	void startCleanupMissingInputs() {
		final var inputText = this.getInputText();
		this.runTask("Fehlerpfadentfernung", () -> this.enterCleanupMissingInputs(inputText));
	}

	public void enterCleanupMissingInputs(final String inputText) {
		this.runDemo(() -> this.leaveCleanupMissingInputs(inputText, 1234567, 7890));
	}

	public void leaveCleanupMissingInputs(final String inputText, final int validCount, final int errorCount) {
		this.setInputText(inputText);
		this.createDialog() //
			.withTitle("Fehlerpfade entfernt") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Zeilen bleiben erhalten.<br> " + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount//
			) //
			.withButton("Okay");
	}

	void _1_3_setupExportInputsToClipboard() {
		this._1_3_startExportInputsToClipboard();
	}

	void _1_3_startExportInputsToClipboard() {
		final var inputText = this.getInputText();
		this.runTask("Exportieren", () -> this.enterExportInputsToClipboard(inputText));
	}

	public void enterExportInputsToClipboard(final String inputText) {
		this.runDemo(() -> this.leaveExportInputsToClipboard(Collections.emptyList()));
	}

	public void leaveExportInputsToClipboard(final List<File> fileList) {
		this.execExportToClipboard(fileList);
	}

	void _1_4_setupResolveInputsToFiles() {
		this.createDialog()//
			.withTitle("Dateien auflösen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Verzeichnispfade wirklich durch die Pfade aller darin enthaltenen Dateien ersetzt werden?</b><br> " + //
				"Die Dateiauflösung wird in allen Unterverzeichnissen fortgesetzt. " + //
				"Duplikate sowie relative Datenpfade werden verworfen. " + //
				"Dateipfade bleiben erhalten. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_1_4_startResolveInputToFiles) //
			.withButton("Nein");
	}

	void _1_4_startResolveInputToFiles() {
		final var inputText = this.getInputText();
		this.runTask("Dateiauflösung", () -> this.enterResolveInputToFiles(inputText));
	}

	public void enterResolveInputToFiles(final String inputText) {
		this.runDemo(() -> this.leaveResolveInputToFiles(inputText, 1234567, 7890));
	}

	public void leaveResolveInputToFiles(final String inputText, final int inputCount, final int deleteCount) {
		this.setInputText(inputText);
		this.createDialog() //
			.withTitle("Dateien aufgelöst") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Dateipfade wurden ermittelt.<br> " + //
				"<b>%,d</b> Datenpfade wurden verworfen." + //
				"</html>", //
				inputCount, deleteCount //
			) //
			.withButton("Okay");
	}

	void _1_5_setupResolveInputsToFolders() {
		this.createDialog()//
			.withTitle("Verzeichnisse auflösen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Verzeichnispfade wirklich um die Pfade aller darin enthaltenen Verzeichnisse ergänzt werden?</b><br> " + //
				"Die Verzeichnisauflösung wird in allen Unterverzeichnissen fortgesetzt. " + //
				"Duplikate sowie relative Datenpfade werden verworfen. " + //
				"Dateipfade werden ebenfalls verworfen. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_1_5_startResolveInputToFolders) //
			.withButton("Nein");
	}

	void _1_5_startResolveInputToFolders() {
		final var inputText = this.getInputText();
		this.runTask("Verzeichnisauflösung", () -> this.enterResolveInputToFolders(inputText));
	}

	public void enterResolveInputToFolders(final String inputText) {
		this.runDemo(() -> this.leaveResolveInputToFolders(inputText, 1234567, 7890));
	}

	public void leaveResolveInputToFolders(final String inputText, final int inputCount, final int deleteCount) {
		this.setInputText(inputText);
		this.createDialog() //
			.withTitle("Verzeichnisse aufgelöst") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Verzeichnispfade wurden ermittelt.<br> " + //
				"<b>%,d</b> Datenpfade wurden verworfen." + //
				"</html>", //
				inputCount, deleteCount //
			) //
			.withButton("Okay");
	}

	void _2_1_setupReplaceTableWithInputs() {
		this.createDialog()//
			.withTitle("Eingabepfade übertragen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Datenpfade wirklich als Quell- und Zielpfade in die Pfadtabelle übernommen werden?</b><br> " + //
				"Duplikate sowie relative Datenpfade werden ignoriert. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_2_1_startReplaceTableWithInputs) //
			.withButton("Nein");
	}

	void _2_1_startReplaceTableWithInputs() {
		final var inputText = this.getInputText();
		this.runTask("Eingabepfaddübertragung", () -> this.enterTransferInputs(inputText));
	}

	public void enterTransferInputs(final String inputText) {
		this.runDemo(() -> this.leaveTransferInputs("", 1234567, 7890));
	}

	public void leaveTransferInputs(final String tableText, final int validCount, final int errorCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Eingabepfade übertragen") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Eingabepfade wurden übernommen.<br> " + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount //
			) //
			.withButton("Okay");
	}

	void _2_2_setupCreateTableWithClones() {
		this.createDialog() //
			.withTitle("Duplikate übernehmen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Dateien auf Duplikate hin untersucht werden?</b><br> " + //
				"Beim Suchen von Duplikaten werden alle Dateien zunächst bezüglich ihrer <u>Dateigröße</u> partitioniert. " + //
				"Die Dateien innerhalb einer Dateigrößenpartition werden dann bezüglich ihres <u>SHA-256-Streuwerts</u> partitioniert. " + //
				"Dieser Streuwert wird aus höchstens der unten eingestellten Anzanl an Bytes ab dem Dateibeginn berechnet. " + //
				"Schließlich werden die Dateien innerhalb einer Streuwertpartition nach ihrem <u>Dateiinhalt</u> partitioniert. " + //
				"Als Dateiinhalt wird höchstens die unten eingestellte Anzanl an Bytes ab dem Dateibeginn betrachtet.<br>" + //
				"Der Pfad der ersten Datei einer Dateiinhaltspartition wird als Quellpfad verwendet. " + //
				"Die Pfade der anderen Dateien der Partitionen werden diesem als Zielpfade zugeordnet. " + //
				"Jedem Zielpfad wird zudem der Streuwert sowie die Dateigröße angefügte." + //
				"Quellpfade ohne Zielpfade werden verworfen. Duplikate sowie Relative Dateipfade werden verworfen." + //
				"</html>" //
			) //
			.withOption("Puffergröße für Streuwert", this.hashSizeModel) //
			.withOption("Puffergröße für Dateivergleich", this.testSizeModel) //
			.withButton("Ja", this::_2_2_startCreateTableWithClones) //
			.withButton("Nein");
	}

	void _2_2_startCreateTableWithClones() {
		final var inputText = this.getInputText();
		final var hashSize = (long)this.hashSizeModel.getValue();
		final var testSize = (long)this.testSizeModel.getValue();
		this.runTask("Duplikateübernahme", () -> this.enterCreateTableWithClones(inputText, hashSize, testSize));
	}

	public void enterCreateTableWithClones(final String inputText, final long hashSize, final long testSize) throws Exception {
		this.runDemo(() -> this.leaveCreateTableWithClones("", 1234567, 7890));
	}

	public void leaveCreateTableWithClones(final String tableText, final int entryCount, final int errorCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Duplikate übernommen") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Duplikate wurden gefunden.<br> " + //
				"<b>%,d</b> Datenpfade konnten nicht verarbeitet werden." + //
				"</html>", //
				entryCount, errorCount //
			) //
			.withButton("Okay");
	}

	void _3_1_setupDeleteInputFiles() {
		this.createDialog()//
			.withTitle("Dateien löschen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Dateien wirklich endgültig gelöscht werden?</b><br> " + //
				"Die Zeilen gelöschter Dateien werden aus der Pfadliste entfert. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_3_1_startDeleteInputFiles) //
			.withButton("Nein");
	}

	void _3_1_startDeleteInputFiles() {
		final var inputText = this.getInputText();
		this.runTask("Dateilöschung", () -> this.enterDeleteInputFilesHard(inputText));
	}

	public void enterDeleteInputFilesHard(final String inputText) {
		this.runDemo(() -> this.leaveDeleteInputFilesHard(inputText, 1234567, 7890));
	}

	public void leaveDeleteInputFilesHard(final String inputText, final int validCount, final int errorCount) {
		this.setInputText(inputText);
		this.createDialog() //
			.withTitle("Dateien gelöscht") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Dateien wurden gelöscht.<br> " + //
				"<b>%,d</b> Datenpfade konnten nicht verarbeitet werden." + //
				"</html>", //
				errorCount, validCount //
			) //
			.withButton("Okay");
	}

	void _3_2_setupRecycleInputFiles() {
		this.createDialog()//
			.withTitle("Dateien recyceln") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Dateien wirklich in den Papierkorb verschoben werden?</b><br> " + //
				"Die Zeilen recycelter Dateien werden aus der Pfadliste entfert. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_3_1_startDeleteInputFiles) //
			.withButton("Nein");
	}

	void _3_2_startRecycleInputFiles() {
		final var inputText = this.getInputText();
		this.runTask("Dateirecyclung", () -> this.enterDeleteInputFilesSoft(inputText));
	}

	public void enterDeleteInputFilesSoft(final String inputText) {
		this.runDemo(() -> this.leaveDeleteInputFilesSoft(inputText, 1234567, 7890));
	}

	public void leaveDeleteInputFilesSoft(final String inputText, final int inputCount, final int recycleCount) {
		this.setInputText(inputText);
		this.createDialog() //
			.withTitle("Dateien recycelt") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Dateien wurden recycelt.<br> " + //
				"<b>%,d</b> Datenpfade konnten nicht verarbeitet werden." + //
				"</html>", //
				recycleCount, inputCount //
			) //
			.withButton("Okay");
	}

	void setupRefreshInputFiles() {
		this.createDialog()//
			.withTitle("Dateien erneuern") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle alten Dateien wirklich erneuert werden?</b><br> " + //
				"Beim Erneuern werden alle Dateien, die vor mehr als der unten angegebenen Anzahl an Tagen erstellt wurden, kopiert und durch ihre Kopien ersetzt. " + //
				"Die dazu temporär erzeugten Kopien tragen die Dateiendung <u>.tempcopy</u>. " + //
				"Die Zeilen erneuerter Dateien werden aus der Pfadliste entfert. " + //
				"</html>" //
			) //
			.withOption("Dateialter in Tagen", this.copyTimeModel) //
			.withButton("Ja", this::startRefreshInputFiles) //
			.withButton("Nein");
	}

	void startRefreshInputFiles() {
		final var inputText = this.getInputText();
		final var copyTime = (long)this.copyTimeModel.getValue();
		this.runTask("Dateierneuerung", () -> this.enterRefreshInputFiles(inputText, copyTime));
	}

	public void enterRefreshInputFiles(final String inputText, final long copyTime) {
		this.runDemo(() -> this.leaveRefreshInputFiles(inputText, 1234567, 7890));
	}

	public void leaveRefreshInputFiles(final String inputText, final int inputCount, final int refreshCount) {
		this.setInputText(inputText);
		this.createDialog() //
			.withTitle("Dateien erneuert") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Dateien wurden erneuert.<br> " + //
				"<b>%,d</b> Datenpfade wurden nicht verarbeitet." + //
				"</html>", //
				refreshCount, inputCount //
			) //
			.withButton("Okay");
	}

	void _4_1_setupDeleteInputFolders() {
		this.createDialog()//
			.withTitle("Verzeichnisse löschen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle leeren Verzeichnisse wirklich endgültig gelöscht werden?</b><br> " + //
				"Die Zeilen gelöschter Verzeichnisse werden aus der Pfadliste entfert. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_4_1_startDeleteInputFolders) //
			.withButton("Nein");
	}

	void _4_1_startDeleteInputFolders() {
		final String inputText = this.getInputText();
		this.runTask("Verzeichnislöschung", () -> this.enterDeleteInputFoldersHard(inputText));
	}

	public void enterDeleteInputFoldersHard(final String inputText) {
		this.runDemo(() -> this.leaveDeleteInputFoldersHard(inputText, 1234567, 7890));
	}

	public void leaveDeleteInputFoldersHard(final String inputText, final int inputCount, final int deleteCount) {
		this.setInputText(inputText);
		this.createDialog() //
			.withTitle("Verzeichnisse gelöscht") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Verzeichnisse wurden gelöscht.<br> " + //
				"<b>%,d</b> Datenpfade konnten nicht verarbeitet werden." + //
				"</html>", //
				deleteCount, inputCount //
			) //
			.withButton("Okay");
	}

	void _4_2_setupRecycleInputFolders() {
		this.createDialog()//
			.withTitle("Verzeichnisse recyceln") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle leeren Verzeichnisse wirklich in den Papierkorb verschoben werden?</b><br> " + //
				"Die Zeilen recycelter Verzeichnisse werden aus der Pfadliste entfert. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_4_2_startRecycleInputFolders) //
			.withButton("Nein");
	}

	void _4_2_startRecycleInputFolders() {
		final var inputText = this.getInputText();
		this.runTask("Verzeichnisrecyclung", () -> this.enterDeleteInputFoldersSoft(inputText));
	}

	public void enterDeleteInputFoldersSoft(final String inputText) {
		this.runDemo(() -> this.leaveDeleteInputFoldersSoft(inputText, 1234567, 7890));
	}

	public void leaveDeleteInputFoldersSoft(final String inputText, final int inputCount, final int recycleCount) {
		this.setInputText(inputText);
		this.createDialog() //
			.withTitle("Verzeichnisse recycelt") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Verzeichnisse wurden recycelt.<br>" + //
				"<b>%,d</b> Datenpfade konnten nicht verarbeitet werden." + //
				"</html>", //
				recycleCount, inputCount //
			) //
			.withButton("Okay");
	}

	void _5_1_setupReplaceSourcesWithTargets() {
		this.createDialog()//
			.withTitle("Quellpfade ersetzen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Quellpfade durch deren Zielpfade ersetzt werden?</b><br> " + //
				"</html>" //
			) //
			.withButton("Ja", this::_5_1_startReplaceSourcesWithTargets) //
			.withButton("Nein");
	}

	void _5_1_startReplaceSourcesWithTargets() {
		final var tableText = this.getTableText();
		this.runTask("Quellpfadersetzung", () -> this.enterReplaceSourcesWithTargets(tableText));
	}

	public void enterReplaceSourcesWithTargets(final String tableText) {
		this.runDemo(() -> this.leaveReplaceSourcesWithTargets(tableText, 1234567, 7890));
	}

	public void leaveReplaceSourcesWithTargets(final String tableText, final int validCount, final int errorCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Quellpfade ersetzt") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Quellpfade wurden ersetzt.<br>" + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount //
			) //
			.withButton("Okay");
	}

	void _5_2_setupExchangeSourcesWithTargets() {
		this.createDialog()//
			.withTitle("Quellpfade tauschen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Quellpfade mit deren Zielpfaden getauscht werden?</b><br> " + //
				"</html>" //
			) //
			.withButton("Ja", this::_5_2_startExchangeSourcesWithTargets) //
			.withButton("Nein");
	}

	void _5_2_startExchangeSourcesWithTargets() {
		final var tableText = this.getTableText();
		this.runTask("Quellpfadtauschung", () -> this.enterExchangeSourcesWithTargets(tableText));
	}

	public void enterExchangeSourcesWithTargets(final String tableText) {
		this.runDemo(() -> this.leaveExchangeSourcesWithTargets(tableText, 1234567, 7890));
	}

	public void leaveExchangeSourcesWithTargets(final String tableText, final int validCount, final int errorCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Quellpfade getauscht") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Quellpfade wurden getauscht.<br>" + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount //
			) //
			.withButton("Okay");
	}

	void _5_3_setupReplaceInputsWithSources() {
		this.createDialog()//
			.withTitle("Quellpfade übertragen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Eingabepfade in der Pfadliste mit allen Quellpfaden ersetzt werden?</b> " + //
				"</html>" //
			) //
			.withButton("Ja", this::_5_3_startReplaceInputsWithSources) //
			.withButton("Nein");
	}

	void _5_3_startReplaceInputsWithSources() {
		final var tableText = this.getTableText();
		this.runTask("Quellpfaddübertragung", () -> this.enterTransferSources(tableText));
	}

	public void enterTransferSources(final String tableText) {
		this.runDemo(() -> this.leaveTransferSources("", 1234567, 7890));
	}

	public void leaveTransferSources(final String inputText, final int validCount, final int errorCount) {
		this.setInputText(inputText);
		this.createDialog() //
			.withTitle("Quellpfade übertragen") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Quellpfade wurden übernommen.<br> " + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount //
			) //
			.withButton("Okay");
	}

	void _5_4_setupExportSourcesToClipboard() {
		this._5_4_startExportSourcesToClipboard();
	}

	void _5_4_startExportSourcesToClipboard() {
		final var tableText = this.getTableText();
		this.runTask("Quellpfadexport", () -> this.enterExportSourcesToClipboard(tableText));
	}

	public void enterExportSourcesToClipboard(final String inputText) {
		this.runDemo(() -> this.leaveExportSourcesToClipboard(Collections.emptyList()));
	}

	public void leaveExportSourcesToClipboard(final List<File> fileList) {
		this.execExportToClipboard(fileList);
	}

	void _5_5_setupCleanupExistingSources() {
		this.createDialog()//
			.withTitle("Fehlerquellpfade erhalten") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Quellpfade zu existierenden Dateien bzw. Verzeichnissen wirklich verworfen werden?</b><br> " + //
				"Relative Datenpfade werden ebenfalls verworfen. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_5_5_startCleanupExistingSources) //
			.withButton("Nein");
	}

	void _5_5_startCleanupExistingSources() {
		final var inputText = this.getInputText();
		this.runTask("Fehlerquellpfaderhaltung", () -> this.enterCleanupExistingSources(inputText));
	}

	public void enterCleanupExistingSources(final String tableText) {
		this.runDemo(() -> this.leaveCleanupExistingSources(tableText, 1234567, 7890));
	}

	public void leaveCleanupExistingSources(final String tableText, final int validCount, final int errorCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Fehlerquellpfade erhalten") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Zeilen bleiben erhalten.<br> " + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount//
			) //
			.withButton("Okay");
	}

	void _5_6_setupCleanupMissingSources() {
		this.createDialog()//
			.withTitle("Fehlerquellpfade entfernen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Quellpfade zu nicht existierenden Dateien bzw. Verzeichnissen wirklich verworfen werden?</b><br> " + //
				"Relative Datenpfade werden ebenfalls verworfen. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_5_6_startCleanupMissingSources) //
			.withButton("Nein");
	}

	void _5_6_startCleanupMissingSources() {
		final var inputText = this.getInputText();
		this.runTask("Fehlerquellpfadentfernung", () -> this.enterCleanupExistingSources(inputText));
	}

	public void enterCleanupMissingSources(final String tableText) {
		this.runDemo(() -> this.leaveCleanupMissingSources(tableText, 1234567, 7890));
	}

	public void leaveCleanupMissingSources(final String tableText, final int validCount, final int errorCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Fehlerquellpfade entfernt") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Zeilen bleiben erhalten.<br> " + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount//
			) //
			.withButton("Okay");
	}

	void _6_1_setupReplaceTargetsWithSources() {
		this.createDialog()//
			.withTitle("Zielpfade ersetzen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Zielpfade mit deren Quellpfaden ersetzt werden?</b> " + //
				"</html>" //
			) //
			.withButton("Ja", this::_6_1_startReplaceTargetsWithSources) //
			.withButton("Nein");
	}

	void _6_1_startReplaceTargetsWithSources() {
		final var tableText = this.getTableText();
		this.runTask("Zielpfadersetzung", () -> this.enterReplaceTargetsWithSources(tableText));
	}

	public void enterReplaceTargetsWithSources(final String tableText) {
		this.runDemo(() -> this.leaveReplaceTargetsWithSources(tableText, 1234567, 7890));
	}

	public void leaveReplaceTargetsWithSources(final String tableText, final int validCount, final int errorCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Zielpfade ersetzt") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Zielpfade wurden ersetzt.<br>" + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount //
			) //
			.withButton("Okay");
	}

	void _6_2_setupExchangeTargetsWithSources() {
		this.createDialog()//
			.withTitle("Zielpfade tauschen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Zielpfade mit deren Quellpfaden getauscht werden?</b> " + //
				"</html>" //
			) //
			.withButton("Ja", this::_6_2_startExchangeTargetsWithSources) //
			.withButton("Nein");
	}

	void _6_2_startExchangeTargetsWithSources() {
		final var tableText = this.getTableText();
		this.runTask("Zielpfadtauschung", () -> this.enterExchangeTargetsWithSources(tableText));
	}

	public void enterExchangeTargetsWithSources(final String tableText) {
		this.runDemo(() -> this.leaveExchangeTargetsWithSources(tableText, 1234567, 7890));
	}

	public void leaveExchangeTargetsWithSources(final String tableText, final int validCount, final int errorCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Quellpfade getauscht") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Zielpfade wurden getauscht.<br>" + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount //
			) //
			.withButton("Okay");
	}

	void _6_3_setupReplaceInputsWithTargets() {
		this.createDialog()//
			.withTitle("Zielpfade übertragen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Zielpfade wirklich als Eingabepfade in die Pfadliste übernommen werden?</b><br> " + //
				"Duplikate sowie relative Zielpfade werden ignoriert. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_6_3_startReplaceInputsWithTargets) //
			.withButton("Nein");
	}

	void _6_3_startReplaceInputsWithTargets() {
		final var tableText = this.getTableText();
		this.runTask("Zielpfaddübertragung", () -> this.enterTransferTargets(tableText));
	}

	public void enterTransferTargets(final String tableText) {
		this.runDemo(() -> this.leaveTransferTargets("", 1234567, 7890));
	}

	public void leaveTransferTargets(final String inputText, final int validCount, final int errorCount) {
		this.setInputText(inputText);
		this.createDialog() //
			.withTitle("Zielpfade übertragen") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Zielpfade wurden übernommen.<br> " + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount //
			) //
			.withButton("Okay");
	}

	void _6_4_setupExportTargetsToClipboard() {
		this._6_4_startExportTargetsToClipboard();
	}

	void _6_4_startExportTargetsToClipboard() {
		final var tableText = this.getTableText();
		this.runTask("Zielpfadexport", () -> this.enterExportTargetsToClipboard(tableText));
	}

	public void enterExportTargetsToClipboard(final String tableText) {
		this.runDemo(() -> this.leaveExportTargetsToClipboard(Collections.emptyList()));
	}

	public void leaveExportTargetsToClipboard(final List<File> fileList) {
		this.execExportToClipboard(fileList);
	}

	void _6_5_setupCreateTargetsWithChangenames() {
		// TODO
		this.createDialog() //
			.withTitle("Zeitnamen ableiten") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen die Zielnamen wirklich aus den Änderungszeitpunkten der Quelldateien abgeleitet werden?</b><br> " + //
				"Die verwendeten Zeitpunkte entsprechen dabei den um die unten angegebene Anzahl an Sekunden in die Zukunft " + //
				"verschobenen Änderungszeitpunkten der Quelldateien. Die Zielpfade haben dabei das Format <u>{PP}\\JJJJ-MM-TT hh.mm.ss{FE}</u>, " + //
				"wobei {PP} für den Zielelternverzeichnispfad und {FE} für die kleingeschriebene Zieldateinamenserweiterung stehen." + //
				"</html>" //
			) //
			.withOption("Zeitkorrektur", this.moveTimeModel) //
			.withButton("Ja", this::_6_5_startCreateTargetsWithChangenames) //
			.withButton("Nein");
	}

	void _6_5_startCreateTargetsWithChangenames() {
		final var tableText = this.getTableText();
		final var moveTime = (long)this.moveTimeModel.getValue();
		this.runTask("Zeitnamensableitung", () -> this._6_5_enterCreateTargetsWithChangenames(tableText, moveTime));
	}

	public void _6_5_enterCreateTargetsWithChangenames(final String tableText, final long moveTime) {
		this.runDemo(() -> this._6_5_leaveCreateTargetsWithChangenames(tableText, 1234567));
	}

	public void _6_5_leaveCreateTargetsWithChangenames(final String tableText, final int changeCount) {
		// TODO
	}

	void _6_6_setupCreateTargetsWithChangepaths() {
		// TODO
		this.createDialog() //
			.withTitle("Zeitpfade ableiten") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen die Änderungszeitpunkte der Quelldateien wirklich in deren Zielpfade überführt werden?</b><br> " + //
				"TODO" + //
				"</html>" //
			) //
			.withOption("Zeitkorrektur", this.moveTimeModel) //
			.withButton("Ja", this::_6_6_startCreateTargetsWithChangepaths) //
			.withButton("Nein");
	}

	void _6_6_startCreateTargetsWithChangepaths() {
		final var tableText = this.getTableText();
		final var moveTime = (long)this.moveTimeModel.getValue();
		this.runTask("Zeitpfadableitung", () -> this._6_6_enterCreateTargetsWithChangepaths(tableText, moveTime));
	}

	public void _6_6_enterCreateTargetsWithChangepaths(final String tableText, final long moveTime) {
		this.runDemo(() -> this._6_6_leaveCreateTargetsWithChangepaths(tableText, 1234567, 7890));
	}

	public void _6_6_leaveCreateTargetsWithChangepaths(final String tableText, final int tableSize, final int errorCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Zeitpfade abgeleitet") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Zeilen wurden angepasst.<br> " + //
				"<b>%s</b> Zeilen konnten nicht angepasst werden." + //
				"</html>", //
				tableSize, errorCount //
			) //
			.withButton("Okay");
	}

	void _6_7_setupCleanupExistingTargets() {
		this.createDialog()//
			.withTitle("Fehlerzielpfade erhalten") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Zielpfade zu existierenden Dateien bzw. Verzeichnissen wirklich verworfen werden?</b><br> " + //
				"Relative Zielpfade werden ebenfalls verworfen. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_6_7_startCleanupExistingTargets) //
			.withButton("Nein");
	}

	void _6_7_startCleanupExistingTargets() {
		final var tableText = this.getTableText();
		this.runTask("Fehlerzielerhaltung", () -> this.enterCleanupExistingTargets(tableText));
	}

	public void enterCleanupExistingTargets(final String tableText) {
		this.runDemo(() -> this.leaveCleanupExistingTargets(tableText, 1234567, 7890));
	}

	public void leaveCleanupExistingTargets(final String tableText, final int validCount, final int errorCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Fehlerzielpfade erhalten") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Zeilen bleiben erhalten.<br> " + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount//
			) //
			.withButton("Okay");
	}

	void _6_8_setupCleanupMissingTargets() {
		this.createDialog()//
			.withTitle("Fehlerzielpfade entfernen") //
			.withMessage("<html>" + //
				"<b>Sollen alle Zielpfade zu nicht existierenden Dateien bzw. Verzeichnissen wirklich verworfen werden?</b><br> " + //
				"Relative Zielpfade werden ebenfalls verworfen. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_6_8_startCleanupMissingTargets) //
			.withButton("Nein");
	}

	void _6_8_startCleanupMissingTargets() {
		final var tableText = this.getTableText();
		this.runTask("Fehlerzielentfernung", () -> this.enterCleanupMissingTargets(tableText));
	}

	public void enterCleanupMissingTargets(final String tableText) {
		this.runDemo(() -> this.leaveCleanupMissingTargets(tableText, 1234567, 7890));
	}

	public void leaveCleanupMissingTargets(final String tableText, final int validCount, final int errorCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Fehlerzielpfade entfernt") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Zeilen bleiben erhalten.<br> " + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				validCount, errorCount//
			) //
			.withButton("Okay");
	}

	void _7_1_setupShowSourcesAndTarets() {
		this.createDialog() //
			.withTitle("Dateipaare anzeigen") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen die Quell- und Zieldateien wirklich angezeigt werden?</b><br> " + //
				"Die Dateien werden dabei als Symlinks in ein temporäres Verzeichnis eingefügt. " + //
				"Die Quelldateien werden als <u>-ORIGINAL-</u> gekennzeichnet, die Zieldateien als <u>-DUPLIKAT-</u>. " + //
				"Das temporäre Verzeichnis wird abschließend angezeigt.<br>" + //
				"Das Erzeugen von Symlinks benötigt Administrator-Rechte!" + //
				"</html>" //
			) //
			.withButton("Ja", this::_7_1_startShowSourceAndTaret) //
			.withButton("Nein");
	}

	void _7_1_startShowSourceAndTaret() {
		final var tableText = this.tableArea.getText();
		this.runTask("Dateianzeigen", () -> this.enterShowSourceAndTaret(tableText));
	}

	public void enterShowSourceAndTaret(final String tableText) throws Exception {
		this.runDemo(() -> this.leaveShowSourceAndTaret("", 0));
	}

	public void leaveShowSourceAndTaret(final Object parentPath, final int entryCount) {
		this.createDialog() //
			.withTitle("Anzeigen abgeschlossen") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Symlinks wurden in das folgende Verzeichnis eingefügt:<br>" + //
				"<b>%s</b>" + //
				"</html>", //
				entryCount, parentPath //
			) //
			.withButton("Okay");
	}

	void _7_2_setupCopySourcesToTargets() {
		this.createDialog() //
			.withTitle("Dateien kopieren") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Dateien wirklich nicht ersetzend kopiert werden?</b><br> " + //
				"Die Zeilen erfolgreich kopierter Dateien werden aus der Pfadtabelle entfernt. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_7_2_startCopySourcesToTargets) //
			.withButton("Nein");
	}

	void _7_2_startCopySourcesToTargets() {
		final var tableText = this.getTableText();
		this.runTask("Dateikopieren", () -> this.enterCopySourcesToTargets(tableText));
	}

	public void enterCopySourcesToTargets(final String tableText) {
		this.runDemo(() -> this.leaveCopySourcesToTargets(tableText, 1234567, 7890));
	}

	public void leaveCopySourcesToTargets(final String tableText, final int entryCount, final int copyCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Dateien kopiert") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Dateien wurden kopiert.<br> " + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				copyCount, entryCount //
			) //
			.withButton("Okay");
	}

	void _7_3_setupMoveSourcesToTargets() {
		this.createDialog() //
			.withTitle("Dateien verschieben") //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen alle Dateien wirklich nicht ersetzend verschoben werden?</b><br> " + //
				"Die Zeilen erfolgreich verschobener Dateien werden aus der Pfadtabelle entfernt. " + //
				"</html>" //
			) //
			.withButton("Ja", this::_7_3_startMoveSourcesToTargets) //
			.withButton("Nein");
	}

	void _7_3_startMoveSourcesToTargets() {
		final var tableText = this.getTableText();
		this.runTask("Dateiverschieben", () -> this.enterMoveSourcesToTargets(tableText));
	}

	public void enterMoveSourcesToTargets(final String tableText) {
		this.runDemo(() -> this.leaveMoveSourcesToTargets(tableText, 1234567, 7890));
	}

	public void leaveMoveSourcesToTargets(final String tableText, final int entryCount, final int moveCount) {
		this.setTableText(tableText);
		this.createDialog() //
			.withTitle("Dateien verschoben") //
			.withMessage("" + //
				"<html>" + //
				"<b>%,d</b> Dateien wurden verschoben.<br> " + //
				"<b>%,d</b> Zeilen konnten nicht verarbeitet werden." + //
				"</html>", //
				moveCount, entryCount //
			) //
			.withButton("Okay");
	}

	void _8_1_setupCancelProcess(final ActionEvent event) {
		this.taskCancel = this.createDialog() //
			.withTitle(Objects.notNull(this.taskTitle, "Abbrechen")) //
			.withMessage("" + //
				"<html>" + //
				"<b>Sollen der Vorgang wirklich abgebrochen werden?</b> " + //
				"</html>" //
			) //
			.withButton("Ja", this::_8_1_startCancelProcess) //
			.withButton("Nein");
	}

	synchronized void _8_1_startCancelProcess() {
		if (this.isTaskCanceled || !this.isTaskRunning) return;
		this.isTaskCanceled = true;
		this.runLater(this::execUpdateEnabled);
	}

	private void _3_1_setupDeleteSourceFiles //
	() {
	}

	private void _3_2_setupRecycleSourceFiles //
	() {
	}

	private void _3_1_setupDeleteTargetFiles //
	() {
	}

	private void _3_2_setupRecycleTargetFiles //
	() {
	}

	private void _4_1_setupDeleteSourceFolders //
	() {
	}

	private void _4_2_setupRecycleSourceFolders //
	() {
	}

	private void _4_1_setupDeleteTargetFolders //
	() {
	}

	private void _4_2_setupRecycleTargetFolders //
	() {
	}

	public void enterDeleteSourceFilesHard(String tableText) {
	}

	public void enterDeleteSourceFoldersHard(String tableText) {
	}

	public void leaveDeleteSourceFoldersHard(String tableText, int validCount, int errorCount) {
	}

	public void leaveDeleteSourceFilesHard(String tableText, int validCount, int errorCount) {
	}

	public void enterDeleteTargetFilesHard(String tableText) {
	}
	
	public void enterDeleteTargetFoldersHard(String tableText) {
	}
	
	public void leaveDeleteTargetFoldersHard(String tableText, int validCount, int errorCount) {
	}
	
	public void leaveDeleteTargetFilesHard(String tableText, int validCount, int errorCount) {
	}
	
}
