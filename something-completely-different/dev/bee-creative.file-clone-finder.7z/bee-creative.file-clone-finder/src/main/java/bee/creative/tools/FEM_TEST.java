package bee.creative.tools;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;
import bee.creative.fem.FEMDomain;
import bee.creative.util.HashMapIO;
import bee.creative.util.Parser.Result;
import bee.creative.util.Parser.Token;
import bee.creative.util.Tester;
import java.awt.Font;

public class FEM_TEST extends JFrame {

	private final JPanel contentPane;

	private final JTextPane text;

	HashMapIO<Color> style = new HashMapIO<>();

	public static void main(final String[] args) throws Exception {
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				try {
					final FEM_TEST frame = new FEM_TEST();
					frame.setVisible(true);
				} catch (final Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/** Create the frame. */
	public FEM_TEST() {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(100, 100, 450, 300);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.contentPane.setLayout(new BorderLayout(0, 0));
		this.setContentPane(this.contentPane);

		final JScrollPane scrollPane = new JScrollPane();
		this.contentPane.add(scrollPane);

		this.text = new JTextPane();
		text.setFont(new Font("Courier New", Font.PLAIN, 24));
		this.text.setText("\r\ngetVar{:system.GET_VAR($1)};\r\n\r\n\r\n<das ist ein beispeil>\r\n{a; b: istGleich($a; $b)};\r\n\r\n'lalala';\r\n\r\nconst{: [\r\n  [\"Ereigniszeitpunkt\"; \"Ereignis\"; \"Auswahl\"];\r\n  [\r\n    \"2021-06-03T13:57:25+02:00\";\r\n    \"Chipkarte\";\r\n    [\r\n      [\"KA_E6\"; \"Berechtigung\"];\r\n      [\r\n        0xE681F7E703C00103C281C50000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000C7284B756E64656E646174656E2020202020202020202020202020202020202020202020202020202020;\r\n       [\"<liste><liste><text>Kennung</text><text>Tarifprodukt</text><text>ProduktAusgangsadapter</text><text>StartTarifpunkt</text><text>ZielTarifpunkt</text><text>Viaweg</text><text>Wegetext</text></liste><liste><text>BERECHTIGUNGSDATEN</text><liste><text>Element</text><text>130050</text><text>Monats-Ticket persönlich Preisstufe 1C</text><undefiniert></undefiniert></liste><undefiniert></undefiniert><liste><text>Element</text><text>1000</text><text>Aachen</text><undefiniert></undefiniert></liste><liste><text>Element</text><text>1000</text><text>Aachen</text><undefiniert></undefiniert></liste><liste><text>Element</text><text>1</text><text>direkt</text><undefiniert></undefiniert></liste><text>Preisstufe 1C, direkt</text></liste></liste>\"; \"<liste><liste><text>Kennung</text><text>Tarifprodukt</text><text>ProduktAusgangsadapter</text><text>StartTarifpunkt</text><text>ZielTarifpunkt</text><text>Viaweg</text><text>Wegetext</text></liste><liste><text>BERECHTIGUNGSDATEN</text><liste><text>Element</text><text>110013</text><text>Einzel-Ticket Erwachsene Preisstufe 1</text><undefiniert></undefiniert></liste><undefiniert></undefiniert><undefiniert></undefiniert><undefiniert></undefiniert><undefiniert></undefiniert><text>Preisstufe 1</text></liste></liste>\"]\r\n      ]\r\n    ]\r\n  ]\r\n]};\r\n\r\nerzeugeVialisteMitReisewunsch{Reisewunsch: berechneWertMit(\r\n  ermittleProduktdatenVonReisewunsch($Reisewunsch);\r\n  ermittleStarthaltestelleVonReisewunsch($Reisewunsch);\r\n  ermittleZielhaltestelleVonReisewunsch($Reisewunsch);\r\n  {Produktdaten; Startadapter; Zieladapter: berechneWertMit(\r\n    ermittleTarifVonProduktdaten($Produktdaten);\r\n    ermittleProduktVonProduktdaten($Produktdaten);\r\n    {Tarif; Produkt: berechneWertMit(\r\n      ermittleTarifmodulVonTarifdaten(ermittleTarifdaten($Tarif));\r\n      {Tarifmodul: berechneWertMit(\r\n        ermittleObjektZuAdapter($Startadapter; $Tarifmodul);\r\n        ermittleObjektZuAdapter($Zieladapter; $Tarifmodul);\r\n        ermittleObjektZuAdapter($Produkt; $Tarifmodul);\r\n        {Startobjekt; Zielobjekt; Produktobjekt: berechneWertMit(\r\n          erzeugeAnfrage(\r\n            /Anfrageart/ \"ASEAG_ANGEBOTSINFO_NACH_EINGABEDATEN_FUER_RELATION-1.0\";\r\n            /Eingabedaten/ erzeugeEingabedaten(\r\n              /Version/ null;\r\n              /Pv/ null;\r\n              /Fkvp/ null;\r\n              /Produkt/ erzeugeElement(/Nr/ ermittleNr($Produktobjekt); /Name/ null; /Domaene/ null);\r\n              /Produktbezeichnung/ null;\r\n              /Gebietsparameter/ null;\r\n              /Nutzerparameter/ null;\r\n              /Zeitparameter/ null;\r\n              /Serviceparameter/ null;\r\n              /Zusatzparameter/ null;\r\n              /Gueltigkeitsbeginn/ null;\r\n              /Gueltigkeitsende/ null;\r\n              /Gueltigkeitsraum/ erzeugeListe(\r\n                erzeugeElement(/Nr/ ermittleNr($Startobjekt); /Name/ null; /Domaene/ null);\r\n                erzeugeElement(/Nr/ ermittleNr($Zielobjekt); /Name/ null; /Domaene/ null)\r\n              );\r\n              /Flaechengruppenliste/ null;\r\n              /Erweiterungsliste/ null\r\n            );\r\n            /Reisendenliste/ null;\r\n            /Verbindungsliste/ null;\r\n            /Berechtigungsliste/ null;\r\n            /Nutzungszustandsliste/ null;\r\n            /Einschraenkung/ null;\r\n            /Erweiterungsliste/ null\r\n          );\r\n          {Anfragedaten: berechneWertMit(\r\n            wennFehler(\r\n              ermittleProduktermittlungsergebnisdaten(ermittleNr($Tarif); aktuellerZeitpunkt(); $Anfragedaten);\r\n              null\r\n            );\r\n            {Antwortdaten: berechneWertMit(\r\n              ermittleTicketdatenlisteVonAntwort($Antwortdaten);\r\n              ermittleAngebotsdatenlisteVonAntwort($Antwortdaten);\r\n              {Ticketdatenliste; Angebotsdatenliste: berechneWertMit(\r\n                listeUmgewandelt(\r\n                  $Angebotsdatenliste;\r\n                  {Angebotsdaten; ?; ?: erzeugeVia(\r\n                    ermittleGueltigkeitsraumVonEingabedaten(\r\n                      ermittleEingabedatenVonTicketdaten(\r\n                        listeElement($Ticketdatenliste; listeErstesElement(ermittleTicketdatenbezugVonAngebotsdaten($Angebotsdaten)))\r\n                      )\r\n                    );\r\n                    ermittleAnzeigetextVonAngebotsdaten($Angebotsdaten)\r\n                  )}\r\n                );\r\n                {Relationsliste: wenn(\r\n                  und($Produktdaten; $Startadapter; $Zieladapter; $Tarif; $Tarifmodul; $Startobjekt; $Zielobjekt; $Produktobjekt);\r\n                  $Relationsliste;\r\n                  []\r\n                )}\r\n              )}\r\n            )}\r\n          )}\r\n        )}\r\n      )}\r\n    )}\r\n  )}\r\n)}\r\n");
		scrollPane.setViewportView(this.text);

		this.text.getDocument().addDocumentListener(new DocumentListener() {

			@Override
			public void removeUpdate(final DocumentEvent e) {
				FEM_TEST.this.col();
			}

			@Override
			public void insertUpdate(final DocumentEvent e) {
				FEM_TEST.this.col();
			}

			@Override
			public void changedUpdate(final DocumentEvent e) {
			}

		});

		this.putStyle(FEMDomain.TYPE_ERROR, "0xb50000");
		this.putStyle(FEMDomain.TYPE_CONST_TOKEN, "0x8100d6");
		this.putStyle(FEMDomain.TYPE_IDENT_TOKEN, "0xffa200");
		this.putStyle(FEMDomain.TYPE_STRING1_TOKEN, "0x268500");
		this.putStyle(FEMDomain.TYPE_STRING2_TOKEN, "0x268500");

		this.putStyle(FEMDomain.TYPE_NAME_TOKEN, "0x5297cc");
		this.putStyle(FEMDomain.TYPE_INDEX_TOKEN, "0x5297cc");
		this.putStyle(FEMDomain.TYPE_COMMENT_TOKEN, "0x8a8a8a");

	}

	void putStyle(int tokTyp, String hexCol) {
		if (hexCol == null) return;
		style.put(tokTyp, Color.decode(hexCol));
	}

	void col() {
		EventQueue.invokeLater(this::col2);
	}

	void col2() {
		try {

			final StyledDocument doc = this.text.getStyledDocument();

			final int s = doc.getStartPosition().getOffset();
			final int e = doc.getEndPosition().getOffset();

			final String str = doc.getText(s, e - s);

			final Result[] res = {null};
			System.out.println(new Tester(() -> res[0] = FEMDomain.DEFAULT.parseResult(str)));

			System.out.println(res);

			final StyleContext sc = StyleContext.getDefaultStyleContext();

			doc.setCharacterAttributes(s, e - s, SimpleAttributeSet.EMPTY, true);

			for (final Token t: res[0]) {

				final Color p = this.style.get(t.type());
				if (p != null) {

					final AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, p);

					doc.setCharacterAttributes(t.start(), t.length(), aset, true);

				}

			}
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}
}
