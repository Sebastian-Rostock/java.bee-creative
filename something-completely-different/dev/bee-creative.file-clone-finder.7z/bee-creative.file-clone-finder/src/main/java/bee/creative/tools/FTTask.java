package bee.creative.tools;

/** Diese Schnittstelle definiert ein Berechnung, die beliebige Ausnahmen auslösen kann. */
interface FTTask {

	/** Diese Methode führt die Berechnung aus. */
	public void run() throws Exception;

}