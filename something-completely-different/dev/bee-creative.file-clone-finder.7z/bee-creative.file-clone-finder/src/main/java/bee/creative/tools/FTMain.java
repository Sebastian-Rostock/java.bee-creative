package bee.creative.tools;

import java.awt.Desktop;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Pattern;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;
import bee.creative.fem.FEMBinary;
import bee.creative.fem.FEMDatetime;
import bee.creative.lang.Objects;
import bee.creative.lang.Strings;
import bee.creative.util.Consumer;
import bee.creative.util.Filter;
import bee.creative.util.Filters;
import bee.creative.util.Getter;
import bee.creative.util.HashMap;
import bee.creative.util.HashSet;
import bee.creative.util.HashSet2;
import bee.creative.util.Iterables;

@SuppressWarnings ({"javadoc", "serial"})
public class FTMain extends FTWindow {

	static final Pattern LINE_BREAK = Pattern.compile("[\r\n]+");

	static final Pattern CELL_BREAK = Pattern.compile("\t+");

	static final File OPTION_FILE = new File(".options").getAbsoluteFile();

	public static void main(final String[] args) throws Exception {
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		new FTMain();
	}

	public FTMain() {
		this.restoreOptions();
		this.persistOptions();
		this.setVisible(true);
	}

	public void persistOptions() {
		try (var file = new FileWriter(FTMain.OPTION_FILE, StandardCharsets.UTF_8)) {
			final var store = new Properties();
			this.persistOption(store, this.hashSizeModel, "hashSize");
			this.persistOption(store, this.testSizeModel, "testSize");
			this.persistOption(store, this.copyTimeModel, "copyTime");
			this.persistOption(store, this.moveTimeModel, "moveTime");
			store.store(file, "file-tool-options");
		} catch (final Exception error) {
			error.printStackTrace();
		}
	}

	private void persistOption(final Properties store, final SpinnerNumberModel model, final String key) {
		store.setProperty(key, String.valueOf(model.getValue()));
	}

	public void restoreOptions() {
		try (var file = new FileReader(FTMain.OPTION_FILE, StandardCharsets.UTF_8)) {
			final var store = new Properties();
			store.load(file);
			this.restoreOption(store, this.hashSizeModel, "hashSize");
			this.restoreOption(store, this.testSizeModel, "testSize");
			this.restoreOption(store, this.copyTimeModel, "copyTime");
			this.restoreOption(store, this.moveTimeModel, "moveTime");
		} catch (final Exception error) {
			error.printStackTrace();
		}
	}

	private void restoreOption(final Properties store, final SpinnerNumberModel model, final String key) {
		model.setValue(Long.valueOf(store.getProperty(key)));
	}

	static boolean isValid(final File file) {
		return (file != null) && file.isAbsolute();
	}

	static boolean isUnique(final File file, final HashSet2<String> visitedSet) {
		return visitedSet.add(file.getPath());
	}

	static boolean isDeletableFile(final File file) {
		return file.isFile();
	}

	static boolean isDeletableFolder(final File file) {
		if (!file.isDirectory()) return false;
		final var files = file.list();
		return (files == null) || (files.length == 0);
	}

	static File getFile(final List<String> line, final int column) {
		return line.size() > column ? new File(line.get(column)) : null;
	}

	Getter<List<String>, String> createGetter(final int column) {
		return line -> line.size() > column ? line.get(column) : null;
	}

	static final Pattern LINE_CONTENT = Pattern.compile("[^\r\n]+");

	static final Pattern CELL_CONTENT = Pattern.compile("\t+");

	// TODO
	// neuer ablauf:
	// 1 text spaltenin zeilen und spalten

	final Getter<List<String>, String> getInput = line -> line.size() > 0 ? line.get(0) : null;

	final Getter<List<String>, String> getSource = line -> line.size() > 0 ? line.get(0) : null;

	final Getter<List<String>, String> getTarget = line -> line.size() > 1 ? line.get(1) : null;

	final Getter<List<String>, List<String>> getEntry = line -> line.size() > 1 ? line.subList(0, 2) : null;

	private List<List<String>> createTableList() {
		return new ArrayList<>();
	}

	List<List<String>> createLineList(final String text) {
		final var linelist = this.createTableList();
		this.runItems_DONE_(Strings.match(FTMain.LINE_CONTENT, text), line -> linelist.add(Strings.match(FTMain.CELL_CONTENT, line)),
			line -> linelist.add(Collections.singletonList(line)));
		Iterables.translate(Strings.match(FTMain.LINE_CONTENT, text), line -> Strings.match(FTMain.CELL_CONTENT, line)).toList();
		return linelist;
	}

	List<List<String>> createLines(final List<List<String>> lines, final Filter<? super List<String>> includeLine) {
		return Iterables.filter(lines, includeLine).toList();
	}

	<GItem> List<List<String>> createLines(final List<List<String>> lines, final Getter<? super List<String>, GItem> getItem,
		final Filter<? super GItem> includeItem) {
		return this.createLines(lines, Filters.translate(includeItem, getItem));
	}

	List<List<String>> createLines(final List<List<String>> lines, final Getter<? super List<String>, ?> getItem, final Collection<?> excludeItems) {
		return this.createLines(lines, getItem, Filters.fromItems(excludeItems).negate());
	}

	<T> Set<T> createItems(final List<List<String>> lines, final Getter<? super List<String>, T> itemGetter) {
		return Iterables.translate(lines, itemGetter).filter(Filters.empty()).toSet();
	}

	// 2 set der verarbeitbaren tupel extragieren (absolute file)

	// 3 set der erfolgreich verarbeiten tupel erzeugen

	// 4 text reduzieren auf erfolgreich/erfolglos verarbeite

	String createString(final Iterable<? extends Iterable<?>> lines) {
		final var string = new StringBuilder();
		Strings.join(string, "\n", lines, (text, line) -> Strings.join(text, "\t", line));
		return string.toString();
	}

	{}

	private <GItem> void runItems_DONE_(final Collection<GItem> items, final Consumer<GItem> regular, final Consumer<GItem> canceled) {
		this.taskCount += items.size();
		final var iter = items.iterator();
		if (regular != null) {
			while (iter.hasNext() && !this.isTaskCanceled) {
				regular.set(iter.next());
				this.taskCount--;
			}
		}
		if (canceled != null) {
			while (iter.hasNext()) {
				canceled.set(iter.next());
				this.taskCount--;
			}
		}
	}

	private List<String> runFiles(final String tableText, final int column, final FileConsumer regular, final LineConsumer canceled) {
		return this.runLines_DONE_(tableText, line -> {
			final var file = FTMain.getFile(line, column);
			this.taskEntry = file;
			regular.set(line, file);
		}, canceled);
	}

	// DONE
	private List<String> runLines_DONE_(final String tableText, final LineConsumer regular, final LineConsumer canceled) {
		final var lineList = Strings.split(FTMain.LINE_BREAK, tableText);
		this.runLines_DONE_(lineList, regular, canceled);
		return lineList;
	}

	private void runLines_DONE_(final List<String> lines, final LineConsumer regular, final LineConsumer canceled) {
		this.runItems_DONE_(lines, //
			line -> regular.set(Strings.split(FTMain.CELL_BREAK, line)), //
			canceled != null ? line -> canceled.set(Strings.split(FTMain.CELL_BREAK, line)) : null);
	}

	private List<String> runEntries(final String tableText, final EntryConsumer regular, final LineConsumer canceled) {
		return this.runLines_DONE_(tableText, line -> regular.set(line, FTMain.getFile(line, 0), FTMain.getFile(line, 1)), canceled);
	}

	private int execResolve_DONE_(final String sourceText, final List<List<String>> targetList, final boolean folders) {
		final var pathSet = this.createPathSet();
		final var fileStack = new LinkedList<File>();
		final var lineCount = this.runFiles(sourceText, 0, (line, file) -> {
			if (!FTMain.isValid(file)) return;
			fileStack.add(file);
			this.taskCount++;
		}, targetList::add).size();
		var deleteCount = lineCount - fileStack.size();
		while (!fileStack.isEmpty() && !this.isTaskCanceled) {
			final var file = fileStack.remove(0);
			this.taskEntry = file;
			final var path = file.getPath();
			if (pathSet.add(path)) {
				if (file.isDirectory()) {
					final var files = file.listFiles();
					if (files != null) {
						fileStack.addAll(0, Arrays.asList(files));
						this.taskCount += files.length;
					}
					if (folders) {
						targetList.add(Collections.singletonList(path));
					}
				} else if (!folders) {
					if (file.isFile()) {
						targetList.add(Collections.singletonList(path));
					}
				}
			} else {
				deleteCount++;
			}
			this.taskCount--;
		}
		targetList.addAll(0, Iterables.translate(fileStack, file -> Collections.singletonList(file.getPath())).toList());
		return deleteCount;
	}

	@Override
	public void enterImportInputs(final String inputText, final List<File> fileList) {
		final var tableList = this.createTableList();
		if (!inputText.isEmpty()) {
			tableList.add(Collections.singletonList(inputText));
		}
		this.runItems_DONE_(fileList, file -> tableList.add(Collections.singletonList(file.getPath())), null);
		this.leaveImportInputs(this.createString(tableList));
	}

	{}

	private int execCleanup_DONE_(final String tableText, final List<List<String>> validList, final int itemCol, final boolean fileExists) {
		final var validCount = new int[1];
		final var lineList = this.createLineList(tableText);
		this.runItems_DONE_(lineList, line -> {
			if (line.size() > itemCol) {
				final var file = new File(line.get(itemCol));
				if (!file.isAbsolute() || (file.exists() == fileExists)) return;
				validCount[0]++;
			}
			validList.add(line);
		}, validList::add);
		return validList.size() - validCount[0];
	}

	private int execCleanupMissing(final String tableText, final List<List<String>> validList, final int itemCol) {
		return this.execCleanup_DONE_(tableText, validList, itemCol, false);
	}

	private int execCleanupExisting(final String tableText, final List<List<String>> validList, final int itemCol) {
		return this.execCleanup_DONE_(tableText, validList, itemCol, true);
	}

	@Override
	public void enterCleanupMissingInputs(final String inputText) {
		final var validList = this.createTableList();
		final var errorCount = this.execCleanupMissing(inputText, validList, 0);
		this.leaveCleanupMissingInputs(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterCleanupMissingSources(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execCleanupMissing(tableText, validList, 0);
		this.leaveCleanupMissingSources(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterCleanupMissingTargets(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execCleanupMissing(tableText, validList, 1);
		this.leaveCleanupMissingTargets(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterCleanupExistingInputs(final String inputText) {
		final var validList = this.createTableList();
		final var errorCount = this.execCleanupExisting(inputText, validList, 0);
		this.leaveCleanupExistingInputs(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterCleanupExistingSources(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execCleanupExisting(tableText, validList, 0);
		this.leaveCleanupExistingSources(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterCleanupExistingTargets(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execCleanupExisting(tableText, validList, 1);
		this.leaveCleanupExistingTargets(this.createString(validList), validList.size(), errorCount);
	}

	{}

	private int execDelete_DONE_(final String tableText, final List<List<String>> validList, final int itemCol, final boolean folder, final boolean recycle) {
		final var pathSet = this.createPathSet();
		final var lineList = this.createLineList(tableText);
		this.runItems_DONE_(lineList, line -> {
			if (line.size() <= itemCol) return;
			final var file = new File(line.get(itemCol));
			if (!file.isAbsolute()) return;
			pathSet.add(file.getPath());
		}, null);
		final var desktop = Desktop.getDesktop();
		final var pathList = new ArrayList<>(pathSet);
		pathSet.clear();
		pathList.sort((a, b) -> a.length() - b.length());
		this.runItems_DONE_(pathList, path -> {
			try {
				final var file = new File(path);
				if (folder) {
					if (!file.isDirectory()) return;
					final var files = file.list();
					if ((files != null) && (files.length != 0)) return;
				} else {
					if (!file.isFile()) return;
				}
				if (recycle) {
					if (!desktop.moveToTrash(file)) return;
				} else {
					if (!file.delete()) return;
				}
				pathSet.add(path); // gelöschte dateien
			} catch (final Exception ignore) {}
		}, null);
		this.runItems_DONE_(lineList, line -> {
			if ((line.size() > itemCol) && pathSet.contains(line.get(itemCol))) return;
			validList.add(line);
		}, validList::add);
		return pathList.size() - pathSet.size();
	}

	private int execDeleteHard_DONE_(final String tableText, final List<List<String>> validList, final int itemCol, final boolean folder) {
		return execDelete_DONE_(tableText, validList, itemCol, folder, false);
	}

	private int execDeleteFilesHard_DONE_(final String tableText, final List<List<String>> validList, final int itemCol) {
		return execDeleteHard_DONE_(tableText, validList, itemCol, false);
	}

	private int execDeleteFoldersHard_DONE_(final String tableText, final List<List<String>> validList, final int itemCol) {
		return execDeleteHard_DONE_(tableText, validList, itemCol, true);
	}

	private int execDeleteSoft_DONE_(final String tableText, final List<List<String>> validList, final int itemCol, final boolean folder) {
		return execDelete_DONE_(tableText, validList, itemCol, folder, true);
	}

	private int execDeleteFilesSoft_DONE_(final String tableText, final List<List<String>> validList, final int itemCol) {
		return execDeleteSoft_DONE_(tableText, validList, itemCol, false);
	}

	private int execDeleteFoldersSoft_DONE_(final String tableText, final List<List<String>> validList, final int itemCol) {
		return execDeleteSoft_DONE_(tableText, validList, itemCol, true);
	}

	@Override
	public void enterDeleteInputFilesHard(final String inputText) {
		final var validList = this.createTableList();
		final var errorCount = this.execDeleteFilesHard_DONE_(inputText, validList, 0);
		this.leaveDeleteInputFilesHard(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterDeleteInputFoldersHard(final String inputText) {
		final var validList = this.createTableList();
		final var errorCount = this.execDeleteFoldersHard_DONE_(inputText, validList, 0);
		this.leaveDeleteInputFoldersHard(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterDeleteSourceFilesHard(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execDeleteFilesHard_DONE_(tableText, validList, 0);
		this.leaveDeleteSourceFilesHard(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterDeleteSourceFoldersHard(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execDeleteFoldersHard_DONE_(tableText, validList, 0);
		this.leaveDeleteSourceFoldersHard(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterDeleteTargetFilesHard(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execDeleteFilesHard_DONE_(tableText, validList, 1);
		this.leaveDeleteTargetFilesHard(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterDeleteTargetFoldersHard(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execDeleteFoldersHard_DONE_(tableText, validList, 1);
		this.leaveDeleteTargetFoldersHard(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterDeleteInputFilesSoft(final String inputText) {
		final var validList = this.createTableList();
		final var errorCount = this.execDeleteFilesSoft_DONE_(inputText, validList, 0);
		this.leaveDeleteInputFilesSoft(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterDeleteInputFoldersSoft(final String inputText) {
		final var validList = this.createTableList();
		final var errorCount = this.execDeleteFoldersSoft_DONE_(inputText, validList, 0);
		this.leaveDeleteInputFoldersSoft(this.createString(validList), validList.size(), errorCount);
	}

	{}

	private int execExchange_DONE_(final String sourceText, final List<List<String>> validList) {
		final var validCount = new int[1];
		this.runLines_DONE_(sourceText, line -> {
			validList.add(line);
			if (line.size() < 2) return;
			validCount[0]++;
			line.set(1, line.set(0, line.get(1)));
		}, validList::add);
		return validList.size() - validCount[0];
	}

	@Override
	public void enterExchangeSourcesWithTargets(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execExchange_DONE_(tableText, validList);
		this.leaveExchangeSourcesWithTargets(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterExchangeTargetsWithSources(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execExchange_DONE_(tableText, validList);
		this.leaveExchangeTargetsWithSources(this.createString(validList), validList.size(), errorCount);
	}

	{}

	private List<File> execExport_DONE_(final String tableText, final int itemCol) {
		final var validList = new ArrayList<File>();
		final var visitedSet = this.createPathSet();
		this.runItems_DONE_(this.createLineList(tableText), line -> {
			if (line.size() <= itemCol) return;
			final var file = new File(line.get(itemCol));
			if (!FTMain.isValid(file) || !FTMain.isUnique(file, visitedSet)) return;
			validList.add(file);
		}, null);
		return validList;
	}

	@Override
	public void enterExportInputsToClipboard(final String inputText) {
		final var validList = this.execExport_DONE_(inputText, 0);
		this.leaveExportInputsToClipboard(validList);
	}

	@Override
	public void enterExportSourcesToClipboard(final String tableText) {
		final var validList = this.execExport_DONE_(tableText, 0);
		this.leaveExportSourcesToClipboard(validList);
	}

	@Override
	public void enterExportTargetsToClipboard(final String tableText) {
		final var validList = this.execExport_DONE_(tableText, 1);
		this.leaveExportTargetsToClipboard(validList);
	}

	{}

	private int execTransfer_DONE_(final String tableText, final List<List<String>> validList, final int itemCol, final int itemCount) {
		final var validCount = new int[1];
		final var visitedSet = this.createPathSet();
		this.runItems_DONE_(this.createLineList(tableText), line -> {
			if (line.size() <= itemCol) return;
			final var item = line.get(itemCol);
			if (item == null) return;
			final var file = new File(item);
			if (!file.isAbsolute()) return;
			validCount[0]++;
			if (!FTMain.isUnique(file, visitedSet)) return;
			validList.add(Collections.nCopies(itemCount, item));
		}, null);
		return validCount[0] - validList.size();
	}

	@Override
	public void enterTransferInputs(final String inputText) {
		final var validList = this.createTableList();
		final var errorCount = this.execTransfer_DONE_(inputText, validList, 0, 2);
		this.leaveTransferInputs(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterTransferSources(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execTransfer_DONE_(tableText, validList, 0, 1);
		this.leaveTransferSources(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterTransferTargets(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execTransfer_DONE_(tableText, validList, 1, 1);
		this.leaveTransferTargets(this.createString(validList), validList.size(), errorCount);
	}

	{}

	private int execReplace_DONE_(final String tableText, final List<List<String>> validList, final int sourceCol, final int targetCol) {
		final var validCount = new int[1];
		this.runItems_DONE_(this.createLineList(tableText), line -> {
			validList.add(line);
			if (line.size() < 2) return;
			validCount[0]++;
			line.set(targetCol, line.get(sourceCol));
		}, validList::add);
		return validList.size() - validCount[0];
	}

	@Override
	public void enterReplaceSourcesWithTargets(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execReplace_DONE_(tableText, validList, 1, 0);
		this.leaveReplaceSourcesWithTargets(this.createString(validList), validList.size(), errorCount);
	}

	@Override
	public void enterReplaceTargetsWithSources(final String tableText) {
		final var validList = this.createTableList();
		final var errorCount = this.execReplace_DONE_(tableText, validList, 0, 1);
		this.leaveReplaceTargetsWithSources(this.createString(validList), validList.size(), errorCount);
	}

	{}

	{}

	@Override
	public void enterResolveInputToFiles(final String inputText) {
		final var targetList = this.createTableList();
		final int deleteCount = this.execResolve_DONE_(inputText, targetList, false);
		this.leaveResolveInputToFiles(this.createString(targetList), targetList.size(), deleteCount);
	}

	@Override
	public void enterResolveInputToFolders(final String inputText) {
		final var targetList = this.createTableList();
		final var deleteCount = this.execResolve_DONE_(inputText, targetList, true);
		this.leaveResolveInputToFolders(this.createString(targetList), targetList.size(), deleteCount);
	}

	@Override
	public void enterCreateTableWithClones(final String inputText, final long hashSizeValue, final long testSize) throws Exception {
		final var pathSet = new HashSet<String>();
		final var itemList = new LinkedList<Item>();
		final var lineCount = this.runLines_DONE_(inputText, line -> {
			if (line.size() > 0) {
				final File file = new File(line.get(0));
				if (file.isAbsolute() && file.isFile()) {
					final String path = file.getPath();
					if (pathSet.add(path)) {
						itemList.add(0, new Item(path));
						this.taskCount++;
					}
				}
			}
		}, null).size();
		final var errorCount = lineCount - itemList.size();
		pathSet.clear();
		final HashMap<Object, Item> sizeListMap = new HashMap<>();

		while (!itemList.isEmpty() && !this.isTaskCanceled) { // rückwärts
			final var item = itemList.remove(0);
			this.taskEntry = item;
			this.taskCount--;
			item.computeSize();
			item.previousItem = sizeListMap.put(item.sourceSize, item);
			if (item.previousItem != null) {
				this.taskCount++;
			}
		}
		sizeListMap.remove(null);
		itemList.clear();

		final HashMap<Object, Item> hashListMap = new HashMap<>();
		final HashMap<Object, Item> itemDataListMap = new HashMap<>();
		final var originalList = new LinkedList<Item>();
		final ByteBuffer hashBuffer = Data.BUFFER_THIS;
		final MessageDigest hashBuilder = MessageDigest.getInstance("SHA-256");

		final var iter = sizeListMap.values().iterator();
		while (iter.hasNext() && !this.isTaskCanceled) {
			final Item sizeList = iter.next();

			if (sizeList.previousItem != null) {
				this.taskCount++;
				hashListMap.clear();
				final long testByteCount = Math.min(sizeList.sourceSize.longValue(), testSize);
				for (Item item2 = sizeList, next; item2 != null; item2 = next) { // vorwärts
					this.taskEntry = item2;
					this.taskCount--;
					next = item2.previousItem;

					item2.computeHash(hashSizeValue, hashBuffer, hashBuilder);

					item2.previousItem = hashListMap.put(item2.sourceHash, item2);
					if (item2.previousItem != null) {
						this.taskCount++;
					}
				}

				final var iterator = hashListMap.values().iterator();
				while (iterator.hasNext() && !this.isTaskCanceled) {
					final Item hashList = iterator.next();

					if (hashList.previousItem != null) {
						this.taskCount++;

						itemDataListMap.clear();
						for (Item item3 = hashList, prev; (item3 != null) && !this.isTaskCanceled; item3 = prev) { // rückwärts

							prev = item3.previousItem;

							item3.computeData(testByteCount);

							item3.previousItem = itemDataListMap.put(item3.sourceData, item3);
							if (item3.previousItem != null) {
								this.taskCount++;
							}
						}
						for (final Item original: itemDataListMap.values()) {
							if (original.previousItem != null) {
								originalList.add(original);
							}
						}

					}
				}

			}
		}

		final var targetList = this.createTableList();
		while (!originalList.isEmpty() && !this.isTaskCanceled) {
			final var original = originalList.remove(0);
			this.taskEntry = original;
			for (Item duplikat = original.previousItem; (duplikat != null) && !this.isTaskCanceled; duplikat = duplikat.previousItem) { // vorwärts
				targetList.add(Arrays.asList(original.sourcePath, duplikat.sourcePath, original.sourceHash.toString(), original.sourceSize.toString()));
			}
			this.taskCount--;
		}
		this.leaveCreateTableWithClones(this.createString(targetList), targetList.size(), errorCount);
	}

	@Override
	public void enterRefreshInputFiles(final String inputText, final long copyTime) {
		final var filterTime = FileTime.fromMillis(System.currentTimeMillis() - (copyTime * 24 * 60 * 60 * 1000));
		final var targetList = this.createTableList();
		final var sourceCount = this.runFiles(inputText, 0, (item, file) -> {
			try {
				if (FTMain.isValid(file)) {
					final var path = file.toPath();
					final var attr = Files.readAttributes(path, BasicFileAttributes.class);
					if (attr.isRegularFile() && (attr.creationTime().compareTo(filterTime) < 0)) {
						final var file2 = new File(file.getParentFile(), file.getName() + ".tempcopy");
						final Path path2 = file2.toPath();
						Files.copy(path, path2, StandardCopyOption.COPY_ATTRIBUTES);
						Files.move(path2, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
						return;
					}
				}
			} catch (final Exception ignored) {}
			targetList.add(item);
		}, targetList::add).size();
		this.leaveRefreshInputFiles(this.createString(targetList), targetList.size(), sourceCount - targetList.size());
	}

	@Override
	public void _6_5_enterCreateTargetsWithChangenames(final String tableText, final long moveTime) {
		final var tableList = this.createTableList();
		final var changedSet = this.createPathSet();
		this.runFiles(tableText, 0, (line, source) -> {
			if (FTMain.isValid(source) && source.isFile()) {
				final var name = source.getName();
				final var type = this.getFileType(name);
				final var parent = source.getParentFile();
				var datetime = this.getFileTime(source, moveTime);
				while (true) {
					final var target = new File(parent, this.getTimeName(datetime, type));
					if (FTMain.isUnique(target, changedSet)) {
						tableList.add(Arrays.asList(source.getPath(), target.getPath()));
						return;
					}
					datetime = datetime.move(0, 1000);
				}
			}
			tableList.add(line);
		}, tableList::add);
		this._6_5_leaveCreateTargetsWithChangenames(this.createString(tableList), changedSet.size()); // TODO
	}

	private FEMDatetime getFileTime(final File file, final long moveTime) {
		return FEMDatetime.from(file.lastModified() + (moveTime * 1000));
	}

	private String getTimeName(final FEMDatetime datetime, final String filetype) {
		final var filename2 = String.format("%04d-%02d-%02d %02d.%02d.%02d%s", //
			datetime.yearValue(), datetime.monthValue(), datetime.dateValue(), datetime.hourValue(), datetime.minuteValue(), datetime.secondValue(), filetype);
		return filename2;
	}

	private String getFileType(final String name) {
		final var position = name.lastIndexOf('.');
		final var filetype = position < 0 ? "" : name.substring(position).toLowerCase();
		return filetype;
	}

	@Override
	public void _6_6_enterCreateTargetsWithChangepaths(final String tableText, final long moveTime) {
		// return new File(new File(parent.getParentFile(), yearname + "-" + monthname + "_" + modelname), filename);
		// TODO
		super._6_6_enterCreateTargetsWithChangepaths(tableText, moveTime);
	}

	@Override
	public void enterShowSourceAndTaret(final String tableText) throws Exception {
		final var entryCount = new int[2];
		final var parentFile = Files.createTempDirectory("file-clone-finder-").toFile();
		this.runEntries(tableText, (line, sourceFile, targetFile) -> {
			if (FTMain.isValid(sourceFile) && FTMain.isValid(targetFile) && sourceFile.isFile() && targetFile.isFile()) {
				entryCount[0]++;
				final var sourceLink = new File(parentFile, entryCount[0] + "-ORIGINAL-" + sourceFile.getName());
				final var targetLink = new File(parentFile, entryCount[0] + "-DUPLIKAT-" + targetFile.getName());
				try {
					Files.createSymbolicLink(sourceLink.toPath(), sourceFile.toPath());
					entryCount[1]++;
				} catch (final Exception ignored) {}
				try {
					Files.createSymbolicLink(targetLink.toPath(), targetFile.toPath());
					entryCount[1]++;
				} catch (final Exception ignored) {}
			}
		}, null);
		Desktop.getDesktop().open(parentFile);
		this.leaveShowSourceAndTaret(parentFile.getPath(), entryCount[1]);
	}

	@Override
	public void enterCopySourcesToTargets(final String tableText) {
		final var targetList = this.createTableList();
		final var sourceCount = this.runEntries(tableText, (line, sourceFile, targetFile) -> {
			if (FTMain.isValid(sourceFile) && FTMain.isValid(targetFile) && sourceFile.isFile() && !targetFile.exists()) {
				try {
					Files.copy(sourceFile.toPath(), targetFile.toPath(), StandardCopyOption.COPY_ATTRIBUTES);
					return;
				} catch (final Exception ignored) {}
			}
			targetList.add(line);
		}, targetList::add).size();
		this.leaveCopySourcesToTargets(this.createString(targetList), targetList.size(), sourceCount - targetList.size());
	}

	@Override
	public void enterMoveSourcesToTargets(final String tableText) {
		final var targetList = this.createTableList();
		final var sourceCount = this.runEntries(tableText, (line, sourceFile, targetFile) -> {
			if (FTMain.isValid(sourceFile) && FTMain.isValid(targetFile) && sourceFile.isFile() && !targetFile.exists()) {
				try {
					Files.move(sourceFile.toPath(), targetFile.toPath());
					return;
				} catch (final Exception ignored) {}
			}
			targetList.add(line);
		}, targetList::add).size();
		this.leaveMoveSourcesToTargets(this.createString(targetList), targetList.size(), sourceCount - targetList.size());
	}

	{}

	private HashSet2<String> createPathSet() {
		return new HashSet2<>();
	}

	interface FileConsumer {

		void set(List<String> line, File input);
	}

	interface LineConsumer {

		void set(List<String> line);
	}

	interface EntryConsumer {

		void set(List<String> line, File source, File target);
	}

	static class Item {

		String sourcePath;

		Long sourceSize;

		Object sourceHash;

		Object sourceData;

		Item previousItem;

		Item(final String sourcePath) {
			this.sourcePath = sourcePath;
		}

		void computeSize() {
			try {
				this.sourceSize = new File(this.sourcePath).length();
			} catch (final Exception error) {
				error.printStackTrace();
				this.sourceSize = null;
			}
		}

		void computeHash(final long hashSize, final ByteBuffer hashBuffer, final MessageDigest hashBuilder) {
			try (var channel = Data.openChannel(this.sourcePath)) {
				hashBuilder.reset();
				final var bufSize = hashBuffer.capacity();
				for (var remSize = hashSize; remSize > 0; remSize -= bufSize) {
					final var remLimit = (int)Math.min(remSize, bufSize);
					hashBuffer.limit(remLimit).position(0);
					final var last = Data.readChannel(channel, hashBuffer);
					hashBuffer.limit(hashBuffer.position()).position(0);
					hashBuilder.update(hashBuffer);
					if (last) {
						break;
					}
				}
				this.sourceHash = FEMBinary.from(hashBuilder.digest()).toString(false);
			} catch (final Exception error) {
				error.printStackTrace();
				this.sourceHash = this;
			}
		}

		void computeData(final long dataSize) {
			try {
				final var fileData = new Data();
				fileData.dataPath = this.sourcePath;
				fileData.dataSize = dataSize;
				this.sourceData = fileData;
			} catch (final Exception error) {
				error.printStackTrace();
				this.sourceData = this;
			}
		}

		@Override
		public String toString() {
			return this.sourcePath;
		}

	}

	static class Data {

		static final int BUFFER_SIZE = 1024 * 1024 * 10;

		static final ByteBuffer BUFFER_THIS = ByteBuffer.allocateDirect(Data.BUFFER_SIZE);

		static final ByteBuffer BUFFER_THAT = ByteBuffer.allocateDirect(Data.BUFFER_SIZE);

		/** Diese Methode füllt den gegebenen Puffer target mit den Daten aus dem Datenkanal und liefert nutr dann true, wenn dabei das Ende des Datenkanals
		 * erreicht wurde. */
		static boolean readChannel(final FileChannel source, final ByteBuffer target) throws IOException {
			while (target.remaining() != 0) {
				if (source.read(target) < 0) return true;
			}
			return false;
		}

		static FileChannel openChannel(final String filepath) throws IOException {
			return FileChannel.open(new File(filepath).toPath(), StandardOpenOption.READ);
		}

		String dataPath;

		long dataSize;

		@Override
		public int hashCode() {
			return 0;
		}

		@Override
		public boolean equals(final Object object) {
			if (object == this) return true;
			if (!(object instanceof Data)) return false;
			final Data that = (Data)object;
			if (Objects.equals(this.dataPath, that.dataPath) || (this.dataSize != that.dataSize)) return true;
			try (FileChannel thisChannel = Data.openChannel(this.dataPath)) {
				try (FileChannel thatChannel = Data.openChannel(that.dataPath)) {
					final int bufSize = Data.BUFFER_SIZE;
					final ByteBuffer thisBuffer = Data.BUFFER_THIS;
					final ByteBuffer thatBuffer = Data.BUFFER_THAT;
					for (long remSize = this.dataSize; remSize > 0; remSize -= bufSize) {
						final int remLimit = (int)Math.min(remSize, bufSize);
						thisBuffer.limit(remLimit).position(0);
						thatBuffer.limit(remLimit).position(0);
						final boolean thisLast = Data.readChannel(thisChannel, thisBuffer);
						final boolean thatLast = Data.readChannel(thatChannel, thatBuffer);
						if (thisLast != thatLast) return false;
						thisBuffer.limit(thisBuffer.position()).position(0);
						thatBuffer.limit(thatBuffer.position()).position(0);
						if (!thisBuffer.equals(thatBuffer)) return false;
					}
					return true;
				}
			} catch (final Exception error) {
				error.printStackTrace();
				return false;
			}
		}

	}

}
