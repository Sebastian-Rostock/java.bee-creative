package bee.creative.tools;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
//import com.jgoodies.forms.layout.ColumnSpec;
//import com.jgoodies.forms.layout.FormLayout;
//import com.jgoodies.forms.layout.FormSpecs;
//import com.jgoodies.forms.layout.RowSpec;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

class FileToolWindow {

	JFrame frame;

	JTextArea sourceList;

	JTextArea targetList;

	JSpinner hashSize;

	JSpinner testSize;

	JSpinner copyTime;

	JButton scanButton;

	JButton copyButton;

	JButton findButton;

	JButton viewButton;

	JLabel progressInfo;

	JButton moveButton;

	JButton stopButton;

	FileToolWindow() {
//		this.initialize();
		this.frame.setVisible(true);
	}

//	void initialize() {
//
//		final JPanel sourcePage = new JPanel();
//		sourcePage.setLayout(new FormLayout(new ColumnSpec[]{ //
//			FormSpecs.LABEL_COMPONENT_GAP_COLSPEC, //
//			ColumnSpec.decode("default:grow"), //
//			FormSpecs.LABEL_COMPONENT_GAP_COLSPEC, //
//		}, new RowSpec[]{ //
//			FormSpecs.RELATED_GAP_ROWSPEC, //
//			FormSpecs.MIN_ROWSPEC, //
//			FormSpecs.RELATED_GAP_ROWSPEC, //
//			RowSpec.decode("default:grow"), //
//			FormSpecs.RELATED_GAP_ROWSPEC, //
//		}));
//		sourcePage.setBackground(UIManager.getColor("TabbedPane.highlight"));
//
//		final JLabel sourceInfo = new JLabel("<html>" //
//			+ "Die abzugleichenden Dateien und Verzeichnisse können hier <b>eingefügt</b> bzw. <b>fallengelassen</b> werden. " //
//			+ "Beim <b>Aufbereiten</b> der Verzeichnisse werden diese durch alle darin enthatenen Dateien ersetzt.\n" //
//			+ "Beim <b>Suchen</b> der Duplikate werden Verzeichnisse sowie relative Dateipfade ignoriert.\n" //
//			+ "Beim <b>Erneuern</b> der Dateien werden diese kopiert und anschließend durch die Kopien ersetzt.\n" //
//			+ "</html>");
//		sourcePage.add(sourceInfo, "2, 2, fill, fill");
//
//		this.sourceList = new JTextArea();
//		final JScrollPane sourcePane = new JScrollPane(this.sourceList);
//		sourcePage.add(sourcePane, "2, 4, fill, fill");
//
//		final JPanel targetPage = new JPanel();
//		targetPage.setLayout(new FormLayout(new ColumnSpec[]{ //
//			FormSpecs.LABEL_COMPONENT_GAP_COLSPEC, //
//			ColumnSpec.decode("default:grow"), //
//			FormSpecs.LABEL_COMPONENT_GAP_COLSPEC, //
//		}, new RowSpec[]{ //
//			FormSpecs.RELATED_GAP_ROWSPEC, //
//			FormSpecs.MIN_ROWSPEC, //
//			FormSpecs.RELATED_GAP_ROWSPEC, //
//			RowSpec.decode("default:grow"), //
//			FormSpecs.RELATED_GAP_ROWSPEC, //
//		}));
//		targetPage.setBackground(UIManager.getColor("TabbedPane.highlight"));
//
//		final JLabel targetInfo = new JLabel("<html>" //
//			+ "Hier werden die Dateipfade der gefundenen Duplikate aufgelistet. " //
//			+ "Jedem kann dabei mit Tabulator getrennt der Dateipfad, der Streuwert sowie die Dateigröße des Originals angefügte sein. "
//			+ "Dateipfade können hier auch eingefügt bzw. fallengelassen werden. " //
//			+ "Beim Recyceln der Duplikate werden diese in den Papierkorb verschoben. " //
//			+ "Beim Anzeigen der Duplikate werden Symlinks zu diesen und deren Originalen in ein temporäres und abschließend angezeigtes Verzeichnis eingefügt. "
//			+ "</html>");
//		targetPage.add(targetInfo, "2, 2, fill, fill");
//
//		this.targetList = new JTextArea();
//		final JScrollPane targetPane = new JScrollPane(this.targetList);
//		targetPage.add(targetPane, "2, 4, fill, fill");
//
//		final JPanel optionPage = new JPanel();
//		optionPage.setBackground(UIManager.getColor("TabbedPane.highlight"));
//
//		final JLabel optionInfo = new JLabel("<html>" //
//			+ "Beim <b>Finden</b> der Duplikate werden Dateien zunächst bezüglich ihrer <b>Dateigröße</b> partitioniert. " //
//			+ "Die Dateien innerhalb einer Dateigrößenpartition werden dann bezüglich ihres <b>SHA-256-Streuwerts</b> partitioniert. " //
//			+ "Dieser Streuwert wird aus höchstens der unten angegebenen Anzanl an Bytes ab dem Dateibeginn berechnet. " //
//			+ "Schließlich werden die Dateien innerhalb einer Streuwertpartition nach ihrem Dateiinhalt partitioniert. " //
//			+ "Dabei wird höchstens die unten angegebene Anzanl an Bytes ab dem Dateibeginn betrachtet. " //
//			+ "Die <b>erste</b> Datei einer Dateiinhaltspartition wird als Originaldatei interpretiert, die übrigen als deren Duplikate. " //
//			+ "</html>");
//
//		final JLabel hashSizeInfo = new JLabel("Puffergröße für Streuwert");
//		this.hashSize = new JSpinner();
//		this.hashSize.setModel(new SpinnerNumberModel(new Long(1048576), new Long(0), null, new Long(1048576)));
//
//		final JLabel testSizeInfo = new JLabel("Puffergröße für Dateivergleich");
//		this.testSize = new JSpinner();
//		this.testSize.setModel(new SpinnerNumberModel(new Long(20971520), new Long(0), null, new Long(1048576)));
//
//		final JLabel copyTimeInfo = new JLabel("Erneuern nach Tagen");
//		this.copyTime = new JSpinner();
//		this.copyTime.setModel(new SpinnerNumberModel(Long.valueOf(1800), Long.valueOf(100), null, Long.valueOf(100)));
//		optionPage.setLayout(new FormLayout(new ColumnSpec[]{ //
//			FormSpecs.LABEL_COMPONENT_GAP_COLSPEC, //
//			FormSpecs.MIN_COLSPEC, //
//			FormSpecs.RELATED_GAP_COLSPEC, //
//			ColumnSpec.decode("default:grow"), //
//			FormSpecs.LABEL_COMPONENT_GAP_COLSPEC, //
//		}, new RowSpec[]{ //
//			FormSpecs.LINE_GAP_ROWSPEC, //
//			FormSpecs.MIN_ROWSPEC, //
//			FormSpecs.LINE_GAP_ROWSPEC, //
//			FormSpecs.DEFAULT_ROWSPEC, //
//			FormSpecs.LINE_GAP_ROWSPEC, //
//			FormSpecs.DEFAULT_ROWSPEC, //
//			FormSpecs.LINE_GAP_ROWSPEC, //
//			FormSpecs.DEFAULT_ROWSPEC, //
//		}));
//
//		optionPage.add(optionInfo, "2, 2, 3, 1, fill, top");
//		optionPage.add(hashSizeInfo, "2, 4, left, top");
//		optionPage.add(this.hashSize, "4, 4, fill, top");
//		optionPage.add(testSizeInfo, "2, 6, left, top");
//		optionPage.add(this.testSize, "4, 6, fill, top");
//		optionPage.add(copyTimeInfo, "2, 8, left, top");
//		optionPage.add(this.copyTime, "4, 8, fill, top");
//
//		final JTabbedPane pagePane = new JTabbedPane(SwingConstants.TOP);
//		pagePane.addTab("Datei- und Verzeichnispfade", null, sourcePage, null);
//		pagePane.addTab("Duplikate", null, targetPage, null);
//		pagePane.addTab("Optionen", null, optionPage, null);
//
//		final JPanel toolPanel = new JPanel();
//		toolPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 5, 5));
//
//		this.scanButton = new JButton("<html><center>Verzeichnisse<br><b>aufbereiten</b></center></html>");
//		toolPanel.add(this.scanButton);
//
//		this.copyButton = new JButton("<html><center>Dateien<br><b>erneuern</b></center></html>");
//		toolPanel.add(this.copyButton);
//
//		this.findButton = new JButton("<html><center>Duplikate<br><b>suchen</b></center></html>");
//		toolPanel.add(this.findButton);
//
//		this.viewButton = new JButton("<html><center>Duplikate<br><b>anzeigen</b></center></html>");
//		toolPanel.add(this.viewButton);
//
//		this.moveButton = new JButton("<html><center>Duplikate<br><b>recyclen</b></center></html>");
//		toolPanel.add(this.moveButton);
//
//		this.stopButton = new JButton("<html><center>Prozess<br><b>abbrechen</b></center></html>");
//		toolPanel.add(this.stopButton);
//
//		this.progressInfo = new JLabel(" ");
//
//		this.frame = new JFrame("Dateiduplikatfinder");
//		this.frame.getContentPane().setLayout(
//			new FormLayout(new ColumnSpec[]{FormSpecs.RELATED_GAP_COLSPEC, ColumnSpec.decode("default:grow"), FormSpecs.RELATED_GAP_COLSPEC,}, new RowSpec[]{
//				FormSpecs.RELATED_GAP_ROWSPEC, RowSpec.decode("default:grow"), FormSpecs.MIN_ROWSPEC, FormSpecs.MIN_ROWSPEC, FormSpecs.RELATED_GAP_ROWSPEC,}));
//		this.frame.getContentPane().add(pagePane, "2, 2, fill, fill");
//		this.frame.getContentPane().add(toolPanel, "2, 3, fill, top");
//		this.frame.getContentPane().add(this.progressInfo, "2, 4, left, top");
//
//	}

}
