/* [cc-by] 2013 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#ifndef BEE_CREATIVE_HPP
#define BEE_CREATIVE_HPP

#include <inttypes.h>
#include <boost/smart_ptr/intrusive_ptr.hpp>
#include <boost/smart_ptr/intrusive_ref_counter.hpp>

namespace bee {

/**
 * Dieser Namensraum definiert die grundlegenden Datentypen für primitive Zahlenwerte und Zahlenfolgen sowie für referenzgezählte Objekte.
 * <p>
 * Referenzgezählte Objekte werden als Nachfahren von @c RCObject definiert und über @c RCPointer referenziert.
 * Der Templateparameter dieser beiden Klassen ist die Klasse des referenzgezählten Objekts, d.h.:
 *
 * <pre>
 * class MyObj: public RCObject<MyObj> {
 *    ...
 * };
 * RCPointer<MyObj> obj;
 * </pre>
 *
 * Wenn das Objekt im Header nur vorwärtsdeklariert wird, muss das Makro @c usingRCObject vorher eingefügt werden, d.h.:
 *
 * <pre>
 * usingRCObject;
 * class MyObj;
 * RCPointer<MyObj> obj;
 * </pre>
 *
 * Dies ist insbesondere dann notwendig, wenn die Klasse des Objekts eine private innere Klasse ist, d.h.:
 *
 * <pre>
 * usingRCObject;
 * class PubObj {
 *   public:
 *   ...
 *   class PrivObj;
 *   private:
 *   RCPointer<PrivObj> obj;
 * };
 * </pre>
 *
 * Das Makro @c usingRCObject steht für:
 *
 * <pre>
 * using bee::creative::intrusive_ptr_add_ref;
 * using bee::creative::intrusive_ptr_release;
 * </pre>
 *
 * @author [cc-by] 2014 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]
 */
namespace creative {

typedef void * PVOID;
typedef void const * PCVOID;

typedef char * PCHAR;
typedef char const * PCCHAR;

typedef int8_t INT8;
typedef int16_t INT16;
typedef int32_t INT32;
typedef int64_t INT64;

typedef uint8_t UINT8;
typedef uint16_t UINT16;
typedef uint32_t UINT32;
typedef uint64_t UINT64;

typedef INT8 * PINT8;
typedef INT16 * PINT16;
typedef INT32 * PINT32;
typedef INT64 * PINT64;

typedef INT8 const * PCINT8;
typedef INT16 const * PCINT16;
typedef INT32 const * PCINT32;
typedef INT64 const * PCINT64;

typedef UINT8 * PUINT8;
typedef UINT16 * PUINT16;
typedef UINT32 * PUINT32;
typedef UINT64 * PUINT64;

typedef UINT8 const * PCUINT8;
typedef UINT16 const * PCUINT16;
typedef UINT32 const * PCUINT32;
typedef UINT64 const * PCUINT64;

/**
 * Dieser generische Datentyp definiert ein referenzgezähltes Objekt, welches seinen Referenzzähler selbst besitzt.
 * @tparam GDATA Klasse des referenzgezählten Objekts, d.h. Klasse, die von dieser erbt.
 * @see RCPointer
 * @see boost::sp_adl_block::intrusive_ref_counter
 */
#ifdef BOOST_NO_CXX11_TEMPLATE_ALIASES
#define RCObject boost::sp_adl_block::intrusive_ref_counter
#else
template<typename GDATA>
using RCObject = boost::sp_adl_block::intrusive_ref_counter<GDATA>;
#endif

/**
 * Dieser generische Datentyp definiert einen Verweis auf ein referenzgezähltes Objekt.
 * @tparam GDATA Klasse des referenzgezählten Objekts.
 * @see RCObject
 * @see boost::intrusive_ptr
 */
#ifdef BOOST_NO_CXX11_TEMPLATE_ALIASES
#define RCPointer boost::intrusive_ptr
#else
template<typename GDATA>
using RCPointer = boost::intrusive_ptr<GDATA>;
#endif

/* Dieses Makro sollte nur dann genutzt werden, wenn das Nachfahren von RCObject nur vorwärtsdeklariert werden.*/
#define usingRCObject \
using bee::creative::intrusive_ptr_add_ref; \
using bee::creative::intrusive_ptr_release;

/**
 * Diese Methode erhöht den Referenzzähler des gegebenen Objekts.
 * @tparam GDATA Klasse des referenzgezählten Objekts.
 * @param data referenzgezähltes Objekt.
 * @see boost::sp_adl_block::intrusive_ptr_add_ref
 */
template<typename GDATA>
void intrusive_ptr_add_ref(GDATA * data) {
	class DATA: public RCObject<DATA> {};
	DATA * data2 = (DATA*)data;
	boost::sp_adl_block::intrusive_ptr_add_ref(data2);
}

/**
 * Diese Methode verringert den Referenzzähler des gegebenen Objekts.
 * @tparam GDATA Klasse des referenzgezählten Objekts.
 * @param data referenzgezähltes Objekt.
 * @see boost::sp_adl_block::intrusive_ptr_release
 */
template<typename GDATA>
void intrusive_ptr_release(GDATA * data) {
	class DATA: public RCObject<DATA> {};
	DATA * data2 = (DATA*)data;
	boost::sp_adl_block::intrusive_ptr_release(data2);
}

}

}

#endif
