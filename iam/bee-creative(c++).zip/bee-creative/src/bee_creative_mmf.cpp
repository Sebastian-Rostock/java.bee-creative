/* [cc-by] 2013 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#include "bee_creative_mmf.hpp"
#include <fstream>

namespace bee {

namespace creative {

namespace mmf {

// function readBE / readLE / lengthOf

UINT32 readBE(PCUINT8 const _array, UINT8 const _size) {
	switch (_size) {
		case 0:
			return 0;
		case 1:
			return (_array[0] << 0);
		case 2:
			return (_array[0] << 8) | (_array[1] << 0);
		case 3:
			return (_array[0] << 16) | (_array[1] << 8) | (_array[2] << 0);
		case 4:
			return (_array[0] << 24) | (_array[1] << 16) | (_array[2] << 8) | (_array[3] << 0);
	}
	return 0;
}

UINT32 readLE(PCUINT8 const _array, UINT8 const _size) {
	switch (_size) {
		case 0:
			return 0;
		case 1:
			return (_array[0] << 0);
		case 2:
			return (_array[1] << 8) | (_array[0] << 0);
		case 3:
			return (_array[2] << 16) | (_array[1] << 8) | (_array[0] << 0);
		case 4:
			return (_array[3] << 24) | (_array[2] << 16) | (_array[1] << 8) | (_array[0] << 0);
	}
	return 0;
}

UINT8 lengthOf(INT32 const _value) {
	if (_value & 0xFF000000) return 4;
	if (_value & 0xFFFF0000) return 3;
	if (_value & 0xFFFFFF00) return 2;
	if (_value) return 1;
	return 0;
}

// class MMFView

define_RCObject(MMFViewData) {

	public:

	MMFViewData()
			: data(0), size(0) {
	}

	~MMFViewData() {
		if (owner || !data) return;
		UnmapViewOfFile(data);
	}

	PVOID data;

	UINT32 size;

	RCPointer<MMFViewData> owner;

};

commit_RCObject(MMFViewData)

RCPointer<MMFViewData> __emptyViewData(new MMFViewData());

MMFView::MMFView()
		: __data(__emptyViewData) {
}

MMFView::MMFView(PCCHAR _fileName, bool _readonly)
		: __data(__emptyViewData) {
	if (!_fileName) return;
	HANDLE _fileHandle = CreateFile(_fileName, !_readonly ? GENERIC_WRITE | GENERIC_READ : GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (_fileHandle == INVALID_HANDLE_VALUE) return;
	LARGE_INTEGER _fileSize;
	if (GetFileSizeEx(_fileHandle, &_fileSize)) {
		_fileSize.LowPart = _fileSize.HighPart ? 0xFFFFFFFF : _fileSize.LowPart;
	} else {
		_fileSize.LowPart = 0;
	}
	UINT32 _viewSize = _fileSize.LowPart;
	HANDLE _fileMapping = _viewSize ? CreateFileMapping(_fileHandle, NULL, _readonly ? PAGE_READONLY : PAGE_READWRITE, 0, _viewSize, _fileName) : NULL;
	CloseHandle(_fileHandle);
	if (_fileMapping == NULL) return;
	PVOID _viewData = MapViewOfFile(_fileMapping, _readonly ? FILE_MAP_READ : FILE_MAP_WRITE, 0, 0, 0);
	CloseHandle(_fileMapping);
	if (!_viewData) return;
	MMFViewData * _data = new MMFViewData();
	__data.reset(_data);
	_data->data = _viewData;
	_data->size = _viewSize;
}

PVOID MMFView::data() const {
	MMFViewData * _data = __data.get();
	return _data->data;
}

UINT32 MMFView::size() const {
	MMFViewData * _data = __data.get();
	return _data->size;
}

MMFView MMFView::part(UINT32 _offset, UINT32 _length) const {
	MMFView _part;
	MMFViewData * _data = __data.get();
	if (_offset + _length > _data->size) return _part;
	MMFViewData * _owner = _data->owner.get();
	MMFViewData * _partData = new MMFViewData();
	_part.__data.reset(_partData);
	_partData->owner = _owner ? _owner : _data;
	_partData->data = (PUINT8) _data->data + _offset;
	_partData->size = _length;
	return _part;
}

}

}

}
