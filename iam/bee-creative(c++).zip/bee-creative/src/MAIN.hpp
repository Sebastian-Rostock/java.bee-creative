#ifndef MAIN_HPP_
#define MAIN_HPP_
#include <fstream>
#include <iostream>
#include <time.h>
#include "bee_creative.hpp"
#include "bee_creative_mmf.hpp"
#include "bee_creative_iam.hpp"
//#include "bee_creative_bex.hpp"
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/smart_ptr.hpp>
using namespace std;
using std::string;
using namespace bee::creative;
using namespace bee::creative::mmf;
using namespace bee::creative::iam;
using namespace boost::posix_time;

int main();

#endif
