/* [cc-by] 2013 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#include "bee_creative_bex.hpp"

namespace bee {

namespace creative {

namespace bex {

using std::string;

using mmf::MMFView;
using iam::IAMList;
using iam::IAMArray;
using iam::IAMIndex;
using iam::IAMException;

define_RCObject(BEXFileData) {

	public:

	void load(MMFView const & _file) {
		if (_file.size() & 3) throw IAMException(IAMException::INVALID_LENGTH);
		load((PCINT32) _file.data(), _file.size() >> 2);
		fileData = _file;
	}

	void load(PCINT32 const _data, INT32 const _length) {
		if (_length < 3) throw IAMException(IAMException::INVALID_LENGTH);

		UINT32 _header = _data[0];
		if (_header != 0xBE10BA5E) throw IAMException(IAMException::INVALID_HEADER);

		INT32 _rootRef = _data[1];
		IAMIndex _nodeData(_data + 2, _length - 2);
		if (false || //
				(_nodeData.mapCount() != 0) || //
				(_nodeData.listCount() != 17) //
				) throw IAMException(IAMException::INVALID_VALUE);

		IAMList _attrUriTextList = _nodeData.list(0);
		IAMList _attrNameTextList = _nodeData.list(1);
		IAMList _attrValueTextList = _nodeData.list(2);
		IAMList _chldUriTextList = _nodeData.list(3);
		IAMList _chldNameTextList = _nodeData.list(4);
		IAMList _chldValueTextList = _nodeData.list(5);
		IAMList _attrUriRefList = _nodeData.list(6);
		IAMList _attrNameRefList = _nodeData.list(7);
		IAMList _attrValueRefList = _nodeData.list(8);
		IAMList _attrParentRefList = _nodeData.list(9);
		IAMList _chldUriRefList = _nodeData.list(10);
		IAMList _chldNameRefList = _nodeData.list(11);
		IAMList _chldContentRefList = _nodeData.list(12);
		IAMList _chldAttributesRefList = _nodeData.list(13);
		IAMList _chldParentRefList = _nodeData.list(14);
		IAMList _chldListRangeList = _nodeData.list(15);
		IAMList _attrListRangeList = _nodeData.list(16);
		if (false || //
				(_attrUriRefList.itemCount() != 1) || //
				(_attrNameRefList.itemCount() != 1) || //
				(_attrValueRefList.itemCount() != 1) || //
				(_attrParentRefList.itemCount() != 1) || //
				(_chldUriRefList.itemCount() != 1) || //
				(_chldNameRefList.itemCount() != 1) || //
				(_chldContentRefList.itemCount() != 1) || //
				(_chldAttributesRefList.itemCount() != 1) || //
				(_chldParentRefList.itemCount() != 1) || //
				(_chldListRangeList.itemCount() != 1) || //
				(_attrListRangeList.itemCount() != 1) //
				) throw IAMException(IAMException::INVALID_VALUE);

		IAMArray _attrUriRef = _attrUriRefList.item(0);
		IAMArray _attrNameRef = _attrNameRefList.item(0);
		IAMArray _attrValueRef = _attrValueRefList.item(0);
		IAMArray _attrParentRef = _attrParentRefList.item(0);
		IAMArray _chldUriRef = _chldUriRefList.item(0);
		IAMArray _chldNameRef = _chldNameRefList.item(0);
		IAMArray _chldContentRef = _chldContentRefList.item(0);
		IAMArray _chldAttributesRef = _chldAttributesRefList.item(0);
		IAMArray _chldParentRef = _chldParentRefList.item(0);
		IAMArray _chldListRange = _chldListRangeList.item(0);
		IAMArray _attrListRange = _attrListRangeList.item(0);
		INT32 _attrCount = _attrNameRef.length();
		INT32 _chldCount = _chldNameRef.length();

		if (false || //
				(_rootRef < 0) || //
				(_chldCount <= _rootRef) || //
				((_attrUriRef.length() != _attrCount) && (_attrUriRef.length() != 0)) || //
				(_attrValueRef.length() != _attrCount) || //
				((_attrParentRef.length() != _attrCount) && (_attrParentRef.length() != 0)) || //
				((_chldUriRef.length() != _chldCount) && (_chldUriRef.length() != 0)) || //
				(_chldContentRef.length() != _chldCount) || //
				(_chldAttributesRef.length() != _chldCount) || //
				((_chldParentRef.length() != _chldCount) && (_chldParentRef.length() != 0)) || //
				(_chldListRange.length() < 3) || //
				(_attrListRange.length() < 2) //
				) throw IAMException(IAMException::INVALID_VALUE);

		rootRef = _rootRef;
		nodeData = _nodeData;
		attrUriText = _attrUriTextList;
		attrNameText = _attrNameTextList;
		attrValueText = _attrValueTextList;
		chldUriText = _chldUriTextList;
		chldNameText = _chldNameTextList;
		chldValueText = _chldValueTextList;
		attrUriRef = _attrUriRef;
		attrNameRef = _attrNameRef;
		attrValueRef = _attrValueRef;
		attrParentRef = _attrParentRef;
		chldUriRef = _chldUriRef;
		chldNameRef = _chldNameRef;
		chldContentRef = _chldContentRef;
		chldAttributesRef = _chldAttributesRef;
		chldParentRef = _chldParentRef;
		chldListRange = _chldListRange;
		attrListRange = _attrListRange;

	}

	MMFView fileData;

	INT32 rootRef;

	IAMIndex nodeData;

	IAMList attrUriText;

	IAMList attrNameText;

	IAMList attrValueText;

	IAMList chldUriText;

	IAMList chldNameText;

	IAMList chldValueText;

	IAMArray attrUriRef;

	IAMArray attrNameRef;

	IAMArray attrValueRef;

	IAMArray attrParentRef;

	IAMArray chldUriRef;

	IAMArray chldNameRef;

	IAMArray chldContentRef;

	IAMArray chldAttributesRef;

	IAMArray chldParentRef;

	IAMArray chldListRange;

	IAMArray attrListRange;

};

commit_RCObject(BEXFileData)

// Typkennung für den undefinierten Knoten bzw. die undefinierte Knotenliste.
const UINT8 BEX_VOID_TYPE = 0;

// Typkennung für einen Attributknoten.
const UINT8 BEX_ATTR_NODE = 1;

// Typkennung für einen Elementknoten.
const UINT8 BEX_ELEM_NODE = 2;

// Typkennung für einen Textknoten.
const UINT8 BEX_TEXT_NODE = 3;

// Typkennung für den Textknoten eines Elementknoten.
const UINT8 BEX_TEXTELEM_NODE = 4;

// Typkennung für eine Attributknotenliste.
const UINT8 BEX_ATTR_LIST = 5;

// Typkennung für eine Kindknotenliste.
const UINT8 BEX_CHLD_LIST = 6;

// Typkennung für die Kindknotenliste dem Textknoten eines Elementknoten.
const UINT8 BEX_CHLDTEXT_LIST = 7;

inline UINT32 bexKey(UINT8 type, UINT32 index) {
	return type | (index << 3);
}

inline UINT8 bexType(UINT32 key) {
	return key & 7;
}

inline INT32 bexIndex(UINT32 key) {
	return key >> 3;
}

inline string bexString(IAMArray const & array) {
	string result((PCCHAR) array.data());
	return result;
}

inline IAMArray bexArray(string const & string) {
	IAMArray result((PCINT8) string.c_str(), string.length());
	return result;
}

// class BEXNode

BEXNode::BEXNode()
		: __key(bexKey(BEX_VOID_TYPE, 0)), __owner() {
}

BEXNode::BEXNode(BEXFile const & _owner)
		: __key(bexKey(BEX_VOID_TYPE, 0)), __owner(_owner) {
}

BEXNode::BEXNode(UINT32 const _key, BEXFile const & _owner)
		: __key(_key), __owner(_owner) {
}

UINT32 BEXNode::key() {
	return __key;
}

UINT8 BEXNode::type() {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_VOID_TYPE:
			return BEXNode::TYPE_VOID;
		case BEX_ATTR_NODE:
			return BEXNode::TYPE_ATTR;
		case BEX_ELEM_NODE:
			return BEXNode::TYPE_ELEM;
		case BEX_TEXT_NODE:
		case BEX_TEXTELEM_NODE:
			return BEXNode::TYPE_TEXT;
	}
	throw IAMException(IAMException::INVALID_HEADER);
}

BEXFile BEXNode::owner() {
	return __owner;
}

string BEXNode::uri() {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_ATTR_NODE: {
			BEXFileData & _data = *__owner.__data;
			IAMArray _result = _data.attrUriText.item(_data.attrUriRef.get(bexIndex(_key)));
			return bexString(_result);
		}
		case BEX_ELEM_NODE: {
			BEXFileData & _data = *__owner.__data;
			IAMArray _result = _data.chldUriText.item(_data.chldUriRef.get(bexIndex(_key)));
			return bexString(_result);
		}
		case BEX_VOID_TYPE:
		case BEX_TEXT_NODE:
		case BEX_TEXTELEM_NODE:
			return string();
	}
	throw IAMException(IAMException::INVALID_HEADER);
}

string BEXNode::name() {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_ATTR_NODE: {
			BEXFileData & _data = *__owner.__data;
			IAMArray _result = _data.attrNameText.item(_data.attrNameRef.get(bexIndex(_key)));
			return bexString(_result);
		}
		case BEX_ELEM_NODE: {
			BEXFileData & _data = *__owner.__data;
			IAMArray _result = _data.chldNameText.item(_data.chldNameRef.get(bexIndex(_key)));
			return bexString(_result);
		}
		case BEX_VOID_TYPE:
		case BEX_TEXT_NODE:
		case BEX_TEXTELEM_NODE:
			return string();
	}
	throw IAMException(IAMException::INVALID_HEADER);
}

string BEXNode::value() {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_VOID_TYPE:
			return string();
		case BEX_ATTR_NODE: {
			BEXFileData & _data = *__owner.__data;
			IAMArray _result = _data.attrValueText.item(_data.attrValueRef.get(bexIndex(_key)));
			return bexString(_result);
		}
		case BEX_ELEM_NODE: {
			BEXFileData & _data = *__owner.__data;
			INT32 _index = bexIndex(_key);
			INT32 _content = _data.chldContentRef.get(_index);
			if (_content >= 0) {
				IAMArray _result = _data.chldValueText.item(_content);
				return bexString(_result);
			} else {
				BEXList _children(bexKey(BEX_CHLD_LIST, _index), -_content, __owner);
				return _children.get(0).value();
			}
		}
		case BEX_TEXT_NODE:
		case BEX_TEXTELEM_NODE: {
			BEXFileData & _data = *__owner.__data;
			IAMArray _result = _data.chldValueText.item(_data.chldContentRef.get(bexIndex(_key)));
			return bexString(_result);
		}
	}
	throw IAMException(IAMException::INVALID_HEADER);
}

INT32 BEXNode::index() {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_VOID_TYPE:
			return -1;
		case BEX_ATTR_NODE: {
			BEXFileData & _data = *__owner.__data;
			IAMArray & _array = _data.attrParentRef;
			if (_array.length() == 0) return -1;
			INT32 _index = bexIndex(_key);
			return _index - _data.attrListRange.get(_data.chldAttributesRef.get(_array.get(_index)));
		}
		case BEX_ELEM_NODE: {
			BEXFileData & _data = *__owner.__data;
			IAMArray & _array = _data.chldParentRef;
			if (_array.length() == 0) return -1;
			INT32 _index = bexIndex(_key);
			INT32 _parent = _array.get(_index);
			if (_index == _parent) return -1;
			return _index - _data.chldListRange.get(_data.chldContentRef.get(_parent));
		}
		case BEX_TEXT_NODE: {
			BEXFileData & _data = *__owner.__data;
			IAMArray & _array = _data.chldParentRef;
			if (_array.length() == 0) return -1;
			INT32 _index = bexIndex(_key);
			return _index - _data.chldListRange.get(_data.chldContentRef.get(_array.get(_index)));
		}
		case BEX_TEXTELEM_NODE:
			return 0;
	}
	throw IAMException(IAMException::INVALID_HEADER);
}

BEXNode BEXNode::parent() {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_VOID_TYPE:
			return BEXNode(__owner);
		case BEX_ATTR_NODE: {
			BEXFileData & _data = *__owner.__data;
			IAMArray & _array = _data.attrParentRef;
			if (_array.length() == 0) return BEXNode(__owner);
			return BEXNode(bexKey(BEX_ELEM_NODE, _array.get(bexIndex(_key))), __owner);
		}
		case BEX_ELEM_NODE: {
			BEXFileData & _data = *__owner.__data;
			IAMArray & _array = _data.chldParentRef;
			if (_array.length() == 0) return BEXNode(__owner);
			INT32 _index = bexIndex(_key);
			INT32 _parent = _array.get(_index);
			if (_index == _parent) return BEXNode(__owner);
			return BEXNode(bexKey(BEX_ELEM_NODE, _parent), __owner);
		}
		case BEX_TEXT_NODE: {
			BEXFileData & _data = *__owner.__data;
			IAMArray & _array = _data.chldParentRef;
			if (_array.length() == 0) return BEXNode(__owner);
			return BEXNode(bexKey(BEX_ELEM_NODE, _array.get(bexIndex(_key))), __owner);
		}
		case BEX_TEXTELEM_NODE:
			return BEXNode(bexKey(BEX_ELEM_NODE, bexIndex(_key)), __owner);
	}
	throw IAMException(IAMException::INVALID_HEADER);
}

BEXList BEXNode::children() {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_ELEM_NODE: {
			BEXFileData & _data = *__owner.__data;
			INT32 _index = bexIndex(_key);
			INT32 _content = _data.chldContentRef.get(_index);
			if (_content >= 0) return BEXList(bexKey(BEX_CHLDTEXT_LIST, _index), 0, __owner);
			return BEXList(bexKey(BEX_CHLD_LIST, _index), -_content, __owner);
		}
		case BEX_VOID_TYPE:
		case BEX_ATTR_NODE:
		case BEX_TEXT_NODE:
		case BEX_TEXTELEM_NODE:
			return BEXList(__owner);
	}
	return BEXList();
}

BEXList BEXNode::attributes() {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_ELEM_NODE: {
			BEXFileData & _data = *__owner.__data;
			INT32 _index = bexIndex(_key);
			return BEXList(bexKey(BEX_ATTR_LIST, _index), _data.chldAttributesRef.get(_index), __owner);
		}
		case BEX_VOID_TYPE:
		case BEX_ATTR_NODE:
		case BEX_TEXT_NODE:
		case BEX_TEXTELEM_NODE:
			return BEXList(__owner);
	}
	return BEXList();
}

// class BEXList

BEXList::BEXList()
		: __key(bexKey(BEX_VOID_TYPE, 0)), __ref(0), __owner() {
}

BEXList::BEXList(BEXFile const & _owner)
		: __key(bexKey(BEX_VOID_TYPE, 0)), __ref(0), __owner(_owner) {
}

BEXList::BEXList(UINT32 const _key, INT32 const _ref, BEXFile const & _owner)
		: __key(_key), __ref(_ref), __owner(_owner) {
}

UINT32 BEXList::key() {
	return __key;
}

UINT8 BEXList::type() {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_VOID_TYPE:
			return BEXList::TYPE_VOID;
		case BEX_ATTR_LIST:
			return BEXList::TYPE_ATTR;
		case BEX_CHLD_LIST:
		case BEX_CHLDTEXT_LIST:
			return BEXList::TYPE_CHLD;
	}
	throw IAMException(IAMException::INVALID_HEADER);
}

BEXFile BEXList::owner() {
	return __owner;
}

BEXNode BEXList::get(INT32 const _index) {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_VOID_TYPE:
			return BEXNode(__owner);
		case BEX_ATTR_LIST: {
			if (_index < 0) return BEXNode(__owner);
			BEXFileData & _data = *__owner.__data;
			IAMArray & _ranges = _data.attrListRange;
			INT32 _ref = __ref;
			INT32 _result = _ranges.get(_ref) + _index;
			if (_result >= _ranges.get(_ref + 1)) return BEXNode(__owner);
			return BEXNode(bexKey(BEX_ATTR_NODE, _result), __owner);
		}
		case BEX_CHLD_LIST: {
			if (_index < 0) return BEXNode(__owner);
			BEXFileData & _data = *__owner.__data;
			IAMArray & _ranges = _data.chldListRange;
			INT32 _ref = __ref;
			INT32 _result = _ranges.get(_ref) + _index;
			if (_result >= _ranges.get(_ref + 1)) return BEXNode(__owner);
			if (_data.chldNameRef.get(_result) == 0) return BEXNode(bexKey(BEX_TEXT_NODE, _result), __owner);
			return BEXNode(bexKey(BEX_ELEM_NODE, _result), __owner);
		}
		case BEX_CHLDTEXT_LIST: {
			if (_index != 0) return BEXNode(__owner);
			return BEXNode(bexKey(BEX_TEXTELEM_NODE, bexIndex(_key)), __owner);
		}
	}
	throw IAMException(IAMException::INVALID_HEADER);
}

INT32 BEXList::find(string const & _uri, string const & _name, INT32 const _start) {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_ATTR_LIST: {
			if (_start < 0) return -1;
			bool _useUri = _uri.length() != 0, _useName = _name.length() != 0;
			IAMArray _uriArray(bexArray(_uri)), _nameArray(bexArray(_name));
			BEXFileData & _data = *__owner.__data;
			IAMArray & _ranges = _data.attrListRange;
			INT32 _ref = __ref;
			INT32 _startRef = _ranges.get(_ref), _finalRef = _ranges.get(_ref + 1);
			for (_ref = _startRef + _start; _ref < _finalRef; _ref++) {
				if (_useUri) {
					IAMArray _attrUri = _data.attrUriText.item(_data.attrUriRef.get(_ref));
					if (!_attrUri.equals(_uriArray)) continue;
				}
				if (_useName) {
					IAMArray _nameUri = _data.attrNameText.item(_data.attrNameRef.get(_ref));
					if (!_nameUri.equals(_nameArray)) continue;
				}
				return _ref - _startRef;
			}
			return -1;
		}
		case BEX_CHLD_LIST: {
			if (_start < 0) return -1;
			bool _useUri = _uri.length() != 0, _useName = _name.length() != 0;
			IAMArray _uriArray(bexArray(_uri)), _nameArray(bexArray(_name));
			BEXFileData & _data = *__owner.__data;
			IAMArray & _ranges = _data.chldListRange;
			INT32 _ref = __ref;
			INT32 _startRef = _ranges.get(_ref), _finalRef = _ranges.get(_ref + 1);
			for (_ref = _startRef + _start; _ref < _finalRef; _ref++) {
				INT32 _nameRef = _data.chldNameRef.get(_ref);
				if (_nameRef == 0) continue;
				if (_useUri) {
					IAMArray _attrUri = _data.chldUriText.item(_data.chldUriRef.get(_ref));
					if (!_attrUri.equals(_uriArray)) continue;
				}
				if (_useName) {
					IAMArray _nameUri = _data.chldNameText.item(_useName);
					if (!_nameUri.equals(_nameArray)) continue;
				}
				return _ref - _startRef;
			}
			return -1;
		}
		case BEX_VOID_TYPE:
		case BEX_CHLDTEXT_LIST:
			return -1;
	}
	throw IAMException(IAMException::INVALID_HEADER);
}

INT32 BEXList::length() {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_VOID_TYPE:
			return 0;
		case BEX_ATTR_LIST: {
			BEXFileData & _data = *__owner.__data;
			IAMArray & _ranges = _data.attrListRange;
			INT32 _ref = __ref;
			return _ranges.get(_ref + 1) - _ranges.get(_ref);
		}
		case BEX_CHLD_LIST: {
			BEXFileData & _data = *__owner.__data;
			IAMArray & _ranges = _data.chldListRange;
			INT32 _ref = __ref;
			return _ranges.get(_ref + 1) - _ranges.get(_ref);
		}
		case BEX_CHLDTEXT_LIST:
			return 1;
	}
	throw IAMException(IAMException::INVALID_HEADER);
}

BEXNode BEXList::parent() {
	UINT32 _key = __key;
	switch (bexType(_key)) {
		case BEX_VOID_TYPE:
			return BEXNode(__owner);
		case BEX_ATTR_LIST:
		case BEX_CHLD_LIST:
		case BEX_CHLDTEXT_LIST:
			return BEXNode(bexKey(BEX_ELEM_NODE, bexIndex(_key)), __owner);
	}
	throw IAMException(IAMException::INVALID_HEADER);
}

// class BEXFile

BEXFile::BEXFile()
		: __data(new BEXFileData()) {
}

BEXFile::BEXFile(mmf::MMFView const & _file)
		: __data(new BEXFileData()) {
	__data->load(_file);
}

BEXFile::BEXFile(PCINT32 const _data, INT32 const _length)
		: __data(new BEXFileData()) {
	__data->load(_data, _length);
}

BEXNode BEXFile::root() {
	return BEXNode(bexKey(BEX_ELEM_NODE, __data->rootRef), *this);
}

BEXNode BEXFile::node(UINT32 const _key) {
	switch (bexType(_key)) {
		case BEX_ATTR_NODE: {
			BEXFileData & _data = *__data;
			INT32 _index = bexIndex(_key);
			if (_index >= _data.attrNameRef.length()) return BEXNode(*this);
			return BEXNode(bexKey(BEX_ATTR_NODE, _index), *this);
		}
		case BEX_ELEM_NODE: {
			BEXFileData & _data = *__data;
			INT32 _index = bexIndex(_key);
			if (_data.chldNameRef.get(_index) == 0) return BEXNode(*this);
			return BEXNode(bexKey(BEX_ELEM_NODE, _index), *this);
		}
		case BEX_TEXT_NODE: {
			BEXFileData & _data = *__data;
			INT32 _index = bexIndex(_key);
			IAMArray & _names = _data.chldNameRef;
			if ((_index >= _names.length()) || (_names.get(_index) != 0)) return BEXNode(*this);
			return BEXNode(bexKey(BEX_TEXT_NODE, _index), *this);
		}
		case BEX_TEXTELEM_NODE: {
			BEXFileData & _data = *__data;
			INT32 _index = bexIndex(_key);
			if ((_data.chldNameRef.get(_index) == 0) || (_data.chldContentRef.get(_index) < 0)) return BEXNode(*this);
			return BEXNode(bexKey(BEX_TEXTELEM_NODE, _index), *this);
		}
	}
	return BEXNode(*this);
}

BEXList BEXFile::list(UINT32 const _key) {
	switch (bexType(_key)) {
		case BEX_ATTR_LIST:
			return node(bexKey(BEX_ELEM_NODE, bexIndex(_key))).attributes();
		case BEX_CHLD_LIST:
		case BEX_CHLDTEXT_LIST:
			return node(bexKey(BEX_ELEM_NODE, bexIndex(_key))).children();
	}
	return BEXList(*this);
}

}

}

}

