#ifndef BEE_CREATIVE_BEX_HPP

#define BEE_CREATIVE_BEX_HPP

#include "bee_creative_iam.hpp"

namespace bee {

namespace creative {

/**
 * Dieser Namensraum realisiert eine nurlesbare Implementation des BEX.<p>
 * Das <i>BEX – Binary Encoded XML</i> beschreibt eine nur lesbare Vereinfachung des <i>Document Object Model (DOM)</i> sowie ein binäres Datenformat zur redundanzarmen Abbildung der Daten eines <i>DOM</i> Dokuments. Ziel dieses Formats ist es, eine leichtgewichtige, nur lesende <i>DOM</i>-Implementation darauf aufsetzen zu können, welche signifikant weniger Arbeitsspeicher verbraucht, als eine zumeist auch modifizierende Implementation einer Standard <i>XML</i> Bibliothek.
 * @author [cc-by] 2013 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]
 */
namespace bex {

using std::string;
using mmf::MMFView;

class BEXNode;

class BEXList;

declare_RCObject(BEXFileData)

class BEXFile {

	public:

	BEXFile();

	BEXFile(MMFView const & file);

	BEXFile(PCINT32 const data, INT32 const length);

	BEXNode root();

	BEXNode node(UINT32 const key);

	BEXList list(UINT32 const key);

	private:

	friend BEXNode;

	friend BEXList;

	RCPointer(BEXFileData) __data;

};

class BEXNode {

	public:

	static UINT8 const TYPE_VOID = 0;

	static UINT8 const TYPE_ATTR = 1;

	static UINT8 const TYPE_ELEM = 2;

	static UINT8 const TYPE_TEXT = 3;

	BEXNode();

	BEXNode(BEXFile const & owner);

	UINT32 key();

	UINT8 type();

	BEXFile owner();

	string uri();

	string name();

	string value();

	INT32 index();

	BEXNode parent();

	BEXList children();

	BEXList attributes();

	private:

	friend BEXFile;

	friend BEXList;

	BEXNode(UINT32 const key, BEXFile const & owner);

	UINT32 __key;

	BEXFile __owner;

};

class BEXList {

	public:

	static UINT8 const TYPE_VOID = 0;

	static UINT8 const TYPE_ATTR = 1;

	static UINT8 const TYPE_CHLD = 2;

	BEXList();

	BEXList(BEXFile const & owner);

	UINT32 key();

	UINT8 type();

	BEXFile owner();

	BEXNode get(INT32 const index);

	INT32 find(string const & uri, string const & name, INT32 const start = 0);

	INT32 length();

	BEXNode parent();

	private:

	friend BEXFile;

	friend BEXNode;

	BEXList(UINT32 const key, INT32 const ref, BEXFile const & owner);

	UINT32 __key;

	INT32 __ref;

	BEXFile __owner;

};

}

}

}

#endif
