/* [cc-by] 2013 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#include "bee_creative_iam.hpp"

namespace bee {

namespace creative {

namespace iam {

using std::vector;
using mmf::MMFView;

// function __byteCount / __byteAlign

/**
 * Diese Methode gibt die Byteanzahl des gegebenen Datengrößentyps zurück.
 * @param _dataType Datengrößentyp (@c 1 = @c INT8, @c 2 = @c INT16, @c 3 = @c INT32).
 * @return Byteanzahl (@c 1, @c 2, @c 4).
 */
UINT8 __byteCount(UINT8 const _dataType) {
	return 1 << (_dataType - 1);
}

/**
 * Diese Methode gibt die kleinste Länge eines @c INT32 Arrays zurück, in dessen Speicherbereich ein @c INT8 Array mit der gegebenen Länge passen.
 * @param _byteCount Länge eines @c INT8 Arrays.
 * @return Länge des @c INT32 Arrays.
 */
UINT32 __byteAlign(UINT32 const _byteCount) {
	return (_byteCount + 3) >> 2;
}

// function __dataGet / __dataType / __dataArray / __dataValue / __dataLength

/**
 * Diese Methode gibt die @c index-te Zahl der gegebenen Zahlenfolge zurück.
 * @see __dataType(UINT8 const, UINT8 const)
 * @param _type Datengrößentyp zur Interpretation der Zahlenfolge (@c [30:0][2:S]).
 * @param _array Zahlenfolge.
 * @param _index Index.
 * @return @c index-te Zahl.
 */
UINT32 __dataGet(UINT8 const _type, PCVOID const _array, INT32 const _index) {
	switch (_type) {
		case 0: // D0
			return (UINT32) _array;
		case 1: // D1
			return ((PCUINT8) _array)[_index];
		case 2: // D2
			return ((PCUINT16) _array)[_index];
		case 3: // D3
			return ((PCUINT32) _array)[_index];
	}
	return 0;
}

/**
 * Diese Methode gibt die aus den gegebenen Größen zusammengesetzte Datentypkennung zurück.
 * @param _dataType Datengrößentyp (1 = INT8, 2 = INT16, 3 = INT32).
 * @param _sizeType Datenlängentyp (0 = statisch UINT32, 1 = dynamisch UINT8, 2 = dynamisch UINT16, 3 = dynamisch UINT32).
 * @return Datentypkennung (_dataType * 4 + _sizeType - 4).
 */
UINT8 __dataType(UINT8 const _dataType, UINT8 const _sizeType) {
	return _dataType * 4 + _sizeType - 4;
}

/**
 * Diese Methode gibt die @c _arrayIndex-te Zahlenfolge mit statischer Größe aus dem gegebenen Speicherbereich zurück.
 * @tparam PCDATA Datentyp zur Interpretation von @c _arrayData.
 * @param _arraySize Größe einer Zahlenfolge (@c UINT32).
 * @param _arrayData Speicherbereich mit den Daten der Zahlenfolgen.
 * @param _arrayIndex Index der Zahlenfolge.
 * @return @c _arrayIndex-te Zahlenfolge.
 */
template<typename PCDATA>
IAMArray __dataArray_S(PCVOID const _arraySize, PCVOID const _arrayData, INT32 const _arrayIndex) {
	UINT32 const _length = (UINT32) _arraySize;
	PCDATA const _array = (PCDATA const) _arrayData;
	return IAMArray(_array + _arrayIndex * _length, _length);
}

/**
 * Diese Methode gibt die @c _arrayIndex-te Zahlenfolge mit dynamischer Größe aus dem gegebenen Speicherbereich zurück.
 * @tparam PCDATA Datentyp zur Interpretation von @c _arrayData.
 * @tparam PCSIZE Datentyp zur Interpretation von @c _arraySize.
 * @param _arraySize Speicherbereich mit den Längen der Zahlenfolgen.
 * @param _arrayData Speicherbereich mit den Daten der Zahlenfolgen.
 * @param _arrayIndex Index der Zahlenfolge.
 * @return @c _arrayIndex-te Zahlenfolge.
 */
template<typename PCDATA, typename PCSIZE>
IAMArray __dataArray_D(PCVOID const _arraySize, PCVOID const _arrayData, INT32 const _arrayIndex) {
	PCSIZE const _size = (PCSIZE const) _arraySize;
	UINT32 _offset = _size[_arrayIndex];
	UINT32 _length = _size[_arrayIndex + 1] - _offset;
	PCDATA const _array = (PCDATA const) _arrayData;
	return IAMArray(_array + _offset, _length);
}

/**
 * Diese Methode gibt die @c _arrayIndex-te Zahlenfolge aus dem gegebenen Speicherbereich zurück.
 * @see __dataType(UINT8 const, UINT8 const)
 * @param _type Datentypkennung zur Interpretation von @c _arraySize und @c _arrayData.
 * @param _arraySize Größe der Zahlenfolge bzw. Speicherbereich mit den Längen der Zahlenfolgen.
 * @param _arrayData Speicherbereich mit den Daten der Zahlenfolgen.
 * @param _arrayIndex Index der Zahlenfolge.
 * @return @c _arrayIndex-te Zahlenfolge.
 */
IAMArray __dataArray(UINT8 const _type, PCVOID const _arraySize, PCVOID const _arrayData, INT32 const _arrayIndex) {
	switch (_type) {
		case 0: // D1, S0
			return __dataArray_S<PCINT8>(_arraySize, _arrayData, _arrayIndex);
		case 1: // D1, S1
			return __dataArray_D<PCINT8, PCUINT8>(_arraySize, _arrayData, _arrayIndex);
		case 2: // D1, S2
			return __dataArray_D<PCINT8, PCUINT16>(_arraySize, _arrayData, _arrayIndex);
		case 3: // D1, S3
			return __dataArray_D<PCINT8, PCUINT32>(_arraySize, _arrayData, _arrayIndex);
		case 4: // D2, S0
			return __dataArray_S<PCINT16>(_arraySize, _arrayData, _arrayIndex);
		case 5: // D2, S1
			return __dataArray_D<PCINT16, PCUINT8>(_arraySize, _arrayData, _arrayIndex);
		case 6: // D2, S2
			return __dataArray_D<PCINT16, PCUINT16>(_arraySize, _arrayData, _arrayIndex);
		case 7: // D2, S3
			return __dataArray_D<PCINT16, PCUINT32>(_arraySize, _arrayData, _arrayIndex);
		case 8: // D3, S0
			return __dataArray_S<PCINT32>(_arraySize, _arrayData, _arrayIndex);
		case 9: // D3, S1
			return __dataArray_D<PCINT32, PCUINT8>(_arraySize, _arrayData, _arrayIndex);
		case 10: // D3, S2
			return __dataArray_D<PCINT32, PCUINT16>(_arraySize, _arrayData, _arrayIndex);
		case 11: // D3, S3
			return __dataArray_D<PCINT32, PCUINT32>(_arraySize, _arrayData, _arrayIndex);
	}
	return IAMArray();
}

/**
 * Diese Methode gibt die @c _valueIndex-te Zahl der @c _arrayIndex-ten Zahlenfolge mit statischer Größe aus dem gegebenen Speicherbereich zurück.
 * @tparam PCDATA Datentyp zur Interpretation von @c _arrayData.
 * @param _arraySize Größe einer Zahlenfolge (@c UINT32).
 * @param _arrayData Speicherbereich mit den Daten der Zahlenfolgen.
 * @param _arrayIndex Index der Zahlenfolge.
 * @param _valueIndex Index der Zahl.
 * @return @c _valueIndex-te Zahl der @c _arrayIndex-ten Zahlenfolge.
 */
template<typename PCDATA>
INT32 __dataValue_S(PCVOID const _arraySize, PCVOID const _arrayData, INT32 const _arrayIndex, INT32 const _valueIndex) {
	UINT32 const _length = (UINT32) _arraySize;
	if ((UINT32) _valueIndex >= _length) return 0;
	PCDATA const _array = (PCDATA const) _arrayData;
	return _array[_arrayIndex * _length + _valueIndex];
}

/**
 * Diese Methode gibt die @c _valueIndex-te Zahl der @c _arrayIndex-ten Zahlenfolge mit dynamischer Größe aus dem gegebenen Speicherbereich zurück.
 * @tparam PCDATA Datentyp zur Interpretation von @c _arrayData.
 * @tparam PCSIZE Datentyp zur Interpretation von @c _arraySize.
 * @param _arraySize Speicherbereich mit den Längen der Zahlenfolgen.
 * @param _arrayData Speicherbereich mit den Daten der Zahlenfolgen.
 * @param _arrayIndex Index der Zahlenfolge.
 * @param _valueIndex Index der Zahl.
 * @return @c _valueIndex-te Zahl der @c _arrayIndex-ten Zahlenfolge.
 */
template<typename PCDATA, typename PCSIZE>
INT32 __dataValue_D(PCVOID const _arraySize, PCVOID const _arrayData, INT32 const _arrayIndex, INT32 const _valueIndex) {
	PCSIZE const _size = (PCSIZE const) _arraySize;
	UINT32 const _index = _size[_arrayIndex] + _valueIndex;
	if (_index >= _size[_arrayIndex + 1]) return 0;
	PCDATA const _array = (PCDATA const) _arrayData;
	return _array[_valueIndex];
}

/**
 * Diese Methode gibt die @c _valueIndex-te Zahl der @c _arrayIndex-ten Zahlenfolge aus dem gegebenen Speicherbereich zurück.
 * @see __dataType(UINT8 const, UINT8 const)
 * @param _type Datentypkennung zur Interpretation von @c _arraySize und @c _arrayData.
 * @param _arraySize Größe der Zahlenfolge bzw. Speicherbereich mit den Längen der Zahlenfolgen.
 * @param _arrayData Speicherbereich mit den Daten der Zahlenfolgen.
 * @param _arrayIndex Index der Zahlenfolge.
 * @param _valueIndex Index der Zahl.
 * @return @c _valueIndex-te Zahl der @c _arrayIndex-ten Zahlenfolge.
 */
INT32 __dataValue(UINT8 const _type, PCVOID const _arraySize, PCVOID const _arrayData, INT32 const _arrayIndex, INT32 const _valueIndex) {
	switch (_type) {
		case 0: // D1, S0
			return __dataValue_S<PCINT8>(_arraySize, _arrayData, _arrayIndex, _valueIndex);
		case 1: // D1, S1
			return __dataValue_D<PCINT8, PCUINT8>(_arraySize, _arrayData, _arrayIndex, _valueIndex);
		case 2: // D1, S2
			return __dataValue_D<PCINT8, PCUINT16>(_arraySize, _arrayData, _arrayIndex, _valueIndex);
		case 3: // D1, S3
			return __dataValue_D<PCINT8, PCUINT32>(_arraySize, _arrayData, _arrayIndex, _valueIndex);
		case 4: // D2, S0
			return __dataValue_S<PCINT16>(_arraySize, _arrayData, _arrayIndex, _valueIndex);
		case 5: // D2, S1
			return __dataValue_D<PCINT16, PCUINT8>(_arraySize, _arrayData, _arrayIndex, _valueIndex);
		case 6: // D2, S2
			return __dataValue_D<PCINT16, PCUINT16>(_arraySize, _arrayData, _arrayIndex, _valueIndex);
		case 7: // D2, S3
			return __dataValue_D<PCINT16, PCUINT32>(_arraySize, _arrayData, _arrayIndex, _valueIndex);
		case 8: // D3, S0
			return __dataValue_S<PCINT32>(_arraySize, _arrayData, _arrayIndex, _valueIndex);
		case 9: // D3, S1
			return __dataValue_D<PCINT32, PCUINT8>(_arraySize, _arrayData, _arrayIndex, _valueIndex);
		case 10: // D3, S2
			return __dataValue_D<PCINT32, PCUINT16>(_arraySize, _arrayData, _arrayIndex, _valueIndex);
		case 11: // D3, S3
			return __dataValue_D<PCINT32, PCUINT32>(_arraySize, _arrayData, _arrayIndex, _valueIndex);
	}
	return 0;
}

/**
 * Diese Methode gibt die Länge der @c _arrayIndex-ten Zahlenfolge aus dem gegebenen Speicherbereich zurück.
 * @tparam PCSIZE Datentyp zur Interpretation von @c _arraySize.
 * @param _arraySize Speicherbereich mit den Längen der Zahlenfolgen.
 * @param _arrayIndex Index der Zahlenfolge.
 * @return Länge der @c _arrayIndex-ten Zahlenfolge
 */
template<typename PCSIZE>
UINT32 __dataLength_D(PCVOID const _arraySize, INT32 const _arrayIndex) {
	PCSIZE const _size = (PCSIZE const) _arraySize;
	return _size[_arrayIndex + 1] - _size[_arrayIndex];
}

/**
 * Diese Methode gibt die Länge der @c _arrayIndex-ten Zahlenfolge aus dem gegebenen Speicherbereich zurück.
 * @see __dataType(UINT8 const, UINT8 const)
 * @param _type Datenlängentyp zur Interpretation von @c _arraySize.
 * @param _arraySize Größe der Zahlenfolge bzw. Speicherbereich mit den Längen der Zahlenfolgen.
 * @param _arrayIndex Index der Zahlenfolge.
 * @return Länge der @c _arrayIndex-ten Zahlenfolge
 */
UINT32 __dataLength(UINT8 const _type, PCVOID const _arraySize, INT32 const _arrayIndex) {
	switch (_type) {
		case 0: // S0
			return (UINT32) _arraySize;
		case 1: // S1
			return __dataLength_D<PCUINT8>(_arraySize, _arrayIndex);
		case 2: // S2
			return __dataLength_D<PCUINT16>(_arraySize, _arrayIndex);
		case 3: // S3
			return __dataLength_D<PCUINT32>(_arraySize, _arrayIndex);
	}
	return 0;
}

/**
 * Diese Methode prüft die Monotonität der gegebenen Zahlenfolge.
 * @tparam PCSIZE Datentyp zur Interpretation von @c _arraySize.
 * @param _arraySize Speicherbereich mit den Startpositionen der Zahlenfolgen.
 * @param _arrayCount Anzahl der Zahlenfolgen.
 * @throws IAMException Wenn die erste Zahl nicht @c 0 ist oder die Zahlen nicht monoton steigen.
 */
template<typename PCSIZE>
void __dataCheck_S(PCVOID const _arraySize, INT32 const _arrayCount) {
	PCSIZE const _size = (PCSIZE const) _arraySize;
	UINT32 value = _size[0];
	if (!value) throw IAMException(IAMException::INVALID_OFFSET);
	for (INT32 i = 0; i <= _arrayCount; i++) {
		UINT32 const value2 = _size[i];
		if (value > value2) throw IAMException(IAMException::INVALID_OFFSET);
		value = value2;
	}
}

/**
 * Diese Methode prüft die Monotonität der gegebenen Zahlenfolge.
 * @see __dataType(UINT8 const, UINT8 const)
 * @param _type Datenlängentyp zur Interpretation von @c _arraySize.
 * @param _arraySize Speicherbereich mit den Startpositionen der Zahlenfolgen.
 * @param _arrayCount Anzahl der Zahlenfolgen.
 * @throws IAMException Wenn die erste Zahl nicht @c 0 ist oder die Zahlen nicht monoton steigen.
 */
void __dataCheck(UINT8 const _type, PCVOID const _arraySize, INT32 const _arrayCount) {
	switch (_type) {
		case 1: // S1
			__dataCheck_S<PCUINT8>(_arraySize, _arrayCount);
			return;
		case 2: // S2
			__dataCheck_S<PCUINT16>(_arraySize, _arrayCount);
			return;
		case 3: // S3
			__dataCheck_S<PCUINT32>(_arraySize, _arrayCount);
			return;
	}
}

// function __arrayHash / __arrayEquals / __arrayCompare

/**
 * Diese Methode gibt den Streuwert der gegebenen Zahlenfolge zurück
 * @tparam PCDATA Datentyp zur Interpretation von @c _array.
 * @param _array Zahlenfolge.
 * @param _length Länge der Zahlenfolge.
 * @return Streuwert.
 */template<typename PCDATA>
INT32 __arrayHash(PCVOID const _array, INT32 const _length) {
	PCDATA _data = (PCDATA) _array;
	INT32 _result = 0x811C9DC5;
	for (INT32 i = 0; i < _length; i++)
		_result = (_result * 0x01000193) ^ (INT32) _data[i];
	return _result;
}

/**
 * Diese Methode gibt nur dann @c true zurück, wenn die gegebenen Zahlenfolgen gleich sind.
 * @tparam PCDATA1 Datentyp zur Interpretation von @c _array1.
 * @tparam PCDATA2 Datentyp zur Interpretation von @c _array2.
 * @param _array1 Erste Zahlenfolge.
 * @param _array2 Zweite Zahlenfolge.
 * @param _length Länge der Zahlenfolgen.
 * @return @c true, wenn die Zahlenfolgen gleich sind.
 */
template<typename PCDATA1, typename PCDATA2>
bool __arrayEquals(PCVOID const _array1, PCVOID const _array2, UINT32 const _length) {
	PCDATA1 const _data1 = (PCDATA1 const) _array1;
	PCDATA2 const _data2 = (PCDATA2 const) _array2;
	for (UINT32 i = 0; i < _length; i++)
		if (_data1[i] != _data2[i]) return false;
	return true;
}

/**
 * Diese Methode gibt eine Zahl kleiner, gleich oder größer als @c 0 zurück, wenn die Ordnung der ersten Zahlenfolge lexikografisch kleiner, gleich bzw. größer als die der zweiten Zahlenfolge ist.
 * @tparam PCDATA1 Datentyp zur Interpretation von @c _array1.
 * @tparam PCDATA2 Datentyp zur Interpretation von @c _array2.
 * @param _array1 Erste Zahlenfolge.
 * @param _array2 Zweite Zahlenfolge.
 * @param _length1 Länge der ersten Zahlenfolge.
 * @param _length2 Länge der zweiten Zahlenfolge.
 * @return Vergleichswert der Ordnungen.
 */
template<typename PCDATA1, typename PCDATA2>
INT32 __arrayCompare(PCVOID const _array1, PCVOID const _array2, UINT32 const _length1, UINT32 const _length2) {
	PCDATA1 const _data1 = (PCDATA1 const) _array1;
	PCDATA2 const _data2 = (PCDATA2 const) _array2;
	UINT32 const _length = _length1 < _length2 ? _length1 : _length2;
	for (INT32 i = 0; i < _length; i++) {
		INT32 _result = _data1[i] - _data2[i];
		if (_result != 0) return _result;
	}
	return _length1 - _length2;
}

// class IAMArray

template<typename PCDATA>
void __arrayNew(PCVOID & _data, UINT32 & _size, UINT8 const _type, PCDATA const _array, INT32 const _length) {
	if (!_array || _length <= 0) {
		_size = 0;
		_data = 0;
	} else {
		UINT32 _count = _length <= 0x3FFFFFFF ? _length : 0x3FFFFFFF;
		if (_type) {
			_data = _array;
			_size = (_count << 2) | _type;
			return;
		} else {
			INT32 * _copy = new INT32[_count + 1];
			_copy[0] = 2;
			_copy++;
			for (INT32 i = 0; i < _count; i++)
				_copy[i] = _array[i];
			_data = _copy;
			_size = _count << 2;
		}
	}
}

define_RCObject(__arrayRC) {
};

/**
 * Diese Methode gibt die Zahlenfolge zurück, der im kopierenden Konstrukteur von @c IAMArray verwendet wird.
 * @param _data @c __data der Quelldaten.
 * @param _size @c __size der Quelldaten.
 * @return Zahlenfolge.
 */
PCVOID __arrayDataUse(PCVOID const _data, UINT32 const _size) {
	if (_size & 3) return _data;
	PINT32 _array = (PINT32) _data - 1;
	intrusive_ptr_add_ref((__arrayRC *) _array);
	return _data;
}

void __arrayDataFree(PCVOID const _data, INT32 const _size) {
	if ((_size & 3) || !_data) return;
	PCINT32 _array = (PCINT32) _data - 1;
	intrusive_ptr_release((__arrayRC *) _array);
	if (_array[0] != 1) return;
	delete[] _array;
}

IAMArray::IAMArray()
		: __size(0), __data(0) {
}

IAMArray::IAMArray(IAMArray const & _source) {
	__data = __arrayDataUse(_source.__data, __size = _source.__size);
}

IAMArray::IAMArray(PCINT8 const _array, INT32 const _length) {
	__arrayNew<PCINT8>(__data, __size, 1, _array, _length);
}

IAMArray::IAMArray(PCINT8 const _array, INT32 const _length, bool const _copy) {
	__arrayNew<PCINT8>(__data, __size, _copy ? 0 : 1, _array, _length);
}

IAMArray::IAMArray(PCINT16 const _array, INT32 const _length) {
	__arrayNew<PCINT16>(__data, __size, 2, _array, _length);
}

IAMArray::IAMArray(PCINT16 const _array, INT32 const _length, bool const _copy) {
	__arrayNew<PCINT16>(__data, __size, _copy ? 0 : 2, _array, _length);
}

IAMArray::IAMArray(PCINT32 const _array, INT32 const _length) {
	__arrayNew<PCINT32>(__data, __size, 3, _array, _length);
}

IAMArray::IAMArray(PCINT32 const _array, INT32 const _length, bool const _copy) {
	__arrayNew<PCINT32>(__data, __size, _copy ? 0 : 3, _array, _length);
}

IAMArray::~IAMArray() {
	__arrayDataFree(__data, __size);
}

INT32 IAMArray::get(INT32 const _index) const {
	UINT32 const _size = __size;
	if (((UINT32) _index) >= (_size >> 2)) return 0;
	PCVOID const _data = __data;
	switch (_size & 3) {
		case 0:
			return ((PCINT32) _data)[_index];
		case 1:
			return ((PCINT8) _data)[_index];
		case 2:
			return ((PCINT16) _data)[_index];
		case 3:
			return ((PCINT32) _data)[_index];
	}
	return 0;
}

INT32 IAMArray::length() const {
	return __size >> 2;
}

PCVOID IAMArray::data() const {
	return __data;
}

UINT8 IAMArray::type() const {
	UINT8 _size = __size & 3;
	return (_size ? 1 << _size : 8) >> 1;
}

INT32 IAMArray::hash() const {
	UINT32 const _size = __size;
	PCVOID const _data = __data;
	UINT32 const _length = _size >> 2;
	switch (_size & 3) {
		case 0:
			return __arrayHash<PCINT32>(_data, _length);
		case 1:
			return __arrayHash<PCINT8>(_data, _length);
		case 2:
			return __arrayHash<PCINT16>(_data, _length);
		case 3:
			return __arrayHash<PCINT32>(_data, _length);
	}
	return 0;
}

bool IAMArray::equals(const IAMArray & _value) const {
	UINT32 const _size1 = __size, _size2 = _value.__size, _length = _size1 >> 2;
	if (_length != (_size2 >> 2)) return false;
	PCVOID const _data1 = __data, _data2 = _value.__data;
	switch (((_size1 & 3) << 2) | (_size2 & 3)) {
		case 0:
			return __arrayEquals<PCINT32, PCINT32>(_data1, _data2, _length);
		case 1:
			return __arrayEquals<PCINT32, PCINT8>(_data1, _data2, _length);
		case 2:
			return __arrayEquals<PCINT32, PCINT16>(_data1, _data2, _length);
		case 3:
			return __arrayEquals<PCINT32, PCINT32>(_data1, _data2, _length);
		case 4:
			return __arrayEquals<PCINT8, PCINT32>(_data1, _data2, _length);
		case 5:
			return __arrayEquals<PCINT8, PCINT8>(_data1, _data2, _length);
		case 6:
			return __arrayEquals<PCINT8, PCINT16>(_data1, _data2, _length);
		case 7:
			return __arrayEquals<PCINT8, PCINT32>(_data1, _data2, _length);
		case 8:
			return __arrayEquals<PCINT16, PCINT32>(_data1, _data2, _length);
		case 9:
			return __arrayEquals<PCINT16, PCINT8>(_data1, _data2, _length);
		case 10:
			return __arrayEquals<PCINT16, PCINT16>(_data1, _data2, _length);
		case 11:
			return __arrayEquals<PCINT16, PCINT32>(_data1, _data2, _length);
		case 12:
			return __arrayEquals<PCINT32, PCINT32>(_data1, _data2, _length);
		case 13:
			return __arrayEquals<PCINT32, PCINT8>(_data1, _data2, _length);
		case 14:
			return __arrayEquals<PCINT32, PCINT16>(_data1, _data2, _length);
		case 15:
			return __arrayEquals<PCINT32, PCINT32>(_data1, _data2, _length);
	}
	return false;
}

INT32 IAMArray::compare(const IAMArray & _value) const {
	UINT32 const _size1 = __size, _size2 = _value.__size;
	PCVOID const _data1 = __data, _data2 = _value.__data;
	UINT32 const _length1 = _size1 >> 2, _length2 = _size2 >> 2;
	switch (((_size1 & 3) << 2) | (_size2 & 3)) {
		case 0:
			return __arrayCompare<PCINT32, PCINT32>(_data1, _data2, _length1, _length2);
		case 1:
			return __arrayCompare<PCINT32, PCINT8>(_data1, _data2, _length1, _length2);
		case 2:
			return __arrayCompare<PCINT32, PCINT16>(_data1, _data2, _length1, _length2);
		case 3:
			return __arrayCompare<PCINT32, PCINT32>(_data1, _data2, _length1, _length2);
		case 4:
			return __arrayCompare<PCINT8, PCINT32>(_data1, _data2, _length1, _length2);
		case 5:
			return __arrayCompare<PCINT8, PCINT8>(_data1, _data2, _length1, _length2);
		case 6:
			return __arrayCompare<PCINT8, PCINT16>(_data1, _data2, _length1, _length2);
		case 7:
			return __arrayCompare<PCINT8, PCINT32>(_data1, _data2, _length1, _length2);
		case 8:
			return __arrayCompare<PCINT16, PCINT32>(_data1, _data2, _length1, _length2);
		case 9:
			return __arrayCompare<PCINT16, PCINT8>(_data1, _data2, _length1, _length2);
		case 10:
			return __arrayCompare<PCINT16, PCINT16>(_data1, _data2, _length1, _length2);
		case 11:
			return __arrayCompare<PCINT16, PCINT32>(_data1, _data2, _length1, _length2);
		case 12:
			return __arrayCompare<PCINT32, PCINT32>(_data1, _data2, _length1, _length2);
		case 13:
			return __arrayCompare<PCINT32, PCINT8>(_data1, _data2, _length1, _length2);
		case 14:
			return __arrayCompare<PCINT32, PCINT16>(_data1, _data2, _length1, _length2);
		case 15:
			return __arrayCompare<PCINT32, PCINT32>(_data1, _data2, _length1, _length2);
	}
	return 0;
}

IAMArray IAMArray::section(INT32 const _offset, INT32 const _length) const {
	UINT32 _size = __size;
	if (_offset < 0 || _length <= 0 || (UINT32) (_offset + _length) > (_size >> 2)) return IAMArray();
	switch (_size & 3) {
		case 0:
			return IAMArray(((INT32 const *) __data) + _offset, _length, true);
		case 1:
			return IAMArray(((INT8 const *) __data) + _offset, _length);
		case 2:
			return IAMArray(((INT16 const *) __data) + _offset, _length);
		case 3:
			return IAMArray(((INT32 const *) __data) + _offset, _length);
	}
	return IAMArray();
}

IAMArray & IAMArray::operator=(IAMArray const & _source) {
	__arrayDataFree(__data, __size);
	__data = __arrayDataUse(_source.__data, __size = _source.__size);
	return *this;
}

// class IAMEntry

IAMEntry::IAMEntry()
		: __key(), __value() {
}

IAMEntry::IAMEntry(const IAMEntry & _source)
		: __key(_source.__key), __value(_source.__value) {
}

IAMEntry::IAMEntry(IAMArray const & _key, IAMArray const & _value)
		: __key(_key), __value(_value) {
}

IAMArray const IAMEntry::key() const {
	return __key;
}

INT32 IAMEntry::key(INT32 const _index) const {
	return __key.get(_index);
}

INT32 IAMEntry::keyLength() const {
	return __key.length();
}

IAMArray const IAMEntry::value() const {
	return __value;
}

INT32 IAMEntry::value(INT32 const _index) const {
	return __value.get(_index);
}

INT32 IAMEntry::valueLength() const {
	return __value.length();
}

// class IAMList

define_RCObject(IAMListData) {

	public:

	IAMListData()
			: type(0), itemSize(0), itemData(0), itemCount(0) {
	}

	void load(PCINT32 const _array, INT32 const _length) {
		if (!_array || _length < 3) throw IAMException(IAMException::INVALID_LENGTH);

		INT32 _offset = 0;
		UINT32 const _header = _array[_offset];
		_offset++;
		if ((_header & 0xFFFFFFF0) != 0xF00D2000) throw IAMException(IAMException::INVALID_HEADER);

		UINT8 const _itemDataType = (_header >> 2) & 3;
		UINT8 const _itemSizeType = (_header >> 0) & 3;
		if (!_itemDataType) throw IAMException(IAMException::INVALID_HEADER);

		INT32 const _itemCount = _array[_offset];
		_offset++;
		if (_itemCount > 0x3FFFFFFF) throw IAMException(IAMException::INVALID_VALUE);

		PCVOID _itemSize;
		UINT32 _itemValue;
		if (_itemSizeType) {

			_itemSize = _array + _offset;
			_itemValue = __byteAlign((_itemCount + 1) * __byteCount(_itemSizeType));
			_offset += _itemValue;
			if (_length < _offset) throw IAMException(IAMException::INVALID_LENGTH);

			__dataCheck(_itemSizeType, _itemSize, _itemCount);
			_itemValue = __dataGet(_itemSizeType, _itemSize, _itemCount);

		} else {

			_itemValue = _array[_offset];
			_offset++;
			if (_itemValue > 0x3FFFFFFF) throw IAMException(IAMException::INVALID_VALUE);

			_itemSize = (PCVOID) _itemValue;
			_itemValue = _itemCount * _itemValue;

		}

		PCVOID _itemData = _array + _offset;
		_itemValue = __byteAlign(_itemValue * __byteCount(_itemDataType));
		_offset += _itemValue;
		if (_length != _offset) throw IAMException(IAMException::INVALID_LENGTH);

		type = __dataType(_itemDataType, _itemSizeType);
		itemCount = _itemCount;
		itemSize = _itemSize;
		itemData = _itemData;

	}

	/**
	 * Dieses Feld speichert den Kodierungstyp im Format <tt>[28:0][2:ID][2:IL]</tt>.<br>
	 * Die Werte @c 0-2 des Elementdatentyps @c ID stehn für @c PCINT8, @c PCINT16 und @c PCINT32 (siehe @c #__itemSize).<br>
	 * Die Werte @c 0-3 des Elementlängentyps @c IL stehn für @c UINT32, @c PCUINT8, @c PCUINT16 und @c PCUINT32 (siehe @c #__itemData).
	 */
	UINT32 type;

	/**
	 * Dieses Feld speichert die Längen der Elemente. Die Interpretation dieses Feldes wird durch den Elementlängentyp vorgegeben.
	 */
	PCVOID itemSize;

	/**
	 * Dieses Feld speichert die Zahlen der Elemente. Die Interpretation dieses Feldes wird durch den Elementdatentypen vorgegeben.
	 */
	PCVOID itemData;

	/**
	 * Dieses Feld speichert die Anzahl der Elemente.
	 */
	UINT32 itemCount;

};

commit_RCObject(IAMListData)

RCPointer<IAMListData> __emptyListData(new IAMListData());

IAMList::IAMList()
		: __data(__emptyListData) {
}

IAMList::IAMList(PCINT32 const _array, INT32 const _length)
		: __data(new IAMListData()) {
	__data->load(_array, _length);
}

IAMArray IAMList::item(INT32 const _itemIndex) const {
	IAMListData * _data = __data.get();
	if ((UINT32) _itemIndex >= _data->itemCount) return IAMArray();
	return __dataArray(_data->type, _data->itemSize, _data->itemData, _itemIndex);
}

INT32 IAMList::item(INT32 const _itemIndex, INT32 const _index) const {
	IAMListData * _data = __data.get();
	if (_index < 0 || (UINT32) _itemIndex >= _data->itemCount) return 0;
	return __dataValue(_data->type, _data->itemSize, _data->itemData, _itemIndex, _index);
}

INT32 IAMList::itemLength(INT32 const _itemIndex) const {
	IAMListData * _data = __data.get();
	if ((UINT32) _itemIndex >= _data->itemCount) return 0;
	return __dataLength(_data->type & 3, _data->itemSize, _itemIndex);
}

INT32 IAMList::itemCount() const {
	IAMListData * _data = __data.get();
	return _data->itemCount;
}

// class IAMMap

/**
 * Diese Methode gibt den Index des Schlüssels mit statischer Größe zurück, der der gegebenen Zahlenfolge ist. Bei erfolgloser Suche, streuwertbasierter wird @c -1 geliefert.
 * @tparam PCDATA Datentyp zur Interpretation von @c _keyData.
 * @tparam PCRANGE Datentyp zur Interpretation von @c _rangeData.
 * @param _keySize Größe eines Schlüssels (@c UINT32).
 * @param _keyData Speicherbereich mit den Daten der Schlüssel.
 * @param _rangeMask Bitmaske für den Streuwert.
 * @param _rangeData Speicherbereich mit den Längen der Schlüsselbereiche.
 * @param _findData Gesuchte Zahlenfolge.
 * @param _findLength Länge der gesuchten Zahlenfolge.
 * @return Index des Schlüssels oder @c -1.
 */
template<typename PCDATA, typename PCRANGE>
INT32 __find_HS(PCVOID const _keySize, PCVOID const _keyData, UINT32 _rangeMask, PCVOID const _rangeData, PCINT32 const _findData, UINT32 const _findLength) {
	PCDATA const _data = (PCDATA) _keyData;
	UINT32 const _size = (UINT32) _keySize;
	PCRANGE const _range = (PCRANGE) _rangeData;
	if (_size != _findLength) return -1;
	UINT32 const _index = __arrayHash<PCINT32>(_findData, _findLength) & _rangeMask;
	for (INT32 _l = _range[_index], _r = _range[_index + 1]; _l < _r; _l++) {
		UINT32 const _offset = _size * _l;
		if (__arrayEquals<PCDATA, PCINT32>(_data + _offset, _findData, _findLength)) return _l;
	}
	return -1;
}

/**
 * Diese Methode gibt den Index des Schlüssels mit dynamischer Größe zurück, der der gegebenen Zahlenfolge ist. Bei erfolgloser, streuwertbasierter Suche wird @c -1 geliefert.
 * @tparam PCDATA Datentyp zur Interpretation von @c _keyData.
 * @tparam PCSIZE Datentyp zur Interpretation von @c _keySize.
 * @tparam PCRANGE Datentyp zur Interpretation von @c _rangeData.
 * @param _keySize Speicherbereich mit den Längen der Schlüssel.
 * @param _keyData Speicherbereich mit den Daten der Schlüssel.
 * @param _rangeMask Bitmaske für den Streuwert.
 * @param _rangeData Speicherbereich mit den Längen der Schlüsselbereiche.
 * @param _findData Gesuchte Zahlenfolge.
 * @param _findLength Länge der gesuchten Zahlenfolge.
 * @return Index des Schlüssels oder @c -1.
 */
template<typename PCDATA, typename PCSIZE, typename PCRANGE>
INT32 __find_HD(PCVOID const _keySize, PCVOID const _keyData, UINT32 _rangeMask, PCVOID const _rangeData, PCINT32 const _findData, UINT32 const _findLength) {
	PCDATA const _data = (PCDATA) _keyData;
	PCSIZE const _size = (PCSIZE) _keySize;
	PCRANGE const _range = (PCRANGE) _rangeData;
	UINT32 const _index = __arrayHash<PCINT32>(_findData, _findLength) & _rangeMask;
	for (INT32 _l = _range[_index], _r = _range[_index + 1]; _l < _r; _l++) {
		UINT32 const _offset = _size[_l];
		UINT32 const _length = _size[_l + 1] - _offset;
		if (_length == _findLength && __arrayEquals<PCDATA, PCINT32>(_data + _offset, _findData, _findLength)) return _l;
	}
	return -1;
}

/**
 * Diese Methode gibt den Index des Schlüssels mit statischer Größe zurück, der der gegebenen Zahlenfolge ist. Bei erfolgloser Suche, binärer wird @c -1 geliefert.
 * @tparam PCDATA Datentyp zur Interpretation von @c _keyData.
 * @param _keySize Größe eines Schlüssels (@c UINT32).
 * @param _keyData Speicherbereich mit den Daten der Schlüssel.
 * @param _keyCount Anzahl der Schlüssel.
 * @param _findData Gesuchte Zahlenfolge.
 * @param _findLength Länge der gesuchten Zahlenfolge.
 * @return Index des Schlüssels oder @c -1.
 */
template<typename PCDATA>
INT32 __find_BS(PCVOID const _keySize, PCVOID const _keyData, UINT32 const _keyCount, PCINT32 const _findData, UINT32 const _findLength) {
	PCDATA const _data = (PCDATA) _keyData;
	UINT32 const _size = (UINT32) _keySize;
	if (_size != _findLength) return -1;
	for (UINT32 _l = 0, _r = _keyCount; _l < _r;) {
		UINT32 const _c = (_l + _r) >> 1;
		UINT32 const _offset = _size * _c;
		INT32 const _value = __arrayCompare<PCDATA, PCINT32>(_data + _offset, _findData, _size, _size);
		if (_value < 0) _r = _c;
		else if (_value > 0) _l = _c + 1;
		else return _c;
	}
	return -1;
}

/**
 * Diese Methode gibt den Index des Schlüssels mit dynamischer Größe zurück, der der gegebenen Zahlenfolge ist. Bei erfolgloser, binärer Suche wird @c -1 geliefert.
 * @tparam PCDATA Datentyp zur Interpretation von @c _keyData.
 * @tparam PCSIZE Datentyp zur Interpretation von @c _keySize.
 * @param _keySize Speicherbereich mit den Längen der Schlüssel.
 * @param _keyData Speicherbereich mit den Daten der Schlüssel.
 * @param _keyCount Anzahl der Schlüssel.
 * @param _findData Gesuchte Zahlenfolge.
 * @param _findLength Länge der gesuchten Zahlenfolge.
 * @return Index des Schlüssels oder @c -1.
 */
template<typename PCDATA, typename PCSIZE>
INT32 __find_BD(PCVOID const _keySize, PCVOID const _keyData, UINT32 const _keyCount, PCINT32 const _findData, UINT32 const _findLength) {
	PCDATA const _data = (PCDATA) _keyData;
	PCSIZE const _size = (PCSIZE) _keySize;
	for (UINT32 _l = 0, _r = _keyCount; _l < _r;) {
		UINT32 const _c = (_l + _r) >> 1;
		UINT32 const _offset = _size[_c];
		UINT32 const _length = _size[_c + 1] - _offset;
		INT32 const _value = __arrayCompare<PCDATA, PCINT32>(_data + _offset, _findData, _length, _findLength);
		if (_value < 0) _r = _c;
		else if (_value > 0) _l = _c + 1;
		else return _c;
	}
	return -1;
}

// IAMMap

define_RCObject(IAMMapData) {

	public:

	IAMMapData()
			: type(0), keySize(0), keyData(0), valueSize(0), valueData(0), rangeMask(0), rangeSize(0), entryCount(0) {
	}

	void load(PCINT32 const _array, INT32 const _length) {
		if (!_array || _length < 4) throw IAMException(IAMException::INVALID_LENGTH);

		INT32 _offset = 0;
		UINT32 const _header = _array[_offset];
		_offset++;
		if ((_header & 0xFFFFFC00) != 0xF00D1000) throw IAMException(IAMException::INVALID_HEADER);

		UINT8 const _keyDataType = (_header >> 8) & 3;
		UINT8 const _keySizeType = (_header >> 6) & 3;
		UINT8 const _rangeSizeType = (_header >> 4) & 3;
		UINT8 const _valueDataType = (_header >> 2) & 3;
		UINT8 const _valueSizeType = (_header >> 0) & 3;
		if (!_keyDataType || !_valueDataType) throw IAMException(IAMException::INVALID_HEADER);

		UINT32 const _entryCount = _array[_offset];
		_offset++;
		if (_entryCount > 0x3FFFFFFF) throw IAMException(IAMException::INVALID_VALUE);

		UINT32 _rangeMask;
		PCVOID _rangeSize;
		UINT32 _rangeValue;
		if (_rangeSizeType) {

			if (_length <= _offset) throw IAMException(IAMException::INVALID_LENGTH);

			_rangeMask = _array[_offset];
			_offset++;
			if ((_rangeMask < 1) || (_rangeMask > 0x1FFFFFFF) || ((_rangeMask + 1) & _rangeMask)) throw IAMException(IAMException::INVALID_VALUE);

			_rangeSize = _array + _offset;
			_rangeValue = __byteAlign((_rangeMask + 2) * __byteCount(_rangeSizeType));
			_offset += _rangeValue;
			if (_length <= _offset) throw IAMException(IAMException::INVALID_LENGTH);

			__dataCheck(_rangeSizeType, _rangeSize, _rangeMask + 1);
			_rangeValue = __dataGet(_rangeSizeType, _rangeSize, _rangeMask + 1);
			if (_rangeValue != _entryCount) throw new IAMException(IAMException::INVALID_OFFSET);

		} else {

			_rangeMask = 0;
			_rangeSize = 0;

		}

		if (_length <= _offset) throw IAMException(IAMException::INVALID_LENGTH);

		PCVOID _keySize;
		UINT32 _keyValue;
		if (_keySizeType) {

			_keySize = _array + _offset;
			_keyValue = __byteAlign((_entryCount + 1) * __byteCount(_keySizeType));
			_offset += _keyValue;
			if (_length <= _offset) throw IAMException(IAMException::INVALID_LENGTH);

			__dataCheck(_keySizeType, _keySize, _entryCount);
			_keyValue = __dataGet(_keySizeType, _keySize, _entryCount);

		} else {

			_keyValue = _array[_offset];
			_offset++;
			if (_length <= _offset) throw IAMException(IAMException::INVALID_LENGTH);

			_keySize = (PCVOID) _keyValue;
			_keyValue = _entryCount * _keyValue;

		}
		if (_keyValue > 0x3FFFFFFF) throw IAMException(IAMException::INVALID_VALUE);

		PCVOID _keyData = _array + _offset;
		_keyValue = __byteAlign(_keyValue * __byteCount(_keyDataType));
		_offset += _keyValue;
		if (_length < _offset) throw IAMException(IAMException::INVALID_LENGTH);

		PCVOID _valueSize;
		UINT32 _valueValue;
		if (_valueSizeType) {

			_valueSize = _array + _offset;
			_valueValue = __byteAlign((_entryCount + 1) * __byteCount(_valueSizeType));
			_offset += _valueValue;
			if (_length < _offset) throw IAMException(IAMException::INVALID_LENGTH);

			__dataCheck(_valueSizeType, _valueSize, _entryCount);
			_valueValue = __dataGet(_valueSizeType, _valueSize, _entryCount);

		} else {

			_valueValue = _array[_offset];
			_offset++;
			if (_length < _offset) throw IAMException(IAMException::INVALID_LENGTH);

			_valueSize = (PCVOID) _valueValue;
			_valueValue = _entryCount * _valueValue;

		}
		if (_valueValue > 0x3FFFFFFF) throw IAMException(IAMException::INVALID_VALUE);

		PCVOID _valueData = _array + _offset;
		_valueValue = __byteAlign(_valueValue * __byteCount(_valueDataType));
		_offset += _valueValue;
		if (_length != _offset) throw IAMException(IAMException::INVALID_LENGTH);

		type = (__dataType(_keyDataType, _keySizeType) << 6) | (_rangeSizeType << 4) | __dataType(_valueDataType, _valueSizeType);
		keySize = _keySize;
		keyData = _keyData;
		valueSize = _valueSize;
		valueData = _valueData;
		rangeMask = _rangeMask;
		rangeSize = _rangeSize;
		entryCount = _entryCount;

	}

	/**
	 * Dieses Feld speichert den Kodierungstyp im Format <tt>[22:0][2:KD][2:KL][2:RL][2:VD][2:VL]</tt>.<br>
	 * Die Werte @c 0-2 des Schlüsseldatentyps @c KD stehn für @c PCINT8, @c PCINT16 und @c PCINT32 (siehe @c #__keySize).<br>
	 * Die Werte @c 0-3 des Schlüssellängentyps @c KL stehn für @c UINT32, @c PCUINT8 , @c PCUINT16 und @c PCUINT32 (siehe @c #__keyData).<br>
	 * Die Werte @c 0-3 des Bereichslängentyps @c RL stehn für @c void, @c PCUINT8, @c PCUINT16 und @c PCUINT32 (siehe @c #__rangeData).<br>
	 * Die Werte @c 0-2 des Wertdatentyps @c VD stehn für @c PCINT8, @c PCINT16 und @c PCINT32 (siehe @c #__valueSize).<br>
	 * Die Werte @c 0-3 des Wertlängentyps @c VL stehn für @c UINT32, @c PCUINT8 , @c PCUINT16 und @c PCUINT32 (siehe @c #__valueData).
	 */
	UINT32 type;

	/**
	 * Dieses Feld speichert die Anzahl der Zahlen in einem Schlüssel. Die Interpretation dieses Feldes wird durch den Schlüssellängentyp vorgegeben.
	 */
	PCVOID keySize;

	/**
	 * Dieses Feld speichert den Speicherbereich mit den Zahlen der Schlüssel. Die Interpretation dieses Feldes wird durch den Schlüsseldatentyp vorgegeben.
	 */
	PCVOID keyData;

	/**
	 * Dieses Feld speichert die Anzahl der Zahlen in einem Wert. Die Interpretation dieses Feldes wird durch den Wertlängentyp vorgegeben.
	 */
	PCVOID valueSize;

	/**
	 * Dieses Feld speichert den Speicherbereich mit den Zahlen der Werte. Die Interpretation dieses Feldes wird durch den Wertdatentyp vorgegeben.
	 */
	PCVOID valueData;

	/**
	 * Dieses Feld speichert die Bitmaske zur Umrechnung des Streuwerts eines gesuchten Schlüssels in den Index des einzigen Schlüsselbereichs, in dem dieser Schlüssel enthalten sein kann. Die Streuwertsuche wird nur bei Bereichslängentyp @c 0 verwendet.
	 */
	UINT32 rangeMask;

	/**
	 * Dieses Feld speichert die Startpositionen der Schlüsselbereiche. Die Interpretation dieses Feldes wird durch den Bereichslängentyp vorgegeben.
	 */
	PCVOID rangeSize;

	/**
	 * Dieses Feld speichert die Anzahl der Einträge.
	 */
	UINT32 entryCount;

};

commit_RCObject(IAMMapData)

RCPointer<IAMMapData> __emptyMapData(new IAMMapData());

IAMMap::IAMMap()
		: __data(__emptyMapData) {
}

IAMMap::IAMMap(PCINT32 const _array, INT32 const _length)
		: __data(new IAMMapData()) {
	__data->load(_array, _length);
}

IAMArray IAMMap::key(INT32 const _entryIndex) const {
	IAMMapData * _data = __data.get();
	if ((UINT32) _entryIndex >= _data->entryCount) return IAMArray();
	return __dataArray(_data->type >> 6, _data->keySize, _data->keyData, _entryIndex);
}

INT32 IAMMap::key(INT32 const _entryIndex, INT32 const _index) const {
	IAMMapData * _data = __data.get();
	if (_index < 0 || (UINT32) _entryIndex >= _data->entryCount) return 0;
	return __dataValue(_data->type >> 6, _data->keySize, _data->keyData, _entryIndex, _index);
}

INT32 IAMMap::keyLength(INT32 const _entryIndex) const {
	IAMMapData * _data = __data.get();
	if ((UINT32) _entryIndex >= _data->entryCount) return 0;
	return __dataLength((_data->type >> 6) & 3, _data->keySize, _entryIndex);
}

IAMArray IAMMap::value(INT32 const _entryIndex) const {
	IAMMapData * _data = __data.get();
	if ((UINT32) _entryIndex >= _data->entryCount) return IAMArray();
	return __dataArray(_data->type & 15, _data->valueSize, _data->valueData, _entryIndex);
}

INT32 IAMMap::value(INT32 const _entryIndex, INT32 const _index) const {
	IAMMapData * _data = __data.get();
	if (_index < 0 || (UINT32) _entryIndex >= _data->entryCount) return 0;
	return __dataValue(_data->type & 15, _data->valueSize, _data->valueData, _entryIndex, _index);
}

INT32 IAMMap::valueLength(INT32 const _entryIndex) const {
	IAMMapData * _data = __data.get();
	if ((UINT32) _entryIndex >= _data->entryCount) return 0;
	return __dataLength(_data->type & 3, _data->valueSize, _entryIndex);
}

IAMEntry IAMMap::entry(INT32 const _entryIndex) const {
	return IAMEntry(key(_entryIndex), value(_entryIndex));
}

INT32 IAMMap::entryCount() const {
	IAMMapData * _data = __data.get();
	return _data->entryCount;
}

INT32 IAMMap::find(PCINT32 const _key, INT32 const _length) const {
	IAMMapData * _data = __data.get();
	if (!_key || _length < 0) return -1;
	switch (_data->type >> 4) {
		case 0: // D1, S0, R0
			return __find_BS<PCINT8>(_data->keySize, _data->keyData, _data->entryCount, _key, _length);
		case 1: // D1, S0, R1
			return __find_HS<PCINT8, PCUINT8>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 2: // D1, S0, R2
			return __find_HS<PCINT8, PCUINT16>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 3: // D1, S0, R3
			return __find_HS<PCINT8, PCUINT32>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 4: // D1, S1, R0
			return __find_BD<PCINT8, PCUINT8>(_data->keySize, _data->keyData, _data->entryCount, _key, _length);
		case 5: // D1, S1, R1
			return __find_HD<PCINT8, PCUINT8, PCUINT8>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 6: // D1, S1, R2
			return __find_HD<PCINT8, PCUINT8, PCUINT16>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 7: // D1, S1, R3
			return __find_HD<PCINT8, PCUINT8, PCUINT32>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 8: // D1, S2, R0
			return __find_BD<PCINT8, PCUINT16>(_data->keySize, _data->keyData, _data->entryCount, _key, _length);
		case 9: // D1, S2, R1
			return __find_HD<PCINT8, PCUINT16, PCUINT8>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 10: // D1, S2, R2
			return __find_HD<PCINT8, PCUINT16, PCUINT16>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 11: // D1, S2, R3
			return __find_HD<PCINT8, PCUINT16, PCUINT32>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 12: // D1, S3, R0
			return __find_BD<PCINT8, PCUINT32>(_data->keySize, _data->keyData, _data->entryCount, _key, _length);
		case 13: // D1, S3, R1
			return __find_HD<PCINT8, PCUINT32, PCUINT8>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 14: // D1, S3, R2
			return __find_HD<PCINT8, PCUINT32, PCUINT16>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 15: // D1, S3, R3
			return __find_HD<PCINT8, PCUINT32, PCUINT32>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 16: // D2, S0, R0
			return __find_BS<PCINT16>(_data->keySize, _data->keyData, _data->entryCount, _key, _length);
		case 17: // D2, S0, R1
			return __find_HS<PCINT16, PCUINT8>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 18: // D2, S0, R2
			return __find_HS<PCINT16, PCUINT16>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 19: // D2, S0, R3
			return __find_HS<PCINT16, PCUINT32>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 20: // D2, S1, R0
			return __find_BD<PCINT16, PCUINT8>(_data->keySize, _data->keyData, _data->entryCount, _key, _length);
		case 21: // D2, S1, R1
			return __find_HD<PCINT16, PCUINT8, PCUINT8>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 22: // D2, S1, R2
			return __find_HD<PCINT16, PCUINT8, PCUINT16>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 23: // D2, S1, R3
			return __find_HD<PCINT16, PCUINT8, PCUINT32>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 24: // D2, S2, R0
			return __find_BD<PCINT16, PCUINT16>(_data->keySize, _data->keyData, _data->entryCount, _key, _length);
		case 25: // D2, S2, R1
			return __find_HD<PCINT16, PCUINT16, PCUINT8>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 26: // D2, S2, R2
			return __find_HD<PCINT16, PCUINT16, PCUINT16>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 27: // D2, S2, R3
			return __find_HD<PCINT16, PCUINT16, PCUINT32>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 28: // D2, S3, R0
			return __find_BD<PCINT16, PCUINT32>(_data->keySize, _data->keyData, _data->entryCount, _key, _length);
		case 29: // D2, S3, R1
			return __find_HD<PCINT16, PCUINT32, PCUINT8>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 30: // D2, S3, R2
			return __find_HD<PCINT16, PCUINT32, PCUINT16>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 31: // D2, S3, R3
			return __find_HD<PCINT16, PCUINT32, PCUINT32>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 32: // D3, S0, R0
			return __find_BS<PCINT32>(_data->keySize, _data->keyData, _data->entryCount, _key, _length);
		case 33: // D3, S0, R1
			return __find_HS<PCINT32, PCUINT8>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 34: // D3, S0, R2
			return __find_HS<PCINT32, PCUINT16>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 35: // D3, S0, R3
			return __find_HS<PCINT32, PCUINT32>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 36: // D3, S1, R0
			return __find_BD<PCINT32, PCUINT8>(_data->keySize, _data->keyData, _data->entryCount, _key, _length);
		case 37: // D3, S1, R1
			return __find_HD<PCINT32, PCUINT8, PCUINT8>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 38: // D3, S1, R2
			return __find_HD<PCINT32, PCUINT8, PCUINT16>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 39: // D3, S1, R3
			return __find_HD<PCINT32, PCUINT8, PCUINT32>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 40: // D3, S2, R0
			return __find_BD<PCINT32, PCUINT16>(_data->keySize, _data->keyData, _data->entryCount, _key, _length);
		case 41: // D3, S2, R1
			return __find_HD<PCINT32, PCUINT16, PCUINT8>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 42: // D3, S2, R2
			return __find_HD<PCINT32, PCUINT16, PCUINT16>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 43: // D3, S2, R3
			return __find_HD<PCINT32, PCUINT16, PCUINT32>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 44: // D3, S3, R0
			return __find_BD<PCINT32, PCUINT32>(_data->keySize, _data->keyData, _data->entryCount, _key, _length);
		case 45: // D3, S3, R1
			return __find_HD<PCINT32, PCUINT32, PCUINT8>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 46: // D3, S3, R2
			return __find_HD<PCINT32, PCUINT32, PCUINT16>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
		case 47: // D3, S3, R3
			return __find_HD<PCINT32, PCUINT32, PCUINT32>(_data->keySize, _data->keyData, _data->rangeMask, _data->rangeSize, _key, _length);
	}
	return -1;
}

// class IAMIndex

define_RCObject(IAMIndexData) {

	public:

	void load(MMFView const & _file) {
		if (_file.size() & 3) throw IAMException(IAMException::INVALID_LENGTH);
		load((PCINT32) _file.data(), _file.size() >> 2);
		file = _file;
	}

	void load(PCINT32 const _array, INT32 const _length) {
		if (!_array || _length < 5) throw IAMException(IAMException::INVALID_LENGTH);

		INT32 _offset = 0;
		UINT32 const _header = _array[_offset];
		_offset++;
		if (_header != 0xF00DBA5E) throw IAMException(IAMException::INVALID_HEADER);

		UINT32 _mapCount = _array[_offset];
		_offset++;
		if (_mapCount > 0x3FFFFFFF) throw IAMException(IAMException::INVALID_VALUE);

		UINT32 _listCount = _array[_offset];
		_offset++;
		if (_listCount > 0x3FFFFFFF) throw IAMException(IAMException::INVALID_VALUE);

		INT32 const * _mapOffset = _array + _offset;
		_offset += _mapCount + 1;
		if (_length < _offset) throw IAMException(IAMException::INVALID_LENGTH);

		UINT32 _mapDataLength = _mapOffset[_mapCount];
		if (_mapDataLength > 0x3FFFFFFF) throw IAMException(IAMException::INVALID_VALUE);

		INT32 const * _listOffset = _array + _offset;
		_offset += _listCount + 1;
		if (_length < _offset) throw IAMException(IAMException::INVALID_LENGTH);

		UINT32 _listDataLength = _listOffset[_listCount];
		if (_listDataLength > 0x3FFFFFFF) throw IAMException(IAMException::INVALID_VALUE);

		PCINT32 _mapData = _array + _offset;
		_offset += _mapDataLength;
		if (_length < _offset) throw IAMException(IAMException::INVALID_LENGTH);

		PCINT32 _listData = _array + _offset;
		_offset += _listDataLength;
		if (_length != _offset) throw IAMException(IAMException::INVALID_LENGTH);

		maps.resize(_mapCount);
		for (UINT32 i = 0; i < _mapCount; i++) {
			PCINT32 const _data2 = _mapData + _mapOffset[i];
			INT32 const _length2 = _mapOffset[i + 1] - _mapOffset[i];
			maps[i] = IAMMap(_data2, _length2);
		}

		lists.resize(_listCount);
		for (UINT32 i = 0; i < _listCount; i++) {
			PCINT32 const _data2 = _listData + _listOffset[i];
			INT32 const _length2 = _listOffset[i + 1] - _listOffset[i];
			lists[i] = IAMList(_data2, _length2);
		}

	}

	MMFView file;

	vector<IAMMap> maps;

	vector<IAMList> lists;

};

commit_RCObject(IAMIndexData)

RCPointer<IAMIndexData> __emptyIndexData(new IAMIndexData());

IAMIndex::IAMIndex()
		: __data(__emptyIndexData) {
}

IAMIndex::IAMIndex(MMFView const & _file)
		: __data(new IAMIndexData()) {
	__data->load(_file);
}

IAMIndex::IAMIndex(PCINT32 const _array, INT32 const _length)
		: __data(new IAMIndexData()) {
	__data->load(_array, _length);
}

IAMMap IAMIndex::map(INT32 const _index) const {
	IAMIndexData * _data = __data.get();
	if ((UINT32) _index >= _data->maps.size()) return IAMMap();
	return _data->maps[_index];
}

INT32 IAMIndex::mapCount() const {
	IAMIndexData * _data = __data.get();
	return (INT32) _data->maps.size();
}

IAMList IAMIndex::list(INT32 const _index) const {
	IAMIndexData * _data = __data.get();
	if ((UINT32) _index >= _data->lists.size()) return IAMList();
	return _data->lists[_index];
}

INT32 IAMIndex::listCount() const {
	IAMIndexData * _data = __data.get();
	return (INT32) _data->lists.size();
}

// IAMException

IAMException::IAMException(INT8 const code)
		: __code(code) {
}

INT8 IAMException::code() const {
	return __code;
}

}

}

}
