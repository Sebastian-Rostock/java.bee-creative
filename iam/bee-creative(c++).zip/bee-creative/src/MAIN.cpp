//============================================================================
// Name        : BEX.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "MAIN.hpp"



int main() {


	 {

		signed int data[3] = { 123, 456, 789 };

		IAMArray arr(data, 3, true);
		IAMArray arr2(data, 3);

		{
			IAMArray a2;

			a2 = arr;

			a2 = arr2;

			cout << a2.length() << '\n';
			cout << a2.get(0) << '\n';
			cout << a2.get(1) << '\n';
			cout << a2.get(2) << '\n';
		}
		cout.flush();
		//	exit(0);
	}
	if(0){

		ptime t1(microsec_clock::local_time());
		string name = "_a.iam";
		PCVOID x = &name;
		PCVOID y = (PCUINT32) x + 1;
		cout << x << " " << y << '\n';
		MMFView view(name.c_str());
		ptime t2(microsec_clock::local_time());
		//	IAMIndex index(view);
		ptime t3(microsec_clock::local_time());
		cout << "1..2: " << (t2 - t1) << '\n';
		cout << "2..3: " << (t3 - t2) << '\n';
		cout << "view.size: " << view.size() << '\n';
//		cout << "index.mapCount: " << index.mapCount() << '\n';
//		cout << "index.listCount: " << index.listCount() << '\n';
	}

//	{
//
//		MMF_DataPtr _file(new MMFData());
//
//		_file->open((PCCHAR)"_2.bex");
//
//		cout << "data: " << (int) _file->data() << " size: " << _file->size() << "\n";
//
//		ptime t1(microsec_clock::local_time());
//
//		BEX_DataPtr data(new BEX_Data(_file));
//
//		BEX_NodePtr docu = data->document();
//
//		ptime t2(microsec_clock::local_time());
//
//		cout << "1..2: " << (t2 - t1) << '\n';
//
//		for (int i = 0; i < 5; i++) {
//			ptime A(microsec_clock::local_time());
//			pn(docu, 0);
//			ptime B(microsec_clock::local_time());
//
//			cout << "2..3: " << (B - A) << '\n';
//		}
//
//		// alte IMPL war 2.15
//		// neu 0.58
//	}

	return 0;
}
