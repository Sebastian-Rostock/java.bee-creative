#ifndef BEE_CREATIVE_IAM_HPP

#define BEE_CREATIVE_IAM_HPP

#include <vector>
#include "bee_creative_mmf.hpp"

namespace bee {

namespace creative {

/**
 * Dieser Namensraum realisiert eine nurlesbare Implementation des IAM.<p>
 * Das <i>IAM – Integer Array Model</i> beschreibt einerseits ein abstraktes Datenmodell aus Listen und Abbildungen sowie andererseits ein binäres und optimiertes Datenformat zur Auslagerung dieser Listen und Abbildungen in eine Datei. Ziel des Datenformats ist es, entsprechende Dateien per File-Mapping in den Arbeitsspeicher abzubilden und darauf sehr effiziente Lese- und Such-operationen ausführen zu können. Die Modifikation der Daten ist nicht vorgesehen.<p>
 * Die Klassen @c IAMArray, @c IAMEntry, @c IAMList, @c IAMMap und @c IAMIndex stellen alle eine Sich auf gegebene, extern verwaltete Speicherbereiche dar. Ihr Verhalten ist unbestimmt, wenn einer der Speicherbereiche freigegeben wird.
 * Die Klasse @c IAMIndex erlaubt das halten des Speicherbereichs, wenn dieser als @c MMFView gegeben ist.
 * @author [cc-by] 2014 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]
 */
namespace iam {

using mmf::MMFView;

/**
 * Ein @c IAMArray ist eine abstrakte Zahlenfolge, welche in einer Liste (@c IAMList) für die Elemente sowie einer Abbildung (@c IAMMap) für die Schlüssel und Werte der Einträge (@c IAMEntry) verwendet wird.<p>
 */
class IAMArray {

	public:

	/**
	 * Dieser Kontrukteur erstellt eine leere Zahlenfolge.
	 */
	IAMArray();

	/**
	 * Dieser Kontrukteur erstellt eine Kopie der gegebenen Zahlenfolge.
	 * @param source Qualldaten.
	 */
	IAMArray(IAMArray const & source);

	/**
	 * Dieser Kontrukteur erstellt eine Zahlenfolge als Sicht auf den gegebenen Speicherbereich.
	 * @param data Zeiger auf den Speicherbereich mit @c INT8 Zahlen.
	 * @param length Anzahl der Zahlen.
	 */
	IAMArray(PCINT8 const data, INT32 const length);

	/**
	 * Dieser Kontrukteur erstellt eine Zahlenfolge als Sicht auf den gegebenen Speicherbereich bzw. als Kopie des gegebenen Speicherbereichs.
	 * @param data Zeiger auf den Speicherbereich mit @c INT8 Zahlen.
	 * @param length Anzahl der Zahlen.
	 * @param copy @c true, wenn eine Kopie des gegebenen Speicherbereichs erzeugt werde soll.
	 */
	IAMArray(PCINT8 const data, INT32 const length, bool const copy);

	/**
	 * Dieser Kontrukteur erstellt eine Zahlenfolge als Sicht auf den gegebenen Speicherbereich.
	 * @param data Zeiger auf den Speicherbereich mit @c INT16 Zahlen.
	 * @param length Anzahl der Zahlen.
	 */
	IAMArray(PCINT16 const data, INT32 const length);

	/**
	 * Dieser Kontrukteur erstellt eine Zahlenfolge als Sicht auf den gegebenen Speicherbereich bzw. als Kopie des gegebenen Speicherbereichs.
	 * @param data Zeiger auf den Speicherbereich mit @c INT16 Zahlen.
	 * @param length Anzahl der Zahlen.
	 * @param copy @c true, wenn eine Kopie des gegebenen Speicherbereichs erzeugt werde soll.
	 */
	IAMArray(PCINT16 const data, INT32 const length, bool const copy);

	/**
	 * Dieser Kontrukteur erstellt eine Zahlenfolge als Sicht auf den gegebenen Speicherbereich.
	 * @param data Zeiger auf den Speicherbereich mit @c INT32 Zahlen.
	 * @param length Anzahl der Zahlen.
	 */
	IAMArray(PCINT32 const data, INT32 const length);

	/**
	 * Dieser Kontrukteur erstellt eine Zahlenfolge als Sicht auf den gegebenen Speicherbereich bzw. als Kopie des gegebenen Speicherbereichs.
	 * @param data Zeiger auf den Speicherbereich mit @c INT32 Zahlen.
	 * @param length Anzahl der Zahlen.
	 * @param copy @c true, wenn eine Kopie des gegebenen Speicherbereichs erzeugt werde soll.
	 */
	IAMArray(PCINT32 const data, INT32 const length, bool const copy);

	/**
	 * Dieser Destrukteur gibt den ggf. reservierten Speicher wieder frei.
	 */
	~IAMArray();

	/**
	 * Diese Methode gibt die @c index -te Zahl zurück. Bei einem ungültigen Index wird @c 0 geliefert.
	 * @param index Index.
	 * @return @c index -te Zahl oder @c 0.
	 */
	INT32 get(INT32 const index) const;

	/**
	 * Diese Methode gibt die Länge der Zahlenfolge zurück (@c 0-1073741823).
	 * @return Anzahl der Zahlen.
	 */
	INT32 length() const;

	/**
	 * Diese Methode gibt den Speicherbereich mit den Zahlen zurück.
	 * @return Speicherbereich.
	 */
	PCVOID data() const;

	/**
	 * Diese Methode gibt die Größe jeder Zahl in Byte zurück.
	 * @return Größe einer Zahl (@c 1, @c 2, @c 4).
	 */
	UINT8 type() const;

	/**
	 * Diese Methode gibt den Streuwert zurück.
	 * @return Streuwert.
	 */
	INT32 hash() const;

	/**
	 * Diese Methode gibt nur dann @c true zurück, wenn diese Zahlenfolge gleich der gegebenen Zahlenfolge ist.
	 * @param value Zahlenfolge.
	 * @return @c true, wenn diese Zahlenfolge gleich der gegebenen ist.
	 */
	bool equals(IAMArray const & value) const;

	/**
	 * Diese Methode gibt eine Zahl kleiner, gleich oder größer als @c 0 zurück, wenn die Ordnung dieser Zahlenfolge lexikografisch kleiner, gleich bzw. größer als die der gegebenen Zahlenfolge ist.
	 * @param value Zahlenfolge.
	 * @return Vergleichswert der Ordnungen.
	 */
	INT32 compare(IAMArray const & value) const;

	/**
	 * Diese Methode gibt einen Abschnitt dieser Zahlenfolge ab der gegebenen Position und mit der gegebene Länge zurück. Wenn der Abschnitt außerhalb der Zahlenfolge liegt oder die Länge kleiner als @c 1 ist, wird eine leere Zahlenfolge geliefert.
	 * @param offset Position, ab welcher der Abschnitt beginnt.
	 * @param length Anzahl der Zahlen im Abschnitt.
	 * @return Abschnitt.
	 */
	IAMArray section(INT32 const offset, INT32 const length) const;

	IAMArray & operator=(IAMArray const & value);

	private:

	/**
	 * Dieses Feld speichert die Kombination aus Länge @c L und Datentyp @c D im Format <tt>[30:L][2:D]</tt>.<br>
	 * Die Datentypen @c 0-3 stehn für @c COPY-PCINT32, @c VIEW-PCINT8, @c VIEW-PCINT16 und @c VIEW-PCINT32.
	 */
	UINT32 __size;

	/**
	 * Dieses Feld verweist auf den Speicherbereich mit den Zahlen.
	 */
	PCVOID __data;

};

/**
 * Ein @c IAMEntry ist ein abstrakter Eintrag einer Abbildung (@c IAMMap) und besteht aus einem Schlüssel und einem Wert, welche selbst Zahlenfolgen (@c IAMArray) sind.
 */
class IAMEntry {

	public:

	/**
	 * Dieser Kontrukteur erstellt einen leeren Eintrag.
	 */
	IAMEntry();

	/**
	 * Dieser Kontrukteur erstellt eine Kopie des gegebenen Eintrags.
	 * @param source Quelldaten.
	 */
	IAMEntry(IAMEntry const & source);

	/**
	 * Dieser Kontrukteur erstellt einen Eintrag mit den gegebenen Eigenschaften.
	 * @param key Schlüssel.
	 * @param value Wert.
	 */
	IAMEntry(IAMArray const & key, IAMArray const & value);

	/**
	 * Diese Methode gibt den Schlüssel als Zahlenfolge zurück.
	 * @return Schlüssel.
	 */
	IAMArray const key() const;

	/**
	 * Diese Methode gibt die @c index -te Zahl des Schlüssels zurück. Bei einem ungültigen @c index wird @c 0 geliefert.
	 * @param index Index.
	 * @return @c index -te Zahl des Schlüssels.
	 */
	INT32 key(INT32 const index) const;

	/**
	 * Diese Methode gibt die Länge der Zahlenfolge des Schlüssels zurück.
	 * @return Länge des Schlüssels.
	 */
	INT32 keyLength() const;

	/**
	 * Diese Methode gibt den Wert als Zahlenfolge zurück.
	 * @return Wert.
	 */
	IAMArray const value() const;

	/**
	 * Diese Methode gibt die @c index -te Zahl des Werts zurück. Bei einem ungültigen @c index wird @c 0 geliefert.
	 * @param index Index.
	 * @return @c index -te Zahl des Werts.
	 */
	INT32 value(INT32 const index) const;

	/**
	 * Diese Methode gibt die Länge der Zahlenfolge des Werts zurück.
	 * @return Länge des Werts.
	 */
	INT32 valueLength() const;

	private:

	/**
	 * Dieses Feld speichert den Schlüssel.
	 */
	IAMArray const __key;

	/**
	 * Dieses Feld speichert den Wert.
	 */
	IAMArray const __value;

};

class_RCObject(IAMListData)

/**
 * Diese Klasse implementiert eine geordnete Liste von Elementen, welche selbst Zahlenfolgen (@c IAMArray) sind.
 */
class IAMList {

	public:

	/**
	 * Dieser Kontrukteur erstellt eine leere Liste.
	 */
	IAMList();

	/**
	 * Dieser Kontrukteur erstellt eine Liste als Sicht auf den gegebenen Speicherbereich.
	 * @param array Zeiger auf den Speicherbereich mit @c INT32 Zahlen.
	 * @param length Anzahl der Zahlen.
	 * @throws IAMException Wenn beim dekodieren des Speicherbereichs ein Fehler erkannt wird.
	 */
	IAMList(PCINT32 const array, INT32 const length);

	/**
	 * Diese Methode gibt das @c itemIndex -te Element als Zahlenfolge zurück. Bei einem ungültigen @c itemIndex wird eine leere Zahlenfolge geliefert.
	 * @param itemIndex Index des Elements.
	 * @return @c itemIndex -tes Element.
	 */
	IAMArray item(INT32 const itemIndex) const;

	/**
	 * Diese Methode gibt die @c index -te Zahl des @c itemIndex -ten Elements zurück. Bei einem ungültigen @c index bzw. @c itemIndex wird @c 0 geliefert.
	 * @param itemIndex Index des Elements.
	 * @param index Index der Zahl.
	 * @return @c index -te Zahl des @c itemIndex -ten Elements.
	 */
	INT32 item(INT32 const itemIndex, INT32 const index) const;

	/**
	 * Diese Methode gibt die Länge der Zahlenfolge des @c itemIndex -ten Elements zurück. Bei einem ungültigen @c itemIndex wird @c 0 geliefert.
	 * @param itemIndex Index des Elements.
	 * @return Länge des @c itemIndex -ten Elements.
	 */
	INT32 itemLength(INT32 const itemIndex) const;

	/**
	 * Diese Methode gibt die Anzahl der Elemente zurück (@c 0-1073741823).
	 * @return Anzahl der Elemente.
	 */
	INT32 itemCount() const;

	private:

	RCPointer<IAMListData> __data;

};

class_RCObject(IAMMapData)

/**
 * Diese Klasse implementiert eine Abbildung von Schlüsseln auf Werte, welche beide selbst Zahlenfolgen (@c IAMArray) sind.
 */
class IAMMap {

	public:

	/**
	 * Dieser Konstruktor erstellt eine leere Abbildung.
	 */
	IAMMap();

	/**
	 * Dieser Kontrukteur erstellt eine Abbildung als Sicht auf den gegebenen Speicherbereich.
	 * @param data Zeiger auf den Speicherbereich mit @c INT32 Zahlen.
	 * @param length Anzahl der Zahlen.
	 * @throws IAMException Wenn beim dekodieren des Speicherbereichs ein Fehler erkannt wird.
	 */
	IAMMap(PCINT32 const data, INT32 const length);

	/**
	 * Diese Methode gibt den Schlüssel des @c entryIndex -ten Eintrags als Zahlenfolge zurück. Bei einem ungültigen @c entryIndex wird eine leere Zahlenfolge geliefert.
	 * @param entryIndex Index des Elements.
	 * @return Schlüssel des @c entryIndex -ten Eintrags.
	 */
	IAMArray key(INT32 const entryIndex) const;

	/**
	 * Diese Methode gibt die @c index -te Zahl des Schlüssels des @c entryIndex -ten Eintrags zurück. Bei einem ungültigen @c index bzw. @c entryIndex wird @c 0 geliefert.
	 * @param entryIndex Index des Elements.
	 * @param index Index der Zahl.
	 * @return @c index -te Zahl des Schlüssels des @c entryIndex -ten Eintrags.
	 */
	INT32 key(INT32 const entryIndex, INT32 const index) const;

	/**
	 * Diese Methode gibt die Länge der Zahlenfolge des Schlüssels des @c entryIndex -ten Eintrags zurück. Bei einem ungültigen @c entryIndex wird @c 0 geliefert.
	 * @param entryIndex Index des Elements.
	 * @return Länge des Schlüssels des @c entryIndex -ten Eintrags.
	 */
	INT32 keyLength(INT32 const entryIndex) const;

	/**
	 * Diese Methode gibt den Wert des @c entryIndex -ten Eintrags als Zahlenfolge zurück. Bei einem ungültigen @c entryIndex wird eine leere Zahlenfolge geliefert.
	 * @param entryIndex Index des Elements.
	 * @return Wert des @c entryIndex -ten Eintrags.
	 */
	IAMArray value(INT32 const entryIndex) const;

	/**
	 * Diese Methode gibt die @c index -te Zahl des Werts des @c entryIndex -ten Eintrags zurück. Bei einem ungültigen @c index bzw. @c entryIndex wird @c 0 geliefert.
	 * @param entryIndex Index des Elements.
	 * @param index Index der Zahl.
	 * @return @c index -te Zahl des Werts des @c entryIndex -ten Eintrags.
	 */
	INT32 value(INT32 const entryIndex, INT32 const index) const;

	/**
	 * Diese Methode gibt die Länge der Zahlenfolge des Werts des @c entryIndex -ten Eintrags zurück. Bei einem ungültigen @c entryIndex wird @c 0 geliefert.
	 * @param entryIndex Index des Elements.
	 * @return Länge des Werts des @c entryIndex -ten Eintrags.
	 */
	INT32 valueLength(INT32 const entryIndex) const;

	/**
	 * Diese Methode gibt den @c entryIndex -ten Eintrag zurück. Bei einem ungültigen @c entryIndex wird ein leerer Eintrag geliefert.
	 * @param entryIndex Index des Elements.
	 * @return @c entryIndex -ter Eintrag.
	 */
	IAMEntry entry(INT32 const entryIndex) const;

	/**
	 * Diese Methode gibt die Anzahl der Einträge zurück (@c 0-1073741823).
	 * @return Anzahl der Einträge.
	 */
	INT32 entryCount() const;

	/**
	 * Diese Methode gibt den Index des Eintrags zurück, dessen Schlüssel gleich dem gegebenen Schlüssel ist. Bei erfolgloser Suche wird @c -1 geliefert.
	 * @param key Zahlenfolge des gesuchten Schlüssels.
	 * @param length Länge des gesuchten Schlüssels.
	 * @return Index des gefundenen Eintrags.
	 */
	INT32 find(PCINT32 const key, INT32 const length) const;

	private:

	RCPointer<IAMMapData> __data;

};

class_RCObject(IAMIndexData)

/**
 * Diese Klasse implementiert eine Zusammenstellung beliebig vieler Listen (@c IAMList) und Abbildungen (@c IAMMap).
 *
 * @author [cc-by] 2014 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]
 */
class IAMIndex {

	public:

	/**
	 * Dieser Konstruktor initialisiert die Zusammenstellung als leer.
	 */
	IAMIndex();

	/**
	 * Dieser Kontrukteur initialisiert die Zusammenstellung mit den Daten der gegebenen Datei.
	 * @param file Datei.
	 * @throws IAMException Wenn beim dekodieren der Datei ein Fehler erkannt wird.
	 */
	IAMIndex(MMFView const & file);

	/**
	 * Dieser Kontrukteur initialisiert die Zusammenstellung als Sicht auf den gegebenen Speicherbereich.
	 * @param array Zeiger auf den Speicherbereich mit @c INT32 Zahlen.
	 * @param length Anzahl der Zahlen.
	 * @throws IAMException Wenn beim dekodieren des Speicherbereichs ein Fehler erkannt wird.
	 */
	IAMIndex(PCINT32 const array, INT32 const length);

	/**
	 * Diese Methode gibt die @c index-te Abbildung zurück. Bei einem ungültigen @c index wird eine leere Abbildung geliefert.
	 * @param index Index.
	 * @return 	@c index-te Abbildung.
	 */
	IAMMap map(INT32 const index) const;

	/**
	 * Diese Methode gibt die Anzahl der Abbildungen zurück (@c 0-1073741823).
	 * @return Anzahl der Abbildungen.
	 */
	INT32 mapCount() const;

	/**
	 * Diese Methode gibt die @c index te Liste zurück. Bei einem ungültigen @c index wird eine leere Liste geliefert.
	 * @param index Index.
	 * @return 	@c index -te Liste.
	 */
	IAMList list(INT32 const index) const;

	/**
	 * Diese Methode gibt die Anzahl der Listen zurück (@c 0-1073741823).
	 * @return Anzahl der Listen.
	 */
	INT32 listCount() const;

	private:

	RCPointer<IAMIndexData> __data;

};

/**
 * Diese Klasse definiert die Exception, die bei Dekodierungsfehlern ausgelöst wird.
 */
class IAMException {

	public:

	/**
	 * Dieses Feld identifiziert die Ausnahme bei der Erkennugn einer ungültigen Anzahl bzw. eines ungültigen Werts.
	 */
	static INT8 const INVALID_VALUE = 1;

	/**
	 * Dieses Feld identifiziert die Ausnahme bei der Erkennugn ungültiger Startpositionen, d.h. negativer Längen.
	 */
	static INT8 const INVALID_OFFSET = 2;

	/**
	 * Dieses Feld identifiziert die Ausnahme bei der Erkennugn eines ungenügend großen Speicherbereichs.
	 */
	static INT8 const INVALID_LENGTH = 4;

	/**
	 * Dieses Feld identifiziert die Ausnahme bei der Erkennugn einer unbekannten Datentypkennung.
	 */
	static INT8 const INVALID_HEADER = 8;

	/**
	 * Dieser Konstrukteur initialisiert die Fehlerursache.
	 * @param code Fehlerursache.
	 */
	IAMException(INT8 const code);

	/**
	 * Diese Methode gibt die Fehlerursache zurück.
	 * @return Fehlerursache.
	 */
	INT8 code() const;

	private:

	/**
	 * Dieses Feld speichert die Fehlerursache.
	 */
	INT8 const __code;

};

}

}

}

#endif
