var NAVTREE =
[
  [ "bee-creative", "index.html", [
    [ "Namensbereiche", null, [
      [ "Liste aller Namensbereiche", "namespaces.html", "namespaces" ],
      [ "Elemente eines Namensbereiches", "namespacemembers.html", [
        [ "Alle", "namespacemembers.html", null ],
        [ "Funktionen", "namespacemembers_func.html", null ]
      ] ]
    ] ],
    [ "Klassen", null, [
      [ "Auflistung der Klassen", "annotated.html", "annotated" ],
      [ "Klassen-Verzeichnis", "classes.html", null ],
      [ "Klassen-Elemente", "functions.html", [
        [ "Alle", "functions.html", null ],
        [ "Funktionen", "functions_func.html", null ],
        [ "Variablen", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Dateien", null, [
      [ "Auflistung der Dateien", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html"
];

var SYNCONMSG = 'Klicken um Panelsynchronisation auszuschalten';
var SYNCOFFMSG = 'Klicken um Panelsynchronisation einzuschalten';