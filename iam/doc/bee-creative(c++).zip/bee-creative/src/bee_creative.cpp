/* [cc-by] 2013 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#include "bee_creative.hpp"

namespace bee {

namespace creative {

}

}
