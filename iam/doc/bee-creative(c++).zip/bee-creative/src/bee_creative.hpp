/* [cc-by] 2013 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#ifndef BEE_CREATIVE_HPP
#define BEE_CREATIVE_HPP

#include <inttypes.h>
#include <boost/smart_ptr/intrusive_ptr.hpp>
#include <boost/smart_ptr/intrusive_ref_counter.hpp>

namespace bee {

/**
 * Dieser Namensraum definiert die grundlegenden Datentypen für primitive Zahlenwerte und Zahlenfolgen sowie für referenzgezählte Objekte.<br>
 * Referenzgezählte Objekte werden als Nachfahren von @c RCObject definiert und über @c RCPointer referenziert.
 * Diese beiden Schablonenklassen stehen für @c boost::intrusive_ptr bzw. @c boost::sp_adl_block::intrusive_ref_counter.
 * Der Schablonenparameter beider Klassen ist die Klasse des referenzgezählten Objekts.<br>
 * Wenn die Datenstruktur des referenzgezählten Objekts nich in der @c hpp Datei sichtbar sein soll, muss dort das Makro @c class_RCObject mit dem Klannennamen des referenzgezählten Objects eingefügt werden.
 * Die Definition der Klasse muss anschließend in der @c cpp Datei mit den Maktros @c define_RCObject und @c commit_RCObject erfolgen.
 *
 * <h5>Variante 1: Datenstruktur des referenzgezählten Objekts in @c hpp </h5>
 * <pre>
 * // hpp
 * class MyDataObject: public RCObject<MyDataObject> {
 * 	...
 * };
 *
 * class MyUserObject {
 * 	...
 * 	RCPointer<MyDataObject> data;
 * };
 * </pre>
 *
 *
 * <h5>Variante 2: Datenstruktur des referenzgezählten Objekts in @c hpp </h5>
 * <pre>
 * // hpp
 * define_RCObject(MyDataObject) {
 * 	...
 * };
 *
 * class MyUserObject {
 * 	...
 * 	RCPointer<MyDataObject> data;
 * };
 * </pre>
 *
 * <h5>Variante 3: Datenstruktur des referenzgezählten Objekts in @c cpp </h5>
 * <pre>
 * // hpp
 * class_RCObject(MyDataObject)
 *
 * class MyUserObject {
 * 	...
 * 	RCPointer<MyDataObject> data;
 * };
 *
 * // cpp
 * define_RCObject(MyDataObject) {
 * 	...
 * };
 *
 * commit_RCObject(MyDataObject)
 * </pre>
 *
 * @author [cc-by] 2013 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]
 */
namespace creative {

typedef void * PVOID;
typedef void const * PCVOID;

typedef char * PCHAR;
typedef char const * PCCHAR;

typedef int8_t INT8;
typedef int16_t INT16;
typedef int32_t INT32;
typedef int64_t INT64;

typedef uint8_t UINT8;
typedef uint16_t UINT16;
typedef uint32_t UINT32;
typedef uint64_t UINT64;

typedef INT8 * PINT8;
typedef INT16 * PINT16;
typedef INT32 * PINT32;
typedef INT64 * PINT64;

typedef INT8 const * PCINT8;
typedef INT16 const * PCINT16;
typedef INT32 const * PCINT32;
typedef INT64 const * PCINT64;

typedef UINT8 * PUINT8;
typedef UINT16 * PUINT16;
typedef UINT32 * PUINT32;
typedef UINT64 * PUINT64;

typedef UINT8 const * PCUINT8;
typedef UINT16 const * PCUINT16;
typedef UINT32 const * PCUINT32;
typedef UINT64 const * PCUINT64;


#define RCCount \
\
boost::detail::atomic_count

/**
 * @def RCObject
 * @brief Dieses Makro definiert ein referenzgezähltes Objekt, welches seinen Referenzzähler selbst besitzt.
 * @tparam GDATA Klasse des referenzgezählten Objekts, d.h. Klasse, die von dieser erbt.
 */
#define RCObject \
\
boost::sp_adl_block::intrusive_ref_counter

/**
 * @def RCPointer
 * @brief Dieses Makro definiert einen Verweis auf ein referenzgezähltes Objekt.
 * @tparam GDATA Klasse des referenzgezählten Objekts.
 */
#define RCPointer \
\
boost::intrusive_ptr

/**
 * @def class_RCObject
 * @brief Dieses Makro muss zur Vorwärtsdeklaration eines referenzgezählten Objekts genutzt werden.
 * @param GDATA Klasse des referenzgezählten Objekts.
 */
#define class_RCObject(GDATA) \
\
class GDATA; \
void intrusive_ptr_add_ref(GDATA * data); \
void intrusive_ptr_release(GDATA * data);

/**
 * @def define_RCObject
 * @brief Dieses Makro muss zur Definition eines referenzgezählten Objekts genutzt werden.
 * @param GDATA Klasse des referenzgezählten Objekts.
 */
#define define_RCObject(GDATA) \
\
class GDATA: public RCObject<GDATA>

/**
 * @def commit_RCObject
 * @brief Dieses Makro muss zum Abschluss der Definition eines referenzgezählten Objekts genutzt werden.
 * @param GDATA Klasse des referenzgezählten Objekts.
 */
#define commit_RCObject(GDATA) \
\
inline void intrusive_ptr_add_ref(GDATA * data) { \
	boost::sp_adl_block::intrusive_ptr_add_ref(data);\
} \
\
inline void intrusive_ptr_release(GDATA * data) { \
	boost::sp_adl_block::intrusive_ptr_release(data);\
}

}

}

#endif
