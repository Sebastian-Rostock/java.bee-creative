/* [cc-by] 2013 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/] */

#ifndef BEE_CREATIVE_MMF_HPP

#define BEE_CREATIVE_MMF_HPP

#include <wchar.h>
#include <windows.h>
#include "bee_creative.hpp"

namespace bee {

namespace creative {

/**
 * Dieser Namensraum definiert Klassen und Methoden zu Bereitstellung der Daten einer Datei als <i>memory-mapped-file</i> sowie zur Interpretation von Speicherbereichen in als Zahlen in <i>big-endian</i> und <i>little-endian</i> Kodierung.
 * @author [cc-by] 2014 Sebastian Rostock [http://creativecommons.org/licenses/by/3.0/de/]
 */
namespace mmf {

/**
 * Diese Methode interpretiert die gegebene Anzahl an Byte des gegebenen Arrays als @c UINT32 in <i>big-endian</i> Bytereigenfolge.
 * @param _array Array.
 * @param _length Anzahl der Byte (@c 0-4).
 * @return Zahlenwert.
 */
inline UINT32 readBE(PCUINT8 const _array, UINT8 const _length);

/**
 * Diese Methode interpretiert die gegebene Anzahl an Byte des gegebenen Arrays als @c UINT32 in <i>little-endian</i> Bytereigenfolge.
 * @param _array Array.
 * @param _length Anzahl der Byte (@c 0-4).
 * @return Zahlenwert.
 */
inline UINT32 readLE(PCUINT8 const _array, UINT8 const _length);

/**
 * Diese Methode gibt die Anzahl der Byte zurück, um den gegebenen positiven Zahlenwert abzubilden.
 * @param _value positiver Zahlenwert.
 * @return Anzahl der Byte (@c 0-4).
 */
inline UINT8 lengthOf(UINT32 const _value);

class_RCObject(MMFViewData)

/**
 * Diese Klasse implementiert ein Objekt zur Bereitstellung der Daten einer Datei als <i>memory-mapped-file</i>.
 */
class MMFView {

	public:

	/**
	 * Dieser Konstruktor erzeugt einen leeren @c MMFView.
	 */
	MMFView();

	/**
	 * Dieser Konstruktor öffnet die Datei mit dem gegebenen Namen im gegebenen Modus.
	 * Wenn das Öffnen erfolglos ist, sind Adresse sowie Größe der Nutzdaten 0.
	 * @param _filename Dateiname.
	 * @param _readonly @c true, wenn die Datei nur zum Lesen geöffnet werden soll.
	 */
	MMFView(PCCHAR _filename, bool _readonly = true);

	/**
	 * Diese Methode gibt die Adresse des ersten Bytes der Nutzdaten zurück.
	 * @return Adresse der Nutzdaten oder 0.
	 */
	PVOID data() const;

	/**
	 * Diese Methode gibt die Größe der Nutzdaten zurück.
	 * @return Größe der Nutzdaten oder 0.
	 */
	UINT32 size() const;

	/**
	 * Diese Methode gibt eine Sicht auf einen Abschnitt der Nutzdaten zurück.
	 * Wenn der Abschnitt außerhalb der Nutzdaten liegt, wird ein leerer Abschnitt geliefert.
	 * @param _offset Anzahl der Byte vor dem Abschnitt.
	 * @param _length Anzahl der Byte im Abschnitt.
	 * @return Abschnitt als @c MMFView.
	 */
	MMFView part(UINT32 _offset, UINT32 _length) const;

	private:

	RCPointer<MMFViewData> __data;

};

}

}

}
#endif
